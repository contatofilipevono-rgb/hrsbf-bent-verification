import H12CloudChart2Data092

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound22802 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22803 : List Nat := [2,4,8,16,0,64,128,256,137,1024,2048,1345,128,1296,1,463,1345,262144,1024,0,1344,4194304,16,463,8,65,4456449,1296,1296,1073741824,1025,4194440,256,461,1344,137]

theorem envBound22803 : H12AffineFastState.Bounded env22803 := by
  intro p hp
  have h : env22803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22802_22803 : H12AffineEnvironment.transform 15 463 env22802 = env22803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 463 env22802 == env22803) = true)

theorem identity22803 : scanCanonicalize (H12AffineFastState.compose env22803 (packedSelected [6,11,18] rootPS)) = affineNative (2^(9+1) ^^^ 204) := by decide +kernel

theorem selectedBound22803 : packedSelected [6,11,18] rootPS < 2^1333 := by decide +kernel

def env22804 : List Nat := [2,4,8,16,0,64,128,256,137,204,2048,397,128,476,1,463,397,262144,204,0,396,4194304,16,463,8,65,4456449,476,476,1073741824,205,4194440,256,461,396,137]

theorem envBound22804 : H12AffineFastState.Bounded env22804 := by
  intro p hp
  have h : env22804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22803_22804 : H12AffineEnvironment.transform 9 204 env22803 = env22804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 204 env22803 == env22804) = true)

def env22805 : List Nat := [2,4,8,16,0,64,128,256,137,204,2048,397,128,476,1,463,397,262144,204,0,396,0,16,463,8,65,262145,476,476,1073741824,205,136,256,461,396,137]

theorem envBound22805 : H12AffineFastState.Bounded env22805 := by
  intro p hp
  have h : env22805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22804_22805 : H12AffineEnvironment.transform 21 0 env22804 = env22805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 0 env22804 == env22805) = true)

theorem identity22805 : scanCanonicalize (H12AffineFastState.compose env22805 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22805 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22806 : List Nat := [2,4,8,16,0,64,9,256,0,69,2048,260,9,341,1,326,260,262144,69,0,261,0,16,326,8,65,262145,341,341,1073741824,68,1,256,324,261,0]

theorem envBound22806 : H12AffineFastState.Bounded env22806 := by
  intro p hp
  have h : env22806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22805_22806 : H12AffineEnvironment.transform 6 9 env22805 = env22806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22805 == env22806) = true)

theorem identity22806 : scanCanonicalize (H12AffineFastState.compose env22806 (packedSelected [13] rootPS)) = affineNative (2^(29+1) ^^^ 2325) := by decide +kernel

theorem selectedBound22806 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env22807 : List Nat := [2,4,8,16,0,64,9,256,0,69,2048,260,9,341,1,326,260,262144,69,0,261,0,16,326,8,65,262145,341,341,2325,68,1,256,324,261,0]

theorem envBound22807 : H12AffineFastState.Bounded env22807 := by
  intro p hp
  have h : env22807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22806_22807 : H12AffineEnvironment.transform 29 2325 env22806 = env22807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2325 env22806 == env22807) = true)

theorem identity22807 : scanCanonicalize (H12AffineFastState.compose env22807 (packedSelected [7,8] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound22807 : packedSelected [7,8] rootPS < 2^1333 := by decide +kernel

def env22808 : List Nat := [2,4,8,16,0,1,9,256,0,4,2048,260,9,276,1,263,260,262144,4,0,261,0,16,263,8,0,262145,276,276,2325,5,1,256,261,261,0]

theorem envBound22808 : H12AffineFastState.Bounded env22808 := by
  intro p hp
  have h : env22808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22807_22808 : H12AffineEnvironment.transform 5 1 env22807 = env22808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env22807 == env22808) = true)

theorem identity22808 : scanCanonicalize (H12AffineFastState.compose env22808 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound22808 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env22809 : List Nat := [2,4,8,16,0,1,9,5,0,4,2048,1,9,17,1,2,1,262144,4,0,0,0,16,2,8,0,262145,17,17,2064,5,1,5,0,0,0]

theorem envBound22809 : H12AffineFastState.Bounded env22809 := by
  intro p hp
  have h : env22809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22808_22809 : H12AffineEnvironment.transform 7 5 env22808 = env22809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env22808 == env22809) = true)

theorem identity22809 : scanCanonicalize (H12AffineFastState.compose env22809 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22809 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env22810 : List Nat := [2,4,8,0,0,1,9,5,0,4,2048,1,9,1,1,2,1,262144,4,0,0,0,0,2,8,0,262145,1,1,2048,5,1,5,0,0,0]

theorem envBound22810 : H12AffineFastState.Bounded env22810 := by
  intro p hp
  have h : env22810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22809_22810 : H12AffineEnvironment.transform 3 0 env22809 = env22810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22809 == env22810) = true)

theorem identity22810 : scanCanonicalize (H12AffineFastState.compose env22810 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound22810 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22811 : List Nat := [2,4,8,0,0,1,9,5,0,4,0,1,9,1,1,2,1,262144,4,0,0,0,0,2,8,0,262145,1,1,0,5,1,5,0,0,0]

theorem envBound22811 : H12AffineFastState.Bounded env22811 := by
  intro p hp
  have h : env22811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22810_22811 : H12AffineEnvironment.transform 10 0 env22810 = env22811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env22810 == env22811) = true)

theorem identity22811 : scanCanonicalize (H12AffineFastState.compose env22811 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 1) := by decide +kernel

theorem selectedBound22811 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22812 : List Nat := [2,4,8,0,0,1,9,5,0,4,0,1,9,1,1,2,1,1,4,0,0,0,0,2,8,0,0,1,1,0,5,1,5,0,0,0]

theorem envBound22812 : H12AffineFastState.Bounded env22812 := by
  intro p hp
  have h : env22812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22811_22812 : H12AffineEnvironment.transform 17 1 env22811 = env22812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env22811 == env22812) = true)

def env22813 : List Nat := [2,4,8,16,0,64,128,256,137,204,2048,397,128,476,1,463,397,262144,204,0,396,1,16,463,8,65,262144,476,476,1073741824,205,137,256,461,396,137]

theorem envBound22813 : H12AffineFastState.Bounded env22813 := by
  intro p hp
  have h : env22813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22804_22813 : H12AffineEnvironment.transform 21 1 env22804 = env22813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1 env22804 == env22813) = true)

theorem identity22813 : scanCanonicalize (H12AffineFastState.compose env22813 (packedSelected [12,23,32,38] rootPS)) = affineNative (2^(29+1) ^^^ 2048) := by decide +kernel

theorem selectedBound22813 : packedSelected [12,23,32,38] rootPS < 2^1333 := by decide +kernel

def env22814 : List Nat := [2,4,8,16,0,64,128,256,137,204,2048,397,128,476,1,463,397,262144,204,0,396,1,16,463,8,65,262144,476,476,2048,205,137,256,461,396,137]

theorem envBound22814 : H12AffineFastState.Bounded env22814 := by
  intro p hp
  have h : env22814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22813_22814 : H12AffineEnvironment.transform 29 2048 env22813 = env22814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2048 env22813 == env22814) = true)

theorem identity22814 : scanCanonicalize (H12AffineFastState.compose env22814 (packedSelected [0,7] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound22814 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22815 : List Nat := [2,4,8,16,0,64,128,256,137,204,2048,397,128,476,1,463,397,2185,204,0,396,1,16,463,8,65,2185,476,476,2048,205,137,256,461,396,137]

theorem envBound22815 : H12AffineFastState.Bounded env22815 := by
  intro p hp
  have h : env22815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22814_22815 : H12AffineEnvironment.transform 17 2185 env22814 = env22815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env22814 == env22815) = true)

theorem identity22815 : scanCanonicalize (H12AffineFastState.compose env22815 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22815 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env22816 : List Nat := [2,4,8,16,0,64,128,4,137,204,2048,137,128,216,1,203,137,2185,204,0,136,1,16,203,8,65,2185,216,216,2048,205,137,4,201,136,137]

theorem envBound22816 : H12AffineFastState.Bounded env22816 := by
  intro p hp
  have h : env22816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22815_22816 : H12AffineEnvironment.transform 7 4 env22815 = env22816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22815 == env22816) = true)

theorem identity22816 : scanCanonicalize (H12AffineFastState.compose env22816 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound22816 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22817 : List Nat := [2,4,8,16,0,64,128,4,137,204,0,137,128,216,1,203,137,137,204,0,136,1,16,203,8,65,137,216,216,0,205,137,4,201,136,137]

theorem envBound22817 : H12AffineFastState.Bounded env22817 := by
  intro p hp
  have h : env22817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22816_22817 : H12AffineEnvironment.transform 10 0 env22816 = env22817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env22816 == env22817) = true)

def env22818 : List Nat := [2,4,8,0,0,64,128,4,137,204,0,137,128,200,1,203,137,137,204,0,136,1,0,203,8,65,137,200,200,0,205,137,4,201,136,137]

theorem envBound22818 : H12AffineFastState.Bounded env22818 := by
  intro p hp
  have h : env22818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22817_22818 : H12AffineEnvironment.transform 3 0 env22817 = env22818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22817 == env22818) = true)

def env22819 : List Nat := [2,4,8,1,0,64,128,4,137,204,0,137,128,201,1,203,137,137,204,0,136,1,1,203,8,65,137,201,201,0,205,137,4,201,136,137]

theorem envBound22819 : H12AffineFastState.Bounded env22819 := by
  intro p hp
  have h : env22819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22817_22819 : H12AffineEnvironment.transform 3 1 env22817 = env22819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22817 == env22819) = true)

theorem identity22819 : scanCanonicalize (H12AffineFastState.compose env22819 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22819 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22820 : List Nat := [2,4,8,1,0,64,9,4,0,69,0,0,9,64,1,66,0,0,69,0,1,1,1,66,8,65,0,64,64,0,68,0,4,64,1,0]

theorem envBound22820 : H12AffineFastState.Bounded env22820 := by
  intro p hp
  have h : env22820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22819_22820 : H12AffineEnvironment.transform 6 9 env22819 = env22820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22819 == env22820) = true)

def env22821 : List Nat := [2,4,8,16,1,64,128,256,137,1024,2048,1345,128,1296,1,65536,1345,262144,1024,0,1344,4194304,16,65536,8,65,4456449,1296,1296,1073741824,1025,4194440,256,65539,1344,137]

theorem envBound22821 : H12AffineFastState.Bounded env22821 := by
  intro p hp
  have h : env22821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22801_22821 : H12AffineEnvironment.transform 4 1 env22801 = env22821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22801 == env22821) = true)

theorem identity22821 : scanCanonicalize (H12AffineFastState.compose env22821 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 327) := by decide +kernel

theorem selectedBound22821 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22822 : List Nat := [2,4,8,16,1,64,128,256,137,1024,2048,1345,128,1296,1,327,1345,262144,1024,0,1344,4194304,16,327,8,65,4456449,1296,1296,1073741824,1025,4194440,256,324,1344,137]

theorem envBound22822 : H12AffineFastState.Bounded env22822 := by
  intro p hp
  have h : env22822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22821_22822 : H12AffineEnvironment.transform 15 327 env22821 = env22822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 327 env22821 == env22822) = true)

theorem identity22822 : scanCanonicalize (H12AffineFastState.compose env22822 (packedSelected [6,11,18] rootPS)) = affineNative (2^(29+1) ^^^ 3141) := by decide +kernel

theorem selectedBound22822 : packedSelected [6,11,18] rootPS < 2^1333 := by decide +kernel

def env22823 : List Nat := [2,4,8,16,1,64,128,256,137,1024,2048,1345,128,1296,1,327,1345,262144,1024,0,1344,4194304,16,327,8,65,4456449,1296,1296,3141,1025,4194440,256,324,1344,137]

theorem envBound22823 : H12AffineFastState.Bounded env22823 := by
  intro p hp
  have h : env22823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22822_22823 : H12AffineEnvironment.transform 29 3141 env22822 = env22823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 3141 env22822 == env22823) = true)

def env22824 : List Nat := [2,4,8,16,1,64,128,256,137,1024,2048,1345,128,1296,1,327,1345,262144,1024,0,1344,0,16,327,8,65,262145,1296,1296,3141,1025,136,256,324,1344,137]

theorem envBound22824 : H12AffineFastState.Bounded env22824 := by
  intro p hp
  have h : env22824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22823_22824 : H12AffineEnvironment.transform 21 0 env22823 = env22824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 0 env22823 == env22824) = true)

theorem identity22824 : scanCanonicalize (H12AffineFastState.compose env22824 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 204) := by decide +kernel

theorem selectedBound22824 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22825 : List Nat := [2,4,8,16,1,64,128,256,137,204,2048,397,128,476,1,327,397,262144,204,0,396,0,16,327,8,65,262145,476,476,2185,205,136,256,324,396,137]

theorem envBound22825 : H12AffineFastState.Bounded env22825 := by
  intro p hp
  have h : env22825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22824_22825 : H12AffineEnvironment.transform 9 204 env22824 = env22825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 204 env22824 == env22825) = true)

theorem identity22825 : scanCanonicalize (H12AffineFastState.compose env22825 (packedSelected [0,7,8,23] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound22825 : packedSelected [0,7,8,23] rootPS < 2^1333 := by decide +kernel

def env22826 : List Nat := [2,4,8,16,1,64,128,84,137,204,2048,217,128,136,1,19,217,262144,204,0,216,0,16,19,8,65,262145,136,136,2185,205,136,84,16,216,137]

theorem envBound22826 : H12AffineFastState.Bounded env22826 := by
  intro p hp
  have h : env22826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22825_22826 : H12AffineEnvironment.transform 7 84 env22825 = env22826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env22825 == env22826) = true)

theorem identity22826 : scanCanonicalize (H12AffineFastState.compose env22826 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound22826 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env22827 : List Nat := [2,4,8,16,1,64,88,84,81,20,2048,1,88,80,1,19,1,262144,20,0,0,0,16,19,8,65,262145,80,80,2129,21,80,84,16,0,81]

theorem envBound22827 : H12AffineFastState.Bounded env22827 := by
  intro p hp
  have h : env22827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22826_22827 : H12AffineEnvironment.transform 6 88 env22826 = env22827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env22826 == env22827) = true)

theorem identity22827 : scanCanonicalize (H12AffineFastState.compose env22827 (packedSelected [0,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22827 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env22828 : List Nat := [2,4,8,16,1,16,8,4,1,20,2048,1,8,0,1,19,1,262144,20,0,0,0,16,19,8,17,262145,0,0,2049,21,0,4,16,0,1]

theorem envBound22828 : H12AffineFastState.Bounded env22828 := by
  intro p hp
  have h : env22828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22827_22828 : H12AffineEnvironment.transform 5 16 env22827 = env22828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22827 == env22828) = true)

def env22829 : List Nat := [2,4,8,16,1,64,128,256,137,1024,2048,1345,128,1296,1,327,1345,262144,1024,0,1344,1,16,327,8,65,262144,1296,1296,3141,1025,137,256,324,1344,137]

theorem envBound22829 : H12AffineFastState.Bounded env22829 := by
  intro p hp
  have h : env22829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22823_22829 : H12AffineEnvironment.transform 21 1 env22823 = env22829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1 env22823 == env22829) = true)

theorem identity22829 : scanCanonicalize (H12AffineFastState.compose env22829 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound22829 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22830 : List Nat := [2,4,8,16,1,64,128,256,137,69,2048,260,128,341,1,327,260,262144,69,0,261,1,16,327,8,65,262144,341,341,2048,68,137,256,324,261,137]

theorem envBound22830 : H12AffineFastState.Bounded env22830 := by
  intro p hp
  have h : env22830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22829_22830 : H12AffineEnvironment.transform 9 69 env22829 = env22830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env22829 == env22830) = true)

theorem identity22830 : scanCanonicalize (H12AffineFastState.compose env22830 (packedSelected [0,7] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound22830 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22831 : List Nat := [2,4,8,16,1,64,128,256,137,69,2048,260,128,341,1,327,260,2184,69,0,261,1,16,327,8,65,2184,341,341,2048,68,137,256,324,261,137]

theorem envBound22831 : H12AffineFastState.Bounded env22831 := by
  intro p hp
  have h : env22831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22830_22831 : H12AffineEnvironment.transform 17 2184 env22830 = env22831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env22830 == env22831) = true)

theorem identity22831 : scanCanonicalize (H12AffineFastState.compose env22831 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22831 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env22832 : List Nat := [2,4,8,16,1,64,128,4,137,69,2048,0,128,81,1,67,0,2184,69,0,1,1,16,67,8,65,2184,81,81,2048,68,137,4,64,1,137]

theorem envBound22832 : H12AffineFastState.Bounded env22832 := by
  intro p hp
  have h : env22832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22831_22832 : H12AffineEnvironment.transform 7 4 env22831 = env22832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22831 == env22832) = true)

theorem identity22832 : scanCanonicalize (H12AffineFastState.compose env22832 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound22832 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22833 : List Nat := [2,4,8,16,1,64,128,4,137,69,1,0,128,81,1,67,0,137,69,0,1,1,16,67,8,65,137,81,81,1,68,137,4,64,1,137]

theorem envBound22833 : H12AffineFastState.Bounded env22833 := by
  intro p hp
  have h : env22833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22832_22833 : H12AffineEnvironment.transform 10 1 env22832 = env22833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env22832 == env22833) = true)

def env22834 : List Nat := [2,4,8,16,1,16,128,4,137,21,1,0,128,1,1,19,0,137,21,0,1,1,16,19,8,17,137,1,1,1,20,137,4,16,1,137]

theorem envBound22834 : H12AffineFastState.Bounded env22834 := by
  intro p hp
  have h : env22834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22833_22834 : H12AffineEnvironment.transform 5 16 env22833 = env22834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22833 == env22834) = true)

theorem identity22834 : scanCanonicalize (H12AffineFastState.compose env22834 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound22834 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22835 : List Nat := [2,4,8,16,1,16,24,4,17,21,1,0,24,1,1,19,0,17,21,0,1,1,16,19,8,17,17,1,1,1,20,17,4,16,1,17]

theorem envBound22835 : H12AffineFastState.Bounded env22835 := by
  intro p hp
  have h : env22835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22834_22835 : H12AffineEnvironment.transform 6 24 env22834 = env22835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env22834 == env22835) = true)

theorem identity22835 : scanCanonicalize (H12AffineFastState.compose env22835 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22835 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22836 : List Nat := [2,4,8,1,1,1,9,4,0,4,1,0,9,1,1,2,0,0,4,0,1,1,1,2,8,0,0,1,1,1,5,0,4,1,1,0]

theorem envBound22836 : H12AffineFastState.Bounded env22836 := by
  intro p hp
  have h : env22836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22835_22836 : H12AffineEnvironment.transform 3 1 env22835 = env22836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22835 == env22836) = true)

def leafEnv22836 : List Nat := [2,4,8,1,1,1,9,4,0,4,1,0,9,1,1,2,0,0,4,0,1,1,1,2,4,8,1,0,0,1,1,1,5,0,4,1,5,2,1,0,0,1,1]

def active22836 : List Nat := [0,1,2]

def tree22836 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22836 : H12WitnessSearch.Good tree22836 := H12GlobalWitnessIndex.good

theorem leafIdentity22836 : H12AffineFastState.composeSystem env22836 rootObs = leafEnv22836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22836 rootObs == leafEnv22836) = true)

theorem terminalChecked22836 : H12PackedTerminal.terminalCheckFast leafEnv22836 active22836 tree22836 = true := by decide +kernel

def env22837 : List Nat := [2,4,8,16,1,17,128,4,137,20,1,0,128,0,1,18,0,137,20,0,1,1,16,18,8,16,137,0,0,1,21,137,4,17,1,137]

theorem envBound22837 : H12AffineFastState.Bounded env22837 := by
  intro p hp
  have h : env22837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22833_22837 : H12AffineEnvironment.transform 5 17 env22833 = env22837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22833 == env22837) = true)

theorem identity22837 : scanCanonicalize (H12AffineFastState.compose env22837 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22837 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22838 : List Nat := [2,4,8,1,1,0,128,4,137,5,1,0,128,0,1,3,0,137,5,0,1,1,1,3,8,1,137,0,0,1,4,137,4,0,1,137]

theorem envBound22838 : H12AffineFastState.Bounded env22838 := by
  intro p hp
  have h : env22838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22837_22838 : H12AffineEnvironment.transform 3 1 env22837 = env22838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22837 == env22838) = true)

def env22839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,128,1296,649,65536,1345,262144,1024,648,1344,4194304,16,65537,8,65,4457096,1296,1296,1073741824,1672,4194440,256,65571,1344,512]

theorem envBound22839 : H12AffineFastState.Bounded env22839 := by
  intro p hp
  have h : env22839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22799_22839 : H12AffineEnvironment.transform 14 649 env22799 = env22839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 649 env22799 == env22839) = true)

theorem identity22839 : scanCanonicalize (H12AffineFastState.compose env22839 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22839 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env22840 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,1093,128,1044,649,65536,1093,262144,1024,648,1092,4194304,16,65537,8,65,4457096,1044,1044,1073741824,1672,4194440,4,65571,1092,512]

theorem envBound22840 : H12AffineFastState.Bounded env22840 := by
  intro p hp
  have h : env22840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22839_22840 : H12AffineEnvironment.transform 7 4 env22839 = env22840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22839 == env22840) = true)

def env22841 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,1093,128,1044,649,65536,1093,262144,1024,648,1092,512,16,65537,8,65,262280,1044,1044,1073741824,1672,648,4,65571,1092,512]

theorem envBound22841 : H12AffineFastState.Bounded env22841 := by
  intro p hp
  have h : env22841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22840_22841 : H12AffineEnvironment.transform 21 512 env22840 = env22841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 512 env22840 == env22841) = true)

theorem identity22841 : scanCanonicalize (H12AffineFastState.compose env22841 (packedSelected [6] rootPS)) = affineNative (2^(29+1) ^^^ 3108) := by decide +kernel

theorem selectedBound22841 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22842 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,1093,128,1044,649,65536,1093,262144,1024,648,1092,512,16,65537,8,65,262280,1044,1044,3108,1672,648,4,65571,1092,512]

theorem envBound22842 : H12AffineFastState.Bounded env22842 := by
  intro p hp
  have h : env22842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22841_22842 : H12AffineEnvironment.transform 29 3108 env22841 = env22842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 3108 env22841 == env22842) = true)

def env22843 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1045,128,1044,649,65536,1045,262144,1024,648,1044,512,16,65537,8,17,262280,1044,1044,3108,1672,648,4,65571,1044,512]

theorem envBound22843 : H12AffineFastState.Bounded env22843 := by
  intro p hp
  have h : env22843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22842_22843 : H12AffineEnvironment.transform 5 16 env22842 = env22843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22842 == env22843) = true)

theorem identity22843 : scanCanonicalize (H12AffineFastState.compose env22843 (packedSelected [2,12,13,15,17,23,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 562) := by decide +kernel

theorem selectedBound22843 : packedSelected [2,12,13,15,17,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env22844 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1045,128,1044,649,562,1045,262144,1024,648,1044,512,16,563,8,17,262280,1044,1044,3108,1672,648,4,529,1044,512]

theorem envBound22844 : H12AffineFastState.Bounded env22844 := by
  intro p hp
  have h : env22844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22843_22844 : H12AffineEnvironment.transform 15 562 env22843 = env22844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 562 env22843 == env22844) = true)

def env22845 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1045,128,1044,649,562,1045,2200,1024,648,1044,512,16,563,8,17,2064,1044,1044,3108,1672,648,4,529,1044,512]

theorem envBound22845 : H12AffineFastState.Bounded env22845 := by
  intro p hp
  have h : env22845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22844_22845 : H12AffineEnvironment.transform 17 2200 env22844 = env22845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2200 env22844 == env22845) = true)

theorem identity22845 : scanCanonicalize (H12AffineFastState.compose env22845 (packedSelected [3] rootPS)) = affineNative (2^(9+1) ^^^ 532) := by decide +kernel

theorem selectedBound22845 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22846 : List Nat := [2,4,8,16,32,16,128,4,512,532,2048,513,128,512,649,562,513,2200,532,648,512,512,16,563,8,17,2064,512,512,2608,156,648,4,529,512,512]

theorem envBound22846 : H12AffineFastState.Bounded env22846 := by
  intro p hp
  have h : env22846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22845_22846 : H12AffineEnvironment.transform 9 532 env22845 = env22846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 532 env22845 == env22846) = true)

theorem identity22846 : scanCanonicalize (H12AffineFastState.compose env22846 (packedSelected [0,1,2,4,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound22846 : packedSelected [0,1,2,4,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env22847 : List Nat := [2,4,8,16,32,16,128,4,512,532,560,513,128,512,649,562,513,680,532,648,512,512,16,563,8,17,544,512,512,0,156,648,4,529,512,512]

theorem envBound22847 : H12AffineFastState.Bounded env22847 := by
  intro p hp
  have h : env22847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22846_22847 : H12AffineEnvironment.transform 10 560 env22846 = env22847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env22846 == env22847) = true)

theorem identity22847 : scanCanonicalize (H12AffineFastState.compose env22847 (packedSelected [0,5,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22847 : packedSelected [0,5,7,9] rootPS < 2^1333 := by decide +kernel

def env22848 : List Nat := [2,4,8,0,32,0,128,4,512,516,544,513,128,512,649,546,513,680,516,648,512,512,0,547,8,1,544,512,512,0,140,648,4,513,512,512]

theorem envBound22848 : H12AffineFastState.Bounded env22848 := by
  intro p hp
  have h : env22848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22847_22848 : H12AffineEnvironment.transform 3 0 env22847 = env22848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22847 == env22848) = true)

def env22849 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1045,128,1044,649,562,1045,2201,1024,648,1044,512,16,563,8,17,2065,1044,1044,3108,1672,648,4,529,1044,512]

theorem envBound22849 : H12AffineFastState.Bounded env22849 := by
  intro p hp
  have h : env22849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22844_22849 : H12AffineEnvironment.transform 17 2201 env22844 = env22849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2201 env22844 == env22849) = true)

theorem identity22849 : scanCanonicalize (H12AffineFastState.compose env22849 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound22849 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22850 : List Nat := [2,4,8,16,32,16,128,4,0,1024,2048,1045,128,1044,137,50,1045,2201,1024,136,1044,0,16,51,8,17,2065,1044,1044,3108,1160,136,4,17,1044,0]

theorem envBound22850 : H12AffineFastState.Bounded env22850 := by
  intro p hp
  have h : env22850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22849_22850 : H12AffineEnvironment.transform 8 0 env22849 = env22850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env22849 == env22850) = true)

theorem identity22850 : scanCanonicalize (H12AffineFastState.compose env22850 (packedSelected [1,2,5,7,12] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound22850 : packedSelected [1,2,5,7,12] rootPS < 2^1333 := by decide +kernel

def env22851 : List Nat := [2,4,8,16,32,16,24,4,0,1024,2048,1045,24,1044,17,50,1045,2049,1024,16,1044,0,16,51,8,17,2065,1044,1044,3108,1040,16,4,17,1044,0]

theorem envBound22851 : H12AffineFastState.Bounded env22851 := by
  intro p hp
  have h : env22851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22850_22851 : H12AffineEnvironment.transform 6 24 env22850 = env22851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env22850 == env22851) = true)

theorem identity22851 : scanCanonicalize (H12AffineFastState.compose env22851 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22851 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22852 : List Nat := [2,4,8,1,32,1,9,4,0,1024,2048,1028,9,1029,0,35,1028,2049,1024,1,1029,0,1,34,8,0,2048,1029,1029,3108,1025,1,4,0,1029,0]

theorem envBound22852 : H12AffineFastState.Bounded env22852 := by
  intro p hp
  have h : env22852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22851_22852 : H12AffineEnvironment.transform 3 1 env22851 = env22852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22851 == env22852) = true)

theorem identity22852 : scanCanonicalize (H12AffineFastState.compose env22852 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound22852 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22853 : List Nat := [2,4,8,1,32,1,9,4,0,1024,33,1028,9,1029,0,35,1028,32,1024,1,1029,0,1,34,8,0,33,1029,1029,1029,1025,1,4,0,1029,0]

theorem envBound22853 : H12AffineFastState.Bounded env22853 := by
  intro p hp
  have h : env22853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22852_22853 : H12AffineEnvironment.transform 10 33 env22852 = env22853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env22852 == env22853) = true)

def env22854 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,1044,128,1044,649,65536,1044,262144,1024,648,1045,512,16,65537,8,16,262280,1044,1044,3108,1672,648,4,65571,1045,512]

theorem envBound22854 : H12AffineFastState.Bounded env22854 := by
  intro p hp
  have h : env22854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22842_22854 : H12AffineEnvironment.transform 5 17 env22842 = env22854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22842 == env22854) = true)

theorem identity22854 : scanCanonicalize (H12AffineFastState.compose env22854 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 172) := by decide +kernel

theorem selectedBound22854 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env22855 : List Nat := [2,4,8,16,32,17,128,4,512,172,2048,184,128,184,649,65536,184,262144,172,648,185,512,16,65537,8,16,262280,184,184,2184,548,648,4,65571,185,512]

theorem envBound22855 : H12AffineFastState.Bounded env22855 := by
  intro p hp
  have h : env22855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22854_22855 : H12AffineEnvironment.transform 9 172 env22854 = env22855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env22854 == env22855) = true)

theorem identity22855 : scanCanonicalize (H12AffineFastState.compose env22855 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22855 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env22856 : List Nat := [2,4,8,16,32,17,8,4,512,36,2048,48,8,48,513,65536,48,262144,36,512,49,512,16,65537,8,16,262144,48,48,2048,548,512,4,65571,49,512]

theorem envBound22856 : H12AffineFastState.Bounded env22856 := by
  intro p hp
  have h : env22856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22855_22856 : H12AffineEnvironment.transform 6 8 env22855 = env22856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22855 == env22856) = true)

theorem identity22856 : scanCanonicalize (H12AffineFastState.compose env22856 (packedSelected [0,7] rootPS)) = affineNative (2^(17+1) ^^^ 2593) := by decide +kernel

theorem selectedBound22856 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22857 : List Nat := [2,4,8,16,32,17,8,4,512,36,2048,48,8,48,513,65536,48,2593,36,512,49,512,16,65537,8,16,2593,48,48,2048,548,512,4,65571,49,512]

theorem envBound22857 : H12AffineFastState.Bounded env22857 := by
  intro p hp
  have h : env22857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22856_22857 : H12AffineEnvironment.transform 17 2593 env22856 = env22857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2593 env22856 == env22857) = true)

theorem identity22857 : scanCanonicalize (H12AffineFastState.compose env22857 (packedSelected [4,9] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound22857 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env22858 : List Nat := [2,4,8,16,32,17,8,4,1,36,2048,48,8,48,0,65536,48,2080,36,1,49,1,16,65537,8,16,2080,48,48,2048,37,1,4,65571,49,1]

theorem envBound22858 : H12AffineFastState.Bounded env22858 := by
  intro p hp
  have h : env22858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22857_22858 : H12AffineEnvironment.transform 8 1 env22857 = env22858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env22857 == env22858) = true)

theorem identity22858 : scanCanonicalize (H12AffineFastState.compose env22858 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound22858 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22859 : List Nat := [2,4,8,16,32,17,8,4,1,36,33,48,8,48,0,65536,48,1,36,1,49,1,16,65537,8,16,1,48,48,33,37,1,4,65571,49,1]

theorem envBound22859 : H12AffineFastState.Bounded env22859 := by
  intro p hp
  have h : env22859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22858_22859 : H12AffineEnvironment.transform 10 33 env22858 = env22859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env22858 == env22859) = true)

theorem identity22859 : scanCanonicalize (H12AffineFastState.compose env22859 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 19) := by decide +kernel

theorem selectedBound22859 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22860 : List Nat := [2,4,8,16,32,17,8,4,1,36,33,48,8,48,0,19,48,1,36,1,49,1,16,18,8,16,1,48,48,33,37,1,4,48,49,1]

theorem envBound22860 : H12AffineFastState.Bounded env22860 := by
  intro p hp
  have h : env22860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22859_22860 : H12AffineEnvironment.transform 15 19 env22859 = env22860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19 env22859 == env22860) = true)

theorem identity22860 : scanCanonicalize (H12AffineFastState.compose env22860 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound22860 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22861 : List Nat := [2,4,8,16,16,17,8,4,1,20,17,0,8,0,0,19,0,1,20,1,1,1,16,18,8,16,1,0,0,17,21,1,4,0,1,1]

theorem envBound22861 : H12AffineFastState.Bounded env22861 := by
  intro p hp
  have h : env22861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22860_22861 : H12AffineEnvironment.transform 4 16 env22860 = env22861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env22860 == env22861) = true)

def env22862 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,1093,128,1044,649,65536,1093,262144,1024,648,1092,513,16,65537,8,65,262281,1044,1044,1073741824,1672,649,4,65571,1092,512]

theorem envBound22862 : H12AffineFastState.Bounded env22862 := by
  intro p hp
  have h : env22862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22840_22862 : H12AffineEnvironment.transform 21 513 env22840 = env22862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 513 env22840 == env22862) = true)

theorem identity22862 : scanCanonicalize (H12AffineFastState.compose env22862 (packedSelected [6] rootPS)) = affineNative (2^(29+1) ^^^ 3245) := by decide +kernel

theorem selectedBound22862 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22863 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,1093,128,1044,649,65536,1093,262144,1024,648,1092,513,16,65537,8,65,262281,1044,1044,3245,1672,649,4,65571,1092,512]

theorem envBound22863 : H12AffineFastState.Bounded env22863 := by
  intro p hp
  have h : env22863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22862_22863 : H12AffineEnvironment.transform 29 3245 env22862 = env22863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 3245 env22862 == env22863) = true)

def env22864 : List Nat := [2,4,8,16,0,64,128,4,512,1024,2048,1093,128,1044,649,65536,1093,262144,1024,648,1092,513,16,65537,8,65,262281,1044,1044,3213,1672,649,4,65539,1092,512]

theorem envBound22864 : H12AffineFastState.Bounded env22864 := by
  intro p hp
  have h : env22864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22863_22864 : H12AffineEnvironment.transform 4 0 env22863 = env22864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22863 == env22864) = true)

theorem identity22864 : scanCanonicalize (H12AffineFastState.compose env22864 (packedSelected [5,11,15,18,41] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound22864 : packedSelected [5,11,15,18,41] rootPS < 2^1333 := by decide +kernel

def env22865 : List Nat := [2,4,8,16,0,64,128,4,512,4,2048,65,128,16,649,65536,65,262144,4,648,64,513,16,65537,8,65,262281,16,16,2185,652,649,4,65539,64,512]

theorem envBound22865 : H12AffineFastState.Bounded env22865 := by
  intro p hp
  have h : env22865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22864_22865 : H12AffineEnvironment.transform 9 4 env22864 = env22865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env22864 == env22865) = true)

theorem identity22865 : scanCanonicalize (H12AffineFastState.compose env22865 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound22865 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env22866 : List Nat := [2,4,8,16,0,64,128,4,512,4,2048,65,128,16,649,65536,65,2184,4,648,64,513,16,65537,8,65,2049,16,16,2185,652,649,4,65539,64,512]

theorem envBound22866 : H12AffineFastState.Bounded env22866 := by
  intro p hp
  have h : env22866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22865_22866 : H12AffineEnvironment.transform 17 2184 env22865 = env22866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env22865 == env22866) = true)

theorem identity22866 : scanCanonicalize (H12AffineFastState.compose env22866 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound22866 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22867 : List Nat := [2,4,8,16,0,64,128,4,137,4,2048,65,128,16,0,65536,65,2184,4,1,64,136,16,65537,8,65,2049,16,16,2185,5,0,4,65539,64,137]

theorem envBound22867 : H12AffineFastState.Bounded env22867 := by
  intro p hp
  have h : env22867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22866_22867 : H12AffineEnvironment.transform 8 137 env22866 = env22867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env22866 == env22867) = true)

theorem identity22867 : scanCanonicalize (H12AffineFastState.compose env22867 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 67) := by decide +kernel

theorem selectedBound22867 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22868 : List Nat := [2,4,8,16,0,64,128,4,137,4,2048,65,128,16,0,67,65,2184,4,1,64,136,16,66,8,65,2049,16,16,2185,5,0,4,64,64,137]

theorem envBound22868 : H12AffineFastState.Bounded env22868 := by
  intro p hp
  have h : env22868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22867_22868 : H12AffineEnvironment.transform 15 67 env22867 = env22868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 67 env22867 == env22868) = true)

def env22869 : List Nat := [2,4,8,16,0,64,128,4,137,4,0,65,128,16,0,67,65,136,4,1,64,136,16,66,8,65,1,16,16,137,5,0,4,64,64,137]

theorem envBound22869 : H12AffineFastState.Bounded env22869 := by
  intro p hp
  have h : env22869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22868_22869 : H12AffineEnvironment.transform 10 0 env22868 = env22869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env22868 == env22869) = true)

def env22870 : List Nat := [2,4,8,16,0,64,128,4,137,4,1,65,128,16,0,67,65,137,4,1,64,136,16,66,8,65,0,16,16,136,5,0,4,64,64,137]

theorem envBound22870 : H12AffineFastState.Bounded env22870 := by
  intro p hp
  have h : env22870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22868_22870 : H12AffineEnvironment.transform 10 1 env22868 = env22870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env22868 == env22870) = true)

theorem identity22870 : scanCanonicalize (H12AffineFastState.compose env22870 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22870 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22871 : List Nat := [2,4,8,16,0,64,9,4,0,4,1,65,9,16,0,67,65,0,4,1,64,1,16,66,8,65,0,16,16,1,5,0,4,64,64,0]

theorem envBound22871 : H12AffineFastState.Bounded env22871 := by
  intro p hp
  have h : env22871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22870_22871 : H12AffineEnvironment.transform 6 9 env22870 = env22871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22870 == env22871) = true)

theorem identity22871 : scanCanonicalize (H12AffineFastState.compose env22871 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22871 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22872 : List Nat := [2,4,8,0,0,64,9,4,0,4,1,65,9,0,0,67,65,0,4,1,64,1,0,66,8,65,0,0,0,1,5,0,4,64,64,0]

theorem envBound22872 : H12AffineFastState.Bounded env22872 := by
  intro p hp
  have h : env22872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22871_22872 : H12AffineEnvironment.transform 3 0 env22871 = env22872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22871 == env22872) = true)

theorem identity22872 : scanCanonicalize (H12AffineFastState.compose env22872 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound22872 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22873 : List Nat := [2,4,8,0,0,0,9,4,0,4,1,1,9,0,0,3,1,0,4,1,0,1,0,2,8,1,0,0,0,1,5,0,4,0,0,0]

theorem envBound22873 : H12AffineFastState.Bounded env22873 := by
  intro p hp
  have h : env22873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22872_22873 : H12AffineEnvironment.transform 5 0 env22872 = env22873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env22872 == env22873) = true)

def leafEnv22873 : List Nat := [2,4,8,0,0,0,9,4,0,4,1,1,9,0,0,3,1,0,4,1,0,1,0,2,4,8,1,1,0,0,0,1,5,0,4,0,5,3,0,0,0,0,1]

def active22873 : List Nat := [0,1,2]

def tree22873 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22873 : H12WitnessSearch.Good tree22873 := H12GlobalWitnessIndex.good

theorem leafIdentity22873 : H12AffineFastState.composeSystem env22873 rootObs = leafEnv22873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22873 rootObs == leafEnv22873) = true)

theorem terminalChecked22873 : H12PackedTerminal.terminalCheckFast leafEnv22873 active22873 tree22873 = true := by decide +kernel

def env22874 : List Nat := [2,4,8,16,1,64,128,4,512,1024,2048,1093,128,1044,649,65536,1093,262144,1024,648,1092,513,16,65537,8,65,262281,1044,1044,3212,1672,649,4,65538,1092,512]

theorem envBound22874 : H12AffineFastState.Bounded env22874 := by
  intro p hp
  have h : env22874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22863_22874 : H12AffineEnvironment.transform 4 1 env22863 = env22874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22863 == env22874) = true)

theorem identity22874 : scanCanonicalize (H12AffineFastState.compose env22874 (packedSelected [8,12,23,32,38] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22874 : packedSelected [8,12,23,32,38] rootPS < 2^1333 := by decide +kernel

def env22875 : List Nat := [2,4,8,16,1,64,9,4,512,1024,2048,1093,9,1044,512,65536,1093,262144,1024,513,1092,513,16,65537,8,65,262144,1044,1044,3077,1537,512,4,65538,1092,512]

theorem envBound22875 : H12AffineFastState.Bounded env22875 := by
  intro p hp
  have h : env22875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22874_22875 : H12AffineEnvironment.transform 6 9 env22874 = env22875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22874 == env22875) = true)

theorem identity22875 : scanCanonicalize (H12AffineFastState.compose env22875 (packedSelected [2,3,7,11,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 1607) := by decide +kernel

theorem selectedBound22875 : packedSelected [2,3,7,11,15,17] rootPS < 2^1333 := by decide +kernel

def env22876 : List Nat := [2,4,8,16,1,64,9,4,512,1024,2048,1093,9,1044,512,1607,1093,262144,1024,513,1092,513,16,1606,8,65,262144,1044,1044,3077,1537,512,4,1605,1092,512]

theorem envBound22876 : H12AffineFastState.Bounded env22876 := by
  intro p hp
  have h : env22876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22875_22876 : H12AffineEnvironment.transform 15 1607 env22875 = env22876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1607 env22875 == env22876) = true)

theorem identity22876 : scanCanonicalize (H12AffineFastState.compose env22876 (packedSelected [13] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound22876 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env22877 : List Nat := [2,4,8,16,1,64,9,4,16,1024,2048,1093,9,1044,16,1111,1093,262144,1024,17,1092,17,16,1110,8,65,262144,1044,1044,3077,1041,16,4,1109,1092,16]

theorem envBound22877 : H12AffineFastState.Bounded env22877 := by
  intro p hp
  have h : env22877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22876_22877 : H12AffineEnvironment.transform 8 16 env22876 = env22877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env22876 == env22877) = true)

theorem identity22877 : scanCanonicalize (H12AffineFastState.compose env22877 (packedSelected [2,5,7] rootPS)) = affineNative (2^(17+1) ^^^ 1029) := by decide +kernel

theorem selectedBound22877 : packedSelected [2,5,7] rootPS < 2^1333 := by decide +kernel

def env22878 : List Nat := [2,4,8,16,1,64,9,4,16,1024,2048,1093,9,1044,16,1111,1093,1029,1024,17,1092,17,16,1110,8,65,1029,1044,1044,3077,1041,16,4,1109,1092,16]

theorem envBound22878 : H12AffineFastState.Bounded env22878 := by
  intro p hp
  have h : env22878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22877_22878 : H12AffineEnvironment.transform 17 1029 env22877 = env22878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1029 env22877 == env22878) = true)

theorem identity22878 : scanCanonicalize (H12AffineFastState.compose env22878 (packedSelected [0,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound22878 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env22879 : List Nat := [2,4,8,16,1,64,9,4,16,1024,1045,1093,9,1044,16,1111,1093,1029,1024,17,1092,17,16,1110,8,65,1029,1044,1044,16,1041,16,4,1109,1092,16]

theorem envBound22879 : H12AffineFastState.Bounded env22879 := by
  intro p hp
  have h : env22879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22878_22879 : H12AffineEnvironment.transform 10 1045 env22878 = env22879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env22878 == env22879) = true)

theorem identity22879 : scanCanonicalize (H12AffineFastState.compose env22879 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22879 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22880 : List Nat := [2,4,8,0,1,64,9,4,0,1024,1029,1093,9,1028,0,1095,1093,1029,1024,1,1092,1,0,1094,8,65,1029,1028,1028,0,1025,0,4,1093,1092,0]

theorem envBound22880 : H12AffineFastState.Bounded env22880 := by
  intro p hp
  have h : env22880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22879_22880 : H12AffineEnvironment.transform 3 0 env22879 = env22880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22879 == env22880) = true)

theorem identity22880 : scanCanonicalize (H12AffineFastState.compose env22880 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound22880 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22881 : List Nat := [2,4,8,0,1,64,9,4,0,5,0,64,9,1,0,66,64,0,5,1,65,1,0,67,8,65,0,1,1,0,4,0,4,64,65,0]

theorem envBound22881 : H12AffineFastState.Bounded env22881 := by
  intro p hp
  have h : env22881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22880_22881 : H12AffineEnvironment.transform 9 5 env22880 = env22881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env22880 == env22881) = true)

def env22882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,129,1296,32768,65536,1345,262144,1024,32769,1344,4194304,16,16777216,9,65,21331968,1296,1296,1073741824,16876544,4194440,256,16777250,1344,512]

theorem envBound22882 : H12AffineFastState.Bounded env22882 := by
  intro p hp
  have h : env22882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22797_22882 : H12AffineEnvironment.transform 12 129 env22797 = env22882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env22797 == env22882) = true)

theorem identity22882 : scanCanonicalize (H12AffineFastState.compose env22882 (packedSelected [3,5,24] rootPS)) = affineNative (2^(8+1) ^^^ 397) := by decide +kernel

theorem selectedBound22882 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env22883 : List Nat := [2,4,8,16,32,64,128,256,397,1024,2048,1345,129,1296,32768,65536,1345,262144,1024,32769,1344,4194304,16,16777216,9,65,21331968,1296,1296,1073741824,16876544,4194440,256,16777250,1344,397]

theorem envBound22883 : H12AffineFastState.Bounded env22883 := by
  intro p hp
  have h : env22883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22882_22883 : H12AffineEnvironment.transform 8 397 env22882 = env22883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 397 env22882 == env22883) = true)

def env22884 : List Nat := [2,4,8,16,32,64,128,256,397,1024,2048,1345,129,1296,32768,65536,1345,262144,1024,32769,1344,4194304,16,65536,9,65,4489216,1296,1296,1073741824,33792,4194440,256,65570,1344,397]

theorem envBound22884 : H12AffineFastState.Bounded env22884 := by
  intro p hp
  have h : env22884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22883_22884 : H12AffineEnvironment.transform 23 65536 env22883 = env22884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 65536 env22883 == env22884) = true)

theorem identity22884 : scanCanonicalize (H12AffineFastState.compose env22884 (packedSelected [1,8,28] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound22884 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env22885 : List Nat := [2,4,8,16,32,64,128,256,397,1024,2048,1345,129,1296,1,65536,1345,262144,1024,0,1344,4194304,16,65536,9,65,4456449,1296,1296,1073741824,1025,4194440,256,65570,1344,397]

theorem envBound22885 : H12AffineFastState.Bounded env22885 := by
  intro p hp
  have h : env22885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22884_22885 : H12AffineEnvironment.transform 14 1 env22884 = env22885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env22884 == env22885) = true)

def env22886 : List Nat := [2,4,8,16,0,64,128,256,397,1024,2048,1345,129,1296,1,65536,1345,262144,1024,0,1344,4194304,16,65536,9,65,4456449,1296,1296,1073741824,1025,4194440,256,65538,1344,397]

theorem envBound22886 : H12AffineFastState.Bounded env22886 := by
  intro p hp
  have h : env22886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22885_22886 : H12AffineEnvironment.transform 4 0 env22885 = env22886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22885 == env22886) = true)

theorem identity22886 : scanCanonicalize (H12AffineFastState.compose env22886 (packedSelected [2] rootPS)) = affineNative (2^(29+1) ^^^ 67787) := by decide +kernel

theorem selectedBound22886 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22887 : List Nat := [2,4,8,16,0,64,128,256,397,1024,2048,1345,129,1296,1,65536,1345,262144,1024,0,1344,4194304,16,65536,9,65,4456449,1296,1296,67787,1025,4194440,256,65538,1344,397]

theorem envBound22887 : H12AffineFastState.Bounded env22887 := by
  intro p hp
  have h : env22887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22886_22887 : H12AffineEnvironment.transform 29 67787 env22886 = env22887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 67787 env22886 == env22887) = true)

theorem identity22887 : scanCanonicalize (H12AffineFastState.compose env22887 (packedSelected [6,11,18] rootPS)) = affineNative (2^(15+1) ^^^ 1419) := by decide +kernel

theorem selectedBound22887 : packedSelected [6,11,18] rootPS < 2^1333 := by decide +kernel

def env22888 : List Nat := [2,4,8,16,0,64,128,256,397,1024,2048,1345,129,1296,1,1419,1345,262144,1024,0,1344,4194304,16,1419,9,65,4456449,1296,1296,3392,1025,4194440,256,1417,1344,397]

theorem envBound22888 : H12AffineFastState.Bounded env22888 := by
  intro p hp
  have h : env22888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22887_22888 : H12AffineEnvironment.transform 15 1419 env22887 = env22888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1419 env22887 == env22888) = true)

def env22889 : List Nat := [2,4,8,16,0,64,128,256,397,320,2048,1,129,80,1,203,1,262144,320,0,0,4194304,16,203,9,65,4456449,80,80,2048,321,4194440,256,201,0,397]

theorem envBound22889 : H12AffineFastState.Bounded env22889 := by
  intro p hp
  have h : env22889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22888_22889 : H12AffineEnvironment.transform 9 320 env22888 = env22889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env22888 == env22889) = true)

theorem identity22889 : scanCanonicalize (H12AffineFastState.compose env22889 (packedSelected [23,32] rootPS)) = affineNative (2^(21+1) ^^^ 1) := by decide +kernel

theorem selectedBound22889 : packedSelected [23,32] rootPS < 2^1333 := by decide +kernel

def env22890 : List Nat := [2,4,8,16,0,64,128,256,397,320,2048,1,129,80,1,203,1,262144,320,0,0,1,16,203,9,65,262144,80,80,2048,321,137,256,201,0,397]

theorem envBound22890 : H12AffineFastState.Bounded env22890 := by
  intro p hp
  have h : env22890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22889_22890 : H12AffineEnvironment.transform 21 1 env22889 = env22890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1 env22889 == env22890) = true)

theorem identity22890 : scanCanonicalize (H12AffineFastState.compose env22890 (packedSelected [0,7] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound22890 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22891 : List Nat := [2,4,8,16,0,64,128,256,397,320,2048,1,129,80,1,203,1,2184,320,0,0,1,16,203,9,65,2184,80,80,2048,321,137,256,201,0,397]

theorem envBound22891 : H12AffineFastState.Bounded env22891 := by
  intro p hp
  have h : env22891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22890_22891 : H12AffineEnvironment.transform 17 2184 env22890 = env22891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env22890 == env22891) = true)

theorem identity22891 : scanCanonicalize (H12AffineFastState.compose env22891 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22891 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env22892 : List Nat := [2,4,8,16,0,64,128,4,137,68,2048,1,129,80,1,203,1,2184,68,0,0,1,16,203,9,65,2184,80,80,2048,69,137,4,201,0,137]

theorem envBound22892 : H12AffineFastState.Bounded env22892 := by
  intro p hp
  have h : env22892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22891_22892 : H12AffineEnvironment.transform 7 4 env22891 = env22892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22891 == env22892) = true)

theorem identity22892 : scanCanonicalize (H12AffineFastState.compose env22892 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound22892 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22893 : List Nat := [2,4,8,16,0,64,128,4,137,68,0,1,129,80,1,203,1,136,68,0,0,1,16,203,9,65,136,80,80,0,69,137,4,201,0,137]

theorem envBound22893 : H12AffineFastState.Bounded env22893 := by
  intro p hp
  have h : env22893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22892_22893 : H12AffineEnvironment.transform 10 0 env22892 = env22893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env22892 == env22893) = true)

def env22894 : List Nat := [2,4,8,16,0,16,128,4,137,20,0,1,129,0,1,155,1,136,20,0,0,1,16,155,9,17,136,0,0,0,21,137,4,153,0,137]

theorem envBound22894 : H12AffineFastState.Bounded env22894 := by
  intro p hp
  have h : env22894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22893_22894 : H12AffineEnvironment.transform 5 16 env22893 = env22894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22893 == env22894) = true)

def env22895 : List Nat := [2,4,8,16,0,17,128,4,137,21,0,1,129,1,1,154,1,136,21,0,0,1,16,154,9,16,136,1,1,0,20,137,4,152,0,137]

theorem envBound22895 : H12AffineFastState.Bounded env22895 := by
  intro p hp
  have h : env22895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22893_22895 : H12AffineEnvironment.transform 5 17 env22893 = env22895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22893 == env22895) = true)

theorem identity22895 : scanCanonicalize (H12AffineFastState.compose env22895 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22895 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22896 : List Nat := [2,4,8,16,0,17,9,4,0,21,0,1,8,1,1,19,1,1,21,0,0,1,16,19,9,16,1,1,1,0,20,0,4,17,0,0]

theorem envBound22896 : H12AffineFastState.Bounded env22896 := by
  intro p hp
  have h : env22896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22895_22896 : H12AffineEnvironment.transform 6 9 env22895 = env22896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22895 == env22896) = true)

theorem identity22896 : scanCanonicalize (H12AffineFastState.compose env22896 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22896 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22897 : List Nat := [2,4,8,1,0,0,9,4,0,4,0,1,8,1,1,2,1,1,4,0,0,1,1,2,9,1,1,1,1,0,5,0,4,0,0,0]

theorem envBound22897 : H12AffineFastState.Bounded env22897 := by
  intro p hp
  have h : env22897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22896_22897 : H12AffineEnvironment.transform 3 1 env22896 = env22897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22896 == env22897) = true)

def leafEnv22897 : List Nat := [2,4,8,1,0,0,9,4,0,4,0,1,8,1,1,2,1,1,4,0,0,1,1,2,4,9,1,1,1,1,1,0,5,0,4,0,5,2,0,0,0,1,1]

def active22897 : List Nat := [0,1,2]

def tree22897 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22897 : H12WitnessSearch.Good tree22897 := H12GlobalWitnessIndex.good

theorem leafIdentity22897 : H12AffineFastState.composeSystem env22897 rootObs = leafEnv22897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22897 rootObs == leafEnv22897) = true)

theorem terminalChecked22897 : H12PackedTerminal.terminalCheckFast leafEnv22897 active22897 tree22897 = true := by decide +kernel

def env22898 : List Nat := [2,4,8,16,0,64,128,256,397,321,2048,0,129,81,1,202,0,262144,321,0,1,4194304,16,202,9,65,4456449,81,81,2049,320,4194440,256,200,1,397]

theorem envBound22898 : H12AffineFastState.Bounded env22898 := by
  intro p hp
  have h : env22898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22888_22898 : H12AffineEnvironment.transform 9 321 env22888 = env22898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env22888 == env22898) = true)

theorem identity22898 : scanCanonicalize (H12AffineFastState.compose env22898 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 80) := by decide +kernel

theorem selectedBound22898 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env22899 : List Nat := [2,4,8,16,0,64,128,256,397,321,2048,0,129,81,1,202,0,262144,321,0,1,80,16,202,9,65,262225,81,81,2049,320,216,256,200,1,397]

theorem envBound22899 : H12AffineFastState.Bounded env22899 := by
  intro p hp
  have h : env22899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22898_22899 : H12AffineEnvironment.transform 21 80 env22898 = env22899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 80 env22898 == env22899) = true)

theorem identity22899 : scanCanonicalize (H12AffineFastState.compose env22899 (packedSelected [0,1,7] rootPS)) = affineNative (2^(17+1) ^^^ 2113) := by decide +kernel

theorem selectedBound22899 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env22900 : List Nat := [2,4,8,16,0,64,128,256,397,321,2048,0,129,81,1,202,0,2113,321,0,1,80,16,202,9,65,2064,81,81,2049,320,216,256,200,1,397]

theorem envBound22900 : H12AffineFastState.Bounded env22900 := by
  intro p hp
  have h : env22900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22899_22900 : H12AffineEnvironment.transform 17 2113 env22899 = env22900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2113 env22899 == env22900) = true)

theorem identity22900 : scanCanonicalize (H12AffineFastState.compose env22900 (packedSelected [8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22900 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env22901 : List Nat := [2,4,8,16,0,16,128,256,397,273,2048,0,129,1,1,154,0,2065,273,0,1,0,16,154,9,17,2064,1,1,2049,272,136,256,152,1,397]

theorem envBound22901 : H12AffineFastState.Bounded env22901 := by
  intro p hp
  have h : env22901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22900_22901 : H12AffineEnvironment.transform 5 16 env22900 = env22901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22900 == env22901) = true)

theorem identity22901 : scanCanonicalize (H12AffineFastState.compose env22901 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22901 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22902 : List Nat := [2,4,8,16,0,16,8,256,261,273,2048,0,9,1,1,18,0,2065,273,0,1,0,16,18,9,17,2064,1,1,2049,272,0,256,16,1,261]

theorem envBound22902 : H12AffineFastState.Bounded env22902 := by
  intro p hp
  have h : env22902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22901_22902 : H12AffineEnvironment.transform 6 8 env22901 = env22902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22901 == env22902) = true)

theorem identity22902 : scanCanonicalize (H12AffineFastState.compose env22902 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22902 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22903 : List Nat := [2,4,8,16,0,16,8,4,1,21,2048,0,9,1,1,18,0,2065,21,0,1,0,16,18,9,17,2064,1,1,2049,20,0,4,16,1,1]

theorem envBound22903 : H12AffineFastState.Bounded env22903 := by
  intro p hp
  have h : env22903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22902_22903 : H12AffineEnvironment.transform 7 4 env22902 = env22903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22902 == env22903) = true)

def env22904 : List Nat := [2,4,8,16,1,64,128,256,397,1024,2048,1345,129,1296,1,65536,1345,262144,1024,0,1344,4194304,16,65536,9,65,4456449,1296,1296,1073741824,1025,4194440,256,65539,1344,397]

theorem envBound22904 : H12AffineFastState.Bounded env22904 := by
  intro p hp
  have h : env22904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22885_22904 : H12AffineEnvironment.transform 4 1 env22885 = env22904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22885 == env22904) = true)

theorem identity22904 : scanCanonicalize (H12AffineFastState.compose env22904 (packedSelected [2] rootPS)) = affineNative (2^(29+1) ^^^ 67651) := by decide +kernel

theorem selectedBound22904 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22905 : List Nat := [2,4,8,16,1,64,128,256,397,1024,2048,1345,129,1296,1,65536,1345,262144,1024,0,1344,4194304,16,65536,9,65,4456449,1296,1296,67651,1025,4194440,256,65539,1344,397]

theorem envBound22905 : H12AffineFastState.Bounded env22905 := by
  intro p hp
  have h : env22905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22904_22905 : H12AffineEnvironment.transform 29 67651 env22904 = env22905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 67651 env22904 == env22905) = true)

theorem identity22905 : scanCanonicalize (H12AffineFastState.compose env22905 (packedSelected [6,11,18] rootPS)) = affineNative (2^(9+1) ^^^ 457) := by decide +kernel

theorem selectedBound22905 : packedSelected [6,11,18] rootPS < 2^1333 := by decide +kernel

def env22906 : List Nat := [2,4,8,16,1,64,128,256,397,457,2048,136,129,217,1,65536,136,262144,457,0,137,4194304,16,65536,9,65,4456449,217,217,67651,456,4194440,256,65539,137,397]

theorem envBound22906 : H12AffineFastState.Bounded env22906 := by
  intro p hp
  have h : env22906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22905_22906 : H12AffineEnvironment.transform 9 457 env22905 = env22906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 457 env22905 == env22906) = true)

def env22907 : List Nat := [2,4,8,16,1,64,128,256,397,457,2048,136,129,217,1,65536,136,262144,457,0,137,0,16,65536,9,65,262145,217,217,67651,456,136,256,65539,137,397]

theorem envBound22907 : H12AffineFastState.Bounded env22907 := by
  intro p hp
  have h : env22907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22906_22907 : H12AffineEnvironment.transform 21 0 env22906 = env22907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 0 env22906 == env22907) = true)

theorem identity22907 : scanCanonicalize (H12AffineFastState.compose env22907 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 203) := by decide +kernel

theorem selectedBound22907 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22908 : List Nat := [2,4,8,16,1,64,128,256,397,457,2048,136,129,217,1,203,136,262144,457,0,137,0,16,203,9,65,262145,217,217,2184,456,136,256,200,137,397]

theorem envBound22908 : H12AffineFastState.Bounded env22908 := by
  intro p hp
  have h : env22908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22907_22908 : H12AffineEnvironment.transform 15 203 env22907 = env22908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 203 env22907 == env22908) = true)

theorem identity22908 : scanCanonicalize (H12AffineFastState.compose env22908 (packedSelected [8] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound22908 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env22909 : List Nat := [2,4,8,16,1,64,89,256,340,272,2048,81,88,0,1,18,81,262144,272,0,80,0,16,18,9,65,262145,0,0,2129,273,81,256,17,80,340]

theorem envBound22909 : H12AffineFastState.Bounded env22909 := by
  intro p hp
  have h : env22909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22908_22909 : H12AffineEnvironment.transform 6 89 env22908 = env22909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env22908 == env22909) = true)

theorem identity22909 : scanCanonicalize (H12AffineFastState.compose env22909 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22909 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env22910 : List Nat := [2,4,8,16,1,16,9,256,260,272,2048,1,8,0,1,18,1,262144,272,0,0,0,16,18,9,17,262145,0,0,2049,273,1,256,17,0,260]

theorem envBound22910 : H12AffineFastState.Bounded env22910 := by
  intro p hp
  have h : env22910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22909_22910 : H12AffineEnvironment.transform 5 16 env22909 = env22910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22909 == env22910) = true)

theorem identity22910 : scanCanonicalize (H12AffineFastState.compose env22910 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound22910 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22911 : List Nat := [2,4,8,16,1,16,9,5,1,21,2048,1,8,0,1,18,1,262144,21,0,0,0,16,18,9,17,262145,0,0,2049,20,1,5,17,0,1]

theorem envBound22911 : H12AffineFastState.Bounded env22911 := by
  intro p hp
  have h : env22911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22910_22911 : H12AffineEnvironment.transform 7 5 env22910 = env22911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env22910 == env22911) = true)

theorem identity22911 : scanCanonicalize (H12AffineFastState.compose env22911 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22911 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22912 : List Nat := [2,4,8,1,1,1,9,5,1,4,2048,1,8,0,1,3,1,262144,4,0,0,0,1,3,9,0,262145,0,0,2049,5,1,5,0,0,1]

theorem envBound22912 : H12AffineFastState.Bounded env22912 := by
  intro p hp
  have h : env22912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22911_22912 : H12AffineEnvironment.transform 3 1 env22911 = env22912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22911 == env22912) = true)

def env22913 : List Nat := [2,4,8,16,1,64,128,256,397,457,2048,136,129,217,1,65536,136,262144,457,0,137,1,16,65536,9,65,262144,217,217,67651,456,137,256,65539,137,397]

theorem envBound22913 : H12AffineFastState.Bounded env22913 := by
  intro p hp
  have h : env22913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22906_22913 : H12AffineEnvironment.transform 21 1 env22906 = env22913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1 env22906 == env22913) = true)

theorem identity22913 : scanCanonicalize (H12AffineFastState.compose env22913 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 67) := by decide +kernel

theorem selectedBound22913 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22914 : List Nat := [2,4,8,16,1,64,128,256,397,457,2048,136,129,217,1,67,136,262144,457,0,137,1,16,67,9,65,262144,217,217,2048,456,137,256,64,137,397]

theorem envBound22914 : H12AffineFastState.Bounded env22914 := by
  intro p hp
  have h : env22914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22913_22914 : H12AffineEnvironment.transform 15 67 env22913 = env22914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 67 env22913 == env22914) = true)

theorem identity22914 : scanCanonicalize (H12AffineFastState.compose env22914 (packedSelected [0,7] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound22914 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22915 : List Nat := [2,4,8,16,1,64,128,256,397,457,2048,136,129,217,1,67,136,2185,457,0,137,1,16,67,9,65,2185,217,217,2048,456,137,256,64,137,397]

theorem envBound22915 : H12AffineFastState.Bounded env22915 := by
  intro p hp
  have h : env22915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22914_22915 : H12AffineEnvironment.transform 17 2185 env22914 = env22915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env22914 == env22915) = true)

theorem identity22915 : scanCanonicalize (H12AffineFastState.compose env22915 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22915 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env22916 : List Nat := [2,4,8,16,1,64,128,4,137,205,2048,136,129,217,1,67,136,2185,205,0,137,1,16,67,9,65,2185,217,217,2048,204,137,4,64,137,137]

theorem envBound22916 : H12AffineFastState.Bounded env22916 := by
  intro p hp
  have h : env22916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22915_22916 : H12AffineEnvironment.transform 7 4 env22915 = env22916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22915 == env22916) = true)

theorem identity22916 : scanCanonicalize (H12AffineFastState.compose env22916 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound22916 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22917 : List Nat := [2,4,8,16,1,64,128,4,137,205,1,136,129,217,1,67,136,136,205,0,137,1,16,67,9,65,136,217,217,1,204,137,4,64,137,137]

theorem envBound22917 : H12AffineFastState.Bounded env22917 := by
  intro p hp
  have h : env22917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22916_22917 : H12AffineEnvironment.transform 10 1 env22916 = env22917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env22916 == env22917) = true)

def env22918 : List Nat := [2,4,8,0,1,64,128,4,137,205,1,136,129,201,1,67,136,136,205,0,137,1,0,67,9,65,136,201,201,1,204,137,4,64,137,137]

theorem envBound22918 : H12AffineFastState.Bounded env22918 := by
  intro p hp
  have h : env22918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22917_22918 : H12AffineEnvironment.transform 3 0 env22917 = env22918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22917 == env22918) = true)

theorem identity22918 : scanCanonicalize (H12AffineFastState.compose env22918 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound22918 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22919 : List Nat := [2,4,8,0,1,0,128,4,137,141,1,136,129,137,1,3,136,136,141,0,137,1,0,3,9,1,136,137,137,1,140,137,4,0,137,137]

theorem envBound22919 : H12AffineFastState.Bounded env22919 := by
  intro p hp
  have h : env22919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22918_22919 : H12AffineEnvironment.transform 5 0 env22918 = env22919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env22918 == env22919) = true)

theorem identity22919 : scanCanonicalize (H12AffineFastState.compose env22919 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22919 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22920 : List Nat := [2,4,8,0,1,0,8,4,1,5,1,0,9,1,1,3,0,0,5,0,1,1,0,3,9,1,0,1,1,1,4,1,4,0,1,1]

theorem envBound22920 : H12AffineFastState.Bounded env22920 := by
  intro p hp
  have h : env22920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22919_22920 : H12AffineEnvironment.transform 6 8 env22919 = env22920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22919 == env22920) = true)

def leafEnv22920 : List Nat := [2,4,8,0,1,0,8,4,1,5,1,0,9,1,1,3,0,0,5,0,1,1,0,3,5,9,1,1,0,1,1,1,4,1,4,0,5,2,1,1,0,1,1]

def active22920 : List Nat := [0,1,2]

def tree22920 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22920 : H12WitnessSearch.Good tree22920 := H12GlobalWitnessIndex.good

theorem leafIdentity22920 : H12AffineFastState.composeSystem env22920 rootObs = leafEnv22920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22920 rootObs == leafEnv22920) = true)

theorem terminalChecked22920 : H12PackedTerminal.terminalCheckFast leafEnv22920 active22920 tree22920 = true := by decide +kernel

def env22921 : List Nat := [2,4,8,1,1,64,128,4,137,205,1,136,129,200,1,67,136,136,205,0,137,1,1,67,9,65,136,200,200,1,204,137,4,64,137,137]

theorem envBound22921 : H12AffineFastState.Bounded env22921 := by
  intro p hp
  have h : env22921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22917_22921 : H12AffineEnvironment.transform 3 1 env22917 = env22921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22917 == env22921) = true)

theorem identity22921 : scanCanonicalize (H12AffineFastState.compose env22921 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound22921 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22922 : List Nat := [2,4,8,1,1,64,72,4,65,5,1,64,73,0,1,67,64,64,5,0,65,1,1,67,9,65,64,0,0,1,4,65,4,64,65,65]

theorem envBound22922 : H12AffineFastState.Bounded env22922 := by
  intro p hp
  have h : env22922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22921_22922 : H12AffineEnvironment.transform 6 72 env22921 = env22922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env22921 == env22922) = true)

theorem identity22922 : scanCanonicalize (H12AffineFastState.compose env22922 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound22922 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22923 : List Nat := [2,4,8,1,1,0,8,4,1,5,1,0,9,0,1,3,0,0,5,0,1,1,1,3,9,1,0,0,0,1,4,1,4,0,1,1]

theorem envBound22923 : H12AffineFastState.Bounded env22923 := by
  intro p hp
  have h : env22923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22922_22923 : H12AffineEnvironment.transform 5 0 env22922 = env22923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env22922 == env22923) = true)

def leafEnv22923 : List Nat := [2,4,8,1,1,0,8,4,1,5,1,0,9,0,1,3,0,0,5,0,1,1,1,3,5,9,1,1,0,0,0,1,4,1,4,0,5,2,1,1,0,0,1]

def active22923 : List Nat := [0,1,2]

def tree22923 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22923 : H12WitnessSearch.Good tree22923 := H12GlobalWitnessIndex.good

theorem leafIdentity22923 : H12AffineFastState.composeSystem env22923 rootObs = leafEnv22923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22923 rootObs == leafEnv22923) = true)

theorem terminalChecked22923 : H12PackedTerminal.terminalCheckFast leafEnv22923 active22923 tree22923 = true := by decide +kernel

def env22924 : List Nat := [2,4,8,16,32,64,128,256,397,1024,2048,1345,129,1296,32768,65536,1345,262144,1024,32769,1344,4194304,16,65537,9,65,4489217,1296,1296,1073741824,33793,4194440,256,65571,1344,397]

theorem envBound22924 : H12AffineFastState.Bounded env22924 := by
  intro p hp
  have h : env22924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22883_22924 : H12AffineEnvironment.transform 23 65537 env22883 = env22924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 65537 env22883 == env22924) = true)

theorem identity22924 : scanCanonicalize (H12AffineFastState.compose env22924 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22924 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env22925 : List Nat := [2,4,8,16,32,64,128,4,137,1024,2048,1093,129,1044,32768,65536,1093,262144,1024,32769,1092,4194304,16,65537,9,65,4489217,1044,1044,1073741824,33793,4194440,4,65571,1092,137]

theorem envBound22925 : H12AffineFastState.Bounded env22925 := by
  intro p hp
  have h : env22925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22924_22925 : H12AffineEnvironment.transform 7 4 env22924 = env22925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22924 == env22925) = true)

def env22926 : List Nat := [2,4,8,16,32,64,128,4,137,1024,2048,1093,129,1044,32768,65536,1093,262144,1024,32769,1092,32768,16,65537,9,65,262145,1044,1044,1073741824,33793,32904,4,65571,1092,137]

theorem envBound22926 : H12AffineFastState.Bounded env22926 := by
  intro p hp
  have h : env22926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22925_22926 : H12AffineEnvironment.transform 21 32768 env22925 = env22926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32768 env22925 == env22926) = true)

theorem identity22926 : scanCanonicalize (H12AffineFastState.compose env22926 (packedSelected [6] rootPS)) = affineNative (2^(29+1) ^^^ 3108) := by decide +kernel

theorem selectedBound22926 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22927 : List Nat := [2,4,8,16,32,64,128,4,137,1024,2048,1093,129,1044,32768,65536,1093,262144,1024,32769,1092,32768,16,65537,9,65,262145,1044,1044,3108,33793,32904,4,65571,1092,137]

theorem envBound22927 : H12AffineFastState.Bounded env22927 := by
  intro p hp
  have h : env22927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22926_22927 : H12AffineEnvironment.transform 29 3108 env22926 = env22927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 3108 env22926 == env22927) = true)

theorem identity22927 : scanCanonicalize (H12AffineFastState.compose env22927 (packedSelected [5,15,41] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound22927 : packedSelected [5,15,41] rootPS < 2^1333 := by decide +kernel

def env22928 : List Nat := [2,4,8,16,32,64,128,4,137,1024,2048,1093,129,1044,0,65536,1093,262144,1024,1,1092,0,16,65537,9,65,262145,1044,1044,3108,1025,136,4,65571,1092,137]

theorem envBound22928 : H12AffineFastState.Bounded env22928 := by
  intro p hp
  have h : env22928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22927_22928 : H12AffineEnvironment.transform 14 0 env22927 = env22928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env22927 == env22928) = true)

def env22929 : List Nat := [2,4,8,16,32,64,128,4,137,1024,2048,1093,129,1044,32768,65536,1093,262144,1024,32769,1092,32769,16,65537,9,65,262144,1044,1044,1073741824,33793,32905,4,65571,1092,137]

theorem envBound22929 : H12AffineFastState.Bounded env22929 := by
  intro p hp
  have h : env22929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22925_22929 : H12AffineEnvironment.transform 21 32769 env22925 = env22929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32769 env22925 == env22929) = true)

theorem identity22929 : scanCanonicalize (H12AffineFastState.compose env22929 (packedSelected [6] rootPS)) = affineNative (2^(29+1) ^^^ 3244) := by decide +kernel

theorem selectedBound22929 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22930 : List Nat := [2,4,8,16,32,64,128,4,137,1024,2048,1093,129,1044,32768,65536,1093,262144,1024,32769,1092,32769,16,65537,9,65,262144,1044,1044,3244,33793,32905,4,65571,1092,137]

theorem envBound22930 : H12AffineFastState.Bounded env22930 := by
  intro p hp
  have h : env22930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22929_22930 : H12AffineEnvironment.transform 29 3244 env22929 = env22930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 3244 env22929 == env22930) = true)

def env22931 : List Nat := [2,4,8,16,32,64,56,4,49,1024,2048,1093,57,1044,32768,65536,1093,262144,1024,32769,1092,32769,16,65537,9,65,262144,1044,1044,3092,33793,32817,4,65571,1092,49]

theorem envBound22931 : H12AffineFastState.Bounded env22931 := by
  intro p hp
  have h : env22931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22930_22931 : H12AffineEnvironment.transform 6 56 env22930 = env22931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env22930 == env22931) = true)

theorem identity22931 : scanCanonicalize (H12AffineFastState.compose env22931 (packedSelected [5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound22931 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env22932 : List Nat := [2,4,8,16,32,64,56,4,49,20,2048,81,57,0,32768,65536,81,262144,20,32769,80,32769,16,65537,9,65,262144,0,0,2048,32789,32817,4,65571,80,49]

theorem envBound22932 : H12AffineFastState.Bounded env22932 := by
  intro p hp
  have h : env22932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22931_22932 : H12AffineEnvironment.transform 9 20 env22931 = env22932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env22931 == env22932) = true)

theorem identity22932 : scanCanonicalize (H12AffineFastState.compose env22932 (packedSelected [0,7] rootPS)) = affineNative (2^(17+1) ^^^ 34833) := by decide +kernel

theorem selectedBound22932 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22933 : List Nat := [2,4,8,16,32,64,56,4,49,20,2048,81,57,0,32768,65536,81,34833,20,32769,80,32769,16,65537,9,65,34833,0,0,2048,32789,32817,4,65571,80,49]

theorem envBound22933 : H12AffineFastState.Bounded env22933 := by
  intro p hp
  have h : env22933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22932_22933 : H12AffineEnvironment.transform 17 34833 env22932 = env22933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34833 env22932 == env22933) = true)

theorem identity22933 : scanCanonicalize (H12AffineFastState.compose env22933 (packedSelected [4,9] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound22933 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env22934 : List Nat := [2,4,8,16,32,64,56,4,49,20,2048,81,57,0,0,65536,81,2065,20,1,80,1,16,65537,9,65,2065,0,0,2048,21,49,4,65571,80,49]

theorem envBound22934 : H12AffineFastState.Bounded env22934 := by
  intro p hp
  have h : env22934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22933_22934 : H12AffineEnvironment.transform 14 0 env22933 = env22934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env22933 == env22934) = true)

theorem identity22934 : scanCanonicalize (H12AffineFastState.compose env22934 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound22934 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22935 : List Nat := [2,4,8,16,32,64,56,4,49,20,33,81,57,0,0,65536,81,48,20,1,80,1,16,65537,9,65,48,0,0,33,21,49,4,65571,80,49]

theorem envBound22935 : H12AffineFastState.Bounded env22935 := by
  intro p hp
  have h : env22935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22934_22935 : H12AffineEnvironment.transform 10 33 env22934 = env22935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env22934 == env22935) = true)

def env22936 : List Nat := [2,4,8,16,32,16,56,4,49,20,33,1,57,0,0,65536,1,48,20,1,0,1,16,65537,9,17,48,0,0,33,21,49,4,65571,0,49]

theorem envBound22936 : H12AffineFastState.Bounded env22936 := by
  intro p hp
  have h : env22936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22935_22936 : H12AffineEnvironment.transform 5 16 env22935 = env22936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22935 == env22936) = true)

theorem identity22936 : scanCanonicalize (H12AffineFastState.compose env22936 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22936 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22937 : List Nat := [2,4,8,16,0,16,24,4,17,20,1,1,25,0,0,65536,1,16,20,1,0,1,16,65537,9,17,16,0,0,1,21,17,4,65539,0,17]

theorem envBound22937 : H12AffineFastState.Bounded env22937 := by
  intro p hp
  have h : env22937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22936_22937 : H12AffineEnvironment.transform 4 0 env22936 = env22937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22936 == env22937) = true)

theorem identity22937 : scanCanonicalize (H12AffineFastState.compose env22937 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound22937 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22938 : List Nat := [2,4,8,16,0,16,24,4,17,20,1,1,25,0,0,2,1,16,20,1,0,1,16,3,9,17,16,0,0,1,21,17,4,1,0,17]

theorem envBound22938 : H12AffineFastState.Bounded env22938 := by
  intro p hp
  have h : env22938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22937_22938 : H12AffineEnvironment.transform 15 2 env22937 = env22938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env22937 == env22938) = true)

theorem identity22938 : scanCanonicalize (H12AffineFastState.compose env22938 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22938 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22939 : List Nat := [2,4,8,0,0,0,8,4,1,4,1,1,9,0,0,2,1,0,4,1,0,1,0,3,9,1,0,0,0,1,5,1,4,1,0,1]

theorem envBound22939 : H12AffineFastState.Bounded env22939 := by
  intro p hp
  have h : env22939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22938_22939 : H12AffineEnvironment.transform 3 0 env22938 = env22939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22938 == env22939) = true)

def leafEnv22939 : List Nat := [2,4,8,0,0,0,8,4,1,4,1,1,9,0,0,2,1,0,4,1,0,1,0,3,4,9,1,1,0,0,0,1,5,1,4,1,5,3,0,1,0,0,1]

def active22939 : List Nat := [0,1,2]

def tree22939 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22939 : H12WitnessSearch.Good tree22939 := H12GlobalWitnessIndex.good

theorem leafIdentity22939 : H12AffineFastState.composeSystem env22939 rootObs = leafEnv22939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22939 rootObs == leafEnv22939) = true)

theorem terminalChecked22939 : H12PackedTerminal.terminalCheckFast leafEnv22939 active22939 tree22939 = true := by decide +kernel

def env22940 : List Nat := [2,4,8,16,32,17,56,4,49,20,33,0,57,0,0,65536,0,48,20,1,1,1,16,65537,9,16,48,0,0,33,21,49,4,65571,1,49]

theorem envBound22940 : H12AffineFastState.Bounded env22940 := by
  intro p hp
  have h : env22940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22935_22940 : H12AffineEnvironment.transform 5 17 env22935 = env22940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22935 == env22940) = true)

theorem identity22940 : scanCanonicalize (H12AffineFastState.compose env22940 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound22940 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22941 : List Nat := [2,4,8,16,32,17,56,4,49,20,33,0,57,0,0,34,0,48,20,1,1,1,16,35,9,16,48,0,0,33,21,49,4,1,1,49]

theorem envBound22941 : H12AffineFastState.Bounded env22941 := by
  intro p hp
  have h : env22941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22940_22941 : H12AffineEnvironment.transform 15 34 env22940 = env22941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env22940 == env22941) = true)

def env22942 : List Nat := [2,4,8,16,0,17,24,4,17,20,1,0,25,0,0,2,0,16,20,1,1,1,16,3,9,16,16,0,0,1,21,17,4,1,1,17]

theorem envBound22942 : H12AffineFastState.Bounded env22942 := by
  intro p hp
  have h : env22942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22941_22942 : H12AffineEnvironment.transform 4 0 env22941 = env22942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22941 == env22942) = true)

def env22943 : List Nat := [2,4,8,16,1,17,25,4,16,20,0,0,24,0,0,3,0,17,20,1,1,1,16,2,9,16,17,0,0,0,21,16,4,1,1,16]

theorem envBound22943 : H12AffineFastState.Bounded env22943 := by
  intro p hp
  have h : env22943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22941_22943 : H12AffineEnvironment.transform 4 1 env22941 = env22943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22941 == env22943) = true)

theorem identity22943 : scanCanonicalize (H12AffineFastState.compose env22943 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22943 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22944 : List Nat := [2,4,8,0,1,1,9,4,0,4,0,0,8,0,0,3,0,1,4,1,1,1,0,2,9,0,1,0,0,0,5,0,4,1,1,0]

theorem envBound22944 : H12AffineFastState.Bounded env22944 := by
  intro p hp
  have h : env22944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22943_22944 : H12AffineEnvironment.transform 3 0 env22943 = env22944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22943 == env22944) = true)

def leafEnv22944 : List Nat := [2,4,8,0,1,1,9,4,0,4,0,0,8,0,0,3,0,1,4,1,1,1,0,2,4,9,1,0,1,0,0,0,5,0,4,1,5,3,1,0,0,0,1]

def active22944 : List Nat := [0,1,2]

def tree22944 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22944 : H12WitnessSearch.Good tree22944 := H12GlobalWitnessIndex.good

theorem leafIdentity22944 : H12AffineFastState.composeSystem env22944 rootObs = leafEnv22944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22944 rootObs == leafEnv22944) = true)

theorem terminalChecked22944 : H12PackedTerminal.terminalCheckFast leafEnv22944 active22944 tree22944 = true := by decide +kernel

def env22945 : List Nat := [2,4,8,16,32,64,57,4,48,1024,2048,1093,56,1044,32768,65536,1093,262144,1024,32769,1092,32769,16,65537,9,65,262144,1044,1044,3093,33793,32816,4,65571,1092,48]

theorem envBound22945 : H12AffineFastState.Bounded env22945 := by
  intro p hp
  have h : env22945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22930_22945 : H12AffineEnvironment.transform 6 57 env22930 = env22945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env22930 == env22945) = true)

def env22946 : List Nat := [2,4,8,16,32,64,57,4,48,1024,2048,1093,56,1044,0,65536,1093,262144,1024,1,1092,1,16,65537,9,65,262144,1044,1044,3093,1025,48,4,65571,1092,48]

theorem envBound22946 : H12AffineFastState.Bounded env22946 := by
  intro p hp
  have h : env22946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22945_22946 : H12AffineEnvironment.transform 14 0 env22945 = env22946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env22945 == env22946) = true)

theorem identity22946 : scanCanonicalize (H12AffineFastState.compose env22946 (packedSelected [7] rootPS)) = affineNative (2^(17+1) ^^^ 49) := by decide +kernel

theorem selectedBound22946 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env22947 : List Nat := [2,4,8,16,32,64,57,4,48,1024,2048,1093,56,1044,0,65536,1093,49,1024,1,1092,1,16,65537,9,65,49,1044,1044,3093,1025,48,4,65571,1092,48]

theorem envBound22947 : H12AffineFastState.Bounded env22947 := by
  intro p hp
  have h : env22947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22946_22947 : H12AffineEnvironment.transform 17 49 env22946 = env22947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 49 env22946 == env22947) = true)

theorem identity22947 : scanCanonicalize (H12AffineFastState.compose env22947 (packedSelected [0,11,15,18] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound22947 : packedSelected [0,11,15,18] rootPS < 2^1333 := by decide +kernel

def env22948 : List Nat := [2,4,8,16,32,64,57,4,48,21,2048,80,56,1,0,65536,80,49,21,1,81,1,16,65537,9,65,49,1,1,2048,20,48,4,65571,81,48]

theorem envBound22948 : H12AffineFastState.Bounded env22948 := by
  intro p hp
  have h : env22948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22947_22948 : H12AffineEnvironment.transform 9 21 env22947 = env22948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env22947 == env22948) = true)

theorem identity22948 : scanCanonicalize (H12AffineFastState.compose env22948 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound22948 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22949 : List Nat := [2,4,8,16,32,64,57,4,48,21,33,80,56,1,0,65536,80,49,21,1,81,1,16,65537,9,65,49,1,1,33,20,48,4,65571,81,48]

theorem envBound22949 : H12AffineFastState.Bounded env22949 := by
  intro p hp
  have h : env22949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22948_22949 : H12AffineEnvironment.transform 10 33 env22948 = env22949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env22948 == env22949) = true)

def env22950 : List Nat := [2,4,8,16,32,16,57,4,48,21,33,0,56,1,0,65536,0,49,21,1,1,1,16,65537,9,17,49,1,1,33,20,48,4,65571,1,48]

theorem envBound22950 : H12AffineFastState.Bounded env22950 := by
  intro p hp
  have h : env22950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22949_22950 : H12AffineEnvironment.transform 5 16 env22949 = env22950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22949 == env22950) = true)

theorem identity22950 : scanCanonicalize (H12AffineFastState.compose env22950 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 19) := by decide +kernel

theorem selectedBound22950 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22951 : List Nat := [2,4,8,16,32,16,57,4,48,21,33,0,56,1,0,19,0,49,21,1,1,1,16,18,9,17,49,1,1,33,20,48,4,48,1,48]

theorem envBound22951 : H12AffineFastState.Bounded env22951 := by
  intro p hp
  have h : env22951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22950_22951 : H12AffineEnvironment.transform 15 19 env22950 = env22951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19 env22950 == env22951) = true)

theorem identity22951 : scanCanonicalize (H12AffineFastState.compose env22951 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22951 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22952 : List Nat := [2,4,8,1,32,1,40,4,33,4,33,0,41,1,0,2,0,32,4,1,1,1,1,3,9,0,32,1,1,33,5,33,4,33,1,33]

theorem envBound22952 : H12AffineFastState.Bounded env22952 := by
  intro p hp
  have h : env22952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22951_22952 : H12AffineEnvironment.transform 3 1 env22951 = env22952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22951 == env22952) = true)

def env22953 : List Nat := [2,4,8,16,32,17,57,4,48,21,33,1,56,1,0,65536,1,49,21,1,0,1,16,65537,9,16,49,1,1,33,20,48,4,65571,0,48]

theorem envBound22953 : H12AffineFastState.Bounded env22953 := by
  intro p hp
  have h : env22953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22949_22953 : H12AffineEnvironment.transform 5 17 env22949 = env22953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22949 == env22953) = true)

theorem identity22953 : scanCanonicalize (H12AffineFastState.compose env22953 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22953 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22954 : List Nat := [2,4,8,1,32,0,40,4,33,4,33,1,41,1,0,65536,1,32,4,1,0,1,1,65537,9,1,32,1,1,33,5,33,4,65571,0,33]

theorem envBound22954 : H12AffineFastState.Bounded env22954 := by
  intro p hp
  have h : env22954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22953_22954 : H12AffineEnvironment.transform 3 1 env22953 = env22954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22953 == env22954) = true)

theorem identity22954 : scanCanonicalize (H12AffineFastState.compose env22954 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound22954 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22955 : List Nat := [2,4,8,1,32,0,40,4,33,4,33,1,41,1,0,2,1,32,4,1,0,1,1,3,9,1,32,1,1,33,5,33,4,33,0,33]

theorem envBound22955 : H12AffineFastState.Bounded env22955 := by
  intro p hp
  have h : env22955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22954_22955 : H12AffineEnvironment.transform 15 2 env22954 = env22955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env22954 == env22955) = true)

theorem identity22955 : scanCanonicalize (H12AffineFastState.compose env22955 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22955 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22956 : List Nat := [2,4,8,1,0,0,8,4,1,4,1,1,9,1,0,2,1,0,4,1,0,1,1,3,9,1,0,1,1,1,5,1,4,1,0,1]

theorem envBound22956 : H12AffineFastState.Bounded env22956 := by
  intro p hp
  have h : env22956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22955_22956 : H12AffineEnvironment.transform 4 0 env22955 = env22956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22955 == env22956) = true)

def leafEnv22956 : List Nat := [2,4,8,1,0,0,8,4,1,4,1,1,9,1,0,2,1,0,4,1,0,1,1,3,4,9,1,1,0,1,1,1,5,1,4,1,5,3,0,1,0,1,1]

def active22956 : List Nat := [0,1,2]

def tree22956 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22956 : H12WitnessSearch.Good tree22956 := H12GlobalWitnessIndex.good

theorem leafIdentity22956 : H12AffineFastState.composeSystem env22956 rootObs = leafEnv22956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22956 rootObs == leafEnv22956) = true)

theorem terminalChecked22956 : H12PackedTerminal.terminalCheckFast leafEnv22956 active22956 tree22956 = true := by decide +kernel

def env22957 : List Nat := [2,4,8,16,32,64,57,4,48,1024,2048,1093,56,1044,1,65536,1093,262144,1024,0,1092,0,16,65537,9,65,262144,1044,1044,3093,1024,49,4,65571,1092,48]

theorem envBound22957 : H12AffineFastState.Bounded env22957 := by
  intro p hp
  have h : env22957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22945_22957 : H12AffineEnvironment.transform 14 1 env22945 = env22957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env22945 == env22957) = true)

theorem identity22957 : scanCanonicalize (H12AffineFastState.compose env22957 (packedSelected [7] rootPS)) = affineNative (2^(17+1) ^^^ 66566) := by decide +kernel

theorem selectedBound22957 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env22958 : List Nat := [2,4,8,16,32,64,57,4,48,1024,2048,1093,56,1044,1,65536,1093,66566,1024,0,1092,0,16,65537,9,65,66566,1044,1044,3093,1024,49,4,65571,1092,48]

theorem envBound22958 : H12AffineFastState.Bounded env22958 := by
  intro p hp
  have h : env22958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22957_22958 : H12AffineEnvironment.transform 17 66566 env22957 = env22958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 66566 env22957 == env22958) = true)

theorem identity22958 : scanCanonicalize (H12AffineFastState.compose env22958 (packedSelected [1,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 3126) := by decide +kernel

theorem selectedBound22958 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env22959 : List Nat := [2,4,8,16,32,64,57,4,48,1024,2048,1093,56,1044,1,3126,1093,2096,1024,0,1092,0,16,3127,9,65,2096,1044,1044,3093,1024,49,4,3093,1092,48]

theorem envBound22959 : H12AffineFastState.Bounded env22959 := by
  intro p hp
  have h : env22959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22958_22959 : H12AffineEnvironment.transform 15 3126 env22958 = env22959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3126 env22958 == env22959) = true)

theorem identity22959 : scanCanonicalize (H12AffineFastState.compose env22959 (packedSelected [1,4,9] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound22959 : packedSelected [1,4,9] rootPS < 2^1333 := by decide +kernel

def env22960 : List Nat := [2,4,8,16,32,64,57,4,48,1024,49,1093,56,1044,1,1031,1093,1,1024,0,1092,0,16,1030,9,65,1,1044,1044,1060,1024,49,4,1060,1092,48]

theorem envBound22960 : H12AffineFastState.Bounded env22960 := by
  intro p hp
  have h : env22960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22959_22960 : H12AffineEnvironment.transform 10 49 env22959 = env22960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env22959 == env22960) = true)

theorem identity22960 : scanCanonicalize (H12AffineFastState.compose env22960 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound22960 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22961 : List Nat := [2,4,8,16,32,64,57,4,48,20,49,81,56,0,1,19,81,1,20,0,80,0,16,18,9,65,1,0,0,48,20,49,4,48,80,48]

theorem envBound22961 : H12AffineFastState.Bounded env22961 := by
  intro p hp
  have h : env22961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22960_22961 : H12AffineEnvironment.transform 9 20 env22960 = env22961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env22960 == env22961) = true)

theorem identity22961 : scanCanonicalize (H12AffineFastState.compose env22961 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22961 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22962 : List Nat := [2,4,8,1,32,64,40,4,33,5,32,64,41,0,1,2,64,1,5,0,65,0,1,3,9,65,1,0,0,33,5,32,4,33,65,33]

theorem envBound22962 : H12AffineFastState.Bounded env22962 := by
  intro p hp
  have h : env22962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22961_22962 : H12AffineEnvironment.transform 3 1 env22961 = env22962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22961 == env22962) = true)

theorem identity22962 : scanCanonicalize (H12AffineFastState.compose env22962 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound22962 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22963 : List Nat := [2,4,8,1,32,1,40,4,33,5,32,1,41,0,1,2,1,1,5,0,0,0,1,3,9,0,1,0,0,33,5,32,4,33,0,33]

theorem envBound22963 : H12AffineFastState.Bounded env22963 := by
  intro p hp
  have h : env22963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22962_22963 : H12AffineEnvironment.transform 5 1 env22962 = env22963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env22962 == env22963) = true)

theorem identity22963 : scanCanonicalize (H12AffineFastState.compose env22963 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22963 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22964 : List Nat := [2,4,8,1,1,1,9,4,0,5,1,1,8,0,1,2,1,1,5,0,0,0,1,3,9,0,1,0,0,0,5,1,4,0,0,0]

theorem envBound22964 : H12AffineFastState.Bounded env22964 := by
  intro p hp
  have h : env22964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22963_22964 : H12AffineEnvironment.transform 4 1 env22963 = env22964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22963 == env22964) = true)

def env22965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914001,134217728,8519745,536870912,1073741824,562663489,4294967296,545789249,4315938986,702907649,512]

theorem envBound22965 : H12AffineFastState.Bounded env22965 := by
  intro p hp
  have h : env22965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21100_22965 : H12AffineEnvironment.transform 34 702907649 env21100 = env22965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 702907649 env21100 == env22965) = true)

def env22966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914001,134217728,8519745,2769920,1073741824,27513921,4294967296,10637633,4315938986,164610305,512]

theorem envBound22966 : H12AffineFastState.Bounded env22966 := by
  intro p hp
  have h : env22966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22965_22966 : H12AffineEnvironment.transform 28 2769920 env22965 = env22966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 2769920 env22965 == env22966) = true)

def env22967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,8388608,16777216,8328,8914001,134217728,8519745,676864,1073741824,25412673,4294967296,8536385,4315938986,164610305,512]

theorem envBound22967 : H12AffineFastState.Bounded env22967 := by
  intro p hp
  have h : env22967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22966_22967 : H12AffineEnvironment.transform 20 4096 env22966 = env22967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env22966 == env22967) = true)

theorem identity22967 : scanCanonicalize (H12AffineFastState.compose env22967 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 528720) := by decide +kernel

theorem selectedBound22967 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env22968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,528720,16777216,8328,5377,134217728,659729,676864,1073741824,17552657,4294967296,675857,4315938986,155701329,512]

theorem envBound22968 : H12AffineFastState.Bounded env22968 := by
  intro p hp
  have h : env22968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22967_22968 : H12AffineEnvironment.transform 22 528720 env22967 = env22968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 528720 env22967 == env22968) = true)

def env22969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,21776,262144,524288,32769,4096,4194304,528720,16777216,8328,5377,134217728,541697,524560,1073741824,17399809,4294967296,525569,4315938986,155551041,512]

theorem envBound22969 : H12AffineFastState.Bounded env22969 := by
  intro p hp
  have h : env22969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22968_22969 : H12AffineEnvironment.transform 16 21776 env22968 = env22969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21776 env22968 == env22969) = true)

theorem identity22969 : scanCanonicalize (H12AffineFastState.compose env22969 (packedSelected [4,9,16] rootPS)) = affineNative (2^(23+1) ^^^ 623877) := by decide +kernel

theorem selectedBound22969 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env22970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,21776,262144,524288,32769,4096,4194304,528720,623877,8328,5377,134217728,541697,524560,1073741824,1284,4294967296,525569,4299785647,139198532,512]

theorem envBound22970 : H12AffineFastState.Bounded env22970 := by
  intro p hp
  have h : env22970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22969_22970 : H12AffineEnvironment.transform 23 623877 env22969 = env22970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 623877 env22969 == env22970) = true)

theorem identity22970 : scanCanonicalize (H12AffineFastState.compose env22970 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(29+1) ^^^ 135105934) := by decide +kernel

theorem selectedBound22970 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env22971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,21776,262144,524288,32769,4096,4194304,528720,623877,8328,5377,134217728,541697,524560,135105934,1284,4294967296,525569,4299785647,139198532,512]

theorem envBound22971 : H12AffineFastState.Bounded env22971 := by
  intro p hp
  have h : env22971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22970_22971 : H12AffineEnvironment.transform 29 135105934 env22970 = env22971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 135105934 env22970 == env22971) = true)

theorem identity22971 : scanCanonicalize (H12AffineFastState.compose env22971 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(26+1) ^^^ 4982021) := by decide +kernel

theorem selectedBound22971 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env22972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,21776,262144,524288,32769,4096,4194304,528720,623877,8328,5377,4982021,541697,524560,4294795,1284,4294967296,525569,4299785647,1345,512]

theorem envBound22972 : H12AffineFastState.Bounded env22972 := by
  intro p hp
  have h : env22972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22971_22972 : H12AffineEnvironment.transform 26 4982021 env22971 = env22972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4982021 env22971 == env22972) = true)

theorem identity22972 : scanCanonicalize (H12AffineFastState.compose env22972 (packedSelected [13,21] rootPS)) = affineNative (2^(18+1) ^^^ 62813) := by decide +kernel

theorem selectedBound22972 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env22973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,21776,262144,62813,32769,4096,4194304,58381,94296,8328,5377,4517976,45404,62541,4294795,1284,4294967296,61532,4299256050,1345,512]

theorem envBound22973 : H12AffineFastState.Bounded env22973 := by
  intro p hp
  have h : env22973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22972_22973 : H12AffineEnvironment.transform 18 62813 env22972 = env22973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 62813 env22972 == env22973) = true)

def env22974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1344,262144,42253,32769,4096,4194304,46173,73736,8328,5377,4497416,45404,42013,4294795,1284,4294967296,40972,4299235490,1345,512]

theorem envBound22974 : H12AffineFastState.Bounded env22974 := by
  intro p hp
  have h : env22974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22973_22974 : H12AffineEnvironment.transform 13 4176 env22973 = env22974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env22973 == env22974) = true)

theorem identity22974 : scanCanonicalize (H12AffineFastState.compose env22974 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 74031) := by decide +kernel

theorem selectedBound22974 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1344,262144,42253,32769,4096,4194304,46173,73736,8328,5377,4497416,45404,42013,4294795,1284,74031,40972,4194701,1345,512]

theorem envBound22975 : H12AffineFastState.Bounded env22975 := by
  intro p hp
  have h : env22975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22974_22975 : H12AffineEnvironment.transform 31 74031 env22974 = env22975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 74031 env22974 == env22975) = true)

theorem identity22975 : scanCanonicalize (H12AffineFastState.compose env22975 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound22975 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22976 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4176,32768,65536,1344,262144,42253,32769,4096,4194304,46173,73736,8328,5377,4497416,45404,42013,4294795,1284,74031,40972,4194701,1345,137]

theorem envBound22976 : H12AffineFastState.Bounded env22976 := by
  intro p hp
  have h : env22976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22975_22976 : H12AffineEnvironment.transform 8 137 env22975 = env22976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env22975 == env22976) = true)

def env22977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1345,262144,42252,32769,4096,4194304,46172,73737,8328,5377,4497417,45404,42012,4294795,1284,4294967296,40973,4299235491,1345,512]

theorem envBound22977 : H12AffineFastState.Bounded env22977 := by
  intro p hp
  have h : env22977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22973_22977 : H12AffineEnvironment.transform 13 4177 env22973 = env22977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env22973 == env22977) = true)

theorem identity22977 : scanCanonicalize (H12AffineFastState.compose env22977 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 4273586) := by decide +kernel

theorem selectedBound22977 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22978 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1345,262144,42252,32769,4096,4194304,46172,73737,8328,5377,4497417,45404,42012,4294795,1284,4273586,40973,5393,1345,512]

theorem envBound22978 : H12AffineFastState.Bounded env22978 := by
  intro p hp
  have h : env22978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22977_22978 : H12AffineEnvironment.transform 31 4273586 env22977 = env22978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4273586 env22977 == env22978) = true)

theorem identity22978 : scanCanonicalize (H12AffineFastState.compose env22978 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 74283) := by decide +kernel

theorem selectedBound22978 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1345,262144,42252,32769,4096,74283,46172,73737,8328,5377,360994,45404,42012,43680,1284,6041,40973,5393,1345,512]

theorem envBound22979 : H12AffineFastState.Bounded env22979 := by
  intro p hp
  have h : env22979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22978_22979 : H12AffineEnvironment.transform 21 74283 env22978 = env22979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 74283 env22978 == env22979) = true)

theorem identity22979 : scanCanonicalize (H12AffineFastState.compose env22979 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound22979 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env22980 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1345,32768,65536,1345,262144,42252,32769,1296,74283,41292,73737,8328,17,360994,42060,42012,43680,1284,649,40973,1,1345,512]

theorem envBound22980 : H12AffineFastState.Bounded env22980 := by
  intro p hp
  have h : env22980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22979_22980 : H12AffineEnvironment.transform 11 1296 env22979 = env22980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env22979 == env22980) = true)

theorem identity22980 : scanCanonicalize (H12AffineFastState.compose env22980 (packedSelected [3,5,8,13,24] rootPS)) = affineNative (2^(15+1) ^^^ 2136) := by decide +kernel

theorem selectedBound22980 : packedSelected [3,5,8,13,24] rootPS < 2^1333 := by decide +kernel

def env22981 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1345,32768,2136,1345,262144,42252,32769,1296,10867,41292,10321,8328,17,297594,42060,42012,43680,1284,649,40973,1,1345,512]

theorem envBound22981 : H12AffineFastState.Bounded env22981 := by
  intro p hp
  have h : env22981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22980_22981 : H12AffineEnvironment.transform 15 2136 env22980 = env22981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2136 env22980 == env22981) = true)

def env22982 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,21777,262144,524288,32769,4096,4194304,528720,16777216,8328,5377,134217728,541696,524561,1073741824,17399808,4294967296,525568,4315938986,155551040,512]

theorem envBound22982 : H12AffineFastState.Bounded env22982 := by
  intro p hp
  have h : env22982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22968_22982 : H12AffineEnvironment.transform 16 21777 env22968 = env22982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21777 env22968 == env22982) = true)

def env22983 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,21777,262144,1024,32769,4096,4194304,5456,16777216,8328,5377,134217728,16384,1297,1073741824,16876544,4294967296,256,4315938986,155551040,512]

theorem envBound22983 : H12AffineFastState.Bounded env22983 := by
  intro p hp
  have h : env22983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22982_22983 : H12AffineEnvironment.transform 18 1024 env22982 = env22983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env22982 == env22983) = true)

def env22984 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,21777,262144,1024,32769,4096,4194304,5456,16777216,8328,5377,21331968,16384,1297,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound22984 : H12AffineFastState.Bounded env22984 := by
  intro p hp
  have h : env22984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22983_22984 : H12AffineEnvironment.transform 26 21331968 env22983 = env22984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331968 env22983 == env22984) = true)

theorem identity22984 : scanCanonicalize (H12AffineFastState.compose env22984 (packedSelected [7,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound22984 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env22985 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1345,262144,1024,32769,4096,4194304,5456,16777216,8328,5377,21331968,4176,1297,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound22985 : H12AffineFastState.Bounded env22985 := by
  intro p hp
  have h : env22985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22984_22985 : H12AffineEnvironment.transform 13 4176 env22984 = env22985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env22984 == env22985) = true)

def env22986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1345,262144,1024,32769,1344,4194304,16,16777216,8328,65,21331968,1296,1297,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound22986 : H12AffineFastState.Bounded env22986 := by
  intro p hp
  have h : env22986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22985_22986 : H12AffineEnvironment.transform 11 1344 env22985 = env22986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env22985 == env22986) = true)

theorem identity22986 : scanCanonicalize (H12AffineFastState.compose env22986 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 98645) := by decide +kernel

theorem selectedBound22986 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env22987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1345,262144,1024,32769,1344,4194304,16,98645,8328,65,4456789,1296,1297,1073741824,1365,4294967296,256,4299260415,1344,512]

theorem envBound22987 : H12AffineFastState.Bounded env22987 := by
  intro p hp
  have h : env22987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22986_22987 : H12AffineEnvironment.transform 23 98645 env22986 = env22987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98645 env22986 == env22987) = true)

theorem identity22987 : scanCanonicalize (H12AffineFastState.compose env22987 (packedSelected [13,17] rootPS)) = affineNative (2^(31+1) ^^^ 1077979376) := by decide +kernel

theorem selectedBound22987 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env22988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1345,262144,1024,32769,1344,4194304,16,98645,8328,65,4456789,1296,1297,1073741824,1365,1077979376,256,1073817871,1344,512]

theorem envBound22988 : H12AffineFastState.Bounded env22988 := by
  intro p hp
  have h : env22988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22987_22988 : H12AffineEnvironment.transform 31 1077979376 env22987 = env22988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1077979376 env22987 == env22988) = true)

theorem identity22988 : scanCanonicalize (H12AffineFastState.compose env22988 (packedSelected [13,21] rootPS)) = affineNative (2^(29+1) ^^^ 43129) := by decide +kernel

theorem selectedBound22988 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env22989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1345,262144,1024,32769,1344,4194304,16,98645,8328,65,4456789,1296,1297,43129,1365,4194441,256,98678,1344,512]

theorem envBound22989 : H12AffineFastState.Bounded env22989 := by
  intro p hp
  have h : env22989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22988_22989 : H12AffineEnvironment.transform 29 43129 env22988 = env22989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 43129 env22988 == env22989) = true)

theorem identity22989 : scanCanonicalize (H12AffineFastState.compose env22989 (packedSelected [1,3,15,24,28,38] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22989 : packedSelected [1,3,15,24,28,38] rootPS < 2^1333 := by decide +kernel

def env22990 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1297,262144,1024,32769,1296,4194304,16,98565,8328,17,4456709,1296,1297,43049,1285,4194441,256,98598,1296,512]

theorem envBound22990 : H12AffineFastState.Bounded env22990 := by
  intro p hp
  have h : env22990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22989_22990 : H12AffineEnvironment.transform 5 16 env22989 = env22990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22989 == env22990) = true)

theorem identity22990 : scanCanonicalize (H12AffineFastState.compose env22990 (packedSelected [1,3,5] rootPS)) = affineNative (2^(17+1) ^^^ 65804) := by decide +kernel

theorem selectedBound22990 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env22991 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1297,65804,1024,32769,1296,4194304,16,98565,8328,17,4259849,1296,1297,43049,1285,4194441,256,98598,1296,512]

theorem envBound22991 : H12AffineFastState.Bounded env22991 := by
  intro p hp
  have h : env22991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22990_22991 : H12AffineEnvironment.transform 17 65804 env22990 = env22991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65804 env22990 == env22991) = true)

theorem identity22991 : scanCanonicalize (H12AffineFastState.compose env22991 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 9092) := by decide +kernel

theorem selectedBound22991 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env22992 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,9092,65536,1297,65804,1024,9093,1296,4194304,16,74369,8328,17,4259849,1296,1297,2989,1285,4194441,256,74402,1296,512]

theorem envBound22992 : H12AffineFastState.Bounded env22992 := by
  intro p hp
  have h : env22992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22991_22992 : H12AffineEnvironment.transform 14 9092 env22991 = env22992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9092 env22991 == env22992) = true)

theorem identity22992 : scanCanonicalize (H12AffineFastState.compose env22992 (packedSelected [1,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 2089) := by decide +kernel

theorem selectedBound22992 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env22993 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,9092,2089,1297,2341,1024,9093,1296,4194304,16,10920,8328,17,4196384,1296,1297,2989,1285,4194441,256,10891,1296,512]

theorem envBound22993 : H12AffineFastState.Bounded env22993 := by
  intro p hp
  have h : env22993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22992_22993 : H12AffineEnvironment.transform 15 2089 env22992 = env22993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2089 env22992 == env22993) = true)

theorem identity22993 : scanCanonicalize (H12AffineFastState.compose env22993 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 2595) := by decide +kernel

theorem selectedBound22993 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env22994 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2595,1296,2471,2089,1297,2341,1024,2470,1296,4194304,16,139,2731,17,4196384,1296,1297,2989,1285,4194441,256,168,1296,512]

theorem envBound22994 : H12AffineFastState.Bounded env22994 := by
  intro p hp
  have h : env22994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22993_22994 : H12AffineEnvironment.transform 12 2595 env22993 = env22994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2595 env22993 == env22994) = true)

theorem identity22994 : scanCanonicalize (H12AffineFastState.compose env22994 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 1976) := by decide +kernel

theorem selectedBound22994 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env22995 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2595,1296,2471,2089,1297,2341,1024,2470,1296,1976,16,139,2731,17,3992,1296,1297,2989,1285,1841,256,168,1296,512]

theorem envBound22995 : H12AffineFastState.Bounded env22995 := by
  intro p hp
  have h : env22995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22994_22995 : H12AffineEnvironment.transform 21 1976 env22994 = env22995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1976 env22994 == env22995) = true)

theorem identity22995 : scanCanonicalize (H12AffineFastState.compose env22995 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound22995 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22996 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,2595,0,2471,2089,1,2341,272,2470,0,680,16,139,2731,17,2696,0,1,2989,21,545,256,168,0,512]

theorem envBound22996 : H12AffineFastState.Bounded env22996 := by
  intro p hp
  have h : env22996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22995_22996 : H12AffineEnvironment.transform 9 272 env22995 = env22996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env22995 == env22996) = true)

theorem identity22996 : scanCanonicalize (H12AffineFastState.compose env22996 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 815) := by decide +kernel

theorem selectedBound22996 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22997 : List Nat := [2,4,8,16,32,16,128,256,512,272,815,0,268,0,648,774,1,522,272,649,0,680,16,139,388,17,423,0,1,130,21,545,256,168,0,512]

theorem envBound22997 : H12AffineFastState.Bounded env22997 := by
  intro p hp
  have h : env22997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22996_22997 : H12AffineEnvironment.transform 10 815 env22996 = env22997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 815 env22996 == env22997) = true)

theorem identity22997 : scanCanonicalize (H12AffineFastState.compose env22997 (packedSelected [2,6] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound22997 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22998 : List Nat := [2,4,8,16,32,16,128,256,137,272,422,0,268,0,1,399,1,131,272,0,0,33,16,139,388,17,423,0,1,130,21,168,256,168,0,137]

theorem envBound22998 : H12AffineFastState.Bounded env22998 := by
  intro p hp
  have h : env22998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22997_22998 : H12AffineEnvironment.transform 8 137 env22997 = env22998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env22997 == env22998) = true)

theorem identity22998 : scanCanonicalize (H12AffineFastState.compose env22998 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound22998 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22999 : List Nat := [2,4,8,16,32,16,128,20,137,4,178,0,24,0,1,155,1,131,4,0,0,33,16,139,144,17,179,0,1,130,21,168,20,168,0,137]

theorem envBound22999 : H12AffineFastState.Bounded env22999 := by
  intro p hp
  have h : env22999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22998_22999 : H12AffineEnvironment.transform 7 20 env22998 = env22999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env22998 == env22999) = true)

def env23000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1345,262144,1024,32769,1345,4194304,17,16777216,8328,64,21331968,1297,1297,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound23000 : H12AffineFastState.Bounded env23000 := by
  intro p hp
  have h : env23000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22985_23000 : H12AffineEnvironment.transform 11 1345 env22985 = env23000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env22985 == env23000) = true)

theorem identity23000 : scanCanonicalize (H12AffineFastState.compose env23000 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23000 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env23001 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,262144,1024,32769,1296,4194304,17,16777216,8328,17,21331968,1297,1297,1073741824,16876544,4294967296,256,4315938986,1297,512]

theorem envBound23001 : H12AffineFastState.Bounded env23001 := by
  intro p hp
  have h : env23001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23000_23001 : H12AffineEnvironment.transform 5 17 env23000 = env23001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23000 == env23001) = true)

theorem identity23001 : scanCanonicalize (H12AffineFastState.compose env23001 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 1073842178) := by decide +kernel

theorem selectedBound23001 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env23002 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,262144,1024,32769,1296,4194304,17,16777216,8328,17,21331968,1297,1297,1073741824,16876544,1073842178,256,1094813864,1297,512]

theorem envBound23002 : H12AffineFastState.Bounded env23002 := by
  intro p hp
  have h : env23002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23001_23002 : H12AffineEnvironment.transform 31 1073842178 env23001 = env23002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1073842178 env23001 == env23002) = true)

def env23003 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1297,32768,65536,1296,262144,1024,32769,1296,4194304,17,16777216,8,17,21331968,1297,1297,1073741824,16876544,1073842178,256,1094813864,1297,512]

theorem envBound23003 : H12AffineFastState.Bounded env23003 := by
  intro p hp
  have h : env23003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23002_23003 : H12AffineEnvironment.transform 12 128 env23002 = env23003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env23002 == env23003) = true)

theorem identity23003 : scanCanonicalize (H12AffineFastState.compose env23003 (packedSelected [3,5,24] rootPS)) = affineNative (2^(17+1) ^^^ 98433) := by decide +kernel

theorem selectedBound23003 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env23004 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1297,32768,65536,1296,98433,1024,32769,1296,4194304,17,16777216,8,17,20971649,1297,1297,1073741824,16876544,1073842178,256,1094813864,1297,512]

theorem envBound23004 : H12AffineFastState.Bounded env23004 := by
  intro p hp
  have h : env23004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23003_23004 : H12AffineEnvironment.transform 17 98433 env23003 = env23004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 98433 env23003 == env23004) = true)

def env23005 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1297,32768,65536,1296,98433,1024,32769,1296,4194304,17,16777216,8,17,20971649,1297,1297,21071872,16876544,20971522,256,168,1297,512]

theorem envBound23005 : H12AffineFastState.Bounded env23005 := by
  intro p hp
  have h : env23005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23004_23005 : H12AffineEnvironment.transform 29 21071872 env23004 = env23005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 21071872 env23004 == env23005) = true)

theorem identity23005 : scanCanonicalize (H12AffineFastState.compose env23005 (packedSelected [5] rootPS)) = affineNative (2^(23+1) ^^^ 67746) := by decide +kernel

theorem selectedBound23005 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23006 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1297,32768,65536,1296,98433,1024,32769,1296,4194304,17,67746,8,17,4261923,1297,1297,4227234,36002,4262048,256,168,1297,512]

theorem envBound23006 : H12AffineFastState.Bounded env23006 := by
  intro p hp
  have h : env23006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23005_23006 : H12AffineEnvironment.transform 23 67746 env23005 = env23006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 67746 env23005 == env23006) = true)

theorem identity23006 : scanCanonicalize (H12AffineFastState.compose env23006 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound23006 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23007 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1297,32768,33166,1296,271,1024,32769,1296,4194304,17,35116,8,17,4229549,1297,1297,4227234,36002,4229422,256,168,1297,512]

theorem envBound23007 : H12AffineFastState.Bounded env23007 := by
  intro p hp
  have h : env23007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23006_23007 : H12AffineEnvironment.transform 15 33166 env23006 = env23007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env23006 == env23007) = true)

theorem identity23007 : scanCanonicalize (H12AffineFastState.compose env23007 (packedSelected [3,10] rootPS)) = affineNative (2^(21+1) ^^^ 2059) := by decide +kernel

theorem selectedBound23007 : packedSelected [3,10] rootPS < 2^1333 := by decide +kernel

def env23008 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1297,32768,33166,1296,271,1024,32769,1296,2059,17,35116,8,17,33190,1297,1297,34985,36002,33061,256,168,1297,512]

theorem envBound23008 : H12AffineFastState.Bounded env23008 := by
  intro p hp
  have h : env23008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23007_23008 : H12AffineEnvironment.transform 21 2059 env23007 = env23008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2059 env23007 == env23008) = true)

theorem identity23008 : scanCanonicalize (H12AffineFastState.compose env23008 (packedSelected [0,2,3,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 533) := by decide +kernel

theorem selectedBound23008 : packedSelected [0,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env23009 : List Nat := [2,4,8,16,32,17,128,256,512,533,2048,773,128,772,32768,33166,773,271,533,32769,773,2059,17,35116,8,17,33190,772,772,34985,35511,33061,256,168,772,512]

theorem envBound23009 : H12AffineFastState.Bounded env23009 := by
  intro p hp
  have h : env23009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23008_23009 : H12AffineEnvironment.transform 9 533 env23008 = env23009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 533 env23008 == env23009) = true)

theorem identity23009 : scanCanonicalize (H12AffineFastState.compose env23009 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 2471) := by decide +kernel

theorem selectedBound23009 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env23010 : List Nat := [2,4,8,16,32,17,128,256,512,533,2048,773,128,772,2471,2089,773,271,533,2470,773,2059,17,139,8,17,2049,772,772,270,784,2178,256,168,772,512]

theorem envBound23010 : H12AffineFastState.Bounded env23010 := by
  intro p hp
  have h : env23010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23009_23010 : H12AffineEnvironment.transform 14 2471 env23009 = env23010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2471 env23009 == env23010) = true)

theorem identity23010 : scanCanonicalize (H12AffineFastState.compose env23010 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 815) := by decide +kernel

theorem selectedBound23010 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23011 : List Nat := [2,4,8,16,32,17,128,256,512,533,815,773,128,772,648,774,773,271,533,649,773,804,17,139,8,17,814,772,772,270,784,941,256,168,772,512]

theorem envBound23011 : H12AffineFastState.Bounded env23011 := by
  intro p hp
  have h : env23011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23010_23011 : H12AffineEnvironment.transform 10 815 env23010 = env23011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 815 env23010 == env23011) = true)

theorem identity23011 : scanCanonicalize (H12AffineFastState.compose env23011 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound23011 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23012 : List Nat := [2,4,8,16,32,17,128,140,512,533,675,649,128,648,648,650,649,131,533,649,649,680,17,139,8,17,674,648,648,130,668,545,140,168,648,512]

theorem envBound23012 : H12AffineFastState.Bounded env23012 := by
  intro p hp
  have h : env23012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23011_23012 : H12AffineEnvironment.transform 7 140 env23011 = env23012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env23011 == env23012) = true)

def env23013 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1297,32768,65536,1296,98433,1024,32769,1296,4194304,17,16777216,8,17,20971649,1297,1297,21071873,16876544,20971523,256,169,1297,512]

theorem envBound23013 : H12AffineFastState.Bounded env23013 := by
  intro p hp
  have h : env23013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23004_23013 : H12AffineEnvironment.transform 29 21071873 env23004 = env23013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 21071873 env23004 == env23013) = true)

theorem identity23013 : scanCanonicalize (H12AffineFastState.compose env23013 (packedSelected [5] rootPS)) = affineNative (2^(23+1) ^^^ 69042) := by decide +kernel

theorem selectedBound23013 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23014 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1297,32768,65536,1296,98433,1024,32769,1296,4194304,17,69042,8,17,4263219,1297,1297,4228531,35250,4263345,256,169,1297,512]

theorem envBound23014 : H12AffineFastState.Bounded env23014 := by
  intro p hp
  have h : env23014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23013_23014 : H12AffineEnvironment.transform 23 69042 env23013 = env23014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 69042 env23013 == env23014) = true)

theorem identity23014 : scanCanonicalize (H12AffineFastState.compose env23014 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 33196) := by decide +kernel

theorem selectedBound23014 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23015 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1297,32768,65536,1296,98433,1024,32769,1296,33196,17,69042,8,17,101535,1297,1297,1055,35250,101405,256,169,1297,512]

theorem envBound23015 : H12AffineFastState.Bounded env23015 := by
  intro p hp
  have h : env23015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23014_23015 : H12AffineEnvironment.transform 21 33196 env23014 = env23015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33196 env23014 == env23015) = true)

theorem identity23015 : scanCanonicalize (H12AffineFastState.compose env23015 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 3254) := by decide +kernel

theorem selectedBound23015 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env23016 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1297,3254,65536,1296,68663,1024,3255,1296,3354,17,69042,8,17,65577,1297,1297,1055,1284,65707,256,169,1297,512]

theorem envBound23016 : H12AffineFastState.Bounded env23016 := by
  intro p hp
  have h : env23016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23015_23016 : H12AffineEnvironment.transform 14 3254 env23015 = env23016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3254 env23015 == env23016) = true)

theorem identity23016 : scanCanonicalize (H12AffineFastState.compose env23016 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1567) := by decide +kernel

theorem selectedBound23016 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23017 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1567,1296,128,1297,681,65536,1296,66088,1024,680,1296,773,17,66477,8,17,65577,1297,1297,1055,1284,65707,256,169,1297,512]

theorem envBound23017 : H12AffineFastState.Bounded env23017 := by
  intro p hp
  have h : env23017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23016_23017 : H12AffineEnvironment.transform 10 1567 env23016 = env23017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1567 env23016 == env23017) = true)

theorem identity23017 : scanCanonicalize (H12AffineFastState.compose env23017 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound23017 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23018 : List Nat := [2,4,8,16,32,17,128,256,1,1024,1054,1296,128,1297,168,65536,1296,65577,1024,169,1296,260,17,65964,8,17,65577,1297,1297,1055,1284,65707,256,169,1297,1]

theorem envBound23018 : H12AffineFastState.Bounded env23018 := by
  intro p hp
  have h : env23018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23017_23018 : H12AffineEnvironment.transform 8 1 env23017 = env23018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env23017 == env23018) = true)

theorem identity23018 : scanCanonicalize (H12AffineFastState.compose env23018 (packedSelected [0,7] rootPS)) = affineNative (2^(15+1) ^^^ 40) := by decide +kernel

theorem selectedBound23018 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23019 : List Nat := [2,4,8,16,32,17,128,256,1,1024,1054,1296,128,1297,168,40,1296,1,1024,169,1296,260,17,388,8,17,1,1297,1297,1055,1284,131,256,169,1297,1]

theorem envBound23019 : H12AffineFastState.Bounded env23019 := by
  intro p hp
  have h : env23019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23018_23019 : H12AffineEnvironment.transform 15 40 env23018 = env23019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40 env23018 == env23019) = true)

theorem identity23019 : scanCanonicalize (H12AffineFastState.compose env23019 (packedSelected [4,6] rootPS)) = affineNative (2^(9+1) ^^^ 282) := by decide +kernel

theorem selectedBound23019 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env23020 : List Nat := [2,4,8,16,32,17,128,256,1,282,260,10,128,11,168,40,10,1,282,169,10,260,17,388,8,17,1,11,11,261,30,131,256,169,11,1]

theorem envBound23020 : H12AffineFastState.Bounded env23020 := by
  intro p hp
  have h : env23020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23019_23020 : H12AffineEnvironment.transform 9 282 env23019 = env23020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 282 env23019 == env23020) = true)

theorem identity23020 : scanCanonicalize (H12AffineFastState.compose env23020 (packedSelected [10] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound23020 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env23021 : List Nat := [2,4,8,16,32,17,128,15,1,21,11,10,128,11,168,40,10,1,21,169,10,11,17,139,8,17,1,11,11,10,30,131,15,169,11,1]

theorem envBound23021 : H12AffineFastState.Bounded env23021 := by
  intro p hp
  have h : env23021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23020_23021 : H12AffineEnvironment.transform 7 15 env23020 = env23021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env23020 == env23021) = true)

theorem identity23021 : scanCanonicalize (H12AffineFastState.compose env23021 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound23021 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env23022 : List Nat := [2,4,8,16,32,17,8,15,1,21,11,10,8,11,32,40,10,1,21,33,10,11,17,3,8,17,1,11,11,10,30,11,15,33,11,1]

theorem envBound23022 : H12AffineFastState.Bounded env23022 := by
  intro p hp
  have h : env23022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23021_23022 : H12AffineEnvironment.transform 6 8 env23021 = env23022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23021 == env23022) = true)

theorem identity23022 : scanCanonicalize (H12AffineFastState.compose env23022 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound23022 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23023 : List Nat := [2,4,8,10,32,11,8,15,1,15,11,10,8,11,32,40,10,1,15,33,10,11,11,3,8,11,1,11,11,10,4,11,15,33,11,1]

theorem envBound23023 : H12AffineFastState.Bounded env23023 := by
  intro p hp
  have h : env23023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23022_23023 : H12AffineEnvironment.transform 3 10 env23022 = env23023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env23022 == env23023) = true)

theorem identity23023 : scanCanonicalize (H12AffineFastState.compose env23023 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound23023 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env23024 : List Nat := [2,4,3,1,32,0,3,4,1,4,0,1,3,0,32,35,1,1,4,33,1,0,0,3,3,0,1,0,0,1,4,0,4,33,0,1]

theorem envBound23024 : H12AffineFastState.Bounded env23024 := by
  intro p hp
  have h : env23024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23023_23024 : H12AffineEnvironment.transform 2 3 env23023 = env23024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env23023 == env23024) = true)

def env23025 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,129,1297,32768,65536,1296,262144,1024,32769,1296,4194304,17,16777216,9,17,21331968,1297,1297,1073741824,16876544,1073842178,256,1094813864,1297,512]

theorem envBound23025 : H12AffineFastState.Bounded env23025 := by
  intro p hp
  have h : env23025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23002_23025 : H12AffineEnvironment.transform 12 129 env23002 = env23025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env23002 == env23025) = true)

theorem identity23025 : scanCanonicalize (H12AffineFastState.compose env23025 (packedSelected [3,5,24] rootPS)) = affineNative (2^(23+1) ^^^ 262533) := by decide +kernel

theorem selectedBound23025 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env23026 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,129,1297,32768,65536,1296,262144,1024,32769,1296,4194304,17,262533,9,17,4292997,1297,1297,1073741824,361861,1073842178,256,1078298925,1297,512]

theorem envBound23026 : H12AffineFastState.Bounded env23026 := by
  intro p hp
  have h : env23026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23025_23026 : H12AffineEnvironment.transform 23 262533 env23025 = env23026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 262533 env23025 == env23026) = true)

def env23027 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,1,32768,65536,0,262144,272,32769,0,4194304,17,262533,9,17,4292997,1,1,1073741824,360597,1073842178,256,1078298925,1,512]

theorem envBound23027 : H12AffineFastState.Bounded env23027 := by
  intro p hp
  have h : env23027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23026_23027 : H12AffineEnvironment.transform 9 272 env23026 = env23027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env23026 == env23027) = true)

theorem identity23027 : scanCanonicalize (H12AffineFastState.compose env23027 (packedSelected [5] rootPS)) = affineNative (2^(14+1) ^^^ 2471) := by decide +kernel

theorem selectedBound23027 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23028 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,1,2471,65536,0,262144,272,2470,0,4194304,17,262533,9,17,4261922,1,1,1073741824,330034,1073807781,256,1078263946,1,512]

theorem envBound23028 : H12AffineFastState.Bounded env23028 := by
  intro p hp
  have h : env23028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23027_23028 : H12AffineEnvironment.transform 14 2471 env23027 = env23028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2471 env23027 == env23028) = true)

def env23029 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,1,2471,65536,0,262144,272,2470,0,4194304,17,262533,9,17,4261922,1,1,4260108,330034,4194473,256,262534,1,512]

theorem envBound23029 : H12AffineFastState.Bounded env23029 := by
  intro p hp
  have h : env23029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23028_23029 : H12AffineEnvironment.transform 29 4260108 env23028 = env23029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4260108 env23028 == env23029) = true)

theorem identity23029 : scanCanonicalize (H12AffineFastState.compose env23029 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 783) := by decide +kernel

theorem selectedBound23029 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23030 : List Nat := [2,4,8,16,32,17,128,256,512,272,783,0,129,1,680,65536,0,262144,272,681,0,4194304,17,262533,9,17,4260653,1,1,4260108,328253,4194473,256,262534,1,512]

theorem envBound23030 : H12AffineFastState.Bounded env23030 := by
  intro p hp
  have h : env23030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23029_23030 : H12AffineEnvironment.transform 10 783 env23029 = env23030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 783 env23029 == env23030) = true)

def env23031 : List Nat := [2,4,8,16,32,17,128,256,512,272,783,0,129,1,680,65536,0,262144,272,681,0,328320,17,262533,9,17,262573,1,1,263052,328253,328233,256,262534,1,512]

theorem envBound23031 : H12AffineFastState.Bounded env23031 := by
  intro p hp
  have h : env23031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23030_23031 : H12AffineEnvironment.transform 21 328320 env23030 = env23031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 328320 env23030 == env23031) = true)

theorem identity23031 : scanCanonicalize (H12AffineFastState.compose env23031 (packedSelected [3] rootPS)) = affineNative (2^(17+1) ^^^ 814) := by decide +kernel

theorem selectedBound23031 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23032 : List Nat := [2,4,8,16,32,17,128,256,512,272,783,0,129,1,680,65536,0,814,272,681,0,65966,17,683,9,17,643,1,1,162,65811,65799,256,680,1,512]

theorem envBound23032 : H12AffineFastState.Bounded env23032 := by
  intro p hp
  have h : env23032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23031_23032 : H12AffineEnvironment.transform 17 814 env23031 = env23032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 814 env23031 == env23032) = true)

theorem identity23032 : scanCanonicalize (H12AffineFastState.compose env23032 (packedSelected [12,13,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 651) := by decide +kernel

theorem selectedBound23032 : packedSelected [12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env23033 : List Nat := [2,4,8,16,32,17,128,256,512,272,783,0,129,1,680,651,0,814,272,681,0,805,17,683,9,17,643,1,1,162,920,908,256,680,1,512]

theorem envBound23033 : H12AffineFastState.Bounded env23033 := by
  intro p hp
  have h : env23033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23032_23033 : H12AffineEnvironment.transform 15 651 env23032 = env23033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 651 env23032 == env23033) = true)

theorem identity23033 : scanCanonicalize (H12AffineFastState.compose env23033 (packedSelected [8,10] rootPS)) = affineNative (2^(8+1) ^^^ 397) := by decide +kernel

theorem selectedBound23033 : packedSelected [8,10] rootPS < 2^1333 := by decide +kernel

def env23034 : List Nat := [2,4,8,16,32,17,128,256,397,272,130,0,129,1,293,262,0,163,272,292,0,168,17,294,9,17,270,1,1,162,21,1,256,293,1,397]

theorem envBound23034 : H12AffineFastState.Bounded env23034 := by
  intro p hp
  have h : env23034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23033_23034 : H12AffineEnvironment.transform 8 397 env23033 = env23034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 397 env23033 == env23034) = true)

theorem identity23034 : scanCanonicalize (H12AffineFastState.compose env23034 (packedSelected [0,4,6] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound23034 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env23035 : List Nat := [2,4,8,16,32,17,24,256,277,272,26,0,25,1,293,262,0,59,272,292,0,48,17,294,9,17,270,1,1,58,21,1,256,293,1,277]

theorem envBound23035 : H12AffineFastState.Bounded env23035 := by
  intro p hp
  have h : env23035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23034_23035 : H12AffineEnvironment.transform 6 24 env23034 = env23035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env23034 == env23035) = true)

theorem identity23035 : scanCanonicalize (H12AffineFastState.compose env23035 (packedSelected [8] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound23035 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23036 : List Nat := [2,4,8,16,32,17,24,53,32,37,26,0,25,1,16,51,0,59,37,17,0,48,17,19,9,17,59,1,1,58,21,1,53,16,1,32]

theorem envBound23036 : H12AffineFastState.Bounded env23036 := by
  intro p hp
  have h : env23036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23035_23036 : H12AffineEnvironment.transform 7 53 env23035 = env23036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env23035 == env23036) = true)

theorem identity23036 : scanCanonicalize (H12AffineFastState.compose env23036 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23036 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env23037 : List Nat := [2,4,8,0,32,1,8,37,32,37,10,0,9,1,0,35,0,43,37,1,0,32,1,3,9,1,43,1,1,42,5,1,37,0,1,32]

theorem envBound23037 : H12AffineFastState.Bounded env23037 := by
  intro p hp
  have h : env23037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23036_23037 : H12AffineEnvironment.transform 3 0 env23036 = env23037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23036 == env23037) = true)

theorem identity23037 : scanCanonicalize (H12AffineFastState.compose env23037 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23037 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23038 : List Nat := [2,4,8,0,0,1,8,5,0,5,10,0,9,1,0,3,0,11,5,1,0,0,1,3,9,1,11,1,1,10,5,1,5,0,1,0]

theorem envBound23038 : H12AffineFastState.Bounded env23038 := by
  intro p hp
  have h : env23038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23037_23038 : H12AffineEnvironment.transform 4 0 env23037 = env23038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23037 == env23038) = true)

theorem identity23038 : scanCanonicalize (H12AffineFastState.compose env23038 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound23038 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23039 : List Nat := [2,4,3,0,0,1,3,5,0,5,1,0,2,1,0,3,0,0,5,1,0,0,1,3,2,1,0,1,1,1,5,1,5,0,1,0]

theorem envBound23039 : H12AffineFastState.Bounded env23039 := by
  intro p hp
  have h : env23039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23038_23039 : H12AffineEnvironment.transform 2 3 env23038 = env23039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env23038 == env23039) = true)

def env23040 : List Nat := [2,4,8,16,32,17,128,256,512,272,783,0,129,1,680,65536,0,262144,272,681,0,328321,17,262533,9,17,262572,1,1,263053,328253,328232,256,262534,1,512]

theorem envBound23040 : H12AffineFastState.Bounded env23040 := by
  intro p hp
  have h : env23040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23030_23040 : H12AffineEnvironment.transform 21 328321 env23030 = env23040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 328321 env23030 == env23040) = true)

theorem identity23040 : scanCanonicalize (H12AffineFastState.compose env23040 (packedSelected [3] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound23040 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23041 : List Nat := [2,4,8,16,32,17,128,256,512,272,783,0,129,1,680,263,0,262144,272,681,0,263046,17,262533,9,17,262572,1,1,263053,262970,262959,256,262534,1,512]

theorem envBound23041 : H12AffineFastState.Bounded env23041 := by
  intro p hp
  have h : env23041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23040_23041 : H12AffineEnvironment.transform 15 263 env23040 = env23041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env23040 == env23041) = true)

theorem identity23041 : scanCanonicalize (H12AffineFastState.compose env23041 (packedSelected [12,13,15,17] rootPS)) = affineNative (2^(17+1) ^^^ 163) := by decide +kernel

theorem selectedBound23041 : packedSelected [12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env23042 : List Nat := [2,4,8,16,32,17,128,256,512,272,783,0,129,1,680,263,0,163,272,681,0,805,17,294,9,17,271,1,1,814,921,908,256,293,1,512]

theorem envBound23042 : H12AffineFastState.Bounded env23042 := by
  intro p hp
  have h : env23042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23041_23042 : H12AffineEnvironment.transform 17 163 env23041 = env23042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 163 env23041 == env23042) = true)

theorem identity23042 : scanCanonicalize (H12AffineFastState.compose env23042 (packedSelected [8,10] rootPS)) = affineNative (2^(8+1) ^^^ 396) := by decide +kernel

theorem selectedBound23042 : packedSelected [8,10] rootPS < 2^1333 := by decide +kernel

def env23043 : List Nat := [2,4,8,16,32,17,128,256,396,272,131,0,129,1,292,263,0,163,272,293,0,169,17,294,9,17,271,1,1,162,21,0,256,293,1,396]

theorem envBound23043 : H12AffineFastState.Bounded env23043 := by
  intro p hp
  have h : env23043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23042_23043 : H12AffineEnvironment.transform 8 396 env23042 = env23043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 396 env23042 == env23043) = true)

theorem identity23043 : scanCanonicalize (H12AffineFastState.compose env23043 (packedSelected [0,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound23043 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env23044 : List Nat := [2,4,8,16,32,17,128,53,185,37,131,0,129,1,17,50,0,163,37,16,0,169,17,19,9,17,58,1,1,162,21,0,53,16,1,185]

theorem envBound23044 : H12AffineFastState.Bounded env23044 := by
  intro p hp
  have h : env23044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23043_23044 : H12AffineEnvironment.transform 7 53 env23043 = env23044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env23043 == env23044) = true)

theorem identity23044 : scanCanonicalize (H12AffineFastState.compose env23044 (packedSelected [8] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound23044 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23045 : List Nat := [2,4,8,16,32,17,24,53,33,37,27,0,25,1,17,50,0,59,37,16,0,49,17,19,9,17,58,1,1,58,21,0,53,16,1,33]

theorem envBound23045 : H12AffineFastState.Bounded env23045 := by
  intro p hp
  have h : env23045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23044_23045 : H12AffineEnvironment.transform 6 24 env23044 = env23045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env23044 == env23045) = true)

theorem identity23045 : scanCanonicalize (H12AffineFastState.compose env23045 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound23045 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env23046 : List Nat := [2,4,8,1,32,0,9,36,33,37,10,0,8,1,0,35,0,42,37,1,0,32,0,2,9,0,43,1,1,43,4,0,36,1,1,33]

theorem envBound23046 : H12AffineFastState.Bounded env23046 := by
  intro p hp
  have h : env23046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23045_23046 : H12AffineEnvironment.transform 3 1 env23045 = env23046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env23045 == env23046) = true)

def env23047 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,1,2471,65536,0,262144,272,2470,0,4194304,17,262533,9,17,4261922,1,1,4260109,330034,4194472,256,262535,1,512]

theorem envBound23047 : H12AffineFastState.Bounded env23047 := by
  intro p hp
  have h : env23047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23028_23047 : H12AffineEnvironment.transform 29 4260109 env23028 = env23047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4260109 env23028 == env23047) = true)

theorem identity23047 : scanCanonicalize (H12AffineFastState.compose env23047 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 66089) := by decide +kernel

theorem selectedBound23047 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23048 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,1,2471,65536,0,66089,272,2470,0,4194304,17,66476,9,17,4261922,1,1,4260109,2843,4194472,256,66478,1,512]

theorem envBound23048 : H12AffineFastState.Bounded env23048 := by
  intro p hp
  have h : env23048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23047_23048 : H12AffineEnvironment.transform 17 66089 env23047 = env23048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 66089 env23047 == env23048) = true)

def env23049 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,1,2471,65536,0,66089,272,2470,0,168,17,66476,9,17,67722,1,1,65957,2843,0,256,66478,1,512]

theorem envBound23049 : H12AffineFastState.Bounded env23049 := by
  intro p hp
  have h : env23049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23048_23049 : H12AffineEnvironment.transform 21 168 env23048 = env23049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 168 env23048 == env23049) = true)

theorem identity23049 : scanCanonicalize (H12AffineFastState.compose env23049 (packedSelected [3] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound23049 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23050 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,1,2471,262,0,815,272,2470,0,168,17,682,9,17,2444,1,1,163,2843,0,256,680,1,512]

theorem envBound23050 : H12AffineFastState.Bounded env23050 := by
  intro p hp
  have h : env23050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23049_23050 : H12AffineEnvironment.transform 15 262 env23049 = env23050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env23049 == env23050) = true)

theorem identity23050 : scanCanonicalize (H12AffineFastState.compose env23050 (packedSelected [12,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound23050 : packedSelected [12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env23051 : List Nat := [2,4,8,16,32,17,128,256,512,272,131,0,129,1,292,262,0,815,272,293,0,168,17,682,9,17,271,1,1,163,920,0,256,680,1,512]

theorem envBound23051 : H12AffineFastState.Bounded env23051 := by
  intro p hp
  have h : env23051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23050_23051 : H12AffineEnvironment.transform 10 131 env23050 = env23051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env23050 == env23051) = true)

theorem identity23051 : scanCanonicalize (H12AffineFastState.compose env23051 (packedSelected [8,10] rootPS)) = affineNative (2^(8+1) ^^^ 397) := by decide +kernel

theorem selectedBound23051 : packedSelected [8,10] rootPS < 2^1333 := by decide +kernel

def env23052 : List Nat := [2,4,8,16,32,17,128,256,397,272,131,0,129,1,292,262,0,162,272,293,0,168,17,295,9,17,271,1,1,163,21,0,256,293,1,397]

theorem envBound23052 : H12AffineFastState.Bounded env23052 := by
  intro p hp
  have h : env23052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23051_23052 : H12AffineEnvironment.transform 8 397 env23051 = env23052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 397 env23051 == env23052) = true)

theorem identity23052 : scanCanonicalize (H12AffineFastState.compose env23052 (packedSelected [0,4,6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound23052 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env23053 : List Nat := [2,4,8,1,32,0,128,256,397,257,131,0,129,1,292,262,0,162,257,293,0,168,0,295,9,0,271,1,1,163,4,0,256,293,1,397]

theorem envBound23053 : H12AffineFastState.Bounded env23053 := by
  intro p hp
  have h : env23053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23052_23053 : H12AffineEnvironment.transform 3 1 env23052 = env23053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env23052 == env23053) = true)

theorem identity23053 : scanCanonicalize (H12AffineFastState.compose env23053 (packedSelected [8] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound23053 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23054 : List Nat := [2,4,8,1,32,0,128,172,33,173,131,0,129,1,136,170,0,162,173,137,0,168,0,139,9,0,163,1,1,163,4,0,172,137,1,33]

theorem envBound23054 : H12AffineFastState.Bounded env23054 := by
  intro p hp
  have h : env23054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23053_23054 : H12AffineEnvironment.transform 7 172 env23053 = env23054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env23053 == env23054) = true)

theorem identity23054 : scanCanonicalize (H12AffineFastState.compose env23054 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound23054 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env23055 : List Nat := [2,4,8,1,32,0,8,36,33,37,11,0,9,1,0,34,0,42,37,1,0,32,0,3,9,0,43,1,1,43,4,0,36,1,1,33]

theorem envBound23055 : H12AffineFastState.Bounded env23055 := by
  intro p hp
  have h : env23055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23054_23055 : H12AffineEnvironment.transform 6 8 env23054 = env23055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23054 == env23055) = true)

def env23056 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,1,2471,65536,0,66089,272,2470,0,169,17,66476,9,17,67723,1,1,65956,2843,1,256,66478,1,512]

theorem envBound23056 : H12AffineFastState.Bounded env23056 := by
  intro p hp
  have h : env23056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23048_23056 : H12AffineEnvironment.transform 21 169 env23048 = env23056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169 env23048 == env23056) = true)

theorem identity23056 : scanCanonicalize (H12AffineFastState.compose env23056 (packedSelected [3] rootPS)) = affineNative (2^(15+1) ^^^ 2569) := by decide +kernel

theorem selectedBound23056 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23057 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,1,2471,2569,0,2080,272,2470,0,169,17,2469,9,17,642,1,1,2989,2843,1,256,2471,1,512]

theorem envBound23057 : H12AffineFastState.Bounded env23057 := by
  intro p hp
  have h : env23057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23056_23057 : H12AffineEnvironment.transform 15 2569 env23056 = env23057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2569 env23056 == env23057) = true)

theorem identity23057 : scanCanonicalize (H12AffineFastState.compose env23057 (packedSelected [12,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound23057 : packedSelected [12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env23058 : List Nat := [2,4,8,16,32,17,128,256,512,272,130,0,129,1,293,651,0,162,272,292,0,169,17,295,9,17,642,1,1,815,921,1,256,293,1,512]

theorem envBound23058 : H12AffineFastState.Bounded env23058 := by
  intro p hp
  have h : env23058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23057_23058 : H12AffineEnvironment.transform 10 130 env23057 = env23058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env23057 == env23058) = true)

theorem identity23058 : scanCanonicalize (H12AffineFastState.compose env23058 (packedSelected [8,10] rootPS)) = affineNative (2^(8+1) ^^^ 396) := by decide +kernel

theorem selectedBound23058 : packedSelected [8,10] rootPS < 2^1333 := by decide +kernel

def env23059 : List Nat := [2,4,8,16,32,17,128,256,396,272,130,0,129,1,293,263,0,162,272,292,0,169,17,295,9,17,270,1,1,163,21,1,256,293,1,396]

theorem envBound23059 : H12AffineFastState.Bounded env23059 := by
  intro p hp
  have h : env23059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23058_23059 : H12AffineEnvironment.transform 8 396 env23058 = env23059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 396 env23058 == env23059) = true)

theorem identity23059 : scanCanonicalize (H12AffineFastState.compose env23059 (packedSelected [0,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 188) := by decide +kernel

theorem selectedBound23059 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2