import H12CloudChart2Data236

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound59864 : packedSelected [0,1,2,3,7,10,11,15] rootPS < 2^1333 := by decide +kernel

def env59865 : List Nat := [2,4,8,16,32,64,128,256,136,273,439,324,349,0,0,115,80,243,4,1,324,200,17,50,192,341,367,1,0,390,337,16,256,340,80,412]

theorem envBound59865 : H12AffineFastState.Bounded env59865 := by
  intro p hp
  have h : env59865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59864_59865 : H12AffineEnvironment.transform 10 439 env59864 = env59865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 439 env59864 == env59865) = true)

theorem identity59865 : scanCanonicalize (H12AffineFastState.compose env59865 (packedSelected [0,2,4,5,7,8,9,10,11,12,16] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound59865 : packedSelected [0,2,4,5,7,8,9,10,11,12,16] rootPS < 2^1333 := by decide +kernel

def env59866 : List Nat := [2,4,8,16,32,33,128,256,136,273,439,293,316,0,0,18,49,146,4,1,293,169,17,50,161,308,270,1,0,390,304,16,256,309,49,412]

theorem envBound59866 : H12AffineFastState.Bounded env59866 := by
  intro p hp
  have h : env59866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59865_59866 : H12AffineEnvironment.transform 5 33 env59865 = env59866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env59865 == env59866) = true)

theorem identity59866 : scanCanonicalize (H12AffineFastState.compose env59866 (packedSelected [0,1,2,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound59866 : packedSelected [0,1,2,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59867 : List Nat := [2,4,8,16,32,33,128,134,136,151,49,163,186,0,0,18,49,146,4,1,163,169,17,50,161,178,136,1,0,0,182,16,134,179,49,26]

theorem envBound59867 : H12AffineFastState.Bounded env59867 := by
  intro p hp
  have h : env59867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59866_59867 : H12AffineEnvironment.transform 7 134 env59866 = env59867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env59866 == env59867) = true)

theorem identity59867 : scanCanonicalize (H12AffineFastState.compose env59867 (packedSelected [2,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound59867 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env59868 : List Nat := [2,4,8,16,32,33,57,63,49,46,49,26,3,0,0,18,49,43,4,1,26,16,17,50,24,11,49,1,0,0,15,16,63,10,49,26]

theorem envBound59868 : H12AffineFastState.Bounded env59868 := by
  intro p hp
  have h : env59868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59867_59868 : H12AffineEnvironment.transform 6 57 env59867 = env59868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env59867 == env59868) = true)

theorem identity59868 : scanCanonicalize (H12AffineFastState.compose env59868 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound59868 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env59869 : List Nat := [2,4,8,16,11,10,18,20,26,5,26,26,3,0,0,18,26,0,4,1,26,16,17,25,24,11,26,1,0,0,15,16,20,10,26,26]

theorem envBound59869 : H12AffineFastState.Bounded env59869 := by
  intro p hp
  have h : env59869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59868_59869 : H12AffineEnvironment.transform 4 11 env59868 = env59869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env59868 == env59869) = true)

def env59870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1297,5204,5158,1344,5286,4416,5205,4096,5277,16,4470,193,5377,1150,1297,1297,7269,5381,1280,256,5376,1345,5953]

theorem envBound59870 : H12AffineFastState.Bounded env59870 := by
  intro p hp
  have h : env59870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59860_59870 : H12AffineEnvironment.transform 12 5385 env59860 = env59870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env59860 == env59870) = true)

theorem identity59870 : scanCanonicalize (H12AffineFastState.compose env59870 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound59870 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env59871 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,4096,5197,1109,5204,5158,1028,5286,4100,5205,4096,5277,16,4146,193,5189,1150,1109,1109,7269,5185,1092,68,5188,1029,5637]

theorem envBound59871 : H12AffineFastState.Bounded env59871 := by
  intro p hp
  have h : env59871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59870_59871 : H12AffineEnvironment.transform 7 68 env59870 = env59871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env59870 == env59871) = true)

theorem identity59871 : scanCanonicalize (H12AffineFastState.compose env59871 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound59871 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env59872 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1029,72,1109,81,35,1028,163,1025,80,1029,152,16,1079,193,64,1150,1109,1109,2144,68,1092,68,65,1029,512]

theorem envBound59872 : H12AffineFastState.Bounded env59872 := by
  intro p hp
  have h : env59872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59871_59872 : H12AffineEnvironment.transform 11 1029 env59871 = env59872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env59871 == env59872) = true)

theorem identity59872 : scanCanonicalize (H12AffineFastState.compose env59872 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound59872 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env59873 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,1,72,81,81,35,0,163,5,80,1,152,16,51,193,64,122,81,81,2144,68,64,68,65,1,512]

theorem envBound59873 : H12AffineFastState.Bounded env59873 := by
  intro p hp
  have h : env59873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59872_59873 : H12AffineEnvironment.transform 9 4 env59872 = env59873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env59872 == env59873) = true)

theorem identity59873 : scanCanonicalize (H12AffineFastState.compose env59873 (packedSelected [2,8] rootPS)) = affineNative (2^(10+1) ^^^ 142) := by decide +kernel

theorem selectedBound59873 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env59874 : List Nat := [2,4,8,16,32,64,128,68,512,4,142,1,72,81,81,35,0,163,5,80,1,152,16,51,193,64,122,81,81,238,68,64,68,65,1,512]

theorem envBound59874 : H12AffineFastState.Bounded env59874 := by
  intro p hp
  have h : env59874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59873_59874 : H12AffineEnvironment.transform 10 142 env59873 = env59874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 142 env59873 == env59874) = true)

theorem identity59874 : scanCanonicalize (H12AffineFastState.compose env59874 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound59874 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59875 : List Nat := [2,4,8,16,32,64,128,68,216,4,142,1,72,81,81,35,0,163,5,80,1,152,16,51,193,64,122,81,81,238,68,64,68,65,1,216]

theorem envBound59875 : H12AffineFastState.Bounded env59875 := by
  intro p hp
  have h : env59875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59874_59875 : H12AffineEnvironment.transform 8 216 env59874 = env59875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env59874 == env59875) = true)

theorem identity59875 : scanCanonicalize (H12AffineFastState.compose env59875 (packedSelected [1,2,12] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound59875 : packedSelected [1,2,12] rootPS < 2^1333 := by decide +kernel

def env59876 : List Nat := [2,4,8,16,32,64,35,68,123,4,45,1,72,81,81,35,0,0,5,80,1,59,16,51,98,64,122,81,81,77,68,64,68,65,1,123]

theorem envBound59876 : H12AffineFastState.Bounded env59876 := by
  intro p hp
  have h : env59876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59875_59876 : H12AffineEnvironment.transform 6 35 env59875 = env59876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env59875 == env59876) = true)

theorem identity59876 : scanCanonicalize (H12AffineFastState.compose env59876 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound59876 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59877 : List Nat := [2,4,8,16,32,13,35,9,54,4,45,1,5,28,28,35,0,0,5,29,1,59,16,51,47,13,55,28,28,0,9,13,9,12,1,54]

theorem envBound59877 : H12AffineFastState.Bounded env59877 := by
  intro p hp
  have h : env59877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59876_59877 : H12AffineEnvironment.transform 5 13 env59876 = env59877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env59876 == env59877) = true)

def env59878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65665,4416,8540,4096,5277,74047,66896,13768,78894,1151,74814,1297,81226,8204,74799,256,8201,1345,5953]

theorem envBound59878 : H12AffineFastState.Bounded env59878 := by
  intro p hp
  have h : env59878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59858_59878 : H12AffineEnvironment.transform 17 65665 env59858 = env59878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env59858 == env59878) = true)

theorem identity59878 : scanCanonicalize (H12AffineFastState.compose env59878 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 358) := by decide +kernel

theorem selectedBound59878 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,358,9481,487,4416,8540,4096,5277,8281,1078,13768,13640,1151,9560,1297,15404,8204,9545,256,8201,1345,5953]

theorem envBound59879 : H12AffineFastState.Bounded env59879 := by
  intro p hp
  have h : env59879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59878_59879 : H12AffineEnvironment.transform 15 358 env59878 = env59879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 358 env59878 == env59879) = true)

def env59880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1297,277,358,1345,487,4416,276,4096,5277,17,1078,5504,5376,1151,1296,1297,7268,68,1281,256,65,1345,5953]

theorem envBound59880 : H12AffineFastState.Bounded env59880 := by
  intro p hp
  have h : env59880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59879_59880 : H12AffineEnvironment.transform 12 72 env59879 = env59880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env59879 == env59880) = true)

theorem identity59880 : scanCanonicalize (H12AffineFastState.compose env59880 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound59880 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env59881 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,72,1297,277,358,1345,487,273,276,81,1228,17,1078,1489,1361,1151,1296,1297,3125,68,1281,256,65,1345,1808]

theorem envBound59881 : H12AffineFastState.Bounded env59881 := by
  intro p hp
  have h : env59881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59880_59881 : H12AffineEnvironment.transform 11 81 env59880 = env59881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env59880 == env59881) = true)

theorem identity59881 : scanCanonicalize (H12AffineFastState.compose env59881 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 413) := by decide +kernel

theorem selectedBound59881 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env59882 : List Nat := [2,4,8,16,32,64,128,256,413,1024,2048,81,72,1297,277,358,1345,487,273,276,81,1228,17,1078,1489,1361,1151,1296,1297,3125,68,1281,256,65,1345,1165]

theorem envBound59882 : H12AffineFastState.Bounded env59882 := by
  intro p hp
  have h : env59882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59881_59882 : H12AffineEnvironment.transform 8 413 env59881 = env59882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 413 env59881 == env59882) = true)

theorem identity59882 : scanCanonicalize (H12AffineFastState.compose env59882 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound59882 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env59883 : List Nat := [2,4,8,16,32,64,128,21,136,1024,2048,81,72,1028,0,115,1108,242,4,1,81,1228,17,1078,1220,1092,1151,1029,1028,3125,68,1044,21,65,1108,1165]

theorem envBound59883 : H12AffineFastState.Bounded env59883 := by
  intro p hp
  have h : env59883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59882_59883 : H12AffineEnvironment.transform 7 21 env59882 = env59883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env59882 == env59883) = true)

theorem identity59883 : scanCanonicalize (H12AffineFastState.compose env59883 (packedSelected [2,3,4,5,9,10,15,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound59883 : packedSelected [2,3,4,5,9,10,15,16,17] rootPS < 2^1333 := by decide +kernel

def env59884 : List Nat := [2,4,8,16,32,64,128,21,136,1024,1212,81,72,1028,0,115,1108,242,4,1,81,1228,17,1078,1220,1092,1151,1029,1028,137,68,1044,21,65,1108,1165]

theorem envBound59884 : H12AffineFastState.Bounded env59884 := by
  intro p hp
  have h : env59884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59883_59884 : H12AffineEnvironment.transform 10 1212 env59883 = env59884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env59883 == env59884) = true)

theorem identity59884 : scanCanonicalize (H12AffineFastState.compose env59884 (packedSelected [0,1,2,3,7,10,11,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound59884 : packedSelected [0,1,2,3,7,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env59885 : List Nat := [2,4,8,16,32,64,128,21,136,141,49,81,72,137,0,115,217,242,4,1,81,65,17,187,73,201,242,136,137,137,68,153,21,65,217,0]

theorem envBound59885 : H12AffineFastState.Bounded env59885 := by
  intro p hp
  have h : env59885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59884_59885 : H12AffineEnvironment.transform 9 141 env59884 = env59885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env59884 == env59885) = true)

theorem identity59885 : scanCanonicalize (H12AffineFastState.compose env59885 (packedSelected [0,1,2,3,5,7,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound59885 : packedSelected [0,1,2,3,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env59886 : List Nat := [2,4,8,16,32,64,104,21,96,101,49,81,72,97,0,115,49,26,4,1,81,65,17,83,73,33,26,96,97,97,68,113,21,65,49,0]

theorem envBound59886 : H12AffineFastState.Bounded env59886 := by
  intro p hp
  have h : env59886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59885_59886 : H12AffineEnvironment.transform 6 104 env59885 = env59886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env59885 == env59886) = true)

theorem identity59886 : scanCanonicalize (H12AffineFastState.compose env59886 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound59886 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59887 : List Nat := [2,4,8,16,32,32,8,21,0,5,49,49,40,1,0,19,49,26,4,1,49,33,17,51,41,33,26,0,1,1,36,17,21,33,49,0]

theorem envBound59887 : H12AffineFastState.Bounded env59887 := by
  intro p hp
  have h : env59887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59886_59887 : H12AffineEnvironment.transform 5 32 env59886 = env59887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env59886 == env59887) = true)

theorem identity59887 : scanCanonicalize (H12AffineFastState.compose env59887 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound59887 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59888 : List Nat := [2,4,8,16,11,11,8,21,0,5,26,26,3,1,0,19,26,26,4,1,26,10,17,24,2,10,26,0,1,1,15,17,21,10,26,0]

theorem envBound59888 : H12AffineFastState.Bounded env59888 := by
  intro p hp
  have h : env59888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59887_59888 : H12AffineEnvironment.transform 4 11 env59887 = env59888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env59887 == env59888) = true)

theorem identity59888 : scanCanonicalize (H12AffineFastState.compose env59888 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound59888 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59889 : List Nat := [2,4,8,11,11,11,8,14,0,5,1,1,3,1,0,8,1,1,4,1,1,10,10,3,2,10,1,0,1,1,15,10,14,10,1,0]

theorem envBound59889 : H12AffineFastState.Bounded env59889 := by
  intro p hp
  have h : env59889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59888_59889 : H12AffineEnvironment.transform 3 11 env59888 = env59889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env59888 == env59889) = true)

theorem identity59889 : scanCanonicalize (H12AffineFastState.compose env59889 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound59889 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59890 : List Nat := [2,4,4,7,7,7,4,2,0,5,1,1,3,1,0,4,1,1,4,1,1,6,6,3,2,6,1,0,1,1,3,6,2,6,1,0]

theorem envBound59890 : H12AffineFastState.Bounded env59890 := by
  intro p hp
  have h : env59890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59889_59890 : H12AffineEnvironment.transform 2 4 env59889 = env59890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env59889 == env59890) = true)

def env59891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1297,276,358,1344,487,4416,277,4096,5277,16,1078,5505,5377,1151,1297,1297,7269,69,1280,256,64,1345,5953]

theorem envBound59891 : H12AffineFastState.Bounded env59891 := by
  intro p hp
  have h : env59891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59879_59891 : H12AffineEnvironment.transform 12 73 env59879 = env59891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env59879 == env59891) = true)

theorem identity59891 : scanCanonicalize (H12AffineFastState.compose env59891 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound59891 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env59892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1028,73,1297,276,358,1344,487,1348,277,1028,153,16,1078,389,261,1151,1297,1297,2145,69,1280,256,64,1345,837]

theorem envBound59892 : H12AffineFastState.Bounded env59892 := by
  intro p hp
  have h : env59892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59891_59892 : H12AffineEnvironment.transform 11 1028 env59891 = env59892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env59891 == env59892) = true)

theorem identity59892 : scanCanonicalize (H12AffineFastState.compose env59892 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound59892 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env59893 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,1028,73,1108,81,35,1029,162,1025,80,1028,153,16,1078,192,64,1151,1108,1108,2145,69,1093,69,64,1028,512]

theorem envBound59893 : H12AffineFastState.Bounded env59893 := by
  intro p hp
  have h : env59893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59892_59893 : H12AffineEnvironment.transform 7 69 env59892 = env59893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env59892 == env59893) = true)

theorem identity59893 : scanCanonicalize (H12AffineFastState.compose env59893 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound59893 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env59894 : List Nat := [2,4,8,16,32,64,128,69,512,1024,147,1028,73,1108,81,35,1029,162,1025,80,1028,153,16,1078,192,64,1151,1108,1108,242,69,1093,69,64,1028,512]

theorem envBound59894 : H12AffineFastState.Bounded env59894 := by
  intro p hp
  have h : env59894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59893_59894 : H12AffineEnvironment.transform 10 147 env59893 = env59894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env59893 == env59894) = true)

theorem identity59894 : scanCanonicalize (H12AffineFastState.compose env59894 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound59894 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env59895 : List Nat := [2,4,8,16,32,64,128,69,49,1024,147,1028,73,1108,81,35,1029,162,1025,80,1028,153,16,1078,192,64,1151,1108,1108,242,69,1093,69,64,1028,49]

theorem envBound59895 : H12AffineFastState.Bounded env59895 := by
  intro p hp
  have h : env59895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59894_59895 : H12AffineEnvironment.transform 8 49 env59894 = env59895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env59894 == env59895) = true)

theorem identity59895 : scanCanonicalize (H12AffineFastState.compose env59895 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound59895 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env59896 : List Nat := [2,4,8,16,32,64,128,69,49,189,147,185,73,233,81,35,184,162,188,80,185,153,16,139,192,64,194,233,233,242,69,248,69,64,185,49]

theorem envBound59896 : H12AffineFastState.Bounded env59896 := by
  intro p hp
  have h : env59896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59895_59896 : H12AffineEnvironment.transform 9 189 env59895 = env59896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env59895 == env59896) = true)

theorem identity59896 : scanCanonicalize (H12AffineFastState.compose env59896 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound59896 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env59897 : List Nat := [2,4,8,16,32,64,56,69,49,5,43,1,73,81,81,35,0,26,4,80,1,33,16,51,120,64,122,81,81,74,69,64,69,64,1,49]

theorem envBound59897 : H12AffineFastState.Bounded env59897 := by
  intro p hp
  have h : env59897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59896_59897 : H12AffineEnvironment.transform 6 56 env59896 = env59897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env59896 == env59897) = true)

theorem identity59897 : scanCanonicalize (H12AffineFastState.compose env59897 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound59897 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env59898 : List Nat := [2,4,8,11,32,64,35,69,42,5,43,1,73,74,74,35,0,1,4,75,1,33,11,40,99,64,97,74,74,74,69,64,69,64,1,42]

theorem envBound59898 : H12AffineFastState.Bounded env59898 := by
  intro p hp
  have h : env59898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59897_59898 : H12AffineEnvironment.transform 3 11 env59897 = env59898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env59897 == env59898) = true)

theorem identity59898 : scanCanonicalize (H12AffineFastState.compose env59898 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 44) := by decide +kernel

theorem selectedBound59898 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59899 : List Nat := [2,4,8,11,32,44,35,41,42,5,43,1,37,38,38,35,0,1,4,39,1,33,11,40,15,44,13,38,38,38,41,44,41,44,1,42]

theorem envBound59899 : H12AffineFastState.Bounded env59899 := by
  intro p hp
  have h : env59899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59898_59899 : H12AffineEnvironment.transform 5 44 env59898 = env59899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env59898 == env59899) = true)

def env59900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4096,61649,91182,123165,533640,614527,385203,90415,545088,96347,25884,74799,256,536904,1345,525825]

theorem envBound59900 : H12AffineFastState.Bounded env59900 := by
  intro p hp
  have h : env59900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59710_59900 : H12AffineEnvironment.transform 23 123165 env59710 = env59900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env59710 == env59900) = true)

def env59901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4096,61649,91182,123165,28888,78895,385203,90415,1296,96347,25884,74799,256,25880,1345,21073]

theorem envBound59901 : H12AffineFastState.Bounded env59901 := by
  intro p hp
  have h : env59901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59900_59901 : H12AffineEnvironment.transform 18 21584 env59900 = env59901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env59900 == env59901) = true)

theorem identity59901 : scanCanonicalize (H12AffineFastState.compose env59901 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound59901 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env59902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74863,262144,21584,13340,4096,17612,91182,87296,28888,78895,349358,90415,1296,96347,25884,74799,256,25880,1345,21073]

theorem envBound59902 : H12AffineFastState.Bounded env59902 := by
  intro p hp
  have h : env59902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59901_59902 : H12AffineEnvironment.transform 14 13341 env59901 = env59902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env59901 == env59902) = true)

def env59903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,262144,4416,13340,4096,476,74046,69648,13768,78895,332222,74815,1296,81227,8204,74799,256,8200,1345,5953]

theorem envBound59903 : H12AffineFastState.Bounded env59903 := by
  intro p hp
  have h : env59903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59902_59903 : H12AffineEnvironment.transform 13 1296 env59902 = env59903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env59902 == env59903) = true)

def env59904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65664,4416,13340,4096,476,74046,69648,13768,78895,4414,74815,1296,81227,8204,74799,256,8200,1345,5953]

theorem envBound59904 : H12AffineFastState.Bounded env59904 := by
  intro p hp
  have h : env59904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59903_59904 : H12AffineEnvironment.transform 17 65664 env59903 = env59904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env59903 == env59904) = true)

theorem identity59904 : scanCanonicalize (H12AffineFastState.compose env59904 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound59904 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59905 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9244,65536,74863,65664,321,9245,1,476,74046,65553,9673,74798,319,74815,1296,77130,8204,74799,256,8200,1345,1856]

theorem envBound59905 : H12AffineFastState.Bounded env59905 := by
  intro p hp
  have h : env59905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59904_59905 : H12AffineEnvironment.transform 11 1 env59904 = env59905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env59904 == env59905) = true)

def env59906 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,8192,1296,9244,65536,74863,65664,321,9245,1,476,74046,65553,9673,74798,319,74815,1296,77130,8204,74799,256,8200,1345,1044]

theorem envBound59906 : H12AffineFastState.Bounded env59906 := by
  intro p hp
  have h : env59906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59905_59906 : H12AffineEnvironment.transform 8 340 env59905 = env59906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env59905 == env59906) = true)

def env59907 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,1,8192,1280,9228,65536,74863,65664,321,9229,1,460,74030,65537,9673,74798,303,74799,1280,77130,8204,74799,256,8200,1345,1028]

theorem envBound59907 : H12AffineFastState.Bounded env59907 := by
  intro p hp
  have h : env59907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59906_59907 : H12AffineEnvironment.transform 3 0 env59906 = env59907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env59906 == env59907) = true)

theorem identity59907 : scanCanonicalize (H12AffineFastState.compose env59907 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1510) := by decide +kernel

theorem selectedBound59907 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env59908 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,1,8192,1280,9228,1510,8585,1382,321,9229,1,460,9416,1511,9673,8648,303,8649,1280,10412,8204,8649,256,8200,1345,1028]

theorem envBound59908 : H12AffineFastState.Bounded env59908 := by
  intro p hp
  have h : env59908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59907_59908 : H12AffineEnvironment.transform 15 1510 env59907 = env59908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1510 env59907 == env59908) = true)

def env59909 : List Nat := [2,4,8,0,32,64,128,256,324,1024,1092,1,8192,1280,9228,1510,8585,1382,321,9229,1,460,9416,1511,9673,8648,303,8649,1280,9448,8204,8649,256,8200,1345,1028]

theorem envBound59909 : H12AffineFastState.Bounded env59909 := by
  intro p hp
  have h : env59909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59908_59909 : H12AffineEnvironment.transform 10 1092 env59908 = env59909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1092 env59908 == env59909) = true)

theorem identity59909 : scanCanonicalize (H12AffineFastState.compose env59909 (packedSelected [0,1,2,3,4,5,9,11,12,15,16,18,24,27,41] rootPS)) = affineNative (2^(12+1) ^^^ 1160) := by decide +kernel

theorem selectedBound59909 : packedSelected [0,1,2,3,4,5,9,11,12,15,16,18,24,27,41] rootPS < 2^1333 := by decide +kernel

def env59910 : List Nat := [2,4,8,0,32,64,128,256,324,1024,1092,1,1160,1280,132,1510,1281,1382,321,133,1,460,64,1511,321,1344,303,1345,1280,96,1156,1345,256,1152,1345,1028]

theorem envBound59910 : H12AffineFastState.Bounded env59910 := by
  intro p hp
  have h : env59910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59909_59910 : H12AffineEnvironment.transform 12 1160 env59909 = env59910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1160 env59909 == env59910) = true)

theorem identity59910 : scanCanonicalize (H12AffineFastState.compose env59910 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 69) := by decide +kernel

theorem selectedBound59910 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59911 : List Nat := [2,4,8,0,32,64,69,256,324,1024,1092,1,1101,1280,65,1315,1281,1382,321,64,1,265,64,1314,321,1344,303,1345,1280,96,1089,1345,256,1093,1345,1028]

theorem envBound59911 : H12AffineFastState.Bounded env59911 := by
  intro p hp
  have h : env59911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59910_59911 : H12AffineEnvironment.transform 6 69 env59910 = env59911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 69 env59910 == env59911) = true)

theorem identity59911 : scanCanonicalize (H12AffineFastState.compose env59911 (packedSelected [0,3,7,8,10,11,12,13,15,17] rootPS)) = affineNative (2^(9+1) ^^^ 105) := by decide +kernel

theorem selectedBound59911 : packedSelected [0,3,7,8,10,11,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env59912 : List Nat := [2,4,8,0,32,64,69,256,324,105,45,1,36,361,65,330,360,271,321,64,1,265,64,331,321,297,303,296,361,96,40,296,256,44,296,109]

theorem envBound59912 : H12AffineFastState.Bounded env59912 := by
  intro p hp
  have h : env59912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59911_59912 : H12AffineEnvironment.transform 9 105 env59911 = env59912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 105 env59911 == env59912) = true)

theorem identity59912 : scanCanonicalize (H12AffineFastState.compose env59912 (packedSelected [1,3,4,7,8,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 73) := by decide +kernel

theorem selectedBound59912 : packedSelected [1,3,4,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env59913 : List Nat := [2,4,8,0,32,64,69,73,13,105,45,1,36,32,65,3,33,70,8,64,1,64,64,2,8,96,102,97,32,96,40,97,73,44,97,109]

theorem envBound59913 : H12AffineFastState.Bounded env59913 := by
  intro p hp
  have h : env59913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59912_59913 : H12AffineEnvironment.transform 7 73 env59912 = env59913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 73 env59912 == env59913) = true)

theorem identity59913 : scanCanonicalize (H12AffineFastState.compose env59913 (packedSelected [3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound59913 : packedSelected [3,5,8] rootPS < 2^1333 := by decide +kernel

def env59914 : List Nat := [2,4,8,0,32,10,15,3,13,35,45,1,36,32,11,3,33,12,8,10,1,10,10,2,8,42,44,43,32,42,40,43,3,44,43,39]

theorem envBound59914 : H12AffineFastState.Bounded env59914 := by
  intro p hp
  have h : env59914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59913_59914 : H12AffineEnvironment.transform 5 10 env59913 = env59914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env59913 == env59914) = true)

theorem identity59914 : scanCanonicalize (H12AffineFastState.compose env59914 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound59914 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59915 : List Nat := [2,4,8,0,10,10,15,3,13,9,7,1,14,10,11,3,11,12,8,10,1,10,10,2,8,0,6,1,10,0,2,1,3,6,1,13]

theorem envBound59915 : H12AffineFastState.Bounded env59915 := by
  intro p hp
  have h : env59915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59914_59915 : H12AffineEnvironment.transform 4 10 env59914 = env59915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env59914 == env59915) = true)

theorem identity59915 : scanCanonicalize (H12AffineFastState.compose env59915 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound59915 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59916 : List Nat := [2,4,4,0,6,6,3,3,1,5,7,1,2,6,7,3,7,0,4,6,1,6,6,2,4,0,6,1,6,0,2,1,3,6,1,1]

theorem envBound59916 : H12AffineFastState.Bounded env59916 := by
  intro p hp
  have h : env59916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59915_59916 : H12AffineEnvironment.transform 2 4 env59915 = env59916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env59915 == env59916) = true)

theorem identity59916 : scanCanonicalize (H12AffineFastState.compose env59916 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound59916 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59917 : List Nat := [2,2,2,0,0,0,3,3,1,3,1,1,2,0,1,3,1,0,2,0,1,0,0,2,2,0,0,1,0,0,2,1,3,0,1,1]

theorem envBound59917 : H12AffineFastState.Bounded env59917 := by
  intro p hp
  have h : env59917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59916_59917 : H12AffineEnvironment.transform 1 2 env59916 = env59917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env59916 == env59917) = true)

def env59918 : List Nat := [2,4,8,0,32,64,128,256,324,1024,1093,1,8192,1280,9228,1510,8585,1382,321,9229,1,460,9416,1511,9673,8648,303,8649,1280,9449,8204,8649,256,8200,1345,1028]

theorem envBound59918 : H12AffineFastState.Bounded env59918 := by
  intro p hp
  have h : env59918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59908_59918 : H12AffineEnvironment.transform 10 1093 env59908 = env59918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1093 env59908 == env59918) = true)

theorem identity59918 : scanCanonicalize (H12AffineFastState.compose env59918 (packedSelected [0,1,2,3,4,5,9,11,12,15,16,18,24,27,41] rootPS)) = affineNative (2^(12+1) ^^^ 1352) := by decide +kernel

theorem selectedBound59918 : packedSelected [0,1,2,3,4,5,9,11,12,15,16,18,24,27,41] rootPS < 2^1333 := by decide +kernel

def env59919 : List Nat := [2,4,8,0,32,64,128,256,324,1024,1093,1,1352,1280,324,1510,1217,1382,321,325,1,460,384,1511,129,1152,303,1153,1280,417,1348,1153,256,1344,1345,1028]

theorem envBound59919 : H12AffineFastState.Bounded env59919 := by
  intro p hp
  have h : env59919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59918_59919 : H12AffineEnvironment.transform 12 1352 env59918 = env59919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1352 env59918 == env59919) = true)

theorem identity59919 : scanCanonicalize (H12AffineFastState.compose env59919 (packedSelected [0,3,4,7,9,16,17,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 46) := by decide +kernel

theorem selectedBound59919 : packedSelected [0,3,4,7,9,16,17,20,21] rootPS < 2^1333 := by decide +kernel

def env59920 : List Nat := [2,4,8,0,32,64,128,46,106,1024,1093,1,1126,1070,106,1224,1217,1096,111,107,1,226,174,1225,129,1152,1,1153,1070,143,1130,1153,46,1134,1135,1028]

theorem envBound59920 : H12AffineFastState.Bounded env59920 := by
  intro p hp
  have h : env59920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59919_59920 : H12AffineEnvironment.transform 7 46 env59919 = env59920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 46 env59919 == env59920) = true)

theorem identity59920 : scanCanonicalize (H12AffineFastState.compose env59920 (packedSelected [1,2,5,11,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound59920 : packedSelected [1,2,5,11,17,18] rootPS < 2^1333 := by decide +kernel

def env59921 : List Nat := [2,4,8,0,32,0,128,46,42,1024,1029,1,1062,1070,42,1160,1153,1032,47,43,1,162,174,1161,129,1152,1,1153,1070,143,1066,1153,46,1070,1071,1028]

theorem envBound59921 : H12AffineFastState.Bounded env59921 := by
  intro p hp
  have h : env59921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59920_59921 : H12AffineEnvironment.transform 5 0 env59920 = env59921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env59920 == env59921) = true)

theorem identity59921 : scanCanonicalize (H12AffineFastState.compose env59921 (packedSelected [0,1,2,3,4,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound59921 : packedSelected [0,1,2,3,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59922 : List Nat := [2,4,8,0,32,0,128,46,42,36,33,1,2,10,42,172,165,44,47,43,1,162,174,173,129,164,1,165,10,143,14,165,46,10,11,32]

theorem envBound59922 : H12AffineFastState.Bounded env59922 := by
  intro p hp
  have h : env59922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59921_59922 : H12AffineEnvironment.transform 9 36 env59921 = env59922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env59921 == env59922) = true)

theorem identity59922 : scanCanonicalize (H12AffineFastState.compose env59922 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound59922 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59923 : List Nat := [2,4,8,0,32,0,4,46,42,36,33,1,2,10,42,40,33,44,47,43,1,38,42,41,5,32,1,33,10,11,14,33,46,10,11,32]

theorem envBound59923 : H12AffineFastState.Bounded env59923 := by
  intro p hp
  have h : env59923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59922_59923 : H12AffineEnvironment.transform 6 4 env59922 = env59923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env59922 == env59923) = true)

theorem identity59923 : scanCanonicalize (H12AffineFastState.compose env59923 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound59923 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env59924 : List Nat := [2,4,8,0,13,0,4,3,7,9,12,1,2,10,7,5,12,1,2,6,1,11,7,4,5,13,1,12,10,11,14,12,3,10,11,13]

theorem envBound59924 : H12AffineFastState.Bounded env59924 := by
  intro p hp
  have h : env59924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59923_59924 : H12AffineEnvironment.transform 4 13 env59923 = env59924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env59923 == env59924) = true)

theorem identity59924 : scanCanonicalize (H12AffineFastState.compose env59924 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound59924 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59925 : List Nat := [2,4,3,0,6,0,4,3,7,2,7,1,2,1,7,5,7,1,2,6,1,0,7,4,5,6,1,7,1,0,5,7,3,1,0,6]

theorem envBound59925 : H12AffineFastState.Bounded env59925 := by
  intro p hp
  have h : env59925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59924_59925 : H12AffineEnvironment.transform 2 3 env59924 = env59925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env59924 == env59925) = true)

theorem identity59925 : scanCanonicalize (H12AffineFastState.compose env59925 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59925 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59926 : List Nat := [1,4,0,0,5,0,4,0,4,1,4,1,1,1,4,5,4,1,1,5,1,0,4,4,5,5,1,4,1,0,5,4,0,1,0,5]

theorem envBound59926 : H12AffineFastState.Bounded env59926 := by
  intro p hp
  have h : env59926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59925_59926 : H12AffineEnvironment.transform 0 1 env59925 = env59926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59925 == env59926) = true)

theorem identity59926 : scanCanonicalize (H12AffineFastState.compose env59926 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound59926 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59927 : List Nat := [1,0,0,0,1,0,0,0,0,1,0,1,1,1,0,1,0,1,1,1,1,0,0,0,1,1,1,0,1,0,1,0,0,1,0,1]

theorem envBound59927 : H12AffineFastState.Bounded env59927 := by
  intro p hp
  have h : env59927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59926_59927 : H12AffineEnvironment.transform 1 0 env59926 = env59927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env59926 == env59927) = true)

def env59928 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,1,8192,1281,9229,65536,74863,65664,321,9228,1,461,74031,65536,9673,74798,302,74798,1281,77130,8204,74799,256,8200,1345,1029]

theorem envBound59928 : H12AffineFastState.Bounded env59928 := by
  intro p hp
  have h : env59928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59906_59928 : H12AffineEnvironment.transform 3 1 env59906 = env59928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env59906 == env59928) = true)

theorem identity59928 : scanCanonicalize (H12AffineFastState.compose env59928 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8431) := by decide +kernel

theorem selectedBound59928 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env59929 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,1,8192,1281,9229,8431,1152,8303,321,9228,1,461,448,8431,9673,1217,302,1217,1281,3493,8204,1216,256,8200,1345,1029]

theorem envBound59929 : H12AffineFastState.Bounded env59929 := by
  intro p hp
  have h : env59929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59928_59929 : H12AffineEnvironment.transform 15 8431 env59928 = env59929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8431 env59928 == env59929) = true)

def env59930 : List Nat := [2,4,8,1,32,64,128,256,325,128,2048,1,8192,385,8333,8431,0,8303,321,8332,1,461,448,8431,8521,65,302,65,385,2341,8204,64,256,8200,449,133]

theorem envBound59930 : H12AffineFastState.Bounded env59930 := by
  intro p hp
  have h : env59930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59929_59930 : H12AffineEnvironment.transform 9 128 env59929 = env59930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 128 env59929 == env59930) = true)

theorem identity59930 : scanCanonicalize (H12AffineFastState.compose env59930 (packedSelected [1,4,8,9,18,20,21,23,24] rootPS)) = affineNative (2^(10+1) ^^^ 107) := by decide +kernel

theorem selectedBound59930 : packedSelected [1,4,8,9,18,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env59931 : List Nat := [2,4,8,1,32,64,128,256,325,128,107,1,8192,385,8333,8431,0,8303,321,8332,1,461,448,8431,8521,65,302,65,385,334,8204,64,256,8200,449,133]

theorem envBound59931 : H12AffineFastState.Bounded env59931 := by
  intro p hp
  have h : env59931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59930_59931 : H12AffineEnvironment.transform 10 107 env59930 = env59931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 107 env59930 == env59931) = true)

theorem identity59931 : scanCanonicalize (H12AffineFastState.compose env59931 (packedSelected [1,3,4,5,9,12,15,17,18,19,21] rootPS)) = affineNative (2^(7+1) ^^^ 105) := by decide +kernel

theorem selectedBound59931 : packedSelected [1,3,4,5,9,12,15,17,18,19,21] rootPS < 2^1333 := by decide +kernel

def env59932 : List Nat := [2,4,8,1,32,64,128,105,44,128,107,1,8192,232,8333,8431,0,8303,40,8332,1,164,169,8431,8224,65,71,65,232,39,8204,64,105,8200,168,133]

theorem envBound59932 : H12AffineFastState.Bounded env59932 := by
  intro p hp
  have h : env59932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59931_59932 : H12AffineEnvironment.transform 7 105 env59931 = env59932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 105 env59931 == env59932) = true)

theorem identity59932 : scanCanonicalize (H12AffineFastState.compose env59932 (packedSelected [0,1,4,5,7,9,10,12,13,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound59932 : packedSelected [0,1,4,5,7,9,10,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env59933 : List Nat := [2,4,8,1,32,64,128,105,44,128,107,1,161,232,44,78,0,206,40,45,1,164,169,78,129,65,71,65,232,39,173,64,105,169,168,133]

theorem envBound59933 : H12AffineFastState.Bounded env59933 := by
  intro p hp
  have h : env59933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59932_59933 : H12AffineEnvironment.transform 12 161 env59932 = env59933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env59932 == env59933) = true)

theorem identity59933 : scanCanonicalize (H12AffineFastState.compose env59933 (packedSelected [1,4,9,11] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound59933 : packedSelected [1,4,9,11] rootPS < 2^1333 := by decide +kernel

def env59934 : List Nat := [2,3,8,1,32,64,128,105,43,128,107,1,161,232,43,73,0,201,40,42,1,163,169,73,129,65,64,65,232,32,170,64,105,169,168,130]

theorem envBound59934 : H12AffineFastState.Bounded env59934 := by
  intro p hp
  have h : env59934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59933_59934 : H12AffineEnvironment.transform 1 3 env59933 = env59934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env59933 == env59934) = true)

theorem identity59934 : scanCanonicalize (H12AffineFastState.compose env59934 (packedSelected [1,2,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound59934 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env59935 : List Nat := [2,3,8,1,32,64,9,105,43,9,107,1,40,97,43,73,0,64,40,42,1,42,32,73,8,65,64,65,97,32,35,64,105,32,33,11]

theorem envBound59935 : H12AffineFastState.Bounded env59935 := by
  intro p hp
  have h : env59935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59934_59935 : H12AffineEnvironment.transform 6 9 env59934 = env59935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env59934 == env59935) = true)

theorem identity59935 : scanCanonicalize (H12AffineFastState.compose env59935 (packedSelected [2,3] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound59935 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env59936 : List Nat := [2,3,8,1,32,43,9,2,43,9,0,1,40,10,43,34,0,43,40,42,1,42,32,34,8,42,43,42,10,32,35,43,2,32,33,11]

theorem envBound59936 : H12AffineFastState.Bounded env59936 := by
  intro p hp
  have h : env59936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59935_59936 : H12AffineEnvironment.transform 5 43 env59935 = env59936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env59935 == env59936) = true)

theorem identity59936 : scanCanonicalize (H12AffineFastState.compose env59936 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound59936 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env59937 : List Nat := [2,3,8,1,1,10,9,2,10,9,0,1,9,10,10,3,0,10,9,11,1,11,1,3,8,11,10,11,10,1,2,10,2,1,0,11]

theorem envBound59937 : H12AffineFastState.Bounded env59937 := by
  intro p hp
  have h : env59937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59936_59937 : H12AffineEnvironment.transform 4 1 env59936 = env59937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env59936 == env59937) = true)

theorem identity59937 : scanCanonicalize (H12AffineFastState.compose env59937 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59937 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59938 : List Nat := [1,0,8,1,1,9,9,1,9,9,0,1,9,9,9,0,0,9,9,8,1,8,1,0,8,8,9,8,9,1,1,9,1,1,0,8]

theorem envBound59938 : H12AffineFastState.Bounded env59938 := by
  intro p hp
  have h : env59938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59937_59938 : H12AffineEnvironment.transform 0 1 env59937 = env59938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59937 == env59938) = true)

theorem identity59938 : scanCanonicalize (H12AffineFastState.compose env59938 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound59938 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59939 : List Nat := [1,0,0,1,1,1,1,1,1,1,0,1,1,1,1,0,0,1,1,0,1,0,1,0,0,0,1,0,1,1,1,1,1,1,0,0]

theorem envBound59939 : H12AffineFastState.Bounded env59939 := by
  intro p hp
  have h : env59939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59938_59939 : H12AffineEnvironment.transform 2 0 env59938 = env59939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env59938 == env59939) = true)

def env59940 : List Nat := [2,4,8,1,32,64,128,256,325,129,2048,1,8192,384,8332,8431,1,8303,321,8333,1,461,448,8431,8520,64,302,64,384,2340,8204,65,256,8200,448,132]

theorem envBound59940 : H12AffineFastState.Bounded env59940 := by
  intro p hp
  have h : env59940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59929_59940 : H12AffineEnvironment.transform 9 129 env59929 = env59940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 129 env59929 == env59940) = true)

theorem identity59940 : scanCanonicalize (H12AffineFastState.compose env59940 (packedSelected [1,4,8,9,18,20,21,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 2283) := by decide +kernel

theorem selectedBound59940 : packedSelected [1,4,8,9,18,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env59941 : List Nat := [2,4,8,1,32,64,128,256,325,129,2048,1,2283,384,2151,2052,1,2180,321,2150,1,461,448,2052,2467,64,302,64,384,2340,2279,65,256,2275,448,132]

theorem envBound59941 : H12AffineFastState.Bounded env59941 := by
  intro p hp
  have h : env59941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59940_59941 : H12AffineEnvironment.transform 12 2283 env59940 = env59941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2283 env59940 == env59941) = true)

theorem identity59941 : scanCanonicalize (H12AffineFastState.compose env59941 (packedSelected [0,5,7,8,10,11,16,19,21,32] rootPS)) = affineNative (2^(10+1) ^^^ 107) := by decide +kernel

theorem selectedBound59941 : packedSelected [0,5,7,8,10,11,16,19,21,32] rootPS < 2^1333 := by decide +kernel

def env59942 : List Nat := [2,4,8,1,32,64,128,256,325,129,107,1,128,384,12,111,1,239,321,13,1,461,448,111,456,64,302,64,384,335,140,65,256,136,448,132]

theorem envBound59942 : H12AffineFastState.Bounded env59942 := by
  intro p hp
  have h : env59942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59941_59942 : H12AffineEnvironment.transform 10 107 env59941 = env59942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 107 env59941 == env59942) = true)

theorem identity59942 : scanCanonicalize (H12AffineFastState.compose env59942 (packedSelected [0,5,7,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 234) := by decide +kernel

theorem selectedBound59942 : packedSelected [0,5,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env59943 : List Nat := [2,4,8,1,32,64,128,234,175,129,107,1,128,106,12,111,1,239,171,13,1,39,42,111,34,64,196,64,106,165,140,65,234,136,42,132]

theorem envBound59943 : H12AffineFastState.Bounded env59943 := by
  intro p hp
  have h : env59943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59942_59943 : H12AffineEnvironment.transform 7 234 env59942 = env59943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 234 env59942 == env59943) = true)

theorem identity59943 : scanCanonicalize (H12AffineFastState.compose env59943 (packedSelected [0,1,3,5,9,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 39) := by decide +kernel

theorem selectedBound59943 : packedSelected [0,1,3,5,9,10,12] rootPS < 2^1333 := by decide +kernel

def env59944 : List Nat := [2,4,8,1,32,39,128,141,175,129,12,1,128,13,12,8,1,136,171,13,1,39,42,8,34,39,163,39,13,165,140,38,141,136,42,132]

theorem envBound59944 : H12AffineFastState.Bounded env59944 := by
  intro p hp
  have h : env59944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59943_59944 : H12AffineEnvironment.transform 5 39 env59943 = env59944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 39 env59943 == env59944) = true)

theorem identity59944 : scanCanonicalize (H12AffineFastState.compose env59944 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound59944 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env59945 : List Nat := [2,4,8,1,7,0,128,141,136,129,12,1,128,13,12,8,1,136,140,13,1,0,13,8,5,0,132,0,13,130,140,1,141,136,13,132]

theorem envBound59945 : H12AffineFastState.Bounded env59945 := by
  intro p hp
  have h : env59945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59944_59945 : H12AffineEnvironment.transform 4 7 env59944 = env59945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env59944 == env59945) = true)

theorem identity59945 : scanCanonicalize (H12AffineFastState.compose env59945 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound59945 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59946 : List Nat := [2,3,8,1,0,0,128,138,136,129,11,1,128,10,11,8,1,136,139,10,1,0,10,8,2,0,131,0,10,130,139,1,138,136,10,131]

theorem envBound59946 : H12AffineFastState.Bounded env59946 := by
  intro p hp
  have h : env59946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59945_59946 : H12AffineEnvironment.transform 1 3 env59945 = env59946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env59945 == env59946) = true)

theorem identity59946 : scanCanonicalize (H12AffineFastState.compose env59946 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound59946 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env59947 : List Nat := [2,3,2,1,0,0,128,128,130,129,1,1,128,0,1,2,1,130,129,0,1,0,0,2,2,0,131,0,0,130,129,1,128,130,0,131]

theorem envBound59947 : H12AffineFastState.Bounded env59947 := by
  intro p hp
  have h : env59947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59946_59947 : H12AffineEnvironment.transform 2 2 env59946 = env59947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env59946 == env59947) = true)

theorem identity59947 : scanCanonicalize (H12AffineFastState.compose env59947 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound59947 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59948 : List Nat := [2,3,2,1,0,0,0,0,2,1,1,1,0,0,1,2,1,2,1,0,1,0,0,2,2,0,3,0,0,2,1,1,0,2,0,3]

theorem envBound59948 : H12AffineFastState.Bounded env59948 := by
  intro p hp
  have h : env59948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59947_59948 : H12AffineEnvironment.transform 6 0 env59947 = env59948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env59947 == env59948) = true)

theorem identity59948 : scanCanonicalize (H12AffineFastState.compose env59948 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59948 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59949 : List Nat := [0,1,0,1,0,0,0,0,0,1,1,1,0,0,1,0,1,0,1,0,1,0,0,0,0,0,1,0,0,0,1,1,0,0,0,1]

theorem envBound59949 : H12AffineFastState.Bounded env59949 := by
  intro p hp
  have h : env59949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59948_59949 : H12AffineEnvironment.transform 0 0 env59948 = env59949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59948 == env59949) = true)

def env59950 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,8192,1296,9244,65536,74863,65664,321,9245,1,476,74046,65553,9673,74798,319,74815,1296,77130,8204,74799,256,8200,1345,1045]

theorem envBound59950 : H12AffineFastState.Bounded env59950 := by
  intro p hp
  have h : env59950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59905_59950 : H12AffineEnvironment.transform 8 341 env59905 = env59950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env59905 == env59950) = true)

def env59951 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,1,8192,1280,9228,65536,74863,65664,321,9229,1,460,74030,65537,9673,74798,303,74799,1280,77130,8204,74799,256,8200,1345,1029]

theorem envBound59951 : H12AffineFastState.Bounded env59951 := by
  intro p hp
  have h : env59951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59950_59951 : H12AffineEnvironment.transform 3 0 env59950 = env59951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env59950 == env59951) = true)

theorem identity59951 : scanCanonicalize (H12AffineFastState.compose env59951 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 1225) := by decide +kernel

theorem selectedBound59951 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env59952 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,1,1225,1280,197,65536,65702,65664,321,196,1,460,67047,65537,256,65767,303,65766,1280,67971,1221,65766,256,1217,1345,1029]

theorem envBound59952 : H12AffineFastState.Bounded env59952 := by
  intro p hp
  have h : env59952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59951_59952 : H12AffineEnvironment.transform 12 1225 env59951 = env59952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1225 env59951 == env59952) = true)

def env59953 : List Nat := [2,4,8,0,32,64,128,192,133,1024,2048,1,1225,1216,197,65536,65702,65664,129,196,1,12,66599,65537,192,65767,239,65766,1216,67651,1221,65766,192,1217,1153,1029]

theorem envBound59953 : H12AffineFastState.Bounded env59953 := by
  intro p hp
  have h : env59953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59952_59953 : H12AffineEnvironment.transform 7 192 env59952 = env59953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 192 env59952 == env59953) = true)

theorem identity59953 : scanCanonicalize (H12AffineFastState.compose env59953 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 1251) := by decide +kernel

theorem selectedBound59953 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59954 : List Nat := [2,4,8,0,32,64,128,192,133,1024,2048,1,1225,1216,197,1251,1093,1123,129,196,1,12,196,1250,192,1028,239,1029,1216,3232,1221,1029,192,1217,1153,1029]

theorem envBound59954 : H12AffineFastState.Bounded env59954 := by
  intro p hp
  have h : env59954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59953_59954 : H12AffineEnvironment.transform 15 1251 env59953 = env59954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1251 env59953 == env59954) = true)

theorem identity59954 : scanCanonicalize (H12AffineFastState.compose env59954 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1059) := by decide +kernel

theorem selectedBound59954 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env59955 : List Nat := [2,4,8,0,32,64,128,192,133,1024,1059,1,1225,1216,197,1251,1093,1123,129,196,1,12,196,1250,192,1028,239,1029,1216,131,1221,1029,192,1217,1153,1029]

theorem envBound59955 : H12AffineFastState.Bounded env59955 := by
  intro p hp
  have h : env59955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59954_59955 : H12AffineEnvironment.transform 10 1059 env59954 = env59955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1059 env59954 == env59955) = true)

theorem identity59955 : scanCanonicalize (H12AffineFastState.compose env59955 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound59955 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env59956 : List Nat := [2,4,8,0,32,1,128,129,133,1024,1059,1,1160,1153,132,1186,1028,1058,129,133,1,12,133,1187,129,1028,174,1029,1153,131,1156,1029,129,1152,1153,1029]

theorem envBound59956 : H12AffineFastState.Bounded env59956 := by
  intro p hp
  have h : env59956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59955_59956 : H12AffineEnvironment.transform 5 1 env59955 = env59956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env59955 == env59956) = true)

theorem identity59956 : scanCanonicalize (H12AffineFastState.compose env59956 (packedSelected [2,3,5,12] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound59956 : packedSelected [2,3,5,12] rootPS < 2^1333 := by decide +kernel

def env59957 : List Nat := [2,4,8,0,32,1,128,129,133,15,44,1,135,142,132,173,11,45,129,133,1,12,133,172,129,11,174,10,142,131,139,10,129,143,142,10]

theorem envBound59957 : H12AffineFastState.Bounded env59957 := by
  intro p hp
  have h : env59957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59956_59957 : H12AffineEnvironment.transform 9 15 env59956 = env59957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env59956 == env59957) = true)

theorem identity59957 : scanCanonicalize (H12AffineFastState.compose env59957 (packedSelected [1,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound59957 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env59958 : List Nat := [2,4,8,0,32,1,5,4,0,15,44,1,2,11,1,40,11,45,4,0,1,12,0,41,4,11,43,10,11,6,14,10,4,10,11,10]

theorem envBound59958 : H12AffineFastState.Bounded env59958 := by
  intro p hp
  have h : env59958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59957_59958 : H12AffineEnvironment.transform 6 5 env59957 = env59958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env59957 == env59958) = true)

theorem identity59958 : scanCanonicalize (H12AffineFastState.compose env59958 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound59958 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env59959 : List Nat := [2,4,8,0,10,1,5,4,0,15,6,1,2,11,1,2,11,7,4,0,1,12,0,3,4,11,1,10,11,6,14,10,4,10,11,10]

theorem envBound59959 : H12AffineFastState.Bounded env59959 := by
  intro p hp
  have h : env59959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59958_59959 : H12AffineEnvironment.transform 4 10 env59958 = env59959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env59958 == env59959) = true)

def env59960 : List Nat := [2,4,8,0,32,64,128,193,132,1024,2048,1,1225,1217,197,65536,65702,65664,128,196,1,13,66598,65537,193,65767,238,65766,1217,67650,1221,65766,193,1217,1152,1029]

theorem envBound59960 : H12AffineFastState.Bounded env59960 := by
  intro p hp
  have h : env59960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59952_59960 : H12AffineEnvironment.transform 7 193 env59952 = env59960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 193 env59952 == env59960) = true)

theorem identity59960 : scanCanonicalize (H12AffineFastState.compose env59960 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound59960 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59961 : List Nat := [2,4,8,0,32,64,128,193,132,1024,2048,1,1225,1217,197,99,197,227,128,196,1,13,1093,98,193,132,238,133,1217,2081,1221,133,193,1217,1152,1029]

theorem envBound59961 : H12AffineFastState.Bounded env59961 := by
  intro p hp
  have h : env59961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59960_59961 : H12AffineEnvironment.transform 15 99 env59960 = env59961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env59960 == env59961) = true)

theorem identity59961 : scanCanonicalize (H12AffineFastState.compose env59961 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 1226) := by decide +kernel

theorem selectedBound59961 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env59962 : List Nat := [2,4,8,0,32,64,128,193,132,1024,1226,1,1225,1217,197,99,197,227,128,196,1,13,1093,98,193,132,238,133,1217,1259,1221,133,193,1217,1152,1029]

theorem envBound59962 : H12AffineFastState.Bounded env59962 := by
  intro p hp
  have h : env59962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59961_59962 : H12AffineEnvironment.transform 10 1226 env59961 = env59962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1226 env59961 == env59962) = true)

theorem identity59962 : scanCanonicalize (H12AffineFastState.compose env59962 (packedSelected [0,1,7,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 231) := by decide +kernel

theorem selectedBound59962 : packedSelected [0,1,7,8,11] rootPS < 2^1333 := by decide +kernel

def env59963 : List Nat := [2,4,8,0,32,64,128,193,132,231,45,1,46,38,197,99,197,227,128,196,1,13,162,98,193,132,238,133,38,12,34,133,193,38,103,226]

theorem envBound59963 : H12AffineFastState.Bounded env59963 := by
  intro p hp
  have h : env59963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59962_59963 : H12AffineEnvironment.transform 9 231 env59962 = env59963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 231 env59962 == env59963) = true)

theorem identity59963 : scanCanonicalize (H12AffineFastState.compose env59963 (packedSelected [1,2,3,4,5,9,12] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound59963 : packedSelected [1,2,3,4,5,9,12] rootPS < 2^1333 := by decide +kernel

def env59964 : List Nat := [2,4,8,0,32,11,128,138,132,172,45,1,46,38,142,40,142,168,128,143,1,13,162,41,138,132,165,133,38,12,34,133,138,38,44,169]

theorem envBound59964 : H12AffineFastState.Bounded env59964 := by
  intro p hp
  have h : env59964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59963_59964 : H12AffineEnvironment.transform 5 11 env59963 = env59964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env59963 == env59964) = true)

theorem identity59964 : scanCanonicalize (H12AffineFastState.compose env59964 (packedSelected [0,1,2,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound59964 : packedSelected [0,1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env59965 : List Nat := [2,4,8,0,32,11,36,46,32,8,45,1,46,38,42,40,42,12,36,43,1,13,6,41,46,32,1,33,38,12,34,33,46,38,44,13]

theorem envBound59965 : H12AffineFastState.Bounded env59965 := by
  intro p hp
  have h : env59965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59964_59965 : H12AffineEnvironment.transform 6 36 env59964 = env59965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env59964 == env59965) = true)

theorem identity59965 : scanCanonicalize (H12AffineFastState.compose env59965 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound59965 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env59966 : List Nat := [2,4,8,0,0,11,4,14,0,8,13,1,14,6,10,8,10,12,4,11,1,13,6,9,14,0,1,1,6,12,2,1,14,6,12,13]

theorem envBound59966 : H12AffineFastState.Bounded env59966 := by
  intro p hp
  have h : env59966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59965_59966 : H12AffineEnvironment.transform 4 0 env59965 = env59966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env59965 == env59966) = true)

theorem identity59966 : scanCanonicalize (H12AffineFastState.compose env59966 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound59966 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59967 : List Nat := [2,4,4,0,0,7,4,2,0,4,1,1,2,6,6,4,6,0,4,7,1,1,6,5,2,0,1,1,6,0,2,1,2,6,0,1]

theorem envBound59967 : H12AffineFastState.Bounded env59967 := by
  intro p hp
  have h : env59967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59966_59967 : H12AffineEnvironment.transform 2 4 env59966 = env59967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env59966 == env59967) = true)

theorem identity59967 : scanCanonicalize (H12AffineFastState.compose env59967 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59967 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59968 : List Nat := [1,4,4,0,0,4,4,1,0,4,1,1,1,5,5,4,5,0,4,4,1,1,5,5,1,0,1,1,5,0,1,1,1,5,0,1]

theorem envBound59968 : H12AffineFastState.Bounded env59968 := by
  intro p hp
  have h : env59968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59967_59968 : H12AffineEnvironment.transform 0 1 env59967 = env59968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59967 == env59968) = true)

theorem identity59968 : scanCanonicalize (H12AffineFastState.compose env59968 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound59968 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59969 : List Nat := [1,0,0,0,0,0,0,1,0,0,1,1,1,1,1,0,1,0,0,0,1,1,1,1,1,0,1,1,1,0,1,1,1,1,0,1]

theorem envBound59969 : H12AffineFastState.Bounded env59969 := by
  intro p hp
  have h : env59969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59968_59969 : H12AffineEnvironment.transform 1 0 env59968 = env59969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env59968 == env59969) = true)

def env59970 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,1,8192,1281,9229,65536,74863,65664,321,9228,1,461,74031,65536,9673,74798,302,74798,1281,77130,8204,74799,256,8200,1345,1028]

theorem envBound59970 : H12AffineFastState.Bounded env59970 := by
  intro p hp
  have h : env59970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59950_59970 : H12AffineEnvironment.transform 3 1 env59950 = env59970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env59950 == env59970) = true)

theorem identity59970 : scanCanonicalize (H12AffineFastState.compose env59970 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 192) := by decide +kernel

theorem selectedBound59970 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env59971 : List Nat := [2,4,8,1,32,64,128,192,132,1024,2048,1,8192,1217,9229,65536,74863,65664,129,9228,1,13,73967,65536,9225,74798,238,74798,1217,76938,8204,74799,192,8200,1153,1028]

theorem envBound59971 : H12AffineFastState.Bounded env59971 := by
  intro p hp
  have h : env59971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59970_59971 : H12AffineEnvironment.transform 7 192 env59970 = env59971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 192 env59970 == env59971) = true)

def env59972 : List Nat := [2,4,8,1,32,64,128,192,132,1024,2048,1,1224,1217,197,65536,65703,65664,129,196,1,13,66599,65536,193,65766,238,65766,1217,67650,1220,65767,192,1216,1153,1028]

theorem envBound59972 : H12AffineFastState.Bounded env59972 := by
  intro p hp
  have h : env59972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59971_59972 : H12AffineEnvironment.transform 12 1224 env59971 = env59972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1224 env59971 == env59972) = true)

theorem identity59972 : scanCanonicalize (H12AffineFastState.compose env59972 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound59972 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59973 : List Nat := [2,4,8,1,32,64,128,192,132,1024,2048,1,1224,1217,197,98,197,226,129,196,1,13,1093,98,193,132,238,132,1217,2080,1220,133,192,1216,1153,1028]

theorem envBound59973 : H12AffineFastState.Bounded env59973 := by
  intro p hp
  have h : env59973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59972_59973 : H12AffineEnvironment.transform 15 98 env59972 = env59973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env59972 == env59973) = true)

theorem identity59973 : scanCanonicalize (H12AffineFastState.compose env59973 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 1226) := by decide +kernel

theorem selectedBound59973 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env59974 : List Nat := [2,4,8,1,32,64,128,192,132,1024,1226,1,1224,1217,197,98,197,226,129,196,1,13,1093,98,193,132,238,132,1217,1258,1220,133,192,1216,1153,1028]

theorem envBound59974 : H12AffineFastState.Bounded env59974 := by
  intro p hp
  have h : env59974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59973_59974 : H12AffineEnvironment.transform 10 1226 env59973 = env59974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1226 env59973 == env59974) = true)

theorem identity59974 : scanCanonicalize (H12AffineFastState.compose env59974 (packedSelected [0,1,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound59974 : packedSelected [0,1,7,8,11] rootPS < 2^1333 := by decide +kernel

def env59975 : List Nat := [2,4,8,1,32,64,34,98,38,1024,1128,1,1130,1123,103,98,103,64,35,102,1,13,1093,98,99,38,76,38,1123,1096,1126,39,98,1122,1059,1028]

theorem envBound59975 : H12AffineFastState.Bounded env59975 := by
  intro p hp
  have h : env59975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59974_59975 : H12AffineEnvironment.transform 6 34 env59974 = env59975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env59974 == env59975) = true)

theorem identity59975 : scanCanonicalize (H12AffineFastState.compose env59975 (packedSelected [3,4,9,10,12,13] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound59975 : packedSelected [3,4,9,10,12,13] rootPS < 2^1333 := by decide +kernel

def env59976 : List Nat := [2,4,8,1,32,7,34,37,38,1024,1071,1,1069,1060,32,37,32,7,35,33,1,13,1026,37,36,38,11,38,1060,1039,1057,39,37,1061,1059,1028]

theorem envBound59976 : H12AffineFastState.Bounded env59976 := by
  intro p hp
  have h : env59976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59975_59976 : H12AffineEnvironment.transform 5 7 env59975 = env59976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env59975 == env59976) = true)

theorem identity59976 : scanCanonicalize (H12AffineFastState.compose env59976 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound59976 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env59977 : List Nat := [2,4,8,1,32,7,34,37,38,46,1,1,3,10,32,37,32,7,35,33,1,13,44,37,36,38,11,38,10,33,15,39,37,11,13,42]

theorem envBound59977 : H12AffineFastState.Bounded env59977 := by
  intro p hp
  have h : env59977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59976_59977 : H12AffineEnvironment.transform 9 46 env59976 = env59977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env59976 == env59977) = true)

def env59978 : List Nat := [2,4,8,1,32,64,128,192,132,1024,2048,1,1225,1217,196,65536,65702,65664,129,197,1,13,66598,65536,192,65767,238,65767,1217,67651,1221,65766,192,1217,1153,1028]

theorem envBound59978 : H12AffineFastState.Bounded env59978 := by
  intro p hp
  have h : env59978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59971_59978 : H12AffineEnvironment.transform 12 1225 env59971 = env59978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1225 env59971 == env59978) = true)

theorem identity59978 : scanCanonicalize (H12AffineFastState.compose env59978 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 1250) := by decide +kernel

theorem selectedBound59978 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59979 : List Nat := [2,4,8,1,32,64,128,192,132,1024,2048,1,1225,1217,196,1250,1092,1122,129,197,1,13,196,1250,192,1029,238,1029,1217,3233,1221,1028,192,1217,1153,1028]

theorem envBound59979 : H12AffineFastState.Bounded env59979 := by
  intro p hp
  have h : env59979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59978_59979 : H12AffineEnvironment.transform 15 1250 env59978 = env59979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1250 env59978 == env59979) = true)

theorem identity59979 : scanCanonicalize (H12AffineFastState.compose env59979 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1058) := by decide +kernel

theorem selectedBound59979 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env59980 : List Nat := [2,4,8,1,32,64,128,192,132,1024,1058,1,1225,1217,196,1250,1092,1122,129,197,1,13,196,1250,192,1029,238,1029,1217,131,1221,1028,192,1217,1153,1028]

theorem envBound59980 : H12AffineFastState.Bounded env59980 := by
  intro p hp
  have h : env59980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59979_59980 : H12AffineEnvironment.transform 10 1058 env59979 = env59980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1058 env59979 == env59980) = true)

theorem identity59980 : scanCanonicalize (H12AffineFastState.compose env59980 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound59980 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env59981 : List Nat := [2,4,8,1,32,0,128,128,132,1024,1058,1,1161,1153,132,1186,1028,1058,129,133,1,13,132,1186,128,1029,174,1029,1153,131,1157,1028,128,1153,1153,1028]

theorem envBound59981 : H12AffineFastState.Bounded env59981 := by
  intro p hp
  have h : env59981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59980_59981 : H12AffineEnvironment.transform 5 0 env59980 = env59981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env59980 == env59981) = true)

theorem identity59981 : scanCanonicalize (H12AffineFastState.compose env59981 (packedSelected [2,3,5,12] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound59981 : packedSelected [2,3,5,12] rootPS < 2^1333 := by decide +kernel

def env59982 : List Nat := [2,4,3,1,32,0,128,128,132,1024,1058,1,1154,1153,132,1186,1028,1058,129,133,1,6,132,1186,128,1029,165,1029,1153,131,1157,1028,128,1153,1153,1028]

theorem envBound59982 : H12AffineFastState.Bounded env59982 := by
  intro p hp
  have h : env59982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59981_59982 : H12AffineEnvironment.transform 2 3 env59981 = env59982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env59981 == env59982) = true)

theorem identity59982 : scanCanonicalize (H12AffineFastState.compose env59982 (packedSelected [2,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound59982 : packedSelected [2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env59983 : List Nat := [2,4,3,1,32,0,2,2,6,1024,1058,1,1024,1027,6,1056,1028,1058,3,7,1,6,6,1056,2,1029,39,1029,1027,1,1031,1028,2,1027,1027,1028]

theorem envBound59983 : H12AffineFastState.Bounded env59983 := by
  intro p hp
  have h : env59983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59982_59983 : H12AffineEnvironment.transform 6 2 env59982 = env59983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env59982 == env59983) = true)

theorem identity59983 : scanCanonicalize (H12AffineFastState.compose env59983 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound59983 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env59984 : List Nat := [2,4,3,1,32,0,2,2,6,4,38,1,4,7,6,36,0,38,3,7,1,6,6,36,2,1,39,1,7,1,3,0,2,7,7,0]

theorem envBound59984 : H12AffineFastState.Bounded env59984 := by
  intro p hp
  have h : env59984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59983_59984 : H12AffineEnvironment.transform 9 4 env59983 = env59984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env59983 == env59984) = true)

theorem identity59984 : scanCanonicalize (H12AffineFastState.compose env59984 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound59984 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env59985 : List Nat := [2,4,3,1,6,0,2,2,6,4,0,1,4,7,6,2,0,0,3,7,1,6,6,2,2,1,1,1,7,1,3,0,2,7,7,0]

theorem envBound59985 : H12AffineFastState.Bounded env59985 := by
  intro p hp
  have h : env59985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59984_59985 : H12AffineEnvironment.transform 4 6 env59984 = env59985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env59984 == env59985) = true)

theorem identity59985 : scanCanonicalize (H12AffineFastState.compose env59985 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound59985 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59986 : List Nat := [2,2,3,1,0,0,2,2,0,2,0,1,2,1,0,2,0,0,3,1,1,0,0,2,2,1,1,1,1,1,3,0,2,1,1,0]

theorem envBound59986 : H12AffineFastState.Bounded env59986 := by
  intro p hp
  have h : env59986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59985_59986 : H12AffineEnvironment.transform 1 2 env59985 = env59986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env59985 == env59986) = true)

def env59987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65665,4416,13340,4096,476,74046,69648,13768,78895,4415,74815,1296,81227,8204,74799,256,8200,1345,5953]

theorem envBound59987 : H12AffineFastState.Bounded env59987 := by
  intro p hp
  have h : env59987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59903_59987 : H12AffineEnvironment.transform 17 65665 env59903 = env59987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env59903 == env59987) = true)

theorem identity59987 : scanCanonicalize (H12AffineFastState.compose env59987 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound59987 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59988 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12636,65536,74030,65665,4416,12637,4096,476,74046,69648,12425,78190,4415,74110,81,79882,8204,74094,256,8200,0,4608]

theorem envBound59988 : H12AffineFastState.Bounded env59988 := by
  intro p hp
  have h : env59988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59987_59988 : H12AffineEnvironment.transform 9 321 env59987 = env59988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env59987 == env59988) = true)

def env59989 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,8192,81,12636,65536,74030,65665,4416,12637,4096,476,74046,69648,12425,78190,4415,74110,81,79882,8204,74094,256,8200,0,4436]

theorem envBound59989 : H12AffineFastState.Bounded env59989 := by
  intro p hp
  have h : env59989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59988_59989 : H12AffineEnvironment.transform 8 340 env59988 = env59989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env59988 == env59989) = true)

def env59990 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,16,8192,81,8524,65536,74030,65665,336,8525,16,476,74046,65536,8345,74110,303,74110,81,75802,8204,74094,256,8200,0,324]

theorem envBound59990 : H12AffineFastState.Bounded env59990 := by
  intro p hp
  have h : env59990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59989_59990 : H12AffineEnvironment.transform 11 16 env59989 = env59990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env59989 == env59990) = true)

theorem identity59990 : scanCanonicalize (H12AffineFastState.compose env59990 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8431) := by decide +kernel

theorem selectedBound59990 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env59991 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,16,8192,81,8524,8431,449,8302,336,8525,16,476,465,8431,8345,401,303,401,81,2293,8204,385,256,8200,0,324]

theorem envBound59991 : H12AffineFastState.Bounded env59991 := by
  intro p hp
  have h : env59991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59990_59991 : H12AffineEnvironment.transform 15 8431 env59990 = env59991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8431 env59990 == env59991) = true)

def env59992 : List Nat := [2,4,8,16,32,64,128,128,212,193,2048,16,8192,81,8396,8431,65,8302,208,8397,16,92,81,8431,8345,17,175,17,81,2293,8204,1,128,8200,0,196]

theorem envBound59992 : H12AffineFastState.Bounded env59992 := by
  intro p hp
  have h : env59992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59991_59992 : H12AffineEnvironment.transform 7 128 env59991 = env59992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env59991 == env59992) = true)

theorem identity59992 : scanCanonicalize (H12AffineFastState.compose env59992 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 140) := by decide +kernel

theorem selectedBound59992 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59993 : List Nat := [2,4,8,16,32,64,128,128,212,193,2048,16,140,81,64,99,65,226,208,65,16,92,81,99,21,17,175,17,81,2293,128,1,128,132,0,196]

theorem envBound59993 : H12AffineFastState.Bounded env59993 := by
  intro p hp
  have h : env59993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59992_59993 : H12AffineEnvironment.transform 12 140 env59992 = env59993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 140 env59992 == env59993) = true)

theorem identity59993 : scanCanonicalize (H12AffineFastState.compose env59993 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59993 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env59994 : List Nat := [2,4,8,16,32,17,128,128,133,144,2048,16,140,0,17,50,16,179,129,16,16,13,0,50,21,17,175,17,0,2212,128,1,128,132,0,149]

theorem envBound59994 : H12AffineFastState.Bounded env59994 := by
  intro p hp
  have h : env59994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59993_59994 : H12AffineEnvironment.transform 5 17 env59993 = env59994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59993 == env59994) = true)

theorem identity59994 : scanCanonicalize (H12AffineFastState.compose env59994 (packedSelected [0,2,7,10,11,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound59994 : packedSelected [0,2,7,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env59995 : List Nat := [2,4,8,16,32,17,14,14,11,30,2048,16,2,0,17,50,16,61,15,16,16,13,0,50,21,17,33,17,0,2090,14,1,14,10,0,27]

theorem envBound59995 : H12AffineFastState.Bounded env59995 := by
  intro p hp
  have h : env59995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59994_59995 : H12AffineEnvironment.transform 6 14 env59994 = env59995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env59994 == env59995) = true)

theorem identity59995 : scanCanonicalize (H12AffineFastState.compose env59995 (packedSelected [0,1,2,3,7,8,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound59995 : packedSelected [0,1,2,3,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env59996 : List Nat := [2,4,8,16,32,17,14,14,11,30,32,16,2,0,17,50,16,61,15,16,16,13,0,50,21,17,33,17,0,10,14,1,14,10,0,27]

theorem envBound59996 : H12AffineFastState.Bounded env59996 := by
  intro p hp
  have h : env59996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59995_59996 : H12AffineEnvironment.transform 10 32 env59995 = env59996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env59995 == env59996) = true)

theorem identity59996 : scanCanonicalize (H12AffineFastState.compose env59996 (packedSelected [0,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound59996 : packedSelected [0,4,8] rootPS < 2^1333 := by decide +kernel

def env59997 : List Nat := [2,4,8,16,10,17,14,14,11,30,10,16,2,0,17,24,16,23,15,16,16,13,0,24,21,17,11,17,0,10,14,1,14,10,0,27]

theorem envBound59997 : H12AffineFastState.Bounded env59997 := by
  intro p hp
  have h : env59997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59996_59997 : H12AffineEnvironment.transform 4 10 env59996 = env59997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env59996 == env59997) = true)

theorem identity59997 : scanCanonicalize (H12AffineFastState.compose env59997 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound59997 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env59998 : List Nat := [2,4,8,11,10,10,14,14,11,5,10,11,2,0,10,3,11,12,15,11,11,13,0,3,14,10,11,10,0,10,14,1,14,10,0,0]

theorem envBound59998 : H12AffineFastState.Bounded env59998 := by
  intro p hp
  have h : env59998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59997_59998 : H12AffineEnvironment.transform 3 11 env59997 = env59998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env59997 == env59998) = true)

def env59999 : List Nat := [2,4,8,16,32,64,128,129,213,192,2048,16,8192,81,8397,8431,64,8302,209,8396,16,93,80,8431,8345,16,174,16,81,2293,8204,0,129,8200,0,197]

theorem envBound59999 : H12AffineFastState.Bounded env59999 := by
  intro p hp
  have h : env59999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59991_59999 : H12AffineEnvironment.transform 7 129 env59991 = env59999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 129 env59991 == env59999) = true)

theorem identity59999 : scanCanonicalize (H12AffineFastState.compose env59999 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 156) := by decide +kernel

theorem selectedBound59999 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60000 : List Nat := [2,4,8,16,32,64,128,129,213,192,2048,16,156,81,81,115,64,242,209,80,16,93,80,115,5,16,174,16,81,2293,144,0,129,148,0,197]

theorem envBound60000 : H12AffineFastState.Bounded env60000 := by
  intro p hp
  have h : env60000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59999_60000 : H12AffineEnvironment.transform 12 156 env59999 = env60000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 156 env59999 == env60000) = true)

theorem identity60000 : scanCanonicalize (H12AffineFastState.compose env60000 (packedSelected [0,1,2,3,7,8,12,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 249) := by decide +kernel

theorem selectedBound60000 : packedSelected [0,1,2,3,7,8,12,15,18] rootPS < 2^1333 := by decide +kernel

def env60001 : List Nat := [2,4,8,16,32,64,128,129,213,192,249,16,156,81,81,115,64,242,209,80,16,93,80,115,5,16,174,16,81,12,144,0,129,148,0,197]

theorem envBound60001 : H12AffineFastState.Bounded env60001 := by
  intro p hp
  have h : env60001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60000_60001 : H12AffineEnvironment.transform 10 249 env60000 = env60001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 249 env60000 == env60001) = true)

theorem identity60001 : scanCanonicalize (H12AffineFastState.compose env60001 (packedSelected [1,2,3,8,10,11,12,13,15,20] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60001 : packedSelected [1,2,3,8,10,11,12,13,15,20] rootPS < 2^1333 := by decide +kernel

def env60002 : List Nat := [2,4,8,16,16,64,128,129,213,192,201,16,156,81,81,67,64,194,209,80,16,93,80,67,5,16,158,16,81,12,144,0,129,148,0,197]

theorem envBound60002 : H12AffineFastState.Bounded env60002 := by
  intro p hp
  have h : env60002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60001_60002 : H12AffineEnvironment.transform 4 16 env60001 = env60002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60001 == env60002) = true)

theorem identity60002 : scanCanonicalize (H12AffineFastState.compose env60002 (packedSelected [0,1,3,4,5,8,10,11] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound60002 : packedSelected [0,1,3,4,5,8,10,11] rootPS < 2^1333 := by decide +kernel

def env60003 : List Nat := [2,4,8,10,10,64,128,129,207,192,201,10,134,75,75,67,64,194,203,74,10,71,74,67,5,10,132,10,75,12,138,0,129,142,0,197]

theorem envBound60003 : H12AffineFastState.Bounded env60003 := by
  intro p hp
  have h : env60003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60002_60003 : H12AffineEnvironment.transform 3 10 env60002 = env60003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env60002 == env60003) = true)

theorem identity60003 : scanCanonicalize (H12AffineFastState.compose env60003 (packedSelected [1,2,3,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound60003 : packedSelected [1,2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env60004 : List Nat := [2,4,8,10,10,64,3,2,76,67,74,10,5,75,75,67,64,65,72,74,10,71,74,67,5,10,7,10,75,12,9,0,2,13,0,70]

theorem envBound60004 : H12AffineFastState.Bounded env60004 := by
  intro p hp
  have h : env60004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60003_60004 : H12AffineEnvironment.transform 6 3 env60003 = env60004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env60003 == env60004) = true)

theorem identity60004 : scanCanonicalize (H12AffineFastState.compose env60004 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound60004 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env60005 : List Nat := [2,4,4,6,6,64,3,2,64,67,70,6,5,71,71,67,64,65,68,70,6,71,70,67,5,6,7,6,71,0,5,0,2,1,0,70]

theorem envBound60005 : H12AffineFastState.Bounded env60005 := by
  intro p hp
  have h : env60005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60004_60005 : H12AffineEnvironment.transform 2 4 env60004 = env60005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env60004 == env60005) = true)

theorem identity60005 : scanCanonicalize (H12AffineFastState.compose env60005 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound60005 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60006 : List Nat := [2,4,4,6,6,0,3,2,0,3,6,6,5,7,7,3,0,1,4,6,6,7,6,3,5,6,7,6,7,0,5,0,2,1,0,6]

theorem envBound60006 : H12AffineFastState.Bounded env60006 := by
  intro p hp
  have h : env60006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60005_60006 : H12AffineEnvironment.transform 5 0 env60005 = env60006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env60005 == env60006) = true)

def env60007 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,17,8192,81,8525,65536,74030,65665,337,8524,17,476,74046,65537,8344,74111,302,74110,81,75803,8204,74094,256,8200,0,325]

theorem envBound60007 : H12AffineFastState.Bounded env60007 := by
  intro p hp
  have h : env60007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59989_60007 : H12AffineEnvironment.transform 11 17 env59989 = env60007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env59989 == env60007) = true)

theorem identity60007 : scanCanonicalize (H12AffineFastState.compose env60007 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 167) := by decide +kernel

theorem selectedBound60007 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env60008 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,17,8192,81,8525,167,8585,38,337,8524,17,476,8601,166,8344,8664,302,8665,81,10428,8204,8649,256,8200,0,325]

theorem envBound60008 : H12AffineFastState.Bounded env60008 := by
  intro p hp
  have h : env60008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60007_60008 : H12AffineEnvironment.transform 15 167 env60007 = env60008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 167 env60007 == env60008) = true)

def env60009 : List Nat := [2,4,8,0,32,64,128,256,324,321,2048,1,8192,65,8525,167,8585,38,321,8524,1,460,8585,166,8328,8648,302,8649,65,10412,8204,8649,256,8200,0,325]

theorem envBound60009 : H12AffineFastState.Bounded env60009 := by
  intro p hp
  have h : env60009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60008_60009 : H12AffineEnvironment.transform 3 0 env60008 = env60009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60008 == env60009) = true)

theorem identity60009 : scanCanonicalize (H12AffineFastState.compose env60009 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound60009 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60010 : List Nat := [2,4,8,0,32,64,128,256,324,321,2048,1,268,65,65,167,133,38,321,64,1,460,133,166,388,196,302,197,65,2464,256,197,256,260,0,325]

theorem envBound60010 : H12AffineFastState.Bounded env60010 := by
  intro p hp
  have h : env60010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60009_60010 : H12AffineEnvironment.transform 12 268 env60009 = env60010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env60009 == env60010) = true)

theorem identity60010 : scanCanonicalize (H12AffineFastState.compose env60010 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 129) := by decide +kernel

theorem selectedBound60010 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60011 : List Nat := [2,4,8,0,32,64,128,129,197,192,2048,1,141,65,65,167,133,38,192,64,1,77,133,166,5,196,175,197,65,2081,129,197,129,133,0,196]

theorem envBound60011 : H12AffineFastState.Bounded env60011 := by
  intro p hp
  have h : env60011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60010_60011 : H12AffineEnvironment.transform 7 129 env60010 = env60011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 129 env60010 == env60011) = true)

theorem identity60011 : scanCanonicalize (H12AffineFastState.compose env60011 (packedSelected [0,1,2,5,7,8,11,12,13,15] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound60011 : packedSelected [0,1,2,5,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60012 : List Nat := [2,4,8,0,32,33,128,129,164,161,2048,1,141,32,32,167,133,38,161,33,1,44,133,166,5,165,175,164,32,2081,129,164,129,133,0,165]

theorem envBound60012 : H12AffineFastState.Bounded env60012 := by
  intro p hp
  have h : env60012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60011_60012 : H12AffineEnvironment.transform 5 33 env60011 = env60012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env60011 == env60012) = true)

theorem identity60012 : scanCanonicalize (H12AffineFastState.compose env60012 (packedSelected [1,3,7,11] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound60012 : packedSelected [1,3,7,11] rootPS < 2^1333 := by decide +kernel

def env60013 : List Nat := [2,0,8,0,32,33,128,129,160,161,2048,1,137,32,32,163,129,34,161,33,1,40,129,162,1,161,171,160,32,2081,129,160,129,129,0,161]

theorem envBound60013 : H12AffineFastState.Bounded env60013 := by
  intro p hp
  have h : env60013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60012_60013 : H12AffineEnvironment.transform 1 0 env60012 = env60013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env60012 == env60013) = true)

theorem identity60013 : scanCanonicalize (H12AffineFastState.compose env60013 (packedSelected [0,1,2,5,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound60013 : packedSelected [0,1,2,5,8,12] rootPS < 2^1333 := by decide +kernel

def env60014 : List Nat := [2,0,8,0,32,33,2,3,34,35,2048,1,11,32,32,33,3,34,35,33,1,40,3,32,1,35,41,34,32,2081,3,34,3,3,0,35]

theorem envBound60014 : H12AffineFastState.Bounded env60014 := by
  intro p hp
  have h : env60014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60013_60014 : H12AffineEnvironment.transform 6 2 env60013 = env60014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env60013 == env60014) = true)

theorem identity60014 : scanCanonicalize (H12AffineFastState.compose env60014 (packedSelected [1,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound60014 : packedSelected [1,3,4,5] rootPS < 2^1333 := by decide +kernel

def env60015 : List Nat := [2,0,8,0,10,11,2,3,8,9,2048,1,11,10,10,11,3,8,9,11,1,2,3,10,1,9,3,8,10,2059,3,8,3,3,0,9]

theorem envBound60015 : H12AffineFastState.Bounded env60015 := by
  intro p hp
  have h : env60015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60014_60015 : H12AffineEnvironment.transform 4 10 env60014 = env60015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env60014 == env60015) = true)

theorem identity60015 : scanCanonicalize (H12AffineFastState.compose env60015 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound60015 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env60016 : List Nat := [2,0,8,0,10,11,2,3,8,9,11,1,11,10,10,11,3,8,9,11,1,2,3,10,1,9,3,8,10,0,3,8,3,3,0,9]

theorem envBound60016 : H12AffineFastState.Bounded env60016 := by
  intro p hp
  have h : env60016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60015_60016 : H12AffineEnvironment.transform 10 11 env60015 = env60016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env60015 == env60016) = true)

theorem identity60016 : scanCanonicalize (H12AffineFastState.compose env60016 (packedSelected [0,2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60016 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env60017 : List Nat := [1,0,8,0,9,8,1,0,8,9,8,1,8,9,9,8,0,8,9,8,1,1,0,9,1,9,0,8,9,0,0,8,0,0,0,9]

theorem envBound60017 : H12AffineFastState.Bounded env60017 := by
  intro p hp
  have h : env60017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60016_60017 : H12AffineEnvironment.transform 0 1 env60016 = env60017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60016 == env60017) = true)

theorem identity60017 : scanCanonicalize (H12AffineFastState.compose env60017 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound60017 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env60018 : List Nat := [1,0,0,0,1,0,1,0,0,1,0,1,0,1,1,0,0,0,1,0,1,1,0,1,1,1,0,0,1,0,0,0,0,0,0,1]

theorem envBound60018 : H12AffineFastState.Bounded env60018 := by
  intro p hp
  have h : env60018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60017_60018 : H12AffineEnvironment.transform 2 0 env60017 = env60018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env60017 == env60018) = true)

def env60019 : List Nat := [2,4,8,1,32,64,128,256,325,321,2048,0,8192,64,8525,167,8585,38,320,8524,0,461,8584,166,8329,8649,302,8648,64,10413,8204,8649,256,8200,0,325]

theorem envBound60019 : H12AffineFastState.Bounded env60019 := by
  intro p hp
  have h : env60019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60008_60019 : H12AffineEnvironment.transform 3 1 env60008 = env60019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env60008 == env60019) = true)

theorem identity60019 : scanCanonicalize (H12AffineFastState.compose env60019 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 69) := by decide +kernel

theorem selectedBound60019 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60020 : List Nat := [2,4,8,1,32,64,69,256,325,321,2048,0,8192,64,8525,98,8524,38,320,8524,0,264,8525,99,8268,8460,302,8461,64,10344,8204,8460,256,8200,0,325]

theorem envBound60020 : H12AffineFastState.Bounded env60020 := by
  intro p hp
  have h : env60020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60019_60020 : H12AffineEnvironment.transform 6 69 env60019 = env60020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 69 env60019 == env60020) = true)

theorem identity60020 : scanCanonicalize (H12AffineFastState.compose env60020 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound60020 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env60021 : List Nat := [2,4,8,1,32,0,5,256,261,257,2048,0,8192,0,8461,34,8460,38,256,8460,0,264,8461,35,8204,8460,302,8461,0,10280,8204,8460,256,8200,0,261]

theorem envBound60021 : H12AffineFastState.Bounded env60021 := by
  intro p hp
  have h : env60021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60020_60021 : H12AffineEnvironment.transform 5 0 env60020 = env60021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env60020 == env60021) = true)

theorem identity60021 : scanCanonicalize (H12AffineFastState.compose env60021 (packedSelected [0,3,7,8,11,12,13,15] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound60021 : packedSelected [0,3,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60022 : List Nat := [2,4,8,1,10,0,5,256,261,257,2048,0,8192,0,8461,8,8460,12,256,8460,0,264,8461,9,8204,8460,260,8461,0,10242,8204,8460,256,8200,0,261]

theorem envBound60022 : H12AffineFastState.Bounded env60022 := by
  intro p hp
  have h : env60022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60021_60022 : H12AffineEnvironment.transform 4 10 env60021 = env60022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env60021 == env60022) = true)

theorem identity60022 : scanCanonicalize (H12AffineFastState.compose env60022 (packedSelected [3,5,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 257) := by decide +kernel

theorem selectedBound60022 : packedSelected [3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env60023 : List Nat := [2,4,8,1,10,0,5,256,261,257,2048,0,257,0,12,8,13,12,256,13,0,264,12,9,269,13,260,12,0,2307,269,13,256,265,0,261]

theorem envBound60023 : H12AffineFastState.Bounded env60023 := by
  intro p hp
  have h : env60023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60022_60023 : H12AffineEnvironment.transform 12 257 env60022 = env60023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 257 env60022 == env60023) = true)

theorem identity60023 : scanCanonicalize (H12AffineFastState.compose env60023 (packedSelected [3,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound60023 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env60024 : List Nat := [2,4,4,1,6,0,5,256,261,257,2048,0,257,0,0,4,1,0,256,1,0,260,0,5,257,1,260,0,0,2307,257,1,256,261,0,261]

theorem envBound60024 : H12AffineFastState.Bounded env60024 := by
  intro p hp
  have h : env60024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60023_60024 : H12AffineEnvironment.transform 2 4 env60023 = env60024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env60023 == env60024) = true)

theorem identity60024 : scanCanonicalize (H12AffineFastState.compose env60024 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound60024 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env60025 : List Nat := [2,3,3,1,1,0,2,256,258,257,2048,0,257,0,0,3,1,0,256,1,0,259,0,2,257,1,259,0,0,2307,257,1,256,258,0,258]

theorem envBound60025 : H12AffineFastState.Bounded env60025 := by
  intro p hp
  have h : env60025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60024_60025 : H12AffineEnvironment.transform 1 3 env60024 = env60025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env60024 == env60025) = true)

theorem identity60025 : scanCanonicalize (H12AffineFastState.compose env60025 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound60025 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60026 : List Nat := [2,3,3,1,1,0,2,256,258,257,1,0,257,0,0,3,1,0,256,1,0,259,0,2,257,1,259,0,0,258,257,1,256,258,0,258]

theorem envBound60026 : H12AffineFastState.Bounded env60026 := by
  intro p hp
  have h : env60026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60025_60026 : H12AffineEnvironment.transform 10 1 env60025 = env60026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env60025 == env60026) = true)

theorem identity60026 : scanCanonicalize (H12AffineFastState.compose env60026 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound60026 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60027 : List Nat := [2,3,3,1,1,0,2,3,1,2,1,0,2,0,0,3,1,0,3,1,0,0,0,2,2,1,0,0,0,1,2,1,3,1,0,1]

theorem envBound60027 : H12AffineFastState.Bounded env60027 := by
  intro p hp
  have h : env60027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60026_60027 : H12AffineEnvironment.transform 7 3 env60026 = env60027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env60026 == env60027) = true)

def env60028 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,8192,81,12636,65536,74030,65665,4416,12637,4096,476,74046,69648,12425,78190,4415,74110,81,79882,8204,74094,256,8200,0,4437]

theorem envBound60028 : H12AffineFastState.Bounded env60028 := by
  intro p hp
  have h : env60028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59988_60028 : H12AffineEnvironment.transform 8 341 env59988 = env60028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env59988 == env60028) = true)

def env60029 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,16,8192,81,8524,65536,74030,65665,336,8525,16,476,74046,65536,8345,74110,303,74110,81,75802,8204,74094,256,8200,0,325]

theorem envBound60029 : H12AffineFastState.Bounded env60029 := by
  intro p hp
  have h : env60029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60028_60029 : H12AffineEnvironment.transform 11 16 env60028 = env60029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env60028 == env60029) = true)

theorem identity60029 : scanCanonicalize (H12AffineFastState.compose env60029 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 192) := by decide +kernel

theorem selectedBound60029 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env60030 : List Nat := [2,4,8,16,32,64,128,192,149,129,2048,16,8192,81,8332,65536,73966,65665,144,8333,16,28,73982,65536,8345,73918,239,73918,81,75802,8204,73902,192,8200,0,133]

theorem envBound60030 : H12AffineFastState.Bounded env60030 := by
  intro p hp
  have h : env60030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60029_60030 : H12AffineEnvironment.transform 7 192 env60029 = env60030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 192 env60029 == env60030) = true)

def env60031 : List Nat := [2,4,8,0,32,64,128,192,133,129,2048,0,8192,65,8332,65536,73966,65665,128,8333,0,12,73966,65536,8329,73902,239,73902,65,75786,8204,73902,192,8200,0,133]

theorem envBound60031 : H12AffineFastState.Bounded env60031 := by
  intro p hp
  have h : env60031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60030_60031 : H12AffineEnvironment.transform 3 0 env60030 = env60031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60030 == env60031) = true)

theorem identity60031 : scanCanonicalize (H12AffineFastState.compose env60031 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound60031 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60032 : List Nat := [2,4,8,0,32,64,128,192,133,129,2048,0,8192,65,8332,99,8333,226,128,8333,0,12,8333,99,8329,8397,239,8397,65,10345,8204,8397,192,8200,0,133]

theorem envBound60032 : H12AffineFastState.Bounded env60032 := by
  intro p hp
  have h : env60032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60031_60032 : H12AffineEnvironment.transform 15 99 env60031 = env60032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env60031 == env60032) = true)

theorem identity60032 : scanCanonicalize (H12AffineFastState.compose env60032 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound60032 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env60033 : List Nat := [2,4,8,0,32,1,128,129,133,129,2048,0,8192,0,8332,34,8333,163,128,8333,0,12,8333,34,8329,8332,174,8332,0,10280,8204,8332,129,8200,0,133]

theorem envBound60033 : H12AffineFastState.Bounded env60033 := by
  intro p hp
  have h : env60033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60032_60033 : H12AffineEnvironment.transform 5 1 env60032 = env60033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env60032 == env60033) = true)

theorem identity60033 : scanCanonicalize (H12AffineFastState.compose env60033 (packedSelected [0,3,7,8,11,12,13,15] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound60033 : packedSelected [0,3,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60034 : List Nat := [2,4,8,0,10,1,128,129,133,129,2048,0,8192,0,8332,8,8333,137,128,8333,0,12,8333,8,8329,8332,132,8332,0,10242,8204,8332,129,8200,0,133]

theorem envBound60034 : H12AffineFastState.Bounded env60034 := by
  intro p hp
  have h : env60034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60033_60034 : H12AffineEnvironment.transform 4 10 env60033 = env60034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env60033 == env60034) = true)

theorem identity60034 : scanCanonicalize (H12AffineFastState.compose env60034 (packedSelected [3,5,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 5) := by decide +kernel

theorem selectedBound60034 : packedSelected [3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env60035 : List Nat := [2,4,8,0,10,1,128,129,133,129,2048,0,5,0,137,8,136,137,128,136,0,12,136,8,140,137,132,137,0,2055,9,137,129,13,0,133]

theorem envBound60035 : H12AffineFastState.Bounded env60035 := by
  intro p hp
  have h : env60035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60034_60035 : H12AffineEnvironment.transform 12 5 env60034 = env60035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5 env60034 == env60035) = true)

theorem identity60035 : scanCanonicalize (H12AffineFastState.compose env60035 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound60035 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env60036 : List Nat := [2,4,8,0,10,1,9,8,12,8,2048,0,5,0,0,8,1,0,9,1,0,12,1,8,5,0,13,0,0,2055,9,0,8,13,0,12]

theorem envBound60036 : H12AffineFastState.Bounded env60036 := by
  intro p hp
  have h : env60036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60035_60036 : H12AffineEnvironment.transform 6 9 env60035 = env60036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env60035 == env60036) = true)

theorem identity60036 : scanCanonicalize (H12AffineFastState.compose env60036 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound60036 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env60037 : List Nat := [2,4,2,0,0,1,3,2,6,2,2048,0,5,0,0,2,1,0,3,1,0,6,1,2,5,0,7,0,0,2055,3,0,2,7,0,6]

theorem envBound60037 : H12AffineFastState.Bounded env60037 := by
  intro p hp
  have h : env60037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60036_60037 : H12AffineEnvironment.transform 2 2 env60036 = env60037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env60036 == env60037) = true)

theorem identity60037 : scanCanonicalize (H12AffineFastState.compose env60037 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound60037 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60038 : List Nat := [2,4,2,0,0,1,3,2,6,2,1,0,5,0,0,2,1,0,3,1,0,6,1,2,5,0,7,0,0,6,3,0,2,7,0,6]

theorem envBound60038 : H12AffineFastState.Bounded env60038 := by
  intro p hp
  have h : env60038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60037_60038 : H12AffineEnvironment.transform 10 1 env60037 = env60038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env60037 == env60038) = true)

theorem identity60038 : scanCanonicalize (H12AffineFastState.compose env60038 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound60038 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60039 : List Nat := [2,3,2,0,0,1,3,2,1,2,1,0,2,0,0,2,1,0,3,1,0,1,1,2,2,0,0,0,0,1,3,0,2,0,0,1]

theorem envBound60039 : H12AffineFastState.Bounded env60039 := by
  intro p hp
  have h : env60039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60038_60039 : H12AffineEnvironment.transform 1 3 env60038 = env60039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env60038 == env60039) = true)

def env60040 : List Nat := [2,4,8,1,32,64,128,192,132,129,2048,1,8192,64,8332,65536,73966,65665,129,8333,1,13,73967,65536,8328,73903,239,73903,64,75787,8204,73902,192,8200,0,133]

theorem envBound60040 : H12AffineFastState.Bounded env60040 := by
  intro p hp
  have h : env60040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60030_60040 : H12AffineEnvironment.transform 3 1 env60030 = env60040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env60030 == env60040) = true)

theorem identity60040 : scanCanonicalize (H12AffineFastState.compose env60040 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 204) := by decide +kernel

theorem selectedBound60040 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60041 : List Nat := [2,4,8,1,32,64,128,192,132,129,2048,1,204,64,64,65536,65570,65665,129,65,1,13,65571,65536,68,65635,239,65635,64,67783,192,65634,192,196,0,133]

theorem envBound60041 : H12AffineFastState.Bounded env60041 := by
  intro p hp
  have h : env60041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60040_60041 : H12AffineEnvironment.transform 12 204 env60040 = env60041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 204 env60040 == env60041) = true)

theorem identity60041 : scanCanonicalize (H12AffineFastState.compose env60041 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 231) := by decide +kernel

theorem selectedBound60041 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60042 : List Nat := [2,4,8,1,32,64,128,192,132,129,2048,1,204,64,64,231,197,102,129,65,1,13,196,231,68,132,239,132,64,2080,192,133,192,196,0,133]

theorem envBound60042 : H12AffineFastState.Bounded env60042 := by
  intro p hp
  have h : env60042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60041_60042 : H12AffineEnvironment.transform 15 231 env60041 = env60042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 231 env60041 == env60042) = true)

def env60043 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,17,8192,81,8525,65536,74030,65665,337,8524,17,476,74046,65537,8344,74111,302,74110,81,75803,8204,74094,256,8200,0,324]

theorem envBound60043 : H12AffineFastState.Bounded env60043 := by
  intro p hp
  have h : env60043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60028_60043 : H12AffineEnvironment.transform 11 17 env60028 = env60043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env60028 == env60043) = true)

theorem identity60043 : scanCanonicalize (H12AffineFastState.compose env60043 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 392) := by decide +kernel

theorem selectedBound60043 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env60044 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,17,392,81,197,65536,65702,65665,337,196,17,476,65718,65537,272,65783,302,65782,81,67987,388,65766,256,384,0,324]

theorem envBound60044 : H12AffineFastState.Bounded env60044 := by
  intro p hp
  have h : env60044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60043_60044 : H12AffineEnvironment.transform 12 392 env60043 = env60044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 392 env60043 == env60044) = true)

def env60045 : List Nat := [2,4,8,0,32,64,128,256,325,321,2048,1,392,65,197,65536,65702,65665,321,196,1,460,65702,65537,256,65767,302,65766,65,67971,388,65766,256,384,0,324]

theorem envBound60045 : H12AffineFastState.Bounded env60045 := by
  intro p hp
  have h : env60045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60044_60045 : H12AffineEnvironment.transform 3 0 env60044 = env60045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60044 == env60045) = true)

theorem identity60045 : scanCanonicalize (H12AffineFastState.compose env60045 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound60045 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60046 : List Nat := [2,4,8,0,32,64,4,256,325,321,2048,1,268,65,65,65536,65570,65541,321,64,1,328,65570,65537,256,65635,302,65634,65,67847,256,65634,256,260,0,324]

theorem envBound60046 : H12AffineFastState.Bounded env60046 := by
  intro p hp
  have h : env60046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60045_60046 : H12AffineEnvironment.transform 6 4 env60045 = env60046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env60045 == env60046) = true)

theorem identity60046 : scanCanonicalize (H12AffineFastState.compose env60046 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 294) := by decide +kernel

theorem selectedBound60046 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60047 : List Nat := [2,4,8,0,32,64,4,256,325,321,2048,1,268,65,65,294,260,291,321,64,1,328,260,295,256,325,302,324,65,2081,256,324,256,260,0,324]

theorem envBound60047 : H12AffineFastState.Bounded env60047 := by
  intro p hp
  have h : env60047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60046_60047 : H12AffineEnvironment.transform 15 294 env60046 = env60047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 294 env60046 == env60047) = true)

theorem identity60047 : scanCanonicalize (H12AffineFastState.compose env60047 (packedSelected [0,1,2,5,7,8,11,12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound60047 : packedSelected [0,1,2,5,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60048 : List Nat := [2,4,8,0,32,64,4,100,33,37,2048,1,104,65,65,66,96,71,37,64,1,44,96,67,100,33,74,32,65,2081,100,32,100,96,0,32]

theorem envBound60048 : H12AffineFastState.Bounded env60048 := by
  intro p hp
  have h : env60048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60047_60048 : H12AffineEnvironment.transform 7 100 env60047 = env60048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env60047 == env60048) = true)

theorem identity60048 : scanCanonicalize (H12AffineFastState.compose env60048 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound60048 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60049 : List Nat := [2,4,8,0,0,64,4,68,1,5,2048,1,72,65,65,66,64,71,5,64,1,12,64,67,68,1,74,0,65,2049,68,0,68,64,0,0]

theorem envBound60049 : H12AffineFastState.Bounded env60049 := by
  intro p hp
  have h : env60049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60048_60049 : H12AffineEnvironment.transform 4 0 env60048 = env60049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env60048 == env60049) = true)

theorem identity60049 : scanCanonicalize (H12AffineFastState.compose env60049 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound60049 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60050 : List Nat := [2,4,4,0,0,64,4,68,1,5,2048,1,68,65,65,66,64,71,5,64,1,0,64,67,68,1,70,0,65,2049,68,0,68,64,0,0]

theorem envBound60050 : H12AffineFastState.Bounded env60050 := by
  intro p hp
  have h : env60050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60049_60050 : H12AffineEnvironment.transform 2 4 env60049 = env60050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env60049 == env60050) = true)

theorem identity60050 : scanCanonicalize (H12AffineFastState.compose env60050 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound60050 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60051 : List Nat := [2,1,1,0,0,64,1,65,1,0,2048,1,65,65,65,66,64,66,0,64,1,0,64,67,65,1,67,0,65,2049,65,0,65,64,0,0]

theorem envBound60051 : H12AffineFastState.Bounded env60051 := by
  intro p hp
  have h : env60051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60050_60051 : H12AffineEnvironment.transform 1 1 env60050 = env60051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env60050 == env60051) = true)

theorem identity60051 : scanCanonicalize (H12AffineFastState.compose env60051 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 3) := by decide +kernel

theorem selectedBound60051 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env60052 : List Nat := [2,1,1,0,0,64,1,65,1,0,3,1,65,65,65,66,64,66,0,64,1,0,64,67,65,1,67,0,65,2,65,0,65,64,0,0]

theorem envBound60052 : H12AffineFastState.Bounded env60052 := by
  intro p hp
  have h : env60052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60051_60052 : H12AffineEnvironment.transform 10 3 env60051 = env60052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 3 env60051 == env60052) = true)

theorem identity60052 : scanCanonicalize (H12AffineFastState.compose env60052 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound60052 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60053 : List Nat := [2,1,1,0,0,3,1,2,1,0,3,1,2,2,2,1,3,1,0,3,1,0,3,0,2,1,0,0,2,2,2,0,2,3,0,0]

theorem envBound60053 : H12AffineFastState.Bounded env60053 := by
  intro p hp
  have h : env60053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60052_60053 : H12AffineEnvironment.transform 5 3 env60052 = env60053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env60052 == env60053) = true)

theorem identity60053 : scanCanonicalize (H12AffineFastState.compose env60053 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60053 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60054 : List Nat := [1,1,1,0,0,0,1,1,1,0,0,1,1,1,1,1,0,1,0,0,1,0,0,0,1,1,0,0,1,1,1,0,1,0,0,0]

theorem envBound60054 : H12AffineFastState.Bounded env60054 := by
  intro p hp
  have h : env60054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60053_60054 : H12AffineEnvironment.transform 0 1 env60053 = env60054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60053 == env60054) = true)

def env60055 : List Nat := [2,4,8,1,32,64,128,256,324,321,2048,0,392,64,197,65536,65702,65665,320,196,0,461,65703,65537,257,65766,302,65767,64,67970,388,65766,256,384,0,324]

theorem envBound60055 : H12AffineFastState.Bounded env60055 := by
  intro p hp
  have h : env60055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60044_60055 : H12AffineEnvironment.transform 3 1 env60044 = env60055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env60044 == env60055) = true)

theorem identity60055 : scanCanonicalize (H12AffineFastState.compose env60055 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound60055 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60056 : List Nat := [2,4,8,1,32,64,128,256,324,321,2048,0,392,64,197,98,196,227,320,196,0,461,197,99,257,132,302,133,64,2528,388,132,256,384,0,324]

theorem envBound60056 : H12AffineFastState.Bounded env60056 := by
  intro p hp
  have h : env60056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60055_60056 : H12AffineEnvironment.transform 15 98 env60055 = env60056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env60055 == env60056) = true)

theorem identity60056 : scanCanonicalize (H12AffineFastState.compose env60056 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound60056 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env60057 : List Nat := [2,4,8,1,32,0,128,256,260,257,2048,0,392,0,133,34,132,163,256,132,0,397,133,35,257,132,302,133,0,2464,388,132,256,384,0,260]

theorem envBound60057 : H12AffineFastState.Bounded env60057 := by
  intro p hp
  have h : env60057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60056_60057 : H12AffineEnvironment.transform 5 0 env60056 = env60057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env60056 == env60057) = true)

theorem identity60057 : scanCanonicalize (H12AffineFastState.compose env60057 (packedSelected [0,3,7,8,11,12,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound60057 : packedSelected [0,3,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60058 : List Nat := [2,4,8,1,32,0,46,256,260,257,2048,0,294,0,43,34,42,13,256,42,0,291,43,35,257,42,302,43,0,2318,298,42,256,302,0,260]

theorem envBound60058 : H12AffineFastState.Bounded env60058 := by
  intro p hp
  have h : env60058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60057_60058 : H12AffineEnvironment.transform 6 46 env60057 = env60058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env60057 == env60058) = true)

theorem identity60058 : scanCanonicalize (H12AffineFastState.compose env60058 (packedSelected [3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound60058 : packedSelected [3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env60059 : List Nat := [2,4,8,1,32,0,46,8,12,9,2048,0,46,0,43,34,42,13,8,42,0,43,43,35,9,42,38,43,0,2054,34,42,8,38,0,12]

theorem envBound60059 : H12AffineFastState.Bounded env60059 := by
  intro p hp
  have h : env60059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60058_60059 : H12AffineEnvironment.transform 7 8 env60058 = env60059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env60058 == env60059) = true)

theorem identity60059 : scanCanonicalize (H12AffineFastState.compose env60059 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound60059 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env60060 : List Nat := [2,4,8,1,6,0,8,8,12,9,2048,0,8,0,13,4,12,13,8,12,0,13,13,5,9,12,0,13,0,2054,4,12,8,0,0,12]

theorem envBound60060 : H12AffineFastState.Bounded env60060 := by
  intro p hp
  have h : env60060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60059_60060 : H12AffineEnvironment.transform 4 6 env60059 = env60060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env60059 == env60060) = true)

theorem identity60060 : scanCanonicalize (H12AffineFastState.compose env60060 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound60060 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60061 : List Nat := [2,4,8,1,6,0,8,8,12,9,12,0,8,0,13,4,12,13,8,12,0,13,13,5,9,12,0,13,0,10,4,12,8,0,0,12]

theorem envBound60061 : H12AffineFastState.Bounded env60061 := by
  intro p hp
  have h : env60061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60060_60061 : H12AffineEnvironment.transform 10 12 env60060 = env60061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env60060 == env60061) = true)

def env60062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,262144,4417,13340,4096,477,74047,69649,13769,78895,332223,74814,1296,81226,8205,74799,256,8201,1345,5952]

theorem envBound60062 : H12AffineFastState.Bounded env60062 := by
  intro p hp
  have h : env60062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59902_60062 : H12AffineEnvironment.transform 13 1297 env59902 = env60062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env59902 == env60062) = true)

def env60063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65664,4417,13340,4096,477,74047,69649,13769,78895,4415,74814,1296,81226,8205,74799,256,8201,1345,5952]

theorem envBound60063 : H12AffineFastState.Bounded env60063 := by
  intro p hp
  have h : env60063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60062_60063 : H12AffineEnvironment.transform 17 65664 env60062 = env60063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env60062 == env60063) = true)

theorem identity60063 : scanCanonicalize (H12AffineFastState.compose env60063 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound60063 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1297,5205,65536,66599,65664,4417,5204,4096,477,65911,69649,5505,70759,4415,66678,1296,72962,69,66663,256,65,1345,5952]

theorem envBound60064 : H12AffineFastState.Bounded env60064 := by
  intro p hp
  have h : env60064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60063_60064 : H12AffineEnvironment.transform 12 72 env60063 = env60064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env60063 == env60064) = true)

def env60065 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,72,1297,5205,65536,66599,65664,4417,5204,4096,477,65911,69649,5505,70759,4415,66678,1296,72962,69,66663,256,65,1345,5140]

theorem envBound60065 : H12AffineFastState.Bounded env60065 := by
  intro p hp
  have h : env60065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60064_60065 : H12AffineEnvironment.transform 8 340 env60064 = env60065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env60064 == env60065) = true)

def env60066 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,72,81,4373,65536,65895,65664,4417,4372,4096,477,65911,69649,4289,69927,4415,65846,80,71746,69,65831,256,65,1,4436]

theorem envBound60066 : H12AffineFastState.Bounded env60066 := by
  intro p hp
  have h : env60066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60065_60066 : H12AffineEnvironment.transform 9 320 env60065 = env60066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env60065 == env60066) = true)

theorem identity60066 : scanCanonicalize (H12AffineFastState.compose env60066 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 4210) := by decide +kernel

theorem selectedBound60066 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60067 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,72,81,4373,4210,4373,4338,4417,4372,4096,477,4357,99,4289,341,4415,4420,80,2096,69,4437,256,65,1,4436]

theorem envBound60067 : H12AffineFastState.Bounded env60067 := by
  intro p hp
  have h : env60067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60066_60067 : H12AffineEnvironment.transform 15 4210 env60066 = env60067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4210 env60066 == env60067) = true)

theorem identity60067 : scanCanonicalize (H12AffineFastState.compose env60067 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound60067 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env60068 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,81,72,81,324,35,324,163,272,325,81,477,340,99,144,341,366,277,80,2096,69,260,256,65,1,261]

theorem envBound60068 : H12AffineFastState.Bounded env60068 := by
  intro p hp
  have h : env60068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60067_60068 : H12AffineEnvironment.transform 11 81 env60067 = env60068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env60067 == env60068) = true)

theorem identity60068 : scanCanonicalize (H12AffineFastState.compose env60068 (packedSelected [0,1,7,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 490) := by decide +kernel

theorem selectedBound60068 : packedSelected [0,1,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env60069 : List Nat := [2,4,8,16,32,64,128,256,340,320,490,81,72,81,324,35,324,163,272,325,81,477,340,99,144,341,366,277,80,474,69,260,256,65,1,261]

theorem envBound60069 : H12AffineFastState.Bounded env60069 := by
  intro p hp
  have h : env60069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60068_60069 : H12AffineEnvironment.transform 10 490 env60068 = env60069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 490 env60068 == env60069) = true)

theorem identity60069 : scanCanonicalize (H12AffineFastState.compose env60069 (packedSelected [1,2,3,4,5,8,9,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 100) := by decide +kernel

theorem selectedBound60069 : packedSelected [1,2,3,4,5,8,9,15,16] rootPS < 2^1333 := by decide +kernel

def env60070 : List Nat := [2,4,8,16,32,64,100,256,340,320,270,81,72,81,324,35,324,71,272,325,81,313,340,99,116,341,366,277,80,318,69,260,256,65,1,261]

theorem envBound60070 : H12AffineFastState.Bounded env60070 := by
  intro p hp
  have h : env60070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60069_60070 : H12AffineEnvironment.transform 6 100 env60069 = env60070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 100 env60069 == env60070) = true)

theorem identity60070 : scanCanonicalize (H12AffineFastState.compose env60070 (packedSelected [0,1,3,5,7,8,11,15] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound60070 : packedSelected [0,1,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env60071 : List Nat := [2,4,8,16,32,27,63,256,271,283,270,10,19,10,287,35,287,28,272,286,10,313,271,56,47,270,309,277,11,318,30,260,256,26,1,261]

theorem envBound60071 : H12AffineFastState.Bounded env60071 := by
  intro p hp
  have h : env60071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60070_60071 : H12AffineEnvironment.transform 5 27 env60070 = env60071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env60070 == env60071) = true)

theorem identity60071 : scanCanonicalize (H12AffineFastState.compose env60071 (packedSelected [1,2,5,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 41) := by decide +kernel

theorem selectedBound60071 : packedSelected [1,2,5,8,10] rootPS < 2^1333 := by decide +kernel

def env60072 : List Nat := [2,4,8,16,32,27,63,41,38,50,39,10,19,10,54,35,54,28,57,55,10,16,38,56,47,39,28,60,11,23,30,45,41,26,1,44]

theorem envBound60072 : H12AffineFastState.Bounded env60072 := by
  intro p hp
  have h : env60072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60071_60072 : H12AffineEnvironment.transform 7 41 env60071 = env60072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 41 env60071 == env60072) = true)

theorem identity60072 : scanCanonicalize (H12AffineFastState.compose env60072 (packedSelected [3,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound60072 : packedSelected [3,5,8] rootPS < 2^1333 := by decide +kernel

def env60073 : List Nat := [2,4,8,16,1,27,30,8,7,19,6,10,19,10,23,2,23,28,24,22,10,16,7,25,14,6,28,29,11,23,30,12,8,26,1,13]

theorem envBound60073 : H12AffineFastState.Bounded env60073 := by
  intro p hp
  have h : env60073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60072_60073 : H12AffineEnvironment.transform 4 1 env60072 = env60073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env60072 == env60073) = true)

theorem identity60073 : scanCanonicalize (H12AffineFastState.compose env60073 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound60073 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env60074 : List Nat := [2,4,8,1,1,10,15,8,7,2,6,10,2,10,6,2,6,13,9,7,10,1,7,8,14,6,13,12,11,6,15,12,8,11,1,13]

theorem envBound60074 : H12AffineFastState.Bounded env60074 := by
  intro p hp
  have h : env60074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60073_60074 : H12AffineEnvironment.transform 3 1 env60073 = env60074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env60073 == env60074) = true)

theorem identity60074 : scanCanonicalize (H12AffineFastState.compose env60074 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound60074 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env60075 : List Nat := [2,4,4,1,1,6,3,4,7,2,6,6,2,6,6,2,6,1,5,7,6,1,7,4,2,6,1,0,7,6,3,0,4,7,1,1]

theorem envBound60075 : H12AffineFastState.Bounded env60075 := by
  intro p hp
  have h : env60075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60074_60075 : H12AffineEnvironment.transform 2 4 env60074 = env60075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env60074 == env60075) = true)

theorem identity60075 : scanCanonicalize (H12AffineFastState.compose env60075 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound60075 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env60076 : List Nat := [2,3,3,1,1,1,3,3,0,2,1,1,2,1,1,2,1,1,2,0,1,1,0,3,2,1,1,0,0,1,3,0,3,0,1,1]

theorem envBound60076 : H12AffineFastState.Bounded env60076 := by
  intro p hp
  have h : env60076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60075_60076 : H12AffineEnvironment.transform 1 3 env60075 = env60076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env60075 == env60076) = true)

theorem identity60076 : scanCanonicalize (H12AffineFastState.compose env60076 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60076 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60077 : List Nat := [1,0,0,1,1,1,0,0,0,1,1,1,1,1,1,1,1,1,1,0,1,1,0,0,1,1,1,0,0,1,0,0,0,0,1,1]

theorem envBound60077 : H12AffineFastState.Bounded env60077 := by
  intro p hp
  have h : env60077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60076_60077 : H12AffineEnvironment.transform 0 1 env60076 = env60077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60076 == env60077) = true)

def env60078 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,72,80,4372,65536,65894,65664,4417,4373,4096,477,65911,69649,4288,69926,4415,65847,81,71747,69,65830,256,65,0,4437]

theorem envBound60078 : H12AffineFastState.Bounded env60078 := by
  intro p hp
  have h : env60078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60065_60078 : H12AffineEnvironment.transform 9 321 env60065 = env60078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env60065 == env60078) = true)

theorem identity60078 : scanCanonicalize (H12AffineFastState.compose env60078 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound60078 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60079 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,72,80,4372,114,276,242,4417,4373,4096,477,261,4195,4288,4436,4415,325,81,6193,69,340,256,65,0,4437]

theorem envBound60079 : H12AffineFastState.Bounded env60079 := by
  intro p hp
  have h : env60079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60078_60079 : H12AffineEnvironment.transform 15 114 env60078 = env60079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env60078 == env60079) = true)

theorem identity60079 : scanCanonicalize (H12AffineFastState.compose env60079 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 2138) := by decide +kernel

theorem selectedBound60079 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env60080 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,2138,72,80,2382,114,276,242,2331,2383,2138,477,261,2105,2202,2318,2405,325,81,107,69,340,256,65,0,2319]

theorem envBound60080 : H12AffineFastState.Bounded env60080 := by
  intro p hp
  have h : env60080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60079_60080 : H12AffineEnvironment.transform 11 2138 env60079 = env60080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2138 env60079 == env60080) = true)

theorem identity60080 : scanCanonicalize (H12AffineFastState.compose env60080 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(10+1) ^^^ 91) := by decide +kernel

theorem selectedBound60080 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env60081 : List Nat := [2,4,8,16,32,64,128,256,340,321,91,1,72,80,277,114,276,242,320,276,1,477,261,98,193,341,318,325,81,107,69,340,256,65,0,340]

theorem envBound60081 : H12AffineFastState.Bounded env60081 := by
  intro p hp
  have h : env60081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60080_60081 : H12AffineEnvironment.transform 10 91 env60080 = env60081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 91 env60080 == env60081) = true)

theorem identity60081 : scanCanonicalize (H12AffineFastState.compose env60081 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound60081 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60082 : List Nat := [2,4,8,16,32,64,128,140,216,205,91,1,72,80,153,114,152,242,204,152,1,81,137,98,193,217,178,201,81,107,69,216,140,65,0,216]

theorem envBound60082 : H12AffineFastState.Bounded env60082 := by
  intro p hp
  have h : env60082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60081_60082 : H12AffineEnvironment.transform 7 140 env60081 = env60082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env60081 == env60082) = true)

theorem identity60082 : scanCanonicalize (H12AffineFastState.compose env60082 (packedSelected [0,2,4,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound60082 : packedSelected [0,2,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env60083 : List Nat := [2,4,8,16,32,64,14,2,86,67,91,1,72,80,23,114,22,124,66,22,1,81,7,98,79,87,60,71,81,107,69,86,2,65,0,86]

theorem envBound60083 : H12AffineFastState.Bounded env60083 := by
  intro p hp
  have h : env60083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60082_60083 : H12AffineEnvironment.transform 6 14 env60082 = env60083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env60082 == env60083) = true)

theorem identity60083 : scanCanonicalize (H12AffineFastState.compose env60083 (packedSelected [0,1,2,3,7,8,11,12,13] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound60083 : packedSelected [0,1,2,3,7,8,11,12,13] rootPS < 2^1333 := by decide +kernel

def env60084 : List Nat := [2,4,8,16,32,1,14,2,23,2,26,1,9,17,23,51,22,61,3,22,1,16,7,35,14,22,60,6,16,42,4,23,2,0,0,23]

theorem envBound60084 : H12AffineFastState.Bounded env60084 := by
  intro p hp
  have h : env60084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60083_60084 : H12AffineEnvironment.transform 5 1 env60083 = env60084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env60083 == env60084) = true)

theorem identity60084 : scanCanonicalize (H12AffineFastState.compose env60084 (packedSelected [1,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound60084 : packedSelected [1,3,5,7] rootPS < 2^1333 := by decide +kernel

def env60085 : List Nat := [2,4,8,16,22,1,14,2,23,2,26,1,9,17,23,5,22,11,3,22,1,16,7,21,14,22,10,6,16,28,4,23,2,0,0,23]

theorem envBound60085 : H12AffineFastState.Bounded env60085 := by
  intro p hp
  have h : env60085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60084_60085 : H12AffineEnvironment.transform 4 22 env60084 = env60085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env60084 == env60085) = true)

theorem identity60085 : scanCanonicalize (H12AffineFastState.compose env60085 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound60085 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60086 : List Nat := [2,4,8,10,12,1,14,2,13,2,0,1,9,11,13,5,12,11,3,12,1,10,7,15,14,12,10,6,10,6,4,13,2,0,0,13]

theorem envBound60086 : H12AffineFastState.Bounded env60086 := by
  intro p hp
  have h : env60086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60085_60086 : H12AffineEnvironment.transform 3 10 env60085 = env60086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env60085 == env60086) = true)

theorem identity60086 : scanCanonicalize (H12AffineFastState.compose env60086 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound60086 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60087 : List Nat := [2,3,8,10,11,1,9,2,10,2,0,1,9,11,10,2,11,11,3,11,1,10,0,8,9,11,10,1,10,1,3,10,2,0,0,10]

theorem envBound60087 : H12AffineFastState.Bounded env60087 := by
  intro p hp
  have h : env60087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60086_60087 : H12AffineEnvironment.transform 1 3 env60086 = env60087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env60086 == env60087) = true)

def env60088 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,72,1297,5205,65536,66599,65664,4417,5204,4096,477,65911,69649,5505,70759,4415,66678,1296,72962,69,66663,256,65,1345,5141]

theorem envBound60088 : H12AffineFastState.Bounded env60088 := by
  intro p hp
  have h : env60088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60064_60088 : H12AffineEnvironment.transform 8 341 env60064 = env60088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env60064 == env60088) = true)

def env60089 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,72,81,4373,65536,65895,65664,4417,4372,4096,477,65911,69649,4289,69927,4415,65846,80,71746,69,65831,256,65,1,4437]

theorem envBound60089 : H12AffineFastState.Bounded env60089 := by
  intro p hp
  have h : env60089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60088_60089 : H12AffineEnvironment.transform 9 320 env60088 = env60089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env60088 == env60089) = true)

theorem identity60089 : scanCanonicalize (H12AffineFastState.compose env60089 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 4210) := by decide +kernel

theorem selectedBound60089 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60090 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,72,81,4373,4210,4373,4338,4417,4372,4096,477,4357,99,4289,341,4415,4420,80,2096,69,4437,256,65,1,4437]

theorem envBound60090 : H12AffineFastState.Bounded env60090 := by
  intro p hp
  have h : env60090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60089_60090 : H12AffineEnvironment.transform 15 4210 env60089 = env60090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4210 env60089 == env60090) = true)

theorem identity60090 : scanCanonicalize (H12AffineFastState.compose env60090 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound60090 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env60091 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,81,72,81,324,35,324,163,272,325,81,477,340,99,144,341,366,277,80,2096,69,260,256,65,1,260]

theorem envBound60091 : H12AffineFastState.Bounded env60091 := by
  intro p hp
  have h : env60091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60090_60091 : H12AffineEnvironment.transform 11 81 env60090 = env60091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env60090 == env60091) = true)

theorem identity60091 : scanCanonicalize (H12AffineFastState.compose env60091 (packedSelected [0,1,7,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 255) := by decide +kernel

theorem selectedBound60091 : packedSelected [0,1,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env60092 : List Nat := [2,4,8,16,32,64,128,256,341,320,255,81,72,81,324,35,324,163,272,325,81,477,340,99,144,341,366,277,80,207,69,260,256,65,1,260]

theorem envBound60092 : H12AffineFastState.Bounded env60092 := by
  intro p hp
  have h : env60092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60091_60092 : H12AffineEnvironment.transform 10 255 env60091 = env60092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 255 env60091 == env60092) = true)

theorem identity60092 : scanCanonicalize (H12AffineFastState.compose env60092 (packedSelected [1,2,3,4,5,8,9,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 160) := by decide +kernel

theorem selectedBound60092 : packedSelected [1,2,3,4,5,8,9,15,16] rootPS < 2^1333 := by decide +kernel

def env60093 : List Nat := [2,4,8,16,32,64,128,160,245,224,255,81,72,81,228,35,228,163,176,229,81,125,244,99,144,245,206,181,80,207,69,164,160,65,1,164]

theorem envBound60093 : H12AffineFastState.Bounded env60093 := by
  intro p hp
  have h : env60093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60092_60093 : H12AffineEnvironment.transform 7 160 env60092 = env60093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 160 env60092 == env60093) = true)

theorem identity60093 : scanCanonicalize (H12AffineFastState.compose env60093 (packedSelected [0,1,3,5,7,8,11,15] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound60093 : packedSelected [0,1,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env60094 : List Nat := [2,4,3,16,32,64,128,160,245,224,244,81,67,81,228,35,228,163,176,229,81,118,244,99,144,245,197,181,80,196,69,164,160,65,1,164]

theorem envBound60094 : H12AffineFastState.Bounded env60094 := by
  intro p hp
  have h : env60094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60093_60094 : H12AffineEnvironment.transform 2 3 env60093 = env60094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env60093 == env60094) = true)

theorem identity60094 : scanCanonicalize (H12AffineFastState.compose env60094 (packedSelected [0,1,5,7,8,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound60094 : packedSelected [0,1,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env60095 : List Nat := [2,4,3,16,23,64,128,151,194,215,195,81,67,81,211,20,211,148,135,210,81,65,195,84,144,194,197,130,80,196,69,147,151,65,1,147]

theorem envBound60095 : H12AffineFastState.Bounded env60095 := by
  intro p hp
  have h : env60095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60094_60095 : H12AffineEnvironment.transform 4 23 env60094 = env60095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env60094 == env60095) = true)

theorem identity60095 : scanCanonicalize (H12AffineFastState.compose env60095 (packedSelected [1,2,3,8] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound60095 : packedSelected [1,2,3,8] rootPS < 2^1333 := by decide +kernel

def env60096 : List Nat := [2,4,3,16,23,64,67,84,1,20,0,81,67,81,16,20,16,87,68,17,81,65,0,84,83,1,6,65,80,7,69,80,84,65,1,80]

theorem envBound60096 : H12AffineFastState.Bounded env60096 := by
  intro p hp
  have h : env60096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60095_60096 : H12AffineEnvironment.transform 6 67 env60095 = env60096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env60095 == env60096) = true)

theorem identity60096 : scanCanonicalize (H12AffineFastState.compose env60096 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound60096 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60097 : List Nat := [2,4,3,7,0,64,67,67,1,3,0,70,67,70,7,3,7,64,68,6,70,65,0,67,68,1,6,65,71,7,69,71,67,65,1,71]

theorem envBound60097 : H12AffineFastState.Bounded env60097 := by
  intro p hp
  have h : env60097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60096_60097 : H12AffineEnvironment.transform 3 7 env60096 = env60097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env60096 == env60097) = true)

theorem identity60097 : scanCanonicalize (H12AffineFastState.compose env60097 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound60097 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env60098 : List Nat := [2,3,3,0,0,64,67,67,1,3,0,65,67,65,0,3,0,64,67,1,65,65,0,67,67,1,1,65,64,0,66,64,67,65,1,64]

theorem envBound60098 : H12AffineFastState.Bounded env60098 := by
  intro p hp
  have h : env60098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60097_60098 : H12AffineEnvironment.transform 1 3 env60097 = env60098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env60097 == env60098) = true)

theorem identity60098 : scanCanonicalize (H12AffineFastState.compose env60098 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound60098 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env60099 : List Nat := [2,3,3,0,0,0,3,3,1,3,0,1,3,1,0,3,0,0,3,1,1,1,0,3,3,1,1,1,0,0,2,0,3,1,1,0]

theorem envBound60099 : H12AffineFastState.Bounded env60099 := by
  intro p hp
  have h : env60099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60098_60099 : H12AffineEnvironment.transform 5 0 env60098 = env60099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env60098 == env60099) = true)

theorem identity60099 : scanCanonicalize (H12AffineFastState.compose env60099 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60099 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60100 : List Nat := [1,0,0,0,0,0,0,0,1,0,0,1,0,1,0,0,0,0,0,1,1,1,0,0,0,1,1,1,0,0,1,0,0,1,1,0]

theorem envBound60100 : H12AffineFastState.Bounded env60100 := by
  intro p hp
  have h : env60100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60099_60100 : H12AffineEnvironment.transform 0 1 env60099 = env60100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60099 == env60100) = true)

def env60101 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,72,80,4372,65536,65894,65664,4417,4373,4096,477,65911,69649,4288,69926,4415,65847,81,71747,69,65830,256,65,0,4436]

theorem envBound60101 : H12AffineFastState.Bounded env60101 := by
  intro p hp
  have h : env60101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60088_60101 : H12AffineEnvironment.transform 9 321 env60088 = env60101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env60088 == env60101) = true)

theorem identity60101 : scanCanonicalize (H12AffineFastState.compose env60101 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound60101 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60102 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,72,80,4372,114,276,242,4417,4373,4096,477,261,4195,4288,4436,4415,325,81,6193,69,340,256,65,0,4436]

theorem envBound60102 : H12AffineFastState.Bounded env60102 := by
  intro p hp
  have h : env60102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60101_60102 : H12AffineEnvironment.transform 15 114 env60101 = env60102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env60101 == env60102) = true)

theorem identity60102 : scanCanonicalize (H12AffineFastState.compose env60102 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 2139) := by decide +kernel

theorem selectedBound60102 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env60103 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,2139,72,80,2383,114,276,242,2330,2382,2139,477,261,2104,2203,2319,2404,325,81,106,69,340,256,65,0,2319]

theorem envBound60103 : H12AffineFastState.Bounded env60103 := by
  intro p hp
  have h : env60103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60102_60103 : H12AffineEnvironment.transform 11 2139 env60102 = env60103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2139 env60102 == env60103) = true)

theorem identity60103 : scanCanonicalize (H12AffineFastState.compose env60103 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(10+1) ^^^ 90) := by decide +kernel

theorem selectedBound60103 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env60104 : List Nat := [2,4,8,16,32,64,128,256,341,321,90,1,72,80,277,114,276,242,320,276,1,477,261,98,193,341,318,325,81,106,69,340,256,65,0,341]

theorem envBound60104 : H12AffineFastState.Bounded env60104 := by
  intro p hp
  have h : env60104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60103_60104 : H12AffineEnvironment.transform 10 90 env60103 = env60104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 90 env60103 == env60104) = true)

theorem identity60104 : scanCanonicalize (H12AffineFastState.compose env60104 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound60104 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60105 : List Nat := [2,4,8,16,32,64,128,141,216,204,90,1,72,80,152,114,153,242,205,153,1,80,136,98,193,216,179,200,81,106,69,217,141,65,0,216]

theorem envBound60105 : H12AffineFastState.Bounded env60105 := by
  intro p hp
  have h : env60105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60104_60105 : H12AffineEnvironment.transform 7 141 env60104 = env60105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env60104 == env60105) = true)

theorem identity60105 : scanCanonicalize (H12AffineFastState.compose env60105 (packedSelected [0,2,4,5,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound60105 : packedSelected [0,2,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env60106 : List Nat := [2,4,8,6,32,64,128,141,206,204,76,1,72,70,142,100,143,228,205,143,1,70,136,98,193,206,165,200,71,106,69,207,141,65,0,206]

theorem envBound60106 : H12AffineFastState.Bounded env60106 := by
  intro p hp
  have h : env60106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60105_60106 : H12AffineEnvironment.transform 3 6 env60105 = env60106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env60105 == env60106) = true)

theorem identity60106 : scanCanonicalize (H12AffineFastState.compose env60106 (packedSelected [0,1,2,3,7,8,11,12,13] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound60106 : packedSelected [0,1,2,3,7,8,11,12,13] rootPS < 2^1333 := by decide +kernel

def env60107 : List Nat := [2,4,8,6,32,0,128,141,142,140,12,1,8,6,142,36,143,164,141,143,1,6,136,34,129,142,165,136,7,42,5,143,141,1,0,142]

theorem envBound60107 : H12AffineFastState.Bounded env60107 := by
  intro p hp
  have h : env60107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60106_60107 : H12AffineEnvironment.transform 5 0 env60106 = env60107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env60106 == env60107) = true)

theorem identity60107 : scanCanonicalize (H12AffineFastState.compose env60107 (packedSelected [1,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound60107 : packedSelected [1,3,5,7] rootPS < 2^1333 := by decide +kernel

def env60108 : List Nat := [2,4,8,6,32,0,46,35,32,34,12,1,8,6,32,36,33,10,35,33,1,6,38,34,47,32,11,38,7,42,5,33,35,1,0,32]

theorem envBound60108 : H12AffineFastState.Bounded env60108 := by
  intro p hp
  have h : env60108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60107_60108 : H12AffineEnvironment.transform 6 46 env60107 = env60108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env60107 == env60108) = true)

theorem identity60108 : scanCanonicalize (H12AffineFastState.compose env60108 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound60108 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60109 : List Nat := [2,4,4,6,32,0,34,35,32,34,0,1,4,6,32,36,33,6,35,33,1,6,38,34,35,32,7,38,7,38,5,33,35,1,0,32]

theorem envBound60109 : H12AffineFastState.Bounded env60109 := by
  intro p hp
  have h : env60109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60108_60109 : H12AffineEnvironment.transform 2 4 env60108 = env60109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env60108 == env60109) = true)

theorem identity60109 : scanCanonicalize (H12AffineFastState.compose env60109 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound60109 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60110 : List Nat := [2,4,4,6,7,0,5,4,7,5,0,1,4,6,7,3,6,6,4,6,1,6,1,5,4,7,7,1,7,1,5,6,4,1,0,7]

theorem envBound60110 : H12AffineFastState.Bounded env60110 := by
  intro p hp
  have h : env60110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60109_60110 : H12AffineEnvironment.transform 4 7 env60109 = env60110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env60109 == env60110) = true)

def env60111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65665,4417,13340,4096,477,74047,69649,13769,78895,4414,74814,1296,81226,8205,74799,256,8201,1345,5952]

theorem envBound60111 : H12AffineFastState.Bounded env60111 := by
  intro p hp
  have h : env60111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60062_60111 : H12AffineEnvironment.transform 17 65665 env60062 = env60111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env60062 == env60111) = true)

theorem identity60111 : scanCanonicalize (H12AffineFastState.compose env60111 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5385) := by decide +kernel

theorem selectedBound60111 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1297,276,65536,69990,65665,4417,277,4096,477,70710,69649,192,65830,4414,69943,1296,67651,5380,69926,256,5376,1345,5952]

theorem envBound60112 : H12AffineFastState.Bounded env60112 := by
  intro p hp
  have h : env60112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60111_60112 : H12AffineEnvironment.transform 12 5385 env60111 = env60112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env60111 == env60112) = true)

def env60113 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,5385,1297,276,65536,69990,65665,4417,277,4096,477,70710,69649,192,65830,4414,69943,1296,67651,5380,69926,256,5376,1345,5140]

theorem envBound60113 : H12AffineFastState.Bounded env60113 := by
  intro p hp
  have h : env60113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60112_60113 : H12AffineEnvironment.transform 8 340 env60112 = env60113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env60112 == env60113) = true)

def env60114 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,1289,1297,276,65536,65894,65665,321,277,0,477,66614,65553,192,65830,318,65847,1296,67651,1284,65830,256,1280,1345,1044]

theorem envBound60114 : H12AffineFastState.Bounded env60114 := by
  intro p hp
  have h : env60114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60113_60114 : H12AffineEnvironment.transform 11 0 env60113 = env60114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env60113 == env60114) = true)

theorem identity60114 : scanCanonicalize (H12AffineFastState.compose env60114 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound60114 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60115 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,1289,1297,276,114,276,243,321,277,0,477,1092,99,192,340,318,325,1296,2097,1284,340,256,1280,1345,1044]

theorem envBound60115 : H12AffineFastState.Bounded env60115 := by
  intro p hp
  have h : env60115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60114_60115 : H12AffineEnvironment.transform 15 114 env60114 = env60115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env60114 == env60115) = true)

theorem identity60115 : scanCanonicalize (H12AffineFastState.compose env60115 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 286) := by decide +kernel

theorem selectedBound60115 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env60116 : List Nat := [2,4,8,16,32,64,128,256,340,1024,286,0,1289,1297,276,114,276,243,321,277,0,477,1092,99,192,340,318,325,1296,303,1284,340,256,1280,1345,1044]

theorem envBound60116 : H12AffineFastState.Bounded env60116 := by
  intro p hp
  have h : env60116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60115_60116 : H12AffineEnvironment.transform 10 286 env60115 = env60116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 286 env60115 == env60116) = true)

theorem identity60116 : scanCanonicalize (H12AffineFastState.compose env60116 (packedSelected [2,11,17,18,21] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound60116 : packedSelected [2,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env60117 : List Nat := [2,4,8,16,32,64,128,256,340,320,286,0,73,81,276,114,276,243,321,277,0,477,260,99,192,340,318,325,80,303,68,340,256,64,1,340]

theorem envBound60117 : H12AffineFastState.Bounded env60117 := by
  intro p hp
  have h : env60117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60116_60117 : H12AffineEnvironment.transform 9 320 env60116 = env60117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env60116 == env60117) = true)

theorem identity60117 : scanCanonicalize (H12AffineFastState.compose env60117 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound60117 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60118 : List Nat := [2,4,8,16,32,64,128,141,217,205,147,0,73,81,153,114,153,243,204,152,0,80,137,99,192,217,179,200,80,162,68,217,141,64,1,217]

theorem envBound60118 : H12AffineFastState.Bounded env60118 := by
  intro p hp
  have h : env60118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60117_60118 : H12AffineEnvironment.transform 7 141 env60117 = env60118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env60117 == env60118) = true)

theorem identity60118 : scanCanonicalize (H12AffineFastState.compose env60118 (packedSelected [1,3,4,8,9,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound60118 : packedSelected [1,3,4,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env60119 : List Nat := [2,4,8,16,32,64,4,9,93,73,23,0,73,81,29,114,29,119,72,28,0,80,13,99,68,93,55,76,80,38,68,93,9,64,1,93]

theorem envBound60119 : H12AffineFastState.Bounded env60119 := by
  intro p hp
  have h : env60119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60118_60119 : H12AffineEnvironment.transform 6 4 env60118 = env60119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env60118 == env60119) = true)

theorem identity60119 : scanCanonicalize (H12AffineFastState.compose env60119 (packedSelected [0,1,2,3,4,5,7,9,13] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound60119 : packedSelected [0,1,2,3,4,5,7,9,13] rootPS < 2^1333 := by decide +kernel

def env60120 : List Nat := [2,4,8,16,32,38,4,9,59,47,23,0,47,55,29,20,29,17,46,28,0,54,13,5,34,59,55,42,54,38,34,59,9,38,1,59]

theorem envBound60120 : H12AffineFastState.Bounded env60120 := by
  intro p hp
  have h : env60120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60119_60120 : H12AffineEnvironment.transform 5 38 env60119 = env60120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env60119 == env60120) = true)

theorem identity60120 : scanCanonicalize (H12AffineFastState.compose env60120 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound60120 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env60121 : List Nat := [2,4,8,16,22,16,4,9,13,25,23,0,25,1,29,20,29,17,24,28,0,0,13,5,20,13,1,28,0,16,20,13,9,16,1,13]

theorem envBound60121 : H12AffineFastState.Bounded env60121 := by
  intro p hp
  have h : env60121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60120_60121 : H12AffineEnvironment.transform 4 22 env60120 = env60121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env60120 == env60121) = true)

def env60122 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,1288,1297,276,65536,65895,65665,320,277,1,477,66615,65552,192,65830,319,65846,1296,67651,1285,65831,256,1281,1345,1045]

theorem envBound60122 : H12AffineFastState.Bounded env60122 := by
  intro p hp
  have h : env60122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60113_60122 : H12AffineEnvironment.transform 11 1 env60113 = env60122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env60113 == env60122) = true)

theorem identity60122 : scanCanonicalize (H12AffineFastState.compose env60122 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound60122 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60123 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,1288,1297,276,1331,1108,1458,320,277,1,477,260,1315,192,1045,319,1029,1296,3440,1285,1044,256,1281,1345,1045]

theorem envBound60123 : H12AffineFastState.Bounded env60123 := by
  intro p hp
  have h : env60123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60122_60123 : H12AffineEnvironment.transform 15 1331 env60122 = env60123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env60122 == env60123) = true)

theorem identity60123 : scanCanonicalize (H12AffineFastState.compose env60123 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1442) := by decide +kernel

theorem selectedBound60123 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env60124 : List Nat := [2,4,8,16,32,64,128,256,340,1024,1442,1,1288,1297,276,1331,1108,1458,320,277,1,477,260,1315,192,1045,319,1029,1296,210,1285,1044,256,1281,1345,1045]

theorem envBound60124 : H12AffineFastState.Bounded env60124 := by
  intro p hp
  have h : env60124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2