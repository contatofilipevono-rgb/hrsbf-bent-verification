import H12CloudChart2Data231

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound58571 : H12AffineFastState.Bounded env58571 := by
  intro p hp
  have h : env58571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58570_58571 : H12AffineEnvironment.transform 5 17 env58570 = env58571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58570 == env58571) = true)

theorem identity58571 : scanCanonicalize (H12AffineFastState.compose env58571 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound58571 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58572 : List Nat := [2,4,8,16,32,17,128,14,512,4,2048,4096,8192,16384,24600,28704,20507,4281,5,24601,4097,4249,4106,16434,8329,4107,20523,4097,20507,2091,20495,20490,14,11,26,512]

theorem envBound58572 : H12AffineFastState.Bounded env58572 := by
  intro p hp
  have h : env58572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58571_58572 : H12AffineEnvironment.transform 9 4 env58571 = env58572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env58571 == env58572) = true)

theorem identity58572 : scanCanonicalize (H12AffineFastState.compose env58572 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58572 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58573 : List Nat := [2,4,8,11,32,10,128,14,512,4,2048,4096,8192,16384,24579,28704,20480,4258,5,24578,4097,4226,4106,16425,8329,4107,20523,4097,20480,2091,20495,20490,14,11,1,512]

theorem envBound58573 : H12AffineFastState.Bounded env58573 := by
  intro p hp
  have h : env58573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58572_58573 : H12AffineEnvironment.transform 3 11 env58572 = env58573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58572 == env58573) = true)

theorem identity58573 : scanCanonicalize (H12AffineFastState.compose env58573 (packedSelected [1,3,5,8,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound58573 : packedSelected [1,3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env58574 : List Nat := [2,4,8,11,32,10,128,14,512,4,555,4096,8192,16384,24579,28704,20480,4258,5,24578,4097,4226,4106,16425,8329,4107,20523,4097,20480,512,20495,20490,14,11,1,512]

theorem envBound58574 : H12AffineFastState.Bounded env58574 := by
  intro p hp
  have h : env58574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58573_58574 : H12AffineEnvironment.transform 10 555 env58573 = env58574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env58573 == env58574) = true)

theorem identity58574 : scanCanonicalize (H12AffineFastState.compose env58574 (packedSelected [10,15] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound58574 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env58575 : List Nat := [2,4,8,11,10,10,128,14,512,4,513,4096,8192,16384,24579,28682,20480,4232,5,24578,4097,4226,4106,16387,8329,4107,20481,4097,20480,512,20495,20490,14,11,1,512]

theorem envBound58575 : H12AffineFastState.Bounded env58575 := by
  intro p hp
  have h : env58575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58574_58575 : H12AffineEnvironment.transform 4 10 env58574 = env58575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env58574 == env58575) = true)

theorem identity58575 : scanCanonicalize (H12AffineFastState.compose env58575 (packedSelected [9,10] rootPS)) = affineNative (2^(13+1) ^^^ 13) := by decide +kernel

theorem selectedBound58575 : packedSelected [9,10] rootPS < 2^1333 := by decide +kernel

def env58576 : List Nat := [2,4,8,11,10,10,128,14,512,4,513,4096,8192,13,8206,12295,4109,4232,5,8207,4097,4226,4106,14,8329,4107,4108,4097,4109,512,4098,4103,14,11,1,512]

theorem envBound58576 : H12AffineFastState.Bounded env58576 := by
  intro p hp
  have h : env58576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58575_58576 : H12AffineEnvironment.transform 13 13 env58575 = env58576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13 env58575 == env58576) = true)

theorem identity58576 : scanCanonicalize (H12AffineFastState.compose env58576 (packedSelected [0,1,2,3,13] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound58576 : packedSelected [0,1,2,3,13] rootPS < 2^1333 := by decide +kernel

def env58577 : List Nat := [2,4,8,11,10,10,128,14,512,4,513,4096,2,13,12,4101,4109,4232,5,13,4097,4226,4106,14,139,4107,4108,4097,4109,512,4098,4103,14,11,1,512]

theorem envBound58577 : H12AffineFastState.Bounded env58577 := by
  intro p hp
  have h : env58577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58576_58577 : H12AffineEnvironment.transform 12 2 env58576 = env58577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env58576 == env58577) = true)

theorem identity58577 : scanCanonicalize (H12AffineFastState.compose env58577 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound58577 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env58578 : List Nat := [2,4,8,11,10,10,128,14,136,4,137,4096,2,13,12,4101,4109,4232,5,13,4097,4226,4106,14,139,4107,4108,4097,4109,136,4098,4103,14,11,1,136]

theorem envBound58578 : H12AffineFastState.Bounded env58578 := by
  intro p hp
  have h : env58578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58577_58578 : H12AffineEnvironment.transform 8 136 env58577 = env58578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env58577 == env58578) = true)

theorem identity58578 : scanCanonicalize (H12AffineFastState.compose env58578 (packedSelected [2,3] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound58578 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env58579 : List Nat := [2,4,8,11,10,10,128,14,136,4,137,136,2,13,12,141,133,0,5,13,137,10,130,14,139,131,132,137,133,136,138,143,14,11,1,136]

theorem envBound58579 : H12AffineFastState.Bounded env58579 := by
  intro p hp
  have h : env58579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58578_58579 : H12AffineEnvironment.transform 11 136 env58578 = env58579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env58578 == env58579) = true)

theorem identity58579 : scanCanonicalize (H12AffineFastState.compose env58579 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound58579 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58580 : List Nat := [2,4,8,11,10,10,4,14,12,4,13,12,2,13,12,9,1,0,5,13,13,10,6,14,15,7,0,13,1,12,14,11,14,11,1,12]

theorem envBound58580 : H12AffineFastState.Bounded env58580 := by
  intro p hp
  have h : env58580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58579_58580 : H12AffineEnvironment.transform 6 4 env58579 = env58580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env58579 == env58580) = true)

def env58581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28705,21776,262144,1375,32769,4097,61648,5456,284033,8663,5214,21872,4177,21534,2171,303521,21840,256,324085,1345,862]

theorem envBound58581 : H12AffineFastState.Bounded env58581 := by
  intro p hp
  have h : env58581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58566_58581 : H12AffineEnvironment.transform 15 28705 env58566 = env58581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28705 env58566 == env58581) = true)

def env58582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533640,672785,17245633,148801,545089,96346,16876545,750911,256,17006916,1344,525825]

theorem envBound58582 : H12AffineFastState.Bounded env58582 := by
  intro p hp
  have h : env58582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58518_58582 : H12AffineEnvironment.transform 26 17245633 env58518 = env58582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env58518 == env58582) = true)

theorem identity58582 : scanCanonicalize (H12AffineFastState.compose env58582 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74863) := by decide +kernel

theorem selectedBound58582 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env58583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4097,61648,91183,16777216,533640,614526,17039790,90414,545089,96346,16876545,545104,256,16819499,1344,525825]

theorem envBound58583 : H12AffineFastState.Bounded env58583 := by
  intro p hp
  have h : env58583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58582_58583 : H12AffineEnvironment.transform 16 74863 env58582 = env58583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74863 env58582 == env58583) = true)

def env58584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4097,61648,91183,123164,533640,614526,385202,90414,545089,96346,25885,545104,256,82999,1344,525825]

theorem envBound58584 : H12AffineFastState.Bounded env58584 := by
  intro p hp
  have h : env58584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58583_58584 : H12AffineEnvironment.transform 23 123164 env58583 = env58584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env58583 == env58584) = true)

def env58585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4097,61648,91183,123164,28888,78894,385202,90414,1297,96346,25885,1280,256,82999,1344,21073]

theorem envBound58585 : H12AffineFastState.Bounded env58585 := by
  intro p hp
  have h : env58585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58584_58585 : H12AffineEnvironment.transform 18 21584 env58584 = env58585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env58584 == env58585) = true)

theorem identity58585 : scanCanonicalize (H12AffineFastState.compose env58585 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound58585 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env58586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74863,262144,21584,25676,4097,5277,91183,66897,28888,78894,328959,90414,1297,96346,25885,1280,256,82999,1344,21073]

theorem envBound58586 : H12AffineFastState.Bounded env58586 := by
  intro p hp
  have h : env58586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58585_58586 : H12AffineEnvironment.transform 14 25677 env58585 = env58586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env58585 == env58586) = true)

def env58587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,262144,4416,8540,4097,5277,74047,66897,13768,78894,328959,74814,1297,81226,8205,1280,256,65831,1344,5953]

theorem envBound58587 : H12AffineFastState.Bounded env58587 := by
  intro p hp
  have h : env58587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58586_58587 : H12AffineEnvironment.transform 13 1296 env58586 = env58587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env58586 == env58587) = true)

def env58588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65664,4416,8540,4097,5277,74047,66897,13768,78894,1151,74814,1297,81226,8205,1280,256,65831,1344,5953]

theorem envBound58588 : H12AffineFastState.Bounded env58588 := by
  intro p hp
  have h : env58588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58587_58588 : H12AffineEnvironment.transform 17 65664 env58587 = env58588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env58587 == env58588) = true)

theorem identity58588 : scanCanonicalize (H12AffineFastState.compose env58588 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5159) := by decide +kernel

theorem selectedBound58588 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,5159,12360,5287,4416,8540,4097,5277,13592,4470,13768,8201,1151,12313,1297,10605,8205,1280,256,5376,1344,5953]

theorem envBound58589 : H12AffineFastState.Bounded env58589 := by
  intro p hp
  have h : env58589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58588_58589 : H12AffineEnvironment.transform 15 5159 env58588 = env58589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5159 env58588 == env58589) = true)

def env58590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1296,5205,5159,1344,5287,4416,5204,4097,5277,16,4470,192,5377,1151,1297,1297,7269,5381,1280,256,5376,1344,5953]

theorem envBound58590 : H12AffineFastState.Bounded env58590 := by
  intro p hp
  have h : env58590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58589_58590 : H12AffineEnvironment.transform 12 5384 env58589 = env58590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env58589 == env58590) = true)

theorem identity58590 : scanCanonicalize (H12AffineFastState.compose env58590 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound58590 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58591 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,4096,5196,1108,5205,5159,1028,5287,4100,5204,4097,5277,16,4146,192,5189,1151,1109,1109,7269,5185,1092,68,5188,1028,5637]

theorem envBound58591 : H12AffineFastState.Bounded env58591 := by
  intro p hp
  have h : env58591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58590_58591 : H12AffineEnvironment.transform 7 68 env58590 = env58591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env58590 == env58591) = true)

theorem identity58591 : scanCanonicalize (H12AffineFastState.compose env58591 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound58591 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env58592 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1029,73,1108,80,34,1028,162,1025,81,1028,152,16,1079,192,64,1151,1109,1109,2144,68,1092,68,65,1028,512]

theorem envBound58592 : H12AffineFastState.Bounded env58592 := by
  intro p hp
  have h : env58592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58591_58592 : H12AffineEnvironment.transform 11 1029 env58591 = env58592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env58591 == env58592) = true)

theorem identity58592 : scanCanonicalize (H12AffineFastState.compose env58592 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound58592 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env58593 : List Nat := [2,4,8,16,32,64,57,68,512,1024,2048,1029,73,1108,80,34,1028,27,1025,81,1028,33,16,1079,121,64,1151,1109,1109,2144,68,1092,68,65,1028,512]

theorem envBound58593 : H12AffineFastState.Bounded env58593 := by
  intro p hp
  have h : env58593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58592_58593 : H12AffineEnvironment.transform 6 57 env58592 = env58593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env58592 == env58593) = true)

theorem identity58593 : scanCanonicalize (H12AffineFastState.compose env58593 (packedSelected [2,3,8,10,13] rootPS)) = affineNative (2^(9+1) ^^^ 612) := by decide +kernel

theorem selectedBound58593 : packedSelected [2,3,8,10,13] rootPS < 2^1333 := by decide +kernel

def env58594 : List Nat := [2,4,8,16,32,64,57,68,512,612,2048,609,73,560,80,34,608,27,613,81,608,33,16,595,121,64,539,561,561,2144,68,544,68,65,608,512]

theorem envBound58594 : H12AffineFastState.Bounded env58594 := by
  intro p hp
  have h : env58594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58593_58594 : H12AffineEnvironment.transform 9 612 env58593 = env58594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 612 env58593 == env58594) = true)

theorem identity58594 : scanCanonicalize (H12AffineFastState.compose env58594 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound58594 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env58595 : List Nat := [2,4,8,16,32,64,57,68,49,85,2048,80,73,1,80,34,81,27,84,81,81,33,16,98,121,64,42,0,0,2144,68,17,68,65,81,49]

theorem envBound58595 : H12AffineFastState.Bounded env58595 := by
  intro p hp
  have h : env58595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58594_58595 : H12AffineEnvironment.transform 8 49 env58594 = env58595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env58594 == env58595) = true)

theorem identity58595 : scanCanonicalize (H12AffineFastState.compose env58595 (packedSelected [2,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound58595 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env58596 : List Nat := [2,4,8,16,16,64,9,68,1,85,2048,80,73,1,80,18,81,27,84,81,81,17,16,82,73,64,26,0,0,2128,68,17,68,65,81,1]

theorem envBound58596 : H12AffineFastState.Bounded env58596 := by
  intro p hp
  have h : env58596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58595_58596 : H12AffineEnvironment.transform 4 16 env58595 = env58596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env58595 == env58596) = true)

theorem identity58596 : scanCanonicalize (H12AffineFastState.compose env58596 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 75) := by decide +kernel

theorem selectedBound58596 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env58597 : List Nat := [2,4,8,16,16,64,9,68,1,85,75,80,73,1,80,18,81,27,84,81,81,17,16,82,73,64,26,0,0,27,68,17,68,65,81,1]

theorem envBound58597 : H12AffineFastState.Bounded env58597 := by
  intro p hp
  have h : env58597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58596_58597 : H12AffineEnvironment.transform 10 75 env58596 = env58597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 75 env58596 == env58597) = true)

theorem identity58597 : scanCanonicalize (H12AffineFastState.compose env58597 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound58597 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58598 : List Nat := [2,4,8,16,16,10,9,14,1,31,1,26,3,1,26,18,27,27,30,27,27,17,16,24,3,10,26,0,0,27,14,17,14,11,27,1]

theorem envBound58598 : H12AffineFastState.Bounded env58598 := by
  intro p hp
  have h : env58598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58597_58598 : H12AffineEnvironment.transform 5 10 env58597 = env58598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env58597 == env58598) = true)

def env58599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1296,5204,5159,1345,5287,4416,5205,4097,5277,17,4470,193,5376,1151,1296,1297,7268,5380,1280,256,5376,1344,5953]

theorem envBound58599 : H12AffineFastState.Bounded env58599 := by
  intro p hp
  have h : env58599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58589_58599 : H12AffineEnvironment.transform 12 5385 env58589 = env58599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env58589 == env58599) = true)

theorem identity58599 : scanCanonicalize (H12AffineFastState.compose env58599 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound58599 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58600 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,4120,1,4421,4406,80,4534,4416,4420,4097,4492,17,4470,193,4113,366,1,0,6517,4117,17,256,4113,81,4688]

theorem envBound58600 : H12AffineFastState.Bounded env58600 := by
  intro p hp
  have h : env58600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58599_58600 : H12AffineEnvironment.transform 9 273 env58599 = env58600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env58599 == env58600) = true)

theorem identity58600 : scanCanonicalize (H12AffineFastState.compose env58600 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 973) := by decide +kernel

theorem selectedBound58600 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env58601 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,973,981,1,648,763,80,635,653,649,972,577,17,699,193,988,366,1,0,2744,984,17,256,988,81,413]

theorem envBound58601 : H12AffineFastState.Bounded env58601 := by
  intro p hp
  have h : env58601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58600_58601 : H12AffineEnvironment.transform 11 973 env58600 = env58601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 973 env58600 == env58601) = true)

theorem identity58601 : scanCanonicalize (H12AffineFastState.compose env58601 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound58601 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env58602 : List Nat := [2,4,8,16,32,64,128,256,136,273,2048,325,349,1,0,115,80,243,5,1,324,201,17,51,193,340,366,1,0,2096,336,17,256,340,81,413]

theorem envBound58602 : H12AffineFastState.Bounded env58602 := by
  intro p hp
  have h : env58602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58601_58602 : H12AffineEnvironment.transform 8 136 env58601 = env58602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env58601 == env58602) = true)

theorem identity58602 : scanCanonicalize (H12AffineFastState.compose env58602 (packedSelected [0,1,2,3,7,10,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound58602 : packedSelected [0,1,2,3,7,10,11,15] rootPS < 2^1333 := by decide +kernel

def env58603 : List Nat := [2,4,8,16,32,64,9,256,1,273,2048,325,349,1,0,115,80,122,5,1,324,64,17,51,72,340,366,1,0,2096,336,17,256,340,81,276]

theorem envBound58603 : H12AffineFastState.Bounded env58603 := by
  intro p hp
  have h : env58603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58602_58603 : H12AffineEnvironment.transform 6 9 env58602 = env58603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env58602 == env58603) = true)

theorem identity58603 : scanCanonicalize (H12AffineFastState.compose env58603 (packedSelected [0,1,2,5,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound58603 : packedSelected [0,1,2,5,7,11] rootPS < 2^1333 := by decide +kernel

def env58604 : List Nat := [2,4,8,16,32,64,9,69,1,84,2048,0,24,1,0,115,80,122,5,1,1,64,17,51,72,17,43,1,0,2096,21,17,69,17,81,81]

theorem envBound58604 : H12AffineFastState.Bounded env58604 := by
  intro p hp
  have h : env58604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58603_58604 : H12AffineEnvironment.transform 7 69 env58603 = env58604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env58603 == env58604) = true)

theorem identity58604 : scanCanonicalize (H12AffineFastState.compose env58604 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58604 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env58605 : List Nat := [2,4,8,10,32,64,9,69,1,78,2048,0,2,1,0,105,74,96,5,1,1,64,11,41,72,11,43,1,0,2090,15,11,69,11,75,75]

theorem envBound58605 : H12AffineFastState.Bounded env58605 := by
  intro p hp
  have h : env58605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58604_58605 : H12AffineEnvironment.transform 3 10 env58604 = env58605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58604 == env58605) = true)

theorem identity58605 : scanCanonicalize (H12AffineFastState.compose env58605 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound58605 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env58606 : List Nat := [2,4,8,10,32,33,9,36,1,47,2048,0,2,1,0,8,43,1,5,1,1,33,11,41,41,11,43,1,0,2090,15,11,36,11,42,42]

theorem envBound58606 : H12AffineFastState.Bounded env58606 := by
  intro p hp
  have h : env58606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58605_58606 : H12AffineEnvironment.transform 5 33 env58605 = env58606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env58605 == env58606) = true)

theorem identity58606 : scanCanonicalize (H12AffineFastState.compose env58606 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound58606 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env58607 : List Nat := [2,4,8,10,7,6,9,3,1,8,2048,0,2,1,0,8,12,1,5,1,1,6,11,14,14,11,12,1,0,2061,15,11,3,11,13,13]

theorem envBound58607 : H12AffineFastState.Bounded env58607 := by
  intro p hp
  have h : env58607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58606_58607 : H12AffineEnvironment.transform 4 7 env58606 = env58607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env58606 == env58607) = true)

theorem identity58607 : scanCanonicalize (H12AffineFastState.compose env58607 (packedSelected [1,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound58607 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env58608 : List Nat := [2,4,8,10,7,6,9,3,1,8,1,0,2,1,0,8,12,1,5,1,1,6,11,14,14,11,12,1,0,12,15,11,3,11,13,13]

theorem envBound58608 : H12AffineFastState.Bounded env58608 := by
  intro p hp
  have h : env58608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58607_58608 : H12AffineEnvironment.transform 10 1 env58607 = env58608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env58607 == env58608) = true)

def env58609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65665,4416,8540,4097,5277,74047,66897,13768,78894,1150,74814,1297,81226,8205,1280,256,65831,1344,5953]

theorem envBound58609 : H12AffineFastState.Bounded env58609 := by
  intro p hp
  have h : env58609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58587_58609 : H12AffineEnvironment.transform 17 65665 env58587 = env58609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env58587 == env58609) = true)

theorem identity58609 : scanCanonicalize (H12AffineFastState.compose env58609 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 359) := by decide +kernel

theorem selectedBound58609 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,359,9480,486,4416,8540,4097,5277,8280,1078,13768,13641,1150,9561,1297,15405,8205,1280,256,64,1344,5953]

theorem envBound58610 : H12AffineFastState.Bounded env58610 := by
  intro p hp
  have h : env58610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58609_58610 : H12AffineEnvironment.transform 15 359 env58609 = env58610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 359 env58609 == env58610) = true)

def env58611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1296,277,359,1344,486,4416,276,4097,5277,16,1078,5504,5377,1150,1297,1297,7269,69,1280,256,64,1344,5953]

theorem envBound58611 : H12AffineFastState.Bounded env58611 := by
  intro p hp
  have h : env58611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58610_58611 : H12AffineEnvironment.transform 12 72 env58610 = env58611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env58610 == env58611) = true)

theorem identity58611 : scanCanonicalize (H12AffineFastState.compose env58611 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound58611 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1028,72,1296,277,359,1344,486,1348,276,1029,153,16,1078,388,261,1150,1297,1297,2145,69,1280,256,64,1344,837]

theorem envBound58612 : H12AffineFastState.Bounded env58612 := by
  intro p hp
  have h : env58612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58611_58612 : H12AffineEnvironment.transform 11 1028 env58611 = env58612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env58611 == env58612) = true)

theorem identity58612 : scanCanonicalize (H12AffineFastState.compose env58612 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound58612 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env58613 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,1028,72,1109,80,34,1029,163,1025,81,1029,153,16,1078,193,64,1150,1108,1108,2145,69,1093,69,64,1029,512]

theorem envBound58613 : H12AffineFastState.Bounded env58613 := by
  intro p hp
  have h : env58613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58612_58613 : H12AffineEnvironment.transform 7 69 env58612 = env58613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env58612 == env58613) = true)

theorem identity58613 : scanCanonicalize (H12AffineFastState.compose env58613 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1070) := by decide +kernel

theorem selectedBound58613 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env58614 : List Nat := [2,4,8,16,32,64,128,69,512,1024,1070,1028,72,1109,80,34,1029,163,1025,81,1029,153,16,1078,193,64,1150,1108,1108,1103,69,1093,69,64,1029,512]

theorem envBound58614 : H12AffineFastState.Bounded env58614 := by
  intro p hp
  have h : env58614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58613_58614 : H12AffineEnvironment.transform 10 1070 env58613 = env58614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1070 env58613 == env58614) = true)

theorem identity58614 : scanCanonicalize (H12AffineFastState.compose env58614 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound58614 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env58615 : List Nat := [2,4,8,16,32,17,128,20,512,1024,1070,1028,25,1028,1,34,1029,163,1025,0,1029,153,16,1078,144,17,1071,1029,1029,1054,20,1044,20,17,1029,512]

theorem envBound58615 : H12AffineFastState.Bounded env58615 := by
  intro p hp
  have h : env58615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58614_58615 : H12AffineEnvironment.transform 5 17 env58614 = env58615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58614 == env58615) = true)

theorem identity58615 : scanCanonicalize (H12AffineFastState.compose env58615 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound58615 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env58616 : List Nat := [2,4,8,16,32,17,128,20,26,1024,1070,1028,25,1028,1,34,1029,163,1025,0,1029,153,16,1078,144,17,1071,1029,1029,1054,20,1044,20,17,1029,26]

theorem envBound58616 : H12AffineFastState.Bounded env58616 := by
  intro p hp
  have h : env58616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58615_58616 : H12AffineEnvironment.transform 8 26 env58615 = env58616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env58615 == env58616) = true)

theorem identity58616 : scanCanonicalize (H12AffineFastState.compose env58616 (packedSelected [2,3,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58616 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env58617 : List Nat := [2,4,8,11,32,10,128,15,1,1024,1070,1028,2,1028,1,34,1029,163,1025,0,1029,130,11,1069,139,10,1071,1029,1029,1029,15,1039,15,10,1029,1]

theorem envBound58617 : H12AffineFastState.Bounded env58617 := by
  intro p hp
  have h : env58617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58616_58617 : H12AffineEnvironment.transform 3 11 env58616 = env58617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58616 == env58617) = true)

theorem identity58617 : scanCanonicalize (H12AffineFastState.compose env58617 (packedSelected [0,1,2] rootPS)) = affineNative (2^(9+1) ^^^ 166) := by decide +kernel

theorem selectedBound58617 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env58618 : List Nat := [2,4,8,11,32,10,128,15,1,166,136,162,2,162,1,34,163,163,167,0,163,130,11,139,139,10,137,163,163,163,15,169,15,10,163,1]

theorem envBound58618 : H12AffineFastState.Bounded env58618 := by
  intro p hp
  have h : env58618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58617_58618 : H12AffineEnvironment.transform 9 166 env58617 = env58618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 166 env58617 == env58618) = true)

theorem identity58618 : scanCanonicalize (H12AffineFastState.compose env58618 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound58618 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env58619 : List Nat := [2,4,8,11,10,10,128,15,1,140,136,136,2,136,1,8,137,137,141,0,137,130,11,139,139,10,137,137,137,137,15,131,15,10,137,1]

theorem envBound58619 : H12AffineFastState.Bounded env58619 := by
  intro p hp
  have h : env58619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58618_58619 : H12AffineEnvironment.transform 4 10 env58618 = env58619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env58618 == env58619) = true)

theorem identity58619 : scanCanonicalize (H12AffineFastState.compose env58619 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound58619 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env58620 : List Nat := [2,4,8,11,10,10,9,15,1,5,1,1,2,1,1,8,0,0,4,0,0,11,11,2,2,10,0,0,0,0,15,10,15,10,0,1]

theorem envBound58620 : H12AffineFastState.Bounded env58620 := by
  intro p hp
  have h : env58620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58619_58620 : H12AffineEnvironment.transform 6 9 env58619 = env58620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env58619 == env58620) = true)

theorem identity58620 : scanCanonicalize (H12AffineFastState.compose env58620 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound58620 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58621 : List Nat := [2,4,5,6,7,7,4,2,1,5,1,1,2,1,1,5,0,0,4,0,0,6,6,2,2,7,0,0,0,0,2,7,2,7,0,1]

theorem envBound58621 : H12AffineFastState.Bounded env58621 := by
  intro p hp
  have h : env58621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58620_58621 : H12AffineEnvironment.transform 2 5 env58620 = env58621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env58620 == env58621) = true)

def env58622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1296,276,359,1345,486,4416,277,4097,5277,17,1078,5505,5376,1150,1296,1297,7268,68,1280,256,64,1344,5953]

theorem envBound58622 : H12AffineFastState.Bounded env58622 := by
  intro p hp
  have h : env58622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58610_58622 : H12AffineEnvironment.transform 12 73 env58610 = env58622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env58610 == env58622) = true)

theorem identity58622 : scanCanonicalize (H12AffineFastState.compose env58622 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound58622 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,73,1296,276,359,1345,486,273,277,80,1228,17,1078,1488,1361,1150,1296,1297,3125,68,1280,256,64,1344,1808]

theorem envBound58623 : H12AffineFastState.Bounded env58623 := by
  intro p hp
  have h : env58623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58622_58623 : H12AffineEnvironment.transform 11 81 env58622 = env58623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env58622 == env58623) = true)

theorem identity58623 : scanCanonicalize (H12AffineFastState.compose env58623 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 412) := by decide +kernel

theorem selectedBound58623 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env58624 : List Nat := [2,4,8,16,32,64,128,256,412,1024,2048,81,73,1296,276,359,1345,486,273,277,80,1228,17,1078,1488,1361,1150,1296,1297,3125,68,1280,256,64,1344,1164]

theorem envBound58624 : H12AffineFastState.Bounded env58624 := by
  intro p hp
  have h : env58624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58623_58624 : H12AffineEnvironment.transform 8 412 env58623 = env58624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 412 env58623 == env58624) = true)

theorem identity58624 : scanCanonicalize (H12AffineFastState.compose env58624 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound58624 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env58625 : List Nat := [2,4,8,16,32,64,128,20,136,1024,2048,81,73,1028,0,115,1109,242,5,1,80,1228,17,1078,1220,1093,1150,1028,1029,3125,68,1044,20,64,1108,1164]

theorem envBound58625 : H12AffineFastState.Bounded env58625 := by
  intro p hp
  have h : env58625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58624_58625 : H12AffineEnvironment.transform 7 20 env58624 = env58625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env58624 == env58625) = true)

theorem identity58625 : scanCanonicalize (H12AffineFastState.compose env58625 (packedSelected [2,3,4,5,9,10,15,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 1108) := by decide +kernel

theorem selectedBound58625 : packedSelected [2,3,4,5,9,10,15,16,17] rootPS < 2^1333 := by decide +kernel

def env58626 : List Nat := [2,4,8,16,32,64,128,20,136,1024,1108,81,73,1028,0,115,1109,242,5,1,80,1228,17,1078,1220,1093,1150,1028,1029,97,68,1044,20,64,1108,1164]

theorem envBound58626 : H12AffineFastState.Bounded env58626 := by
  intro p hp
  have h : env58626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58625_58626 : H12AffineEnvironment.transform 10 1108 env58625 = env58626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1108 env58625 == env58626) = true)

theorem identity58626 : scanCanonicalize (H12AffineFastState.compose env58626 (packedSelected [1,3,5,8,10,12] rootPS)) = affineNative (2^(9+1) ^^^ 198) := by decide +kernel

theorem selectedBound58626 : packedSelected [1,3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env58627 : List Nat := [2,4,8,16,32,64,128,20,136,198,146,81,73,194,0,115,147,242,5,1,80,10,17,240,2,131,184,194,195,97,68,210,20,64,146,74]

theorem envBound58627 : H12AffineFastState.Bounded env58627 := by
  intro p hp
  have h : env58627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58626_58627 : H12AffineEnvironment.transform 9 198 env58626 = env58627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 198 env58626 == env58627) = true)

theorem identity58627 : scanCanonicalize (H12AffineFastState.compose env58627 (packedSelected [0,5,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound58627 : packedSelected [0,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env58628 : List Nat := [2,4,8,16,32,64,105,20,97,47,123,81,73,43,0,115,122,27,5,1,80,10,17,25,2,106,81,43,42,97,68,59,20,64,123,74]

theorem envBound58628 : H12AffineFastState.Bounded env58628 := by
  intro p hp
  have h : env58628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58627_58628 : H12AffineEnvironment.transform 6 105 env58627 = env58628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env58627 == env58628) = true)

def env58629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,262144,4417,8541,4097,5277,74046,66897,13769,78894,328959,74815,1297,81227,8204,1280,256,65830,1344,5952]

theorem envBound58629 : H12AffineFastState.Bounded env58629 := by
  intro p hp
  have h : env58629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58586_58629 : H12AffineEnvironment.transform 13 1297 env58586 = env58629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env58586 == env58629) = true)

def env58630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65664,4417,8541,4097,5277,74046,66897,13769,78894,1151,74815,1297,81227,8204,1280,256,65830,1344,5952]

theorem envBound58630 : H12AffineFastState.Bounded env58630 := by
  intro p hp
  have h : env58630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58629_58630 : H12AffineEnvironment.transform 17 65664 env58629 = env58630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env58629 == env58630) = true)

theorem identity58630 : scanCanonicalize (H12AffineFastState.compose env58630 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9327) := by decide +kernel

theorem selectedBound58630 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,9327,0,9455,4417,8541,4097,5277,1361,8510,13769,4161,1151,80,1297,6436,8204,1280,256,9545,1344,5952]

theorem envBound58631 : H12AffineFastState.Bounded env58631 := by
  intro p hp
  have h : env58631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58630_58631 : H12AffineEnvironment.transform 15 9327 env58630 = env58631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9327 env58630 == env58631) = true)

def env58632 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,8540,8495,0,8623,4417,8541,4097,4573,17,8510,12425,4161,319,80,81,6436,8204,64,256,8201,0,4608]

theorem envBound58632 : H12AffineFastState.Bounded env58632 := by
  intro p hp
  have h : env58632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58631_58632 : H12AffineEnvironment.transform 9 320 env58631 = env58632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env58631 == env58632) = true)

theorem identity58632 : scanCanonicalize (H12AffineFastState.compose env58632 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound58632 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58633 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,268,81,80,35,0,163,4417,81,4097,4573,17,50,4485,4161,319,80,81,6436,256,64,256,261,0,4608]

theorem envBound58633 : H12AffineFastState.Bounded env58633 := by
  intro p hp
  have h : env58633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58632_58633 : H12AffineEnvironment.transform 12 268 env58632 = env58633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env58632 == env58633) = true)

theorem identity58633 : scanCanonicalize (H12AffineFastState.compose env58633 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound58633 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env58634 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,268,81,80,35,0,163,321,81,1,477,17,50,389,65,319,80,81,2340,256,64,256,261,0,512]

theorem envBound58634 : H12AffineFastState.Bounded env58634 := by
  intro p hp
  have h : env58634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58633_58634 : H12AffineEnvironment.transform 11 0 env58633 = env58634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env58633 == env58634) = true)

theorem identity58634 : scanCanonicalize (H12AffineFastState.compose env58634 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound58634 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58635 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,268,1,0,35,0,163,273,1,1,397,17,50,389,17,319,0,1,2340,256,16,256,261,0,512]

theorem envBound58635 : H12AffineFastState.Bounded env58635 := by
  intro p hp
  have h : env58635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58634_58635 : H12AffineEnvironment.transform 5 16 env58634 = env58635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58634 == env58635) = true)

theorem identity58635 : scanCanonicalize (H12AffineFastState.compose env58635 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound58635 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env58636 : List Nat := [2,4,8,16,32,16,128,256,27,272,2048,0,268,1,0,35,0,163,273,1,1,397,17,50,389,17,319,0,1,2340,256,16,256,261,0,27]

theorem envBound58636 : H12AffineFastState.Bounded env58636 := by
  intro p hp
  have h : env58636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58635_58636 : H12AffineEnvironment.transform 8 27 env58635 = env58636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env58635 == env58636) = true)

theorem identity58636 : scanCanonicalize (H12AffineFastState.compose env58636 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound58636 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env58637 : List Nat := [2,4,8,16,32,16,128,256,27,272,1,0,268,1,0,35,0,163,273,1,1,397,17,50,389,17,319,0,1,293,256,16,256,261,0,27]

theorem envBound58637 : H12AffineFastState.Bounded env58637 := by
  intro p hp
  have h : env58637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58636_58637 : H12AffineEnvironment.transform 10 1 env58636 = env58637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env58636 == env58637) = true)

theorem identity58637 : scanCanonicalize (H12AffineFastState.compose env58637 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound58637 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env58638 : List Nat := [2,4,8,16,32,16,19,256,27,272,1,0,268,1,0,35,0,48,273,1,1,286,17,50,278,17,319,0,1,293,256,16,256,261,0,27]

theorem envBound58638 : H12AffineFastState.Bounded env58638 := by
  intro p hp
  have h : env58638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58637_58638 : H12AffineEnvironment.transform 6 19 env58637 = env58638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env58637 == env58638) = true)

theorem identity58638 : scanCanonicalize (H12AffineFastState.compose env58638 (packedSelected [0,1,2] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound58638 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env58639 : List Nat := [2,4,8,16,32,16,19,15,27,31,1,0,3,1,0,35,0,48,30,1,1,17,17,50,25,17,48,0,1,42,15,16,15,10,0,27]

theorem envBound58639 : H12AffineFastState.Bounded env58639 := by
  intro p hp
  have h : env58639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58638_58639 : H12AffineEnvironment.transform 7 15 env58638 = env58639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env58638 == env58639) = true)

theorem identity58639 : scanCanonicalize (H12AffineFastState.compose env58639 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58639 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env58640 : List Nat := [2,4,8,10,32,10,9,15,1,5,1,0,3,1,0,35,0,42,4,1,1,11,11,40,3,11,42,0,1,42,15,10,15,10,0,1]

theorem envBound58640 : H12AffineFastState.Bounded env58640 := by
  intro p hp
  have h : env58640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58639_58640 : H12AffineEnvironment.transform 3 10 env58639 = env58640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58639 == env58640) = true)

theorem identity58640 : scanCanonicalize (H12AffineFastState.compose env58640 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound58640 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58641 : List Nat := [2,4,8,10,7,10,9,15,1,5,1,0,3,1,0,4,0,13,4,1,1,11,11,15,3,11,13,0,1,13,15,10,15,10,0,1]

theorem envBound58641 : H12AffineFastState.Bounded env58641 := by
  intro p hp
  have h : env58641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58640_58641 : H12AffineEnvironment.transform 4 7 env58640 = env58641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env58640 == env58641) = true)

theorem identity58641 : scanCanonicalize (H12AffineFastState.compose env58641 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound58641 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env58642 : List Nat := [2,4,4,6,7,6,5,3,1,5,1,0,3,1,0,4,0,1,4,1,1,7,7,3,3,7,1,0,1,1,3,6,3,6,0,1]

theorem envBound58642 : H12AffineFastState.Bounded env58642 := by
  intro p hp
  have h : env58642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58641_58642 : H12AffineEnvironment.transform 2 4 env58641 = env58642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env58641 == env58642) = true)

def env58643 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,8540,8494,0,8622,4417,8541,4097,4572,16,8510,12424,4161,318,80,80,6436,8204,65,256,8200,1,4609]

theorem envBound58643 : H12AffineFastState.Bounded env58643 := by
  intro p hp
  have h : env58643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58631_58643 : H12AffineEnvironment.transform 9 321 env58631 = env58643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env58631 == env58643) = true)

theorem identity58643 : scanCanonicalize (H12AffineFastState.compose env58643 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound58643 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58644 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,25,80,325,311,0,439,4417,324,4097,4572,16,295,4241,4161,318,80,80,6436,21,65,256,17,1,4609]

theorem envBound58644 : H12AffineFastState.Bounded env58644 := by
  intro p hp
  have h : env58644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58643_58644 : H12AffineEnvironment.transform 12 25 env58643 = env58644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env58643 == env58644) = true)

theorem identity58644 : scanCanonicalize (H12AffineFastState.compose env58644 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 950) := by decide +kernel

theorem selectedBound58644 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env58645 : List Nat := [2,4,8,16,32,64,128,256,512,321,950,4096,25,80,325,311,0,439,4417,324,4097,4572,16,295,4241,4161,318,80,80,4754,21,65,256,17,1,4609]

theorem envBound58645 : H12AffineFastState.Bounded env58645 := by
  intro p hp
  have h : env58645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58644_58645 : H12AffineEnvironment.transform 10 950 env58644 = env58645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 950 env58644 == env58645) = true)

theorem identity58645 : scanCanonicalize (H12AffineFastState.compose env58645 (packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(11+1) ^^^ 804) := by decide +kernel

theorem selectedBound58645 : packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env58646 : List Nat := [2,4,8,16,32,64,128,256,512,321,950,804,25,80,325,311,0,439,613,324,805,760,16,295,949,869,318,80,80,438,21,65,256,17,1,293]

theorem envBound58646 : H12AffineFastState.Bounded env58646 := by
  intro p hp
  have h : env58646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58645_58646 : H12AffineEnvironment.transform 11 804 env58645 = env58646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 804 env58645 == env58646) = true)

theorem identity58646 : scanCanonicalize (H12AffineFastState.compose env58646 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound58646 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env58647 : List Nat := [2,4,8,16,32,64,128,256,136,321,318,428,25,80,325,311,0,439,237,324,429,112,16,295,317,493,318,80,80,438,21,65,256,17,1,293]

theorem envBound58647 : H12AffineFastState.Bounded env58647 := by
  intro p hp
  have h : env58647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58646_58647 : H12AffineEnvironment.transform 8 136 env58646 = env58647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env58646 == env58647) = true)

theorem identity58647 : scanCanonicalize (H12AffineFastState.compose env58647 (packedSelected [0,2,3,4,8,10] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound58647 : packedSelected [0,2,3,4,8,10] rootPS < 2^1333 := by decide +kernel

def env58648 : List Nat := [2,4,8,16,11,64,128,256,136,321,277,391,25,80,325,284,0,412,198,324,390,91,16,268,278,454,277,80,80,413,21,65,256,17,1,270]

theorem envBound58648 : H12AffineFastState.Bounded env58648 := by
  intro p hp
  have h : env58648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58647_58648 : H12AffineEnvironment.transform 4 11 env58647 = env58648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env58647 == env58648) = true)

theorem identity58648 : scanCanonicalize (H12AffineFastState.compose env58648 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound58648 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env58649 : List Nat := [2,4,8,16,11,16,128,256,136,273,277,391,25,0,277,284,0,412,150,276,390,11,16,268,278,406,277,0,0,413,21,17,256,17,1,270]

theorem envBound58649 : H12AffineFastState.Bounded env58649 := by
  intro p hp
  have h : env58649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58648_58649 : H12AffineEnvironment.transform 5 16 env58648 = env58649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58648 == env58649) = true)

theorem identity58649 : scanCanonicalize (H12AffineFastState.compose env58649 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound58649 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58650 : List Nat := [2,4,8,16,11,16,128,157,136,140,136,26,25,0,136,129,0,1,150,137,27,11,16,145,139,11,136,0,0,0,21,17,157,17,1,147]

theorem envBound58650 : H12AffineFastState.Bounded env58650 := by
  intro p hp
  have h : env58650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58649_58650 : H12AffineEnvironment.transform 7 157 env58649 = env58650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env58649 == env58650) = true)

theorem identity58650 : scanCanonicalize (H12AffineFastState.compose env58650 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 30) := by decide +kernel

theorem selectedBound58650 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58651 : List Nat := [2,4,8,16,11,16,30,3,22,18,22,26,25,0,22,31,0,1,8,23,27,11,16,15,21,11,22,0,0,0,21,17,3,17,1,13]

theorem envBound58651 : H12AffineFastState.Bounded env58651 := by
  intro p hp
  have h : env58651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58650_58651 : H12AffineEnvironment.transform 6 30 env58650 = env58651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 30 env58650 == env58651) = true)

theorem identity58651 : scanCanonicalize (H12AffineFastState.compose env58651 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound58651 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env58652 : List Nat := [2,4,8,6,11,6,8,3,0,4,0,12,15,0,0,9,0,1,8,1,13,11,6,15,3,11,0,0,0,0,3,7,3,7,1,13]

theorem envBound58652 : H12AffineFastState.Bounded env58652 := by
  intro p hp
  have h : env58652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58651_58652 : H12AffineEnvironment.transform 3 6 env58651 = env58652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env58651 == env58652) = true)

def env58653 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65665,4417,8541,4097,5277,74046,66897,13769,78894,1150,74815,1297,81227,8204,1280,256,65830,1344,5952]

theorem envBound58653 : H12AffineFastState.Bounded env58653 := by
  intro p hp
  have h : env58653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58629_58653 : H12AffineEnvironment.transform 17 65665 env58629 = env58653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env58629 == env58653) = true)

theorem identity58653 : scanCanonicalize (H12AffineFastState.compose env58653 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound58653 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,12590,5441,12719,4417,8541,4097,5277,4112,13439,13769,1280,1150,5393,1297,3173,8204,1280,256,12296,1344,5952]

theorem envBound58654 : H12AffineFastState.Bounded env58654 := by
  intro p hp
  have h : env58654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58653_58654 : H12AffineEnvironment.transform 15 12590 env58653 = env58654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env58653 == env58654) = true)

def env58655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,8540,8494,1345,8623,321,8541,1,1181,16,9343,9673,1280,1150,1297,1297,3173,8204,1280,256,8200,1344,1856]

theorem envBound58655 : H12AffineFastState.Bounded env58655 := by
  intro p hp
  have h : env58655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58654_58655 : H12AffineEnvironment.transform 11 0 env58654 = env58655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env58654 == env58655) = true)

theorem identity58655 : scanCanonicalize (H12AffineFastState.compose env58655 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1368) := by decide +kernel

theorem selectedBound58655 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,1368,1297,1028,1142,1345,1271,321,1029,1,1181,16,295,145,1280,1150,1297,1297,3173,1364,1280,256,1360,1344,1856]

theorem envBound58656 : H12AffineFastState.Bounded env58656 := by
  intro p hp
  have h : env58656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58655_58656 : H12AffineEnvironment.transform 12 1368 env58655 = env58656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1368 env58655 == env58656) = true)

theorem identity58656 : scanCanonicalize (H12AffineFastState.compose env58656 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 1782) := by decide +kernel

theorem selectedBound58656 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env58657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1782,0,1368,1297,1028,1142,1345,1271,321,1029,1,1181,16,295,145,1280,1150,1297,1297,659,1364,1280,256,1360,1344,1856]

theorem envBound58657 : H12AffineFastState.Bounded env58657 := by
  intro p hp
  have h : env58657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58656_58657 : H12AffineEnvironment.transform 10 1782 env58656 = env58657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1782 env58656 == env58657) = true)

theorem identity58657 : scanCanonicalize (H12AffineFastState.compose env58657 (packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(9+1) ^^^ 612) := by decide +kernel

theorem selectedBound58657 : packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env58658 : List Nat := [2,4,8,16,32,64,128,256,512,612,146,0,828,885,608,530,805,659,321,609,1,761,16,295,145,868,538,885,885,659,816,868,256,820,804,292]

theorem envBound58658 : H12AffineFastState.Bounded env58658 := by
  intro p hp
  have h : env58658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58657_58658 : H12AffineEnvironment.transform 9 612 env58657 = env58658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 612 env58657 == env58658) = true)

theorem identity58658 : scanCanonicalize (H12AffineFastState.compose env58658 (packedSelected [0,1,2,7,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound58658 : packedSelected [0,1,2,7,8,11] rootPS < 2^1333 := by decide +kernel

def env58659 : List Nat := [2,4,8,16,32,64,128,256,216,188,146,0,484,429,184,202,509,75,321,185,1,33,16,295,145,444,194,429,429,75,488,444,256,492,508,292]

theorem envBound58659 : H12AffineFastState.Bounded env58659 := by
  intro p hp
  have h : env58659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58658_58659 : H12AffineEnvironment.transform 8 216 env58658 = env58659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env58658 == env58659) = true)

theorem identity58659 : scanCanonicalize (H12AffineFastState.compose env58659 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound58659 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env58660 : List Nat := [2,4,8,16,32,64,128,134,216,188,146,0,98,43,184,202,123,75,199,185,1,33,16,161,145,58,194,43,43,75,110,58,134,106,122,162]

theorem envBound58660 : H12AffineFastState.Bounded env58660 := by
  intro p hp
  have h : env58660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58659_58660 : H12AffineEnvironment.transform 7 134 env58659 = env58660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env58659 == env58660) = true)

theorem identity58660 : scanCanonicalize (H12AffineFastState.compose env58660 (packedSelected [0,1,2,3,7,10] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound58660 : packedSelected [0,1,2,3,7,10] rootPS < 2^1333 := by decide +kernel

def env58661 : List Nat := [2,4,8,16,32,64,105,111,49,85,123,0,98,43,81,35,123,75,46,80,1,33,16,72,120,58,43,43,43,75,110,58,111,106,122,75]

theorem envBound58661 : H12AffineFastState.Bounded env58661 := by
  intro p hp
  have h : env58661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58660_58661 : H12AffineEnvironment.transform 6 105 env58660 = env58661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env58660 == env58661) = true)

theorem identity58661 : scanCanonicalize (H12AffineFastState.compose env58661 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound58661 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env58662 : List Nat := [2,4,8,16,16,64,89,95,1,85,75,0,82,27,81,19,75,75,30,80,1,17,16,72,72,10,27,27,27,75,94,10,95,90,74,75]

theorem envBound58662 : H12AffineFastState.Bounded env58662 := by
  intro p hp
  have h : env58662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58661_58662 : H12AffineEnvironment.transform 4 16 env58661 = env58662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env58661 == env58662) = true)

def env58663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,8540,8495,1344,8622,320,8541,0,1180,17,9342,9672,1280,1150,1296,1297,3173,8204,1280,256,8201,1344,1857]

theorem envBound58663 : H12AffineFastState.Bounded env58663 := by
  intro p hp
  have h : env58663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58654_58663 : H12AffineEnvironment.transform 11 1 env58654 = env58663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env58654 == env58663) = true)

theorem identity58663 : scanCanonicalize (H12AffineFastState.compose env58663 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound58663 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,268,1297,80,35,1344,162,320,81,0,1180,17,1394,1220,1280,1150,1296,1297,3173,256,1280,256,261,1344,1857]

theorem envBound58664 : H12AffineFastState.Bounded env58664 := by
  intro p hp
  have h : env58664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58663_58664 : H12AffineEnvironment.transform 12 268 env58663 = env58664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env58663 == env58664) = true)

theorem identity58664 : scanCanonicalize (H12AffineFastState.compose env58664 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound58664 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env58665 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,268,80,80,35,1,162,320,81,0,477,17,51,389,65,319,81,80,2340,256,65,256,261,1,512]

theorem envBound58665 : H12AffineFastState.Bounded env58665 := by
  intro p hp
  have h : env58665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58664_58665 : H12AffineEnvironment.transform 9 321 env58664 = env58665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env58664 == env58665) = true)

theorem identity58665 : scanCanonicalize (H12AffineFastState.compose env58665 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound58665 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58666 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,268,0,0,35,1,162,272,1,0,397,17,51,389,17,319,1,0,2340,256,17,256,261,1,512]

theorem envBound58666 : H12AffineFastState.Bounded env58666 := by
  intro p hp
  have h : env58666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58665_58666 : H12AffineEnvironment.transform 5 16 env58665 = env58666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58665 == env58666) = true)

theorem identity58666 : scanCanonicalize (H12AffineFastState.compose env58666 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 805) := by decide +kernel

theorem selectedBound58666 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env58667 : List Nat := [2,4,8,16,32,16,128,256,512,273,805,1,268,0,0,35,1,162,272,1,0,397,17,51,389,17,319,1,0,513,256,17,256,261,1,512]

theorem envBound58667 : H12AffineFastState.Bounded env58667 := by
  intro p hp
  have h : env58667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58666_58667 : H12AffineEnvironment.transform 10 805 env58666 = env58667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 805 env58666 == env58667) = true)

theorem identity58667 : scanCanonicalize (H12AffineFastState.compose env58667 (packedSelected [3,8] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound58667 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env58668 : List Nat := [2,4,8,16,32,16,128,134,512,151,675,1,138,0,0,35,1,162,150,1,0,11,17,51,3,17,185,1,0,513,134,17,134,131,1,512]

theorem envBound58668 : H12AffineFastState.Bounded env58668 := by
  intro p hp
  have h : env58668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58667_58668 : H12AffineEnvironment.transform 7 134 env58667 = env58668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env58667 == env58668) = true)

theorem identity58668 : scanCanonicalize (H12AffineFastState.compose env58668 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound58668 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env58669 : List Nat := [2,4,8,16,32,16,128,134,137,151,42,1,138,0,0,35,1,162,150,1,0,11,17,51,3,17,185,1,0,136,134,17,134,131,1,137]

theorem envBound58669 : H12AffineFastState.Bounded env58669 := by
  intro p hp
  have h : env58669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58668_58669 : H12AffineEnvironment.transform 8 137 env58668 = env58669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env58668 == env58669) = true)

theorem identity58669 : scanCanonicalize (H12AffineFastState.compose env58669 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound58669 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env58670 : List Nat := [2,4,8,16,32,16,18,20,27,5,42,1,24,0,0,35,1,48,4,1,0,11,17,51,3,17,43,1,0,26,20,17,20,17,1,27]

theorem envBound58670 : H12AffineFastState.Bounded env58670 := by
  intro p hp
  have h : env58670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58669_58670 : H12AffineEnvironment.transform 6 18 env58669 = env58670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env58669 == env58670) = true)

theorem identity58670 : scanCanonicalize (H12AffineFastState.compose env58670 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound58670 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58671 : List Nat := [2,4,8,16,6,16,18,20,27,5,12,1,24,0,0,5,1,22,4,1,0,11,17,21,3,17,13,1,0,26,20,17,20,17,1,27]

theorem envBound58671 : H12AffineFastState.Bounded env58671 := by
  intro p hp
  have h : env58671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58670_58671 : H12AffineEnvironment.transform 4 6 env58670 = env58671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env58670 == env58671) = true)

theorem identity58671 : scanCanonicalize (H12AffineFastState.compose env58671 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound58671 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58672 : List Nat := [2,4,8,6,6,6,4,2,13,5,12,1,14,0,0,5,1,0,4,1,0,11,7,3,3,7,13,1,0,12,2,7,2,7,1,13]

theorem envBound58672 : H12AffineFastState.Bounded env58672 := by
  intro p hp
  have h : env58672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58671_58672 : H12AffineEnvironment.transform 3 6 env58671 = env58672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env58671 == env58672) = true)

theorem identity58672 : scanCanonicalize (H12AffineFastState.compose env58672 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound58672 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58673 : List Nat := [2,4,5,6,6,6,4,2,0,5,1,1,3,0,0,5,1,0,4,1,0,6,7,3,3,7,0,1,0,1,2,7,2,7,1,0]

theorem envBound58673 : H12AffineFastState.Bounded env58673 := by
  intro p hp
  have h : env58673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58672_58673 : H12AffineEnvironment.transform 2 5 env58672 = env58673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env58672 == env58673) = true)

def env58674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4097,61648,91183,123164,28889,78895,385202,90414,1296,96346,25885,1281,256,82999,1344,21072]

theorem envBound58674 : H12AffineFastState.Bounded env58674 := by
  intro p hp
  have h : env58674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58584_58674 : H12AffineEnvironment.transform 18 21585 env58584 = env58674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env58584 == env58674) = true)

theorem identity58674 : scanCanonicalize (H12AffineFastState.compose env58674 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound58674 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env58675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74863,262144,21585,13340,4097,17613,91183,87297,28889,78895,349359,90414,1296,96346,25885,1281,256,82999,1344,21072]

theorem envBound58675 : H12AffineFastState.Bounded env58675 := by
  intro p hp
  have h : env58675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58674_58675 : H12AffineEnvironment.transform 14 13341 env58674 = env58675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env58674 == env58675) = true)

def env58676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,262144,4417,13340,4097,477,74047,69649,13769,78895,332223,74814,1296,81226,8205,1281,256,65831,1344,5952]

theorem envBound58676 : H12AffineFastState.Bounded env58676 := by
  intro p hp
  have h : env58676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58675_58676 : H12AffineEnvironment.transform 13 1296 env58675 = env58676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env58675 == env58676) = true)

def env58677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65664,4417,13340,4097,477,74047,69649,13769,78895,4415,74814,1296,81226,8205,1281,256,65831,1344,5952]

theorem envBound58677 : H12AffineFastState.Bounded env58677 := by
  intro p hp
  have h : env58677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58676_58677 : H12AffineEnvironment.transform 17 65664 env58676 = env58677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env58676 == env58677) = true)

theorem identity58677 : scanCanonicalize (H12AffineFastState.compose env58677 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 358) := by decide +kernel

theorem selectedBound58677 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,358,9481,486,4417,13340,4097,477,8281,4471,13769,13641,4415,9560,1296,15404,8205,1281,256,65,1344,5952]

theorem envBound58678 : H12AffineFastState.Bounded env58678 := by
  intro p hp
  have h : env58678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58677_58678 : H12AffineEnvironment.transform 15 358 env58677 = env58678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 358 env58677 == env58678) = true)

def env58679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1296,5205,358,1345,486,4417,5204,4097,477,17,4471,5505,5377,4415,1296,1296,7268,69,1281,256,65,1344,5952]

theorem envBound58679 : H12AffineFastState.Bounded env58679 := by
  intro p hp
  have h : env58679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58678_58679 : H12AffineEnvironment.transform 12 72 env58678 = env58679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env58678 == env58679) = true)

theorem identity58679 : scanCanonicalize (H12AffineFastState.compose env58679 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound58679 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1029,72,1296,80,358,1345,486,1348,81,1028,477,17,1394,388,260,1338,1296,1296,2145,69,1281,256,65,1344,837]

theorem envBound58680 : H12AffineFastState.Bounded env58680 := by
  intro p hp
  have h : env58680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58679_58680 : H12AffineEnvironment.transform 11 1029 env58679 = env58680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env58679 == env58680) = true)

theorem identity58680 : scanCanonicalize (H12AffineFastState.compose env58680 (packedSelected [1,2,3,11,19,20] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound58680 : packedSelected [1,2,3,11,19,20] rootPS < 2^1333 := by decide +kernel

def env58681 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,1029,72,1296,80,358,1345,486,1348,81,1028,477,17,1394,388,260,1338,1296,1296,2145,69,1281,256,65,1344,413]

theorem envBound58681 : H12AffineFastState.Bounded env58681 := by
  intro p hp
  have h : env58681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58680_58681 : H12AffineEnvironment.transform 8 216 env58680 = env58681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env58680 == env58681) = true)

theorem identity58681 : scanCanonicalize (H12AffineFastState.compose env58681 (packedSelected [1,2,3,10,17,19] rootPS)) = affineNative (2^(10+1) ^^^ 367) := by decide +kernel

theorem selectedBound58681 : packedSelected [1,2,3,10,17,19] rootPS < 2^1333 := by decide +kernel

def env58682 : List Nat := [2,4,8,16,32,64,128,256,216,1024,367,1029,72,1296,80,358,1345,486,1348,81,1028,477,17,1394,388,260,1338,1296,1296,270,69,1281,256,65,1344,413]

theorem envBound58682 : H12AffineFastState.Bounded env58682 := by
  intro p hp
  have h : env58682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58681_58682 : H12AffineEnvironment.transform 10 367 env58681 = env58682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 367 env58681 == env58682) = true)

theorem identity58682 : scanCanonicalize (H12AffineFastState.compose env58682 (packedSelected [1,2,3,5,8,10,11,16,17] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound58682 : packedSelected [1,2,3,5,8,10,11,16,17] rootPS < 2^1333 := by decide +kernel

def env58683 : List Nat := [2,4,8,16,32,64,128,256,216,85,367,80,72,325,80,358,276,486,273,81,81,477,17,295,388,260,367,325,325,270,69,340,256,65,277,413]

theorem envBound58683 : H12AffineFastState.Bounded env58683 := by
  intro p hp
  have h : env58683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58682_58683 : H12AffineEnvironment.transform 9 85 env58682 = env58683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env58682 == env58683) = true)

theorem identity58683 : scanCanonicalize (H12AffineFastState.compose env58683 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound58683 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env58684 : List Nat := [2,4,8,16,32,64,104,256,48,85,367,80,72,325,80,358,276,270,273,81,81,309,17,295,364,260,367,325,325,270,69,340,256,65,277,373]

theorem envBound58684 : H12AffineFastState.Bounded env58684 := by
  intro p hp
  have h : env58684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58683_58684 : H12AffineEnvironment.transform 6 104 env58683 = env58684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env58683 == env58684) = true)

theorem identity58684 : scanCanonicalize (H12AffineFastState.compose env58684 (packedSelected [1,3,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound58684 : packedSelected [1,3,7,9] rootPS < 2^1333 := by decide +kernel

def env58685 : List Nat := [2,4,8,16,10,64,66,256,26,85,325,80,72,325,80,332,276,270,273,81,81,287,17,269,326,260,325,325,325,270,69,340,256,65,277,351]

theorem envBound58685 : H12AffineFastState.Bounded env58685 := by
  intro p hp
  have h : env58685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58684_58685 : H12AffineEnvironment.transform 4 10 env58684 = env58685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env58684 == env58685) = true)

theorem identity58685 : scanCanonicalize (H12AffineFastState.compose env58685 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound58685 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env58686 : List Nat := [2,4,8,16,10,17,19,256,26,4,276,1,25,276,1,285,276,270,273,0,0,287,17,269,279,260,276,276,276,270,20,261,256,16,277,270]

theorem envBound58686 : H12AffineFastState.Bounded env58686 := by
  intro p hp
  have h : env58686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58685_58686 : H12AffineEnvironment.transform 5 17 env58685 = env58686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58685 == env58686) = true)

def env58687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1296,5204,358,1344,486,4417,5205,4097,477,16,4471,5504,5376,4415,1297,1296,7269,68,1281,256,65,1344,5952]

theorem envBound58687 : H12AffineFastState.Bounded env58687 := by
  intro p hp
  have h : env58687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58678_58687 : H12AffineEnvironment.transform 12 73 env58678 = env58687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env58678 == env58687) = true)

theorem identity58687 : scanCanonicalize (H12AffineFastState.compose env58687 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound58687 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58688 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,73,1,4421,358,81,486,4417,4420,4097,477,16,4471,4241,4113,4415,0,1,6516,68,16,256,65,81,4689]

theorem envBound58688 : H12AffineFastState.Bounded env58688 := by
  intro p hp
  have h : env58688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58687_58688 : H12AffineEnvironment.transform 9 273 env58687 = env58688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env58687 == env58688) = true)

theorem identity58688 : scanCanonicalize (H12AffineFastState.compose env58688 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 509) := by decide +kernel

theorem selectedBound58688 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env58689 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,509,73,1,184,358,81,486,188,185,508,477,16,138,364,492,194,0,1,2185,68,16,256,65,81,940]

theorem envBound58689 : H12AffineFastState.Bounded env58689 := by
  intro p hp
  have h : env58689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58688_58689 : H12AffineEnvironment.transform 11 509 env58688 = env58689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 509 env58688 == env58689) = true)

theorem identity58689 : scanCanonicalize (H12AffineFastState.compose env58689 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound58689 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env58690 : List Nat := [2,4,8,16,32,64,128,256,373,273,2048,509,73,1,184,358,81,486,188,185,508,477,16,138,364,492,194,0,1,2185,68,16,256,65,81,217]

theorem envBound58690 : H12AffineFastState.Bounded env58690 := by
  intro p hp
  have h : env58690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58689_58690 : H12AffineEnvironment.transform 8 373 env58689 = env58690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env58689 == env58690) = true)

theorem identity58690 : scanCanonicalize (H12AffineFastState.compose env58690 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound58690 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env58691 : List Nat := [2,4,8,16,32,64,128,256,373,273,0,509,73,1,184,358,81,486,188,185,508,477,16,138,364,492,194,0,1,137,68,16,256,65,81,217]

theorem envBound58691 : H12AffineFastState.Bounded env58691 := by
  intro p hp
  have h : env58691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58690_58691 : H12AffineEnvironment.transform 10 0 env58690 = env58691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env58690 == env58691) = true)

theorem identity58691 : scanCanonicalize (H12AffineFastState.compose env58691 (packedSelected [0,1,3,4,10] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound58691 : packedSelected [0,1,3,4,10] rootPS < 2^1333 := by decide +kernel

def env58692 : List Nat := [2,4,8,16,32,32,128,256,277,273,0,413,41,1,184,262,49,390,188,185,412,445,16,138,268,396,162,0,1,137,36,16,256,33,49,185]

theorem envBound58692 : H12AffineFastState.Bounded env58692 := by
  intro p hp
  have h : env58692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58691_58692 : H12AffineEnvironment.transform 5 32 env58691 = env58692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env58691 == env58692) = true)

theorem identity58692 : scanCanonicalize (H12AffineFastState.compose env58692 (packedSelected [1,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound58692 : packedSelected [1,7,8,9] rootPS < 2^1333 := by decide +kernel

def env58693 : List Nat := [2,4,8,16,32,32,9,256,277,273,0,276,41,1,49,262,49,271,53,48,277,308,16,3,268,261,43,0,1,0,36,16,256,33,49,48]

theorem envBound58693 : H12AffineFastState.Bounded env58693 := by
  intro p hp
  have h : env58693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58692_58693 : H12AffineEnvironment.transform 6 9 env58692 = env58693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env58692 == env58693) = true)

theorem identity58693 : scanCanonicalize (H12AffineFastState.compose env58693 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound58693 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58694 : List Nat := [2,4,8,16,32,32,9,37,48,52,0,49,41,1,49,35,49,42,53,48,48,17,16,3,41,32,43,0,1,0,36,16,37,33,49,48]

theorem envBound58694 : H12AffineFastState.Bounded env58694 := by
  intro p hp
  have h : env58694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58693_58694 : H12AffineEnvironment.transform 7 37 env58693 = env58694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env58693 == env58694) = true)

theorem identity58694 : scanCanonicalize (H12AffineFastState.compose env58694 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound58694 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env58695 : List Nat := [2,4,8,16,11,11,9,14,27,31,0,26,2,1,26,8,26,1,30,27,27,17,16,3,2,11,0,0,1,0,15,16,14,10,26,27]

theorem envBound58695 : H12AffineFastState.Bounded env58695 := by
  intro p hp
  have h : env58695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58694_58695 : H12AffineEnvironment.transform 4 11 env58694 = env58695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env58694 == env58695) = true)

theorem identity58695 : scanCanonicalize (H12AffineFastState.compose env58695 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58695 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env58696 : List Nat := [2,4,8,11,11,11,9,14,0,4,0,1,2,1,1,8,1,1,5,0,0,10,11,3,2,11,0,0,1,0,15,11,14,10,1,0]

theorem envBound58696 : H12AffineFastState.Bounded env58696 := by
  intro p hp
  have h : env58696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58695_58696 : H12AffineEnvironment.transform 3 11 env58695 = env58696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58695 == env58696) = true)

theorem identity58696 : scanCanonicalize (H12AffineFastState.compose env58696 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound58696 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58697 : List Nat := [2,4,4,7,7,7,5,2,0,4,0,1,2,1,1,4,1,1,5,0,0,6,7,3,2,7,0,0,1,0,3,7,2,6,1,0]

theorem envBound58697 : H12AffineFastState.Bounded env58697 := by
  intro p hp
  have h : env58697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58696_58697 : H12AffineEnvironment.transform 2 4 env58696 = env58697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env58696 == env58697) = true)

def env58698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65665,4417,13340,4097,477,74047,69649,13769,78895,4414,74814,1296,81226,8205,1281,256,65831,1344,5952]

theorem envBound58698 : H12AffineFastState.Bounded env58698 := by
  intro p hp
  have h : env58698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58676_58698 : H12AffineEnvironment.transform 17 65665 env58676 = env58698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env58676 == env58698) = true)

theorem identity58698 : scanCanonicalize (H12AffineFastState.compose env58698 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5159) := by decide +kernel

theorem selectedBound58698 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,5159,12360,5286,4417,13340,4097,477,13592,1078,13769,8200,4414,12313,1296,10605,8205,1281,256,5376,1344,5952]

theorem envBound58699 : H12AffineFastState.Bounded env58699 := by
  intro p hp
  have h : env58699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58698_58699 : H12AffineEnvironment.transform 15 5159 env58698 = env58699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5159 env58698 == env58699) = true)

def env58700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1296,277,5159,1344,5286,4417,276,4097,477,16,1078,193,5376,4414,1297,1296,7269,5381,1281,256,5376,1344,5952]

theorem envBound58700 : H12AffineFastState.Bounded env58700 := by
  intro p hp
  have h : env58700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58699_58700 : H12AffineEnvironment.transform 12 5384 env58699 = env58700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env58699 == env58700) = true)

theorem identity58700 : scanCanonicalize (H12AffineFastState.compose env58700 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound58700 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1368,1296,277,1143,1344,1270,273,276,81,477,16,1078,193,1360,366,1297,1296,3125,1365,1281,256,1360,1344,1808]

theorem envBound58701 : H12AffineFastState.Bounded env58701 := by
  intro p hp
  have h : env58701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58700_58701 : H12AffineEnvironment.transform 11 80 env58700 = env58701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env58700 == env58701) = true)

theorem identity58701 : scanCanonicalize (H12AffineFastState.compose env58701 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound58701 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env58702 : List Nat := [2,4,8,16,32,64,128,256,512,188,2048,80,484,428,277,203,508,74,273,276,81,477,16,138,193,492,366,429,428,2185,489,445,256,492,508,940]

theorem envBound58702 : H12AffineFastState.Bounded env58702 := by
  intro p hp
  have h : env58702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58701_58702 : H12AffineEnvironment.transform 9 188 env58701 = env58702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env58701 == env58702) = true)

theorem identity58702 : scanCanonicalize (H12AffineFastState.compose env58702 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound58702 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env58703 : List Nat := [2,4,8,16,32,64,128,256,373,188,2048,80,484,428,277,203,508,74,273,276,81,477,16,138,193,492,366,429,428,2185,489,445,256,492,508,217]

theorem envBound58703 : H12AffineFastState.Bounded env58703 := by
  intro p hp
  have h : env58703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58702_58703 : H12AffineEnvironment.transform 8 373 env58702 = env58703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env58702 == env58703) = true)

theorem identity58703 : scanCanonicalize (H12AffineFastState.compose env58703 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound58703 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env58704 : List Nat := [2,4,8,16,32,64,128,256,373,188,1,80,484,428,277,203,508,74,273,276,81,477,16,138,193,492,366,429,428,136,489,445,256,492,508,217]

theorem envBound58704 : H12AffineFastState.Bounded env58704 := by
  intro p hp
  have h : env58704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58703_58704 : H12AffineEnvironment.transform 10 1 env58703 = env58704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env58703 == env58704) = true)

theorem identity58704 : scanCanonicalize (H12AffineFastState.compose env58704 (packedSelected [1,2,3,7,9,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound58704 : packedSelected [1,2,3,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env58705 : List Nat := [2,4,8,16,32,64,34,256,373,30,1,80,326,270,277,105,350,74,273,276,81,383,16,40,99,334,366,271,270,42,331,287,256,334,350,123]

theorem envBound58705 : H12AffineFastState.Bounded env58705 := by
  intro p hp
  have h : env58705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58704_58705 : H12AffineEnvironment.transform 6 34 env58704 = env58705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env58704 == env58705) = true)

theorem identity58705 : scanCanonicalize (H12AffineFastState.compose env58705 (packedSelected [0,1,4,7,8,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound58705 : packedSelected [0,1,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env58706 : List Nat := [2,4,8,16,32,16,34,256,293,30,1,0,278,270,277,57,270,26,273,276,1,303,16,40,51,286,318,271,270,42,283,287,256,286,270,43]

theorem envBound58706 : H12AffineFastState.Bounded env58706 := by
  intro p hp
  have h : env58706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58705_58706 : H12AffineEnvironment.transform 5 16 env58705 = env58706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58705 == env58706) = true)

theorem identity58706 : scanCanonicalize (H12AffineFastState.compose env58706 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound58706 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58707 : List Nat := [2,4,8,16,7,16,5,256,258,30,1,0,278,270,277,30,270,26,273,276,1,264,16,15,20,286,281,271,270,13,283,287,256,286,270,12]

theorem envBound58707 : H12AffineFastState.Bounded env58707 := by
  intro p hp
  have h : env58707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58706_58707 : H12AffineEnvironment.transform 4 7 env58706 = env58707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env58706 == env58707) = true)

theorem identity58707 : scanCanonicalize (H12AffineFastState.compose env58707 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound58707 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58708 : List Nat := [2,4,8,16,7,16,5,21,23,30,1,0,3,27,0,30,27,26,4,1,1,29,16,15,20,11,12,26,27,13,14,10,21,11,27,12]

theorem envBound58708 : H12AffineFastState.Bounded env58708 := by
  intro p hp
  have h : env58708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58707_58708 : H12AffineEnvironment.transform 7 21 env58707 = env58708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env58707 == env58708) = true)

theorem identity58708 : scanCanonicalize (H12AffineFastState.compose env58708 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58708 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env58709 : List Nat := [2,4,8,10,7,10,5,15,13,4,1,0,3,1,0,4,1,0,4,1,1,7,10,15,14,11,12,0,1,13,14,10,15,11,1,12]

theorem envBound58709 : H12AffineFastState.Bounded env58709 := by
  intro p hp
  have h : env58709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58708_58709 : H12AffineEnvironment.transform 3 10 env58708 = env58709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58708 == env58709) = true)

theorem identity58709 : scanCanonicalize (H12AffineFastState.compose env58709 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound58709 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58710 : List Nat := [2,4,1,3,7,3,5,6,4,4,1,0,3,1,0,4,1,0,4,1,1,7,3,6,7,2,5,0,1,4,7,3,6,2,1,5]

theorem envBound58710 : H12AffineFastState.Bounded env58710 := by
  intro p hp
  have h : env58710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58709_58710 : H12AffineEnvironment.transform 2 1 env58709 = env58710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env58709 == env58710) = true)

theorem identity58710 : scanCanonicalize (H12AffineFastState.compose env58710 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound58710 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58711 : List Nat := [2,1,1,3,2,3,0,3,1,1,1,0,3,1,0,1,1,0,1,1,1,2,3,3,2,2,0,0,1,1,2,3,3,2,1,0]

theorem envBound58711 : H12AffineFastState.Bounded env58711 := by
  intro p hp
  have h : env58711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58710_58711 : H12AffineEnvironment.transform 1 1 env58710 = env58711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env58710 == env58711) = true)

theorem identity58711 : scanCanonicalize (H12AffineFastState.compose env58711 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound58711 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env58712 : List Nat := [0,1,1,1,0,1,0,1,1,1,1,0,1,1,0,1,1,0,1,1,1,0,1,1,0,0,0,0,1,1,0,1,1,0,1,0]

theorem envBound58712 : H12AffineFastState.Bounded env58712 := by
  intro p hp
  have h : env58712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58711_58712 : H12AffineEnvironment.transform 0 0 env58711 = env58712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env58711 == env58712) = true)

def env58713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1296,276,5159,1345,5286,4417,277,4097,477,17,1078,192,5377,4414,1296,1296,7268,5380,1281,256,5376,1344,5952]

theorem envBound58713 : H12AffineFastState.Bounded env58713 := by
  intro p hp
  have h : env58713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58699_58713 : H12AffineEnvironment.transform 12 5385 env58699 = env58713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env58699 == env58713) = true)

theorem identity58713 : scanCanonicalize (H12AffineFastState.compose env58713 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound58713 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58714 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,4096,5197,1108,80,5159,1029,5286,4101,81,4097,153,17,1078,192,5189,4218,1108,1108,7268,5184,1093,68,5188,1028,5636]

theorem envBound58714 : H12AffineFastState.Bounded env58714 := by
  intro p hp
  have h : env58714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58713_58714 : H12AffineEnvironment.transform 7 68 env58713 = env58714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env58713 == env58714) = true)

theorem identity58714 : scanCanonicalize (H12AffineFastState.compose env58714 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound58714 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env58715 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1028,73,1108,80,35,1029,162,1025,81,1029,153,17,1078,192,65,1150,1108,1108,2144,68,1093,68,64,1028,512]

theorem envBound58715 : H12AffineFastState.Bounded env58715 := by
  intro p hp
  have h : env58715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58714_58715 : H12AffineEnvironment.transform 11 1028 env58714 = env58715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env58714 == env58715) = true)

theorem identity58715 : scanCanonicalize (H12AffineFastState.compose env58715 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1222) := by decide +kernel

theorem selectedBound58715 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env58716 : List Nat := [2,4,8,16,32,64,128,68,512,1024,1222,1028,73,1108,80,35,1029,162,1025,81,1029,153,17,1078,192,65,1150,1108,1108,1190,68,1093,68,64,1028,512]

theorem envBound58716 : H12AffineFastState.Bounded env58716 := by
  intro p hp
  have h : env58716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58715_58716 : H12AffineEnvironment.transform 10 1222 env58715 = env58716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1222 env58715 == env58716) = true)

theorem identity58716 : scanCanonicalize (H12AffineFastState.compose env58716 (packedSelected [0,1,2,3,4,5,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound58716 : packedSelected [0,1,2,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env58717 : List Nat := [2,4,8,16,32,64,128,68,512,84,146,80,73,0,80,35,81,162,85,81,81,153,17,98,192,65,42,0,0,242,68,17,68,64,80,512]

theorem envBound58717 : H12AffineFastState.Bounded env58717 := by
  intro p hp
  have h : env58717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58716_58717 : H12AffineEnvironment.transform 9 84 env58716 = env58717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env58716 == env58717) = true)

theorem identity58717 : scanCanonicalize (H12AffineFastState.compose env58717 (packedSelected [2,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound58717 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env58718 : List Nat := [2,4,8,16,16,64,128,68,512,84,146,80,73,0,80,19,81,146,85,81,81,153,17,82,192,65,26,0,0,194,68,17,68,64,80,512]

theorem envBound58718 : H12AffineFastState.Bounded env58718 := by
  intro p hp
  have h : env58718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58717_58718 : H12AffineEnvironment.transform 4 16 env58717 = env58718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env58717 == env58718) = true)

theorem identity58718 : scanCanonicalize (H12AffineFastState.compose env58718 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 75) := by decide +kernel

theorem selectedBound58718 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58719 : List Nat := [2,4,8,16,16,64,128,68,75,84,146,80,73,0,80,19,81,146,85,81,81,153,17,82,192,65,26,0,0,194,68,17,68,64,80,75]

theorem envBound58719 : H12AffineFastState.Bounded env58719 := by
  intro p hp
  have h : env58719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58718_58719 : H12AffineEnvironment.transform 8 75 env58718 = env58719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 75 env58718 == env58719) = true)

theorem identity58719 : scanCanonicalize (H12AffineFastState.compose env58719 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound58719 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env58720 : List Nat := [2,4,8,16,16,64,89,68,75,84,75,80,73,0,80,19,81,75,85,81,81,64,17,82,25,65,26,0,0,27,68,17,68,64,80,75]

theorem envBound58720 : H12AffineFastState.Bounded env58720 := by
  intro p hp
  have h : env58720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58719_58720 : H12AffineEnvironment.transform 6 89 env58719 = env58720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env58719 == env58720) = true)

theorem identity58720 : scanCanonicalize (H12AffineFastState.compose env58720 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58720 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env58721 : List Nat := [2,4,8,10,10,64,67,68,75,78,75,74,73,0,74,9,75,75,79,75,75,64,11,72,3,65,0,0,0,1,68,11,68,64,74,75]

theorem envBound58721 : H12AffineFastState.Bounded env58721 := by
  intro p hp
  have h : env58721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58720_58721 : H12AffineEnvironment.transform 3 10 env58720 = env58721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58720 == env58721) = true)

theorem identity58721 : scanCanonicalize (H12AffineFastState.compose env58721 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound58721 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env58722 : List Nat := [2,4,8,10,10,10,9,14,1,4,1,0,3,0,0,9,1,1,5,1,1,10,11,2,3,11,0,0,0,1,14,11,14,10,0,1]

theorem envBound58722 : H12AffineFastState.Bounded env58722 := by
  intro p hp
  have h : env58722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58721_58722 : H12AffineEnvironment.transform 5 10 env58721 = env58722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env58721 == env58722) = true)

theorem identity58722 : scanCanonicalize (H12AffineFastState.compose env58722 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound58722 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58723 : List Nat := [2,4,5,7,7,7,4,3,1,4,1,0,3,0,0,4,1,1,5,1,1,7,6,2,3,6,0,0,0,1,3,6,3,7,0,1]

theorem envBound58723 : H12AffineFastState.Bounded env58723 := by
  intro p hp
  have h : env58723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58722_58723 : H12AffineEnvironment.transform 2 5 env58722 = env58723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env58722 == env58723) = true)

def env58724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,262144,4416,13340,4097,476,74046,69648,13768,78895,332222,74815,1296,81227,8204,1281,256,65830,1344,5953]

theorem envBound58724 : H12AffineFastState.Bounded env58724 := by
  intro p hp
  have h : env58724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58675_58724 : H12AffineEnvironment.transform 13 1297 env58675 = env58724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env58675 == env58724) = true)

def env58725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65664,4416,13340,4097,476,74046,69648,13768,78895,4414,74815,1296,81227,8204,1281,256,65830,1344,5953]

theorem envBound58725 : H12AffineFastState.Bounded env58725 := by
  intro p hp
  have h : env58725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58724_58725 : H12AffineEnvironment.transform 17 65664 env58724 = env58725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env58724 == env58725) = true)

theorem identity58725 : scanCanonicalize (H12AffineFastState.compose env58725 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12591) := by decide +kernel

theorem selectedBound58725 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,12591,5440,12719,4416,13340,4097,476,4113,8511,13768,1280,4414,5392,1296,3172,8204,1281,256,12297,1344,5953]

theorem envBound58726 : H12AffineFastState.Bounded env58726 := by
  intro p hp
  have h : env58726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58725_58726 : H12AffineEnvironment.transform 15 12591 env58725 = env58726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12591 env58725 == env58726) = true)

def env58727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,9245,8495,1344,8623,320,9244,1,476,17,8511,9672,1280,318,1296,1296,3172,8204,1281,256,8201,1344,1857]

theorem envBound58727 : H12AffineFastState.Bounded env58727 := by
  intro p hp
  have h : env58727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58726_58727 : H12AffineEnvironment.transform 11 0 env58726 = env58727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env58726 == env58727) = true)

theorem identity58727 : scanCanonicalize (H12AffineFastState.compose env58727 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound58727 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,24,1297,1029,311,1344,439,320,1028,1,476,17,295,1488,1280,318,1296,1296,3172,20,1281,256,17,1344,1857]

theorem envBound58728 : H12AffineFastState.Bounded env58728 := by
  intro p hp
  have h : env58728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58727_58728 : H12AffineEnvironment.transform 12 24 env58727 = env58728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env58727 == env58728) = true)

theorem identity58728 : scanCanonicalize (H12AffineFastState.compose env58728 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound58728 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env58729 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,0,24,1212,1029,154,1261,26,237,1028,1,113,17,138,1149,1197,147,1213,1213,3172,20,1196,173,17,1261,1772]

theorem envBound58729 : H12AffineFastState.Bounded env58729 := by
  intro p hp
  have h : env58729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58728_58729 : H12AffineEnvironment.transform 7 173 env58728 = env58729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env58728 == env58729) = true)

theorem identity58729 : scanCanonicalize (H12AffineFastState.compose env58729 (packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound58729 : packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env58730 : List Nat := [2,4,8,16,32,64,128,173,512,1024,674,0,24,1212,1029,154,1261,26,237,1028,1,113,17,138,1149,1197,147,1213,1213,1734,20,1196,173,17,1261,1772]

theorem envBound58730 : H12AffineFastState.Bounded env58730 := by
  intro p hp
  have h : env58730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58729_58730 : H12AffineEnvironment.transform 10 674 env58729 = env58730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env58729 == env58730) = true)

theorem identity58730 : scanCanonicalize (H12AffineFastState.compose env58730 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound58730 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env58731 : List Nat := [2,4,8,16,32,64,128,173,163,1024,1,0,24,1212,1029,154,1261,26,237,1028,1,113,17,138,1149,1197,147,1213,1213,1125,20,1196,173,17,1261,1103]

theorem envBound58731 : H12AffineFastState.Bounded env58731 := by
  intro p hp
  have h : env58731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58730_58731 : H12AffineEnvironment.transform 8 163 env58730 = env58731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env58730 == env58731) = true)

theorem identity58731 : scanCanonicalize (H12AffineFastState.compose env58731 (packedSelected [0,1,4,7,8,9,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 115) := by decide +kernel

theorem selectedBound58731 : packedSelected [0,1,4,7,8,9,12,13] rootPS < 2^1333 := by decide +kernel

def env58732 : List Nat := [2,4,8,16,32,64,115,94,80,1024,1,0,24,1103,1029,105,1054,26,30,1028,1,113,17,121,1149,1118,96,1102,1102,1125,20,1119,94,17,1054,1103]

theorem envBound58732 : H12AffineFastState.Bounded env58732 := by
  intro p hp
  have h : env58732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58731_58732 : H12AffineEnvironment.transform 6 115 env58731 = env58732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 115 env58731 == env58732) = true)

theorem identity58732 : scanCanonicalize (H12AffineFastState.compose env58732 (packedSelected [2,3,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound58732 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env58733 : List Nat := [2,4,8,16,32,64,115,94,80,53,1,0,24,122,48,105,43,26,30,49,1,113,17,121,72,107,96,123,123,80,20,106,94,17,43,122]

theorem envBound58733 : H12AffineFastState.Bounded env58733 := by
  intro p hp
  have h : env58733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58732_58733 : H12AffineEnvironment.transform 9 53 env58732 = env58733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env58732 == env58733) = true)

theorem identity58733 : scanCanonicalize (H12AffineFastState.compose env58733 (packedSelected [0,1,2,3,4,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58733 : packedSelected [0,1,2,3,4,10] rootPS < 2^1333 := by decide +kernel

def env58734 : List Nat := [2,4,8,16,17,64,66,94,80,4,1,0,24,75,1,88,26,26,30,0,1,64,17,72,72,90,81,74,74,80,20,91,94,17,26,75]

theorem envBound58734 : H12AffineFastState.Bounded env58734 := by
  intro p hp
  have h : env58734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58733_58734 : H12AffineEnvironment.transform 4 17 env58733 = env58734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58733 == env58734) = true)

def env58735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,9244,8494,1345,8622,321,9245,0,476,16,8511,9673,1280,319,1297,1296,3172,8204,1281,256,8200,1344,1856]

theorem envBound58735 : H12AffineFastState.Bounded env58735 := by
  intro p hp
  have h : env58735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58726_58735 : H12AffineEnvironment.transform 11 1 env58726 = env58735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env58726 == env58735) = true)

theorem identity58735 : scanCanonicalize (H12AffineFastState.compose env58735 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound58735 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,268,1297,1296,34,1345,162,321,1297,0,476,16,51,1221,1280,319,1297,1296,3172,256,1281,256,260,1344,1856]

theorem envBound58736 : H12AffineFastState.Bounded env58736 := by
  intro p hp
  have h : env58736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58735_58736 : H12AffineEnvironment.transform 12 268 env58735 = env58736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env58735 == env58736) = true)

theorem identity58736 : scanCanonicalize (H12AffineFastState.compose env58736 (packedSelected [1,2,3,10,12,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 783) := by decide +kernel

theorem selectedBound58736 : packedSelected [1,2,3,10,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env58737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,783,1,268,1297,1296,34,1345,162,321,1297,0,476,16,51,1221,1280,319,1297,1296,1899,256,1281,256,260,1344,1856]

theorem envBound58737 : H12AffineFastState.Bounded env58737 := by
  intro p hp
  have h : env58737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58736_58737 : H12AffineEnvironment.transform 10 783 env58736 = env58737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 783 env58736 == env58737) = true)

theorem identity58737 : scanCanonicalize (H12AffineFastState.compose env58737 (packedSelected [1,3,12,15,16,17,19,23] rootPS)) = affineNative (2^(9+1) ^^^ 920) := by decide +kernel

theorem selectedBound58737 : packedSelected [1,3,12,15,16,17,19,23] rootPS < 2^1333 := by decide +kernel

def env58738 : List Nat := [2,4,8,16,32,64,128,256,512,920,783,1,268,649,648,34,729,162,321,649,0,476,16,51,861,664,319,649,648,243,256,665,256,260,728,216]

theorem envBound58738 : H12AffineFastState.Bounded env58738 := by
  intro p hp
  have h : env58738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58737_58738 : H12AffineEnvironment.transform 9 920 env58737 = env58738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 920 env58737 == env58738) = true)

theorem identity58738 : scanCanonicalize (H12AffineFastState.compose env58738 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound58738 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env58739 : List Nat := [2,4,8,16,32,64,128,20,512,652,539,1,24,649,648,34,729,162,85,649,0,200,16,51,585,664,43,649,648,243,20,665,20,16,728,216]

theorem envBound58739 : H12AffineFastState.Bounded env58739 := by
  intro p hp
  have h : env58739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58738_58739 : H12AffineEnvironment.transform 7 20 env58738 = env58739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env58738 == env58739) = true)

theorem identity58739 : scanCanonicalize (H12AffineFastState.compose env58739 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound58739 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env58740 : List Nat := [2,4,8,16,32,64,105,20,512,613,539,1,24,608,609,34,560,75,85,608,0,33,16,51,585,625,43,608,609,26,20,624,20,16,561,49]

theorem envBound58740 : H12AffineFastState.Bounded env58740 := by
  intro p hp
  have h : env58740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58739_58740 : H12AffineEnvironment.transform 6 105 env58739 = env58740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env58739 == env58740) = true)

theorem identity58740 : scanCanonicalize (H12AffineFastState.compose env58740 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound58740 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env58741 : List Nat := [2,4,8,16,32,64,105,20,42,79,49,1,24,74,75,34,26,75,85,74,0,33,16,51,99,91,43,74,75,26,20,90,20,16,27,49]

theorem envBound58741 : H12AffineFastState.Bounded env58741 := by
  intro p hp
  have h : env58741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58740_58741 : H12AffineEnvironment.transform 8 42 env58740 = env58741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env58740 == env58741) = true)

theorem identity58741 : scanCanonicalize (H12AffineFastState.compose env58741 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58741 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env58742 : List Nat := [2,4,8,16,17,64,88,20,27,79,0,1,24,74,75,19,26,75,85,74,0,16,16,2,82,91,26,74,75,26,20,90,20,16,27,0]

theorem envBound58742 : H12AffineFastState.Bounded env58742 := by
  intro p hp
  have h : env58742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58741_58742 : H12AffineEnvironment.transform 4 17 env58741 = env58742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58741 == env58742) = true)

theorem identity58742 : scanCanonicalize (H12AffineFastState.compose env58742 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound58742 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58743 : List Nat := [2,4,8,16,17,17,9,20,27,30,0,1,24,27,26,19,26,26,4,27,0,16,16,2,3,10,26,27,26,26,20,11,20,16,27,0]

theorem envBound58743 : H12AffineFastState.Bounded env58743 := by
  intro p hp
  have h : env58743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58742_58743 : H12AffineEnvironment.transform 5 17 env58742 = env58743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58742 == env58743) = true)

theorem identity58743 : scanCanonicalize (H12AffineFastState.compose env58743 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound58743 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env58744 : List Nat := [2,4,8,12,13,13,9,8,7,2,0,1,4,7,6,15,6,6,4,7,0,12,12,2,3,10,6,7,6,6,8,11,8,12,7,0]

theorem envBound58744 : H12AffineFastState.Bounded env58744 := by
  intro p hp
  have h : env58744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58743_58744 : H12AffineEnvironment.transform 3 12 env58743 = env58744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env58743 == env58744) = true)

theorem identity58744 : scanCanonicalize (H12AffineFastState.compose env58744 (packedSelected [1,8] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound58744 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env58745 : List Nat := [2,3,8,11,10,10,9,8,0,2,0,1,3,0,1,8,1,1,3,0,0,11,11,2,3,10,1,0,1,1,8,11,8,11,0,0]

theorem envBound58745 : H12AffineFastState.Bounded env58745 := by
  intro p hp
  have h : env58745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58744_58745 : H12AffineEnvironment.transform 1 3 env58744 = env58745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env58744 == env58745) = true)

def env58746 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65665,4416,13340,4097,476,74046,69648,13768,78895,4415,74815,1296,81227,8204,1281,256,65830,1344,5953]

theorem envBound58746 : H12AffineFastState.Bounded env58746 := by
  intro p hp
  have h : env58746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58724_58746 : H12AffineEnvironment.transform 17 65665 env58724 = env58746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env58724 == env58746) = true)

theorem identity58746 : scanCanonicalize (H12AffineFastState.compose env58746 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9327) := by decide +kernel

theorem selectedBound58746 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58747 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,9327,0,9454,4416,13340,4097,476,1361,13439,13768,4160,4415,80,1296,6436,8204,1281,256,9545,1344,5953]

theorem envBound58747 : H12AffineFastState.Bounded env58747 := by
  intro p hp
  have h : env58747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58746_58747 : H12AffineEnvironment.transform 15 9327 env58746 = env58747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9327 env58746 == env58747) = true)

def env58748 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,12637,8495,0,8622,4416,12636,4097,476,17,12607,12424,4160,4415,80,80,6436,8204,65,256,8201,0,4609]

theorem envBound58748 : H12AffineFastState.Bounded env58748 := by
  intro p hp
  have h : env58748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58747_58748 : H12AffineEnvironment.transform 9 320 env58747 = env58748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env58747 == env58748) = true)

theorem identity58748 : scanCanonicalize (H12AffineFastState.compose env58748 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4120) := by decide +kernel

theorem selectedBound58748 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58749 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,4120,81,325,4407,0,4534,4416,324,4097,476,17,295,144,4160,4415,80,80,6436,4116,65,256,4113,0,4609]

theorem envBound58749 : H12AffineFastState.Bounded env58749 := by
  intro p hp
  have h : env58749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58748_58749 : H12AffineEnvironment.transform 12 4120 env58748 = env58749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4120 env58748 == env58749) = true)

theorem identity58749 : scanCanonicalize (H12AffineFastState.compose env58749 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound58749 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env58750 : List Nat := [2,4,8,16,32,64,128,173,512,237,2048,4096,4120,81,232,4250,0,4123,4333,233,4097,113,17,138,144,4160,4242,80,80,6281,4116,65,173,4113,0,4609]

theorem envBound58750 : H12AffineFastState.Bounded env58750 := by
  intro p hp
  have h : env58750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58749_58750 : H12AffineEnvironment.transform 7 173 env58749 = env58750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env58749 == env58750) = true)

theorem identity58750 : scanCanonicalize (H12AffineFastState.compose env58750 (packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound58750 : packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env58751 : List Nat := [2,4,8,16,32,64,128,173,512,237,675,4096,4120,81,232,4250,0,4123,4333,233,4097,113,17,138,144,4160,4242,80,80,4650,4116,65,173,4113,0,4609]

theorem envBound58751 : H12AffineFastState.Bounded env58751 := by
  intro p hp
  have h : env58751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58750_58751 : H12AffineEnvironment.transform 10 675 env58750 = env58751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env58750 == env58751) = true)

theorem identity58751 : scanCanonicalize (H12AffineFastState.compose env58751 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 675) := by decide +kernel

theorem selectedBound58751 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env58752 : List Nat := [2,4,8,16,32,64,128,173,512,237,675,675,699,81,232,569,0,696,590,233,674,113,17,138,144,739,561,80,80,137,695,65,173,690,0,162]

theorem envBound58752 : H12AffineFastState.Bounded env58752 := by
  intro p hp
  have h : env58752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58751_58752 : H12AffineEnvironment.transform 11 675 env58751 = env58752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 675 env58751 == env58752) = true)

theorem identity58752 : scanCanonicalize (H12AffineFastState.compose env58752 (packedSelected [0,1,4,7,8,9,12] rootPS)) = affineNative (2^(8+1) ^^^ 243) := by decide +kernel

theorem selectedBound58752 : packedSelected [0,1,4,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env58753 : List Nat := [2,4,8,16,32,64,128,173,243,237,80,80,72,81,232,202,0,75,189,233,81,113,17,138,144,16,194,80,80,137,68,65,173,65,0,162]

theorem envBound58753 : H12AffineFastState.Bounded env58753 := by
  intro p hp
  have h : env58753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58752_58753 : H12AffineEnvironment.transform 8 243 env58752 = env58753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 243 env58752 == env58753) = true)

theorem identity58753 : scanCanonicalize (H12AffineFastState.compose env58753 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound58753 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58754 : List Nat := [2,4,8,16,32,58,128,173,137,151,42,42,50,43,146,176,0,49,189,147,43,11,17,138,144,16,184,42,42,137,62,59,173,59,0,162]

theorem envBound58754 : H12AffineFastState.Bounded env58754 := by
  intro p hp
  have h : env58754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58753_58754 : H12AffineEnvironment.transform 5 58 env58753 = env58754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env58753 == env58754) = true)

theorem identity58754 : scanCanonicalize (H12AffineFastState.compose env58754 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound58754 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env58755 : List Nat := [2,4,8,16,32,58,63,18,54,40,42,42,50,43,45,15,0,49,2,44,43,11,17,53,47,16,7,42,42,54,62,59,18,59,0,29]

theorem envBound58755 : H12AffineFastState.Bounded env58755 := by
  intro p hp
  have h : env58755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58754_58755 : H12AffineEnvironment.transform 6 63 env58754 = env58755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env58754 == env58755) = true)

theorem identity58755 : scanCanonicalize (H12AffineFastState.compose env58755 (packedSelected [1,3,8] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound58755 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env58756 : List Nat := [2,2,8,16,32,58,57,18,48,40,42,42,50,43,43,9,0,49,2,42,43,11,17,51,41,16,1,42,42,48,56,59,18,59,0,27]

theorem envBound58756 : H12AffineFastState.Bounded env58756 := by
  intro p hp
  have h : env58756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58755_58756 : H12AffineEnvironment.transform 1 2 env58755 = env58756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env58755 == env58756) = true)

theorem identity58756 : scanCanonicalize (H12AffineFastState.compose env58756 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58756 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58757 : List Nat := [2,2,8,10,32,32,35,8,42,40,42,42,40,43,43,9,0,43,2,42,43,11,11,41,41,10,1,42,42,42,34,33,8,33,0,1]

theorem envBound58757 : H12AffineFastState.Bounded env58757 := by
  intro p hp
  have h : env58757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58756_58757 : H12AffineEnvironment.transform 3 10 env58756 = env58757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58756 == env58757) = true)

theorem identity58757 : scanCanonicalize (H12AffineFastState.compose env58757 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound58757 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58758 : List Nat := [2,2,8,10,10,10,9,8,0,2,0,0,2,1,1,9,0,1,2,0,1,11,11,3,3,10,1,0,0,0,8,11,8,11,0,1]

theorem envBound58758 : H12AffineFastState.Bounded env58758 := by
  intro p hp
  have h : env58758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58757_58758 : H12AffineEnvironment.transform 4 10 env58757 = env58758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env58757 == env58758) = true)

theorem identity58758 : scanCanonicalize (H12AffineFastState.compose env58758 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound58758 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58759 : List Nat := [2,2,1,3,3,3,0,1,0,2,0,0,2,1,1,0,0,1,2,0,1,2,2,3,3,3,1,0,0,0,1,2,1,2,0,1]

theorem envBound58759 : H12AffineFastState.Bounded env58759 := by
  intro p hp
  have h : env58759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58758_58759 : H12AffineEnvironment.transform 2 1 env58758 = env58759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env58758 == env58759) = true)

theorem identity58759 : scanCanonicalize (H12AffineFastState.compose env58759 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound58759 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env58760 : List Nat := [0,0,1,1,1,1,0,1,0,0,0,0,0,1,1,0,0,1,0,0,1,0,0,1,1,1,1,0,0,0,1,0,1,0,0,1]

theorem envBound58760 : H12AffineFastState.Bounded env58760 := by
  intro p hp
  have h : env58760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58759_58760 : H12AffineEnvironment.transform 0 0 env58759 = env58760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env58759 == env58760) = true)

def env58761 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,12636,8494,0,8623,4416,12637,4097,476,16,12606,12425,4160,4415,80,81,6436,8204,64,256,8200,1,4608]

theorem envBound58761 : H12AffineFastState.Bounded env58761 := by
  intro p hp
  have h : env58761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58747_58761 : H12AffineEnvironment.transform 9 321 env58747 = env58761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env58747 == env58761) = true)

theorem identity58761 : scanCanonicalize (H12AffineFastState.compose env58761 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound58761 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58762 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,268,80,4176,34,0,163,4416,4177,4097,476,16,4146,4485,4160,4415,80,81,6436,256,64,256,260,1,4608]

theorem envBound58762 : H12AffineFastState.Bounded env58762 := by
  intro p hp
  have h : env58762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58761_58762 : H12AffineEnvironment.transform 12 268 env58761 = env58762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env58761 == env58762) = true)

theorem identity58762 : scanCanonicalize (H12AffineFastState.compose env58762 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound58762 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env58763 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,268,80,80,34,0,163,320,81,1,476,16,50,389,64,319,80,81,2340,256,64,256,260,1,512]

theorem envBound58763 : H12AffineFastState.Bounded env58763 := by
  intro p hp
  have h : env58763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58762_58763 : H12AffineEnvironment.transform 11 0 env58762 = env58763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env58762 == env58763) = true)

theorem identity58763 : scanCanonicalize (H12AffineFastState.compose env58763 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound58763 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58764 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,268,1,1,34,0,163,273,0,1,397,16,50,389,17,319,1,0,2340,256,17,256,260,1,512]

theorem envBound58764 : H12AffineFastState.Bounded env58764 := by
  intro p hp
  have h : env58764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58763_58764 : H12AffineEnvironment.transform 5 17 env58763 = env58764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58763 == env58764) = true)

theorem identity58764 : scanCanonicalize (H12AffineFastState.compose env58764 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound58764 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env58765 : List Nat := [2,4,8,16,32,17,128,256,512,272,554,0,268,1,1,34,0,163,273,0,1,397,16,50,389,17,319,1,0,782,256,17,256,260,1,512]

theorem envBound58765 : H12AffineFastState.Bounded env58765 := by
  intro p hp
  have h : env58765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58764_58765 : H12AffineEnvironment.transform 10 554 env58764 = env58765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env58764 == env58765) = true)

theorem identity58765 : scanCanonicalize (H12AffineFastState.compose env58765 (packedSelected [3,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound58765 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env58766 : List Nat := [2,4,8,16,32,17,128,37,512,53,554,0,41,1,1,34,0,163,52,0,1,168,16,50,160,17,26,1,0,555,37,17,37,33,1,512]

theorem envBound58766 : H12AffineFastState.Bounded env58766 := by
  intro p hp
  have h : env58766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58765_58766 : H12AffineEnvironment.transform 7 37 env58765 = env58766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env58765 == env58766) = true)

theorem identity58766 : scanCanonicalize (H12AffineFastState.compose env58766 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound58766 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58767 : List Nat := [2,4,8,16,32,17,9,37,512,53,554,0,41,1,1,34,0,42,52,0,1,33,16,50,41,17,26,1,0,555,37,17,37,33,1,512]

theorem envBound58767 : H12AffineFastState.Bounded env58767 := by
  intro p hp
  have h : env58767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58766_58767 : H12AffineEnvironment.transform 6 9 env58766 = env58767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env58766 == env58767) = true)

theorem identity58767 : scanCanonicalize (H12AffineFastState.compose env58767 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58767 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58768 : List Nat := [2,4,8,11,32,10,9,37,512,46,554,0,41,1,1,34,0,42,47,0,1,33,11,41,41,10,1,1,0,555,37,10,37,33,1,512]

theorem envBound58768 : H12AffineFastState.Bounded env58768 := by
  intro p hp
  have h : env58768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58767_58768 : H12AffineEnvironment.transform 3 11 env58767 = env58768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58767 == env58768) = true)

theorem identity58768 : scanCanonicalize (H12AffineFastState.compose env58768 (packedSelected [1,4] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound58768 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env58769 : List Nat := [2,4,8,11,32,10,9,37,43,46,1,0,41,1,1,34,0,42,47,0,1,33,11,41,41,10,1,1,0,0,37,10,37,33,1,43]

theorem envBound58769 : H12AffineFastState.Bounded env58769 := by
  intro p hp
  have h : env58769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58768_58769 : H12AffineEnvironment.transform 8 43 env58768 = env58769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env58768 == env58769) = true)

def env58770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4097,61648,91183,123165,533640,614526,385203,90414,545089,96346,25884,545104,256,82998,1344,525825]

theorem envBound58770 : H12AffineFastState.Bounded env58770 := by
  intro p hp
  have h : env58770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58583_58770 : H12AffineEnvironment.transform 23 123165 env58583 = env58770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env58583 == env58770) = true)

def env58771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4097,61648,91183,123165,28888,78894,385203,90414,1297,96346,25884,1280,256,82998,1344,21073]

theorem envBound58771 : H12AffineFastState.Bounded env58771 := by
  intro p hp
  have h : env58771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58770_58771 : H12AffineEnvironment.transform 18 21584 env58770 = env58771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env58770 == env58771) = true)

theorem identity58771 : scanCanonicalize (H12AffineFastState.compose env58771 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound58771 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env58772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74863,262144,21584,25676,4097,5277,91183,66896,28888,78894,328958,90414,1297,96346,25884,1280,256,82998,1344,21073]

theorem envBound58772 : H12AffineFastState.Bounded env58772 := by
  intro p hp
  have h : env58772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58771_58772 : H12AffineEnvironment.transform 14 25677 env58771 = env58772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env58771 == env58772) = true)

def env58773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,262144,4416,8540,4097,5277,74047,66896,13768,78894,328958,74814,1297,81226,8204,1280,256,65830,1344,5953]

theorem envBound58773 : H12AffineFastState.Bounded env58773 := by
  intro p hp
  have h : env58773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58772_58773 : H12AffineEnvironment.transform 13 1296 env58772 = env58773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env58772 == env58773) = true)

def env58774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65664,4416,8540,4097,5277,74047,66896,13768,78894,1150,74814,1297,81226,8204,1280,256,65830,1344,5953]

theorem envBound58774 : H12AffineFastState.Bounded env58774 := by
  intro p hp
  have h : env58774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58773_58774 : H12AffineEnvironment.transform 17 65664 env58773 = env58774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env58773 == env58774) = true)

theorem identity58774 : scanCanonicalize (H12AffineFastState.compose env58774 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5385) := by decide +kernel

theorem selectedBound58774 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1296,5204,65536,69990,65664,4416,5205,4097,5277,70710,66896,193,65831,1150,69943,1297,67651,5381,1280,256,65830,1344,5953]

theorem envBound58775 : H12AffineFastState.Bounded env58775 := by
  intro p hp
  have h : env58775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58774_58775 : H12AffineEnvironment.transform 12 5385 env58774 = env58775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env58774 == env58775) = true)

def env58776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,797,1296,576,65536,67442,65664,1876,577,1557,649,66082,66896,193,65831,1150,67363,1297,67651,785,1280,256,65830,1344,341]

theorem envBound58776 : H12AffineFastState.Bounded env58776 := by
  intro p hp
  have h : env58776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58775_58776 : H12AffineEnvironment.transform 11 1556 env58775 = env58776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env58775 == env58776) = true)

def env58777 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,797,64,576,65536,66082,65664,516,577,837,649,66082,65536,193,65831,302,66163,65,67651,785,80,256,65830,16,341]

theorem envBound58777 : H12AffineFastState.Bounded env58777 := by
  intro p hp
  have h : env58777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58776_58777 : H12AffineEnvironment.transform 9 336 env58776 = env58777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env58776 == env58777) = true)

theorem identity58777 : scanCanonicalize (H12AffineFastState.compose env58777 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 29) := by decide +kernel

theorem selectedBound58777 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env58778 : List Nat := [2,4,8,16,32,64,128,256,29,336,2048,345,256,64,93,65536,65599,65664,25,92,344,148,65599,65536,193,65831,302,65646,65,67651,268,80,256,65830,16,341]

theorem envBound58778 : H12AffineFastState.Bounded env58778 := by
  intro p hp
  have h : env58778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58777_58778 : H12AffineEnvironment.transform 8 29 env58777 = env58778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 29 env58777 == env58778) = true)

def env58779 : List Nat := [2,4,8,16,32,0,128,256,29,272,2048,281,256,0,29,65536,65599,65664,25,28,280,148,65599,65536,129,65831,302,65582,1,67587,268,16,256,65830,16,277]

theorem envBound58779 : H12AffineFastState.Bounded env58779 := by
  intro p hp
  have h : env58779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58778_58779 : H12AffineEnvironment.transform 5 0 env58778 = env58779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env58778 == env58779) = true)

theorem identity58779 : scanCanonicalize (H12AffineFastState.compose env58779 (packedSelected [2,3,11,12,17,18,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 155) := by decide +kernel

theorem selectedBound58779 : packedSelected [2,3,11,12,17,18,21,24] rootPS < 2^1333 := by decide +kernel

def env58780 : List Nat := [2,4,8,16,32,0,128,256,29,272,2048,281,256,0,29,155,164,27,25,28,280,148,164,155,129,444,302,181,1,2200,268,16,256,445,16,277]

theorem envBound58780 : H12AffineFastState.Bounded env58780 := by
  intro p hp
  have h : env58780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58779_58780 : H12AffineEnvironment.transform 15 155 env58779 = env58780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 155 env58779 == env58780) = true)

theorem identity58780 : scanCanonicalize (H12AffineFastState.compose env58780 (packedSelected [1,3,5,16,17,20,21] rootPS)) = affineNative (2^(6+1) ^^^ 53) := by decide +kernel

theorem selectedBound58780 : packedSelected [1,3,5,16,17,20,21] rootPS < 2^1333 := by decide +kernel

def env58781 : List Nat := [2,4,8,16,32,0,53,256,29,272,2048,281,256,0,29,46,17,27,25,28,280,33,17,46,52,265,302,0,1,2093,268,16,256,264,16,277]

theorem envBound58781 : H12AffineFastState.Bounded env58781 := by
  intro p hp
  have h : env58781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58780_58781 : H12AffineEnvironment.transform 6 53 env58780 = env58781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 53 env58780 == env58781) = true)

theorem identity58781 : scanCanonicalize (H12AffineFastState.compose env58781 (packedSelected [0,1,2,3,4,5,7,8,9,12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 47) := by decide +kernel

theorem selectedBound58781 : packedSelected [0,1,2,3,4,5,7,8,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env58782 : List Nat := [2,4,8,16,32,0,53,47,29,63,2048,54,47,0,29,46,17,27,25,28,55,33,17,46,52,38,1,0,1,2093,35,16,47,39,16,58]

theorem envBound58782 : H12AffineFastState.Bounded env58782 := by
  intro p hp
  have h : env58782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58781_58782 : H12AffineEnvironment.transform 7 47 env58781 = env58782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 47 env58781 == env58782) = true)

theorem identity58782 : scanCanonicalize (H12AffineFastState.compose env58782 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound58782 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env58783 : List Nat := [2,4,8,16,32,0,53,47,29,63,49,54,47,0,29,46,17,27,25,28,55,33,17,46,52,38,1,0,1,28,35,16,47,39,16,58]

theorem envBound58783 : H12AffineFastState.Bounded env58783 := by
  intro p hp
  have h : env58783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58782_58783 : H12AffineEnvironment.transform 10 49 env58782 = env58783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env58782 == env58783) = true)

theorem identity58783 : scanCanonicalize (H12AffineFastState.compose env58783 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound58783 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env58784 : List Nat := [2,4,8,16,1,0,20,14,29,30,16,23,14,0,29,15,17,27,25,28,22,0,17,15,21,7,1,0,1,28,2,16,14,6,16,27]

theorem envBound58784 : H12AffineFastState.Bounded env58784 := by
  intro p hp
  have h : env58784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58783_58784 : H12AffineEnvironment.transform 4 1 env58783 = env58784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env58783 == env58784) = true)

def env58785 : List Nat := [2,4,8,16,32,1,128,256,29,273,2048,280,256,1,28,65536,65599,65664,25,29,281,148,65599,65536,128,65831,302,65583,0,67586,268,17,256,65830,16,276]

theorem envBound58785 : H12AffineFastState.Bounded env58785 := by
  intro p hp
  have h : env58785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58778_58785 : H12AffineEnvironment.transform 5 1 env58778 = env58785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env58778 == env58785) = true)

theorem identity58785 : scanCanonicalize (H12AffineFastState.compose env58785 (packedSelected [2,3,11,12,17,18,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 405) := by decide +kernel

theorem selectedBound58785 : packedSelected [2,3,11,12,17,18,21,24] rootPS < 2^1333 := by decide +kernel

def env58786 : List Nat := [2,4,8,16,32,1,128,256,29,273,2048,280,256,1,28,405,426,277,25,29,281,148,426,405,128,178,302,442,0,2455,268,17,256,179,16,276]

theorem envBound58786 : H12AffineFastState.Bounded env58786 := by
  intro p hp
  have h : env58786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58785_58786 : H12AffineEnvironment.transform 15 405 env58785 = env58786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 405 env58785 == env58786) = true)

theorem identity58786 : scanCanonicalize (H12AffineFastState.compose env58786 (packedSelected [3,4,5,9,13,15,18,19,20,21,23] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound58786 : packedSelected [3,4,5,9,13,15,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env58787 : List Nat := [2,4,8,16,11,1,128,256,29,273,2048,280,256,1,28,405,385,277,25,29,281,148,385,405,128,153,261,401,0,2455,268,17,256,152,16,276]

theorem envBound58787 : H12AffineFastState.Bounded env58787 := by
  intro p hp
  have h : env58787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58786_58787 : H12AffineEnvironment.transform 4 11 env58786 = env58787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env58786 == env58787) = true)

theorem identity58787 : scanCanonicalize (H12AffineFastState.compose env58787 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 151) := by decide +kernel

theorem selectedBound58787 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env58788 : List Nat := [2,4,8,16,11,1,128,151,29,134,2048,143,151,1,28,2,22,130,25,29,142,148,22,2,128,153,146,6,0,2048,155,17,151,152,16,131]

theorem envBound58788 : H12AffineFastState.Bounded env58788 := by
  intro p hp
  have h : env58788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58787_58788 : H12AffineEnvironment.transform 7 151 env58787 = env58788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 151 env58787 == env58788) = true)

def env58789 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,797,65,576,65536,66083,65664,517,577,836,649,66082,65537,193,65831,303,66162,64,67651,785,81,256,65830,17,341]

theorem envBound58789 : H12AffineFastState.Bounded env58789 := by
  intro p hp
  have h : env58789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58776_58789 : H12AffineEnvironment.transform 9 337 env58776 = env58789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env58776 == env58789) = true)

theorem identity58789 : scanCanonicalize (H12AffineFastState.compose env58789 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 89) := by decide +kernel

theorem selectedBound58789 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env58790 : List Nat := [2,4,8,16,32,64,128,89,512,8,2048,540,580,65,576,65536,66083,65664,517,577,541,649,66082,65537,193,65662,118,66162,64,67651,584,81,89,65663,17,12]

theorem envBound58790 : H12AffineFastState.Bounded env58790 := by
  intro p hp
  have h : env58790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58789_58790 : H12AffineEnvironment.transform 7 89 env58789 = env58790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 89 env58789 == env58790) = true)

def env58791 : List Nat := [2,4,8,16,32,64,128,89,92,8,2048,64,24,65,28,65536,65663,65664,89,29,65,213,65662,65537,193,65662,118,65582,64,67651,20,81,89,65663,17,12]

theorem envBound58791 : H12AffineFastState.Bounded env58791 := by
  intro p hp
  have h : env58791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58790_58791 : H12AffineEnvironment.transform 8 92 env58790 = env58791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 92 env58790 == env58791) = true)

theorem identity58791 : scanCanonicalize (H12AffineFastState.compose env58791 (packedSelected [2,4,5,8,9,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2241) := by decide +kernel

theorem selectedBound58791 : packedSelected [2,4,5,8,9,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env58792 : List Nat := [2,4,8,16,32,64,128,89,92,8,2048,64,24,65,28,2241,2238,2113,89,29,65,213,2239,2240,193,2239,118,2287,64,130,20,81,89,2238,17,12]

theorem envBound58792 : H12AffineFastState.Bounded env58792 := by
  intro p hp
  have h : env58792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58791_58792 : H12AffineEnvironment.transform 15 2241 env58791 = env58792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2241 env58791 == env58792) = true)

theorem identity58792 : scanCanonicalize (H12AffineFastState.compose env58792 (packedSelected [1,5,10,12,13,15,17,19,21] rootPS)) = affineNative (2^(10+1) ^^^ 158) := by decide +kernel

theorem selectedBound58792 : packedSelected [1,5,10,12,13,15,17,19,21] rootPS < 2^1333 := by decide +kernel

def env58793 : List Nat := [2,4,8,16,32,64,128,89,92,8,158,64,24,65,28,95,32,223,89,29,65,213,33,94,193,33,118,113,64,130,20,81,89,32,17,12]

theorem envBound58793 : H12AffineFastState.Bounded env58793 := by
  intro p hp
  have h : env58793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58792_58793 : H12AffineEnvironment.transform 10 158 env58792 = env58793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 158 env58792 == env58793) = true)

theorem identity58793 : scanCanonicalize (H12AffineFastState.compose env58793 (packedSelected [1,3,4,9,11,19] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound58793 : packedSelected [1,3,4,9,11,19] rootPS < 2^1333 := by decide +kernel

def env58794 : List Nat := [2,4,8,16,32,64,51,89,92,8,45,64,24,65,28,95,32,108,89,29,65,102,33,94,114,33,118,113,64,49,20,81,89,32,17,12]

theorem envBound58794 : H12AffineFastState.Bounded env58794 := by
  intro p hp
  have h : env58794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58793_58794 : H12AffineEnvironment.transform 6 51 env58793 = env58794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env58793 == env58794) = true)

theorem identity58794 : scanCanonicalize (H12AffineFastState.compose env58794 (packedSelected [0,1,3,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound58794 : packedSelected [0,1,3,4,5] rootPS < 2^1333 := by decide +kernel

def env58795 : List Nat := [2,4,8,12,32,64,47,69,64,8,45,64,4,65,0,67,32,108,69,1,65,102,33,66,110,33,106,109,64,45,8,77,69,32,13,12]

theorem envBound58795 : H12AffineFastState.Bounded env58795 := by
  intro p hp
  have h : env58795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58794_58795 : H12AffineEnvironment.transform 3 12 env58794 = env58795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env58794 == env58795) = true)

theorem identity58795 : scanCanonicalize (H12AffineFastState.compose env58795 (packedSelected [0,1,2,3,4,7,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound58795 : packedSelected [0,1,2,3,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env58796 : List Nat := [2,4,8,12,32,11,47,14,11,8,45,11,4,10,0,8,32,39,14,1,10,45,33,9,37,33,33,38,11,45,8,6,14,32,13,12]

theorem envBound58796 : H12AffineFastState.Bounded env58796 := by
  intro p hp
  have h : env58796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58795_58796 : H12AffineEnvironment.transform 5 11 env58795 = env58796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env58795 == env58796) = true)

theorem identity58796 : scanCanonicalize (H12AffineFastState.compose env58796 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound58796 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env58797 : List Nat := [2,2,8,10,32,11,41,8,11,8,43,11,2,10,0,8,32,33,8,1,10,43,33,9,35,33,33,32,11,43,8,0,8,32,11,10]

theorem envBound58797 : H12AffineFastState.Bounded env58797 := by
  intro p hp
  have h : env58797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58796_58797 : H12AffineEnvironment.transform 1 2 env58796 = env58797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env58796 == env58797) = true)

theorem identity58797 : scanCanonicalize (H12AffineFastState.compose env58797 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound58797 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58798 : List Nat := [0,0,8,8,32,9,41,8,9,8,41,9,0,8,0,8,32,33,8,1,8,41,33,9,33,33,33,32,9,41,8,0,8,32,9,8]

theorem envBound58798 : H12AffineFastState.Bounded env58798 := by
  intro p hp
  have h : env58798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58797_58798 : H12AffineEnvironment.transform 0 0 env58797 = env58798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env58797 == env58798) = true)

theorem identity58798 : scanCanonicalize (H12AffineFastState.compose env58798 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound58798 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58799 : List Nat := [0,0,8,8,9,9,0,8,9,8,0,9,0,8,0,8,9,8,8,1,8,0,8,9,8,8,8,9,9,0,8,0,8,9,9,8]

theorem envBound58799 : H12AffineFastState.Bounded env58799 := by
  intro p hp
  have h : env58799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58798_58799 : H12AffineEnvironment.transform 4 9 env58798 = env58799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env58798 == env58799) = true)

theorem identity58799 : scanCanonicalize (H12AffineFastState.compose env58799 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound58799 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58800 : List Nat := [0,0,1,1,0,0,0,1,0,1,0,0,0,1,0,1,0,1,1,1,1,0,1,0,1,1,1,0,0,0,1,0,1,0,0,1]

theorem envBound58800 : H12AffineFastState.Bounded env58800 := by
  intro p hp
  have h : env58800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58799_58800 : H12AffineEnvironment.transform 2 1 env58799 = env58800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env58799 == env58800) = true)

def env58801 : List Nat := [2,4,8,16,32,64,128,89,93,8,2048,65,25,65,29,65536,65662,65664,88,28,64,212,65663,65537,193,65662,118,65583,64,67651,21,81,89,65663,17,12]

theorem envBound58801 : H12AffineFastState.Bounded env58801 := by
  intro p hp
  have h : env58801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58790_58801 : H12AffineEnvironment.transform 8 93 env58790 = env58801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 93 env58790 == env58801) = true)

theorem identity58801 : scanCanonicalize (H12AffineFastState.compose env58801 (packedSelected [2,4,5,8,9,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2199) := by decide +kernel

theorem selectedBound58801 : packedSelected [2,4,5,8,9,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env58802 : List Nat := [2,4,8,16,32,64,128,89,93,8,2048,65,25,65,29,2199,2281,2071,88,28,64,212,2280,2198,193,2281,118,2232,64,212,21,81,89,2280,17,12]

theorem envBound58802 : H12AffineFastState.Bounded env58802 := by
  intro p hp
  have h : env58802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58801_58802 : H12AffineEnvironment.transform 15 2199 env58801 = env58802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2199 env58801 == env58802) = true)

theorem identity58802 : scanCanonicalize (H12AffineFastState.compose env58802 (packedSelected [7,20,27] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound58802 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env58803 : List Nat := [2,4,8,16,32,13,128,20,16,8,2048,12,25,12,29,2199,2212,2071,21,28,13,153,2213,2198,140,2212,59,2232,13,153,21,28,20,2213,17,12]

theorem envBound58803 : H12AffineFastState.Bounded env58803 := by
  intro p hp
  have h : env58803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58802_58803 : H12AffineEnvironment.transform 5 13 env58802 = env58803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env58802 == env58803) = true)

theorem identity58803 : scanCanonicalize (H12AffineFastState.compose env58803 (packedSelected [0,3,4,5,7,9,10,11,12,13,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound58803 : packedSelected [0,3,4,5,7,9,10,11,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58804 : List Nat := [2,4,8,16,32,13,19,20,16,8,2048,12,25,12,29,2052,2103,2071,21,28,13,10,2102,2053,31,2103,59,2091,13,10,21,28,20,2102,17,12]

theorem envBound58804 : H12AffineFastState.Bounded env58804 := by
  intro p hp
  have h : env58804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58803_58804 : H12AffineEnvironment.transform 6 19 env58803 = env58804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env58803 == env58804) = true)

theorem identity58804 : scanCanonicalize (H12AffineFastState.compose env58804 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound58804 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env58805 : List Nat := [2,4,5,16,32,0,19,20,16,5,2048,1,20,1,16,2052,2103,2071,21,17,0,7,2102,2053,18,2103,54,2086,0,7,21,17,20,2102,17,1]

theorem envBound58805 : H12AffineFastState.Bounded env58805 := by
  intro p hp
  have h : env58805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58804_58805 : H12AffineEnvironment.transform 2 5 env58804 = env58805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env58804 == env58805) = true)

theorem identity58805 : scanCanonicalize (H12AffineFastState.compose env58805 (packedSelected [0,2,3,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58805 : packedSelected [0,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env58806 : List Nat := [2,4,5,16,17,0,19,20,16,5,2048,1,20,1,16,2052,2054,2071,21,17,0,7,2055,2053,18,2054,7,2071,0,7,21,17,20,2055,17,1]

theorem envBound58806 : H12AffineFastState.Bounded env58806 := by
  intro p hp
  have h : env58806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58805_58806 : H12AffineEnvironment.transform 4 17 env58805 = env58806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58805 == env58806) = true)

theorem identity58806 : scanCanonicalize (H12AffineFastState.compose env58806 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound58806 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58807 : List Nat := [2,4,5,1,0,0,2,5,1,5,2048,1,5,1,1,2052,2054,2054,4,0,0,7,2055,2053,3,2054,7,2054,0,7,4,0,5,2055,0,1]

theorem envBound58807 : H12AffineFastState.Bounded env58807 := by
  intro p hp
  have h : env58807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58806_58807 : H12AffineEnvironment.transform 3 1 env58806 = env58807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env58806 == env58807) = true)

theorem identity58807 : scanCanonicalize (H12AffineFastState.compose env58807 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound58807 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env58808 : List Nat := [2,4,5,1,0,0,2,5,1,5,6,1,5,1,1,2,0,0,4,0,0,7,1,3,3,0,7,0,0,7,4,0,5,1,0,1]

theorem envBound58808 : H12AffineFastState.Bounded env58808 := by
  intro p hp
  have h : env58808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58807_58808 : H12AffineEnvironment.transform 10 6 env58807 = env58808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env58807 == env58808) = true)

theorem identity58808 : scanCanonicalize (H12AffineFastState.compose env58808 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound58808 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58809 : List Nat := [2,2,3,1,0,0,2,3,1,3,0,1,3,1,1,2,0,0,2,0,0,1,1,3,3,0,1,0,0,1,2,0,3,1,0,1]

theorem envBound58809 : H12AffineFastState.Bounded env58809 := by
  intro p hp
  have h : env58809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58808_58809 : H12AffineEnvironment.transform 1 2 env58808 = env58809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env58808 == env58809) = true)

def env58810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,796,1296,577,65536,67443,65664,1877,576,1556,648,66083,66896,193,65831,1150,67362,1297,67651,784,1280,256,65830,1344,340]

theorem envBound58810 : H12AffineFastState.Bounded env58810 := by
  intro p hp
  have h : env58810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58775_58810 : H12AffineEnvironment.transform 11 1557 env58775 = env58810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env58775 == env58810) = true)

def env58811 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,796,64,577,65536,66083,65664,517,576,836,648,66083,65536,193,65831,302,66162,65,67651,784,80,256,65830,16,340]

theorem envBound58811 : H12AffineFastState.Bounded env58811 := by
  intro p hp
  have h : env58811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58810_58811 : H12AffineEnvironment.transform 9 336 env58810 = env58811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env58810 == env58811) = true)

theorem identity58811 : scanCanonicalize (H12AffineFastState.compose env58811 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 46) := by decide +kernel

theorem selectedBound58811 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env58812 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,796,64,577,46,525,174,517,576,836,648,525,46,193,265,302,604,65,2157,784,80,256,264,16,340]

theorem envBound58812 : H12AffineFastState.Bounded env58812 := by
  intro p hp
  have h : env58812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58811_58812 : H12AffineEnvironment.transform 15 46 env58811 = env58812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 46 env58811 == env58812) = true)

def env58813 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,837,780,64,577,46,525,174,517,576,836,648,525,46,193,265,302,588,65,2157,768,64,256,264,0,324]

theorem envBound58813 : H12AffineFastState.Bounded env58813 := by
  intro p hp
  have h : env58813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58812_58813 : H12AffineEnvironment.transform 3 0 env58812 = env58813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env58812 == env58813) = true)

theorem identity58813 : scanCanonicalize (H12AffineFastState.compose env58813 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound58813 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58814 : List Nat := [2,4,8,0,32,64,128,4,512,68,2048,577,520,64,577,46,525,174,517,576,576,648,525,46,193,13,42,588,65,2157,516,64,4,12,0,64]

theorem envBound58814 : H12AffineFastState.Bounded env58814 := by
  intro p hp
  have h : env58814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58813_58814 : H12AffineEnvironment.transform 7 4 env58813 = env58814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env58813 == env58814) = true)

theorem identity58814 : scanCanonicalize (H12AffineFastState.compose env58814 (packedSelected [2,4,9,11,13,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound58814 : packedSelected [2,4,9,11,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env58815 : List Nat := [2,4,8,0,32,64,128,4,512,68,163,577,520,64,577,46,525,174,517,576,576,648,525,46,193,13,42,588,65,206,516,64,4,12,0,64]

theorem envBound58815 : H12AffineFastState.Bounded env58815 := by
  intro p hp
  have h : env58815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58814_58815 : H12AffineEnvironment.transform 10 163 env58814 = env58815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env58814 == env58815) = true)

theorem identity58815 : scanCanonicalize (H12AffineFastState.compose env58815 (packedSelected [0,1,2,3,5,7,8,10,11,12,13,15] rootPS)) = affineNative (2^(8+1) ^^^ 109) := by decide +kernel

theorem selectedBound58815 : packedSelected [0,1,2,3,5,7,8,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env58816 : List Nat := [2,4,8,0,32,64,128,4,109,68,163,44,101,64,44,46,96,174,104,45,45,229,96,46,193,13,42,33,65,206,105,64,4,12,0,64]

theorem envBound58816 : H12AffineFastState.Bounded env58816 := by
  intro p hp
  have h : env58816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58815_58816 : H12AffineEnvironment.transform 8 109 env58815 = env58816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 109 env58815 == env58816) = true)

theorem identity58816 : scanCanonicalize (H12AffineFastState.compose env58816 (packedSelected [0,2,4,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound58816 : packedSelected [0,2,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env58817 : List Nat := [2,4,8,0,32,64,46,4,109,68,13,44,101,64,44,46,96,0,104,45,45,75,96,46,111,13,42,33,65,96,105,64,4,12,0,64]

theorem envBound58817 : H12AffineFastState.Bounded env58817 := by
  intro p hp
  have h : env58817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58816_58817 : H12AffineEnvironment.transform 6 46 env58816 = env58817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env58816 == env58817) = true)

theorem identity58817 : scanCanonicalize (H12AffineFastState.compose env58817 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound58817 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58818 : List Nat := [2,4,8,0,32,13,46,4,32,9,13,44,40,13,44,46,45,0,37,45,45,6,45,46,34,13,42,33,12,45,36,13,4,12,0,13]

theorem envBound58818 : H12AffineFastState.Bounded env58818 := by
  intro p hp
  have h : env58818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58817_58818 : H12AffineEnvironment.transform 5 13 env58817 = env58818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env58817 == env58818) = true)

theorem identity58818 : scanCanonicalize (H12AffineFastState.compose env58818 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound58818 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58819 : List Nat := [2,4,5,0,32,0,35,4,32,4,0,33,37,0,33,35,32,0,37,32,32,6,32,35,34,0,39,33,1,32,36,0,4,1,0,0]

theorem envBound58819 : H12AffineFastState.Bounded env58819 := by
  intro p hp
  have h : env58819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58818_58819 : H12AffineEnvironment.transform 2 5 env58818 = env58819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env58818 == env58819) = true)

theorem identity58819 : scanCanonicalize (H12AffineFastState.compose env58819 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound58819 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env58820 : List Nat := [2,4,5,0,7,0,4,4,7,4,0,6,2,0,6,4,7,0,2,7,7,6,7,4,5,0,0,6,1,7,3,0,4,1,0,0]

theorem envBound58820 : H12AffineFastState.Bounded env58820 := by
  intro p hp
  have h : env58820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58819_58820 : H12AffineEnvironment.transform 4 7 env58819 = env58820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env58819 == env58820) = true)

def env58821 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,837,781,64,577,46,525,174,517,576,836,648,525,46,193,265,302,589,65,2157,769,65,256,264,1,325]

theorem envBound58821 : H12AffineFastState.Bounded env58821 := by
  intro p hp
  have h : env58821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58812_58821 : H12AffineEnvironment.transform 3 1 env58812 = env58821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env58812 == env58821) = true)

theorem identity58821 : scanCanonicalize (H12AffineFastState.compose env58821 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound58821 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58822 : List Nat := [2,4,8,1,32,64,128,256,64,321,2048,261,333,64,1,46,77,174,69,0,260,200,77,46,193,265,302,13,65,2157,321,65,256,264,1,325]

theorem envBound58822 : H12AffineFastState.Bounded env58822 := by
  intro p hp
  have h : env58822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58821_58822 : H12AffineEnvironment.transform 8 64 env58821 = env58822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env58821 == env58822) = true)

theorem identity58822 : scanCanonicalize (H12AffineFastState.compose env58822 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound58822 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env58823 : List Nat := [2,4,5,1,32,64,128,256,64,321,2048,261,320,64,1,35,64,163,69,0,260,197,64,35,193,260,291,0,65,2144,321,65,256,261,1,325]

theorem envBound58823 : H12AffineFastState.Bounded env58823 := by
  intro p hp
  have h : env58823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58822_58823 : H12AffineEnvironment.transform 2 5 env58822 = env58823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env58822 == env58823) = true)

theorem identity58823 : scanCanonicalize (H12AffineFastState.compose env58823 (packedSelected [1,3,10] rootPS)) = affineNative (2^(10+1) ^^^ 228) := by decide +kernel

theorem selectedBound58823 : packedSelected [1,3,10] rootPS < 2^1333 := by decide +kernel

def env58824 : List Nat := [2,4,5,1,32,64,128,256,64,321,228,261,320,64,1,35,64,163,69,0,260,197,64,35,193,260,291,0,65,132,321,65,256,261,1,325]

theorem envBound58824 : H12AffineFastState.Bounded env58824 := by
  intro p hp
  have h : env58824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58823_58824 : H12AffineEnvironment.transform 10 228 env58823 = env58824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 228 env58823 == env58824) = true)

theorem identity58824 : scanCanonicalize (H12AffineFastState.compose env58824 (packedSelected [0,5,7,8,11,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound58824 : packedSelected [0,5,7,8,11,12,13] rootPS < 2^1333 := by decide +kernel

def env58825 : List Nat := [2,4,5,1,32,64,36,256,64,321,64,261,320,64,1,35,64,7,69,0,260,97,64,35,101,260,291,0,65,32,321,65,256,261,1,325]

theorem envBound58825 : H12AffineFastState.Bounded env58825 := by
  intro p hp
  have h : env58825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58824_58825 : H12AffineEnvironment.transform 6 36 env58824 = env58825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env58824 == env58825) = true)

theorem identity58825 : scanCanonicalize (H12AffineFastState.compose env58825 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound58825 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env58826 : List Nat := [2,4,5,1,32,38,36,256,38,295,38,261,294,38,1,35,38,7,35,0,260,7,38,35,3,260,291,0,39,32,295,39,256,261,1,291]

theorem envBound58826 : H12AffineFastState.Bounded env58826 := by
  intro p hp
  have h : env58826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58825_58826 : H12AffineEnvironment.transform 5 38 env58825 = env58826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env58825 == env58826) = true)

theorem identity58826 : scanCanonicalize (H12AffineFastState.compose env58826 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound58826 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58827 : List Nat := [2,4,5,1,32,38,36,36,38,3,38,33,2,38,1,35,38,7,35,0,32,7,38,35,3,32,7,0,39,32,3,39,36,33,1,7]

theorem envBound58827 : H12AffineFastState.Bounded env58827 := by
  intro p hp
  have h : env58827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58826_58827 : H12AffineEnvironment.transform 7 36 env58826 = env58827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env58826 == env58827) = true)

theorem identity58827 : scanCanonicalize (H12AffineFastState.compose env58827 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound58827 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env58828 : List Nat := [2,4,5,1,6,0,2,2,0,3,0,7,2,0,1,5,0,7,5,0,6,7,0,5,3,6,7,0,1,6,3,1,2,7,1,7]

theorem envBound58828 : H12AffineFastState.Bounded env58828 := by
  intro p hp
  have h : env58828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58827_58828 : H12AffineEnvironment.transform 4 6 env58827 = env58828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env58827 == env58828) = true)

theorem identity58828 : scanCanonicalize (H12AffineFastState.compose env58828 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound58828 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58829 : List Nat := [2,2,3,1,0,0,2,2,0,3,0,1,2,0,1,3,0,1,3,0,0,1,0,3,3,0,1,0,1,0,3,1,2,1,1,1]

theorem envBound58829 : H12AffineFastState.Bounded env58829 := by
  intro p hp
  have h : env58829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58828_58829 : H12AffineEnvironment.transform 1 2 env58828 = env58829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env58828 == env58829) = true)

theorem identity58829 : scanCanonicalize (H12AffineFastState.compose env58829 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound58829 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58830 : List Nat := [1,1,0,1,0,0,1,1,0,0,0,1,1,0,1,0,0,1,0,0,0,1,0,0,0,0,1,0,1,0,0,1,1,1,1,1]

theorem envBound58830 : H12AffineFastState.Bounded env58830 := by
  intro p hp
  have h : env58830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2