import H12CloudChart2Data140

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans35047_35048 : H12AffineEnvironment.transform 9 53 env35047 = env35048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env35047 == env35048) = true)

theorem identity35048 : scanCanonicalize (H12AffineFastState.compose env35048 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound35048 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35049 : List Nat := [2,4,8,16,16,16,19,15,0,5,0,26,25,26,27,8,26,26,5,26,27,17,17,3,3,17,27,27,26,27,20,17,14,10,27,0]

theorem envBound35049 : H12AffineFastState.Bounded env35049 := by
  intro p hp
  have h : env35049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35048_35049 : H12AffineEnvironment.transform 4 16 env35048 = env35049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env35048 == env35049) = true)

def env35050 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5385,1296,276,65536,1297,65665,66870,277,4097,396,17,69649,70838,65830,66841,1297,69943,67602,5380,65830,257,69927,1296,66358]

theorem envBound35050 : H12AffineFastState.Bounded env35050 := by
  intro p hp
  have h : env35050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35040_35050 : H12AffineEnvironment.transform 5 17 env35040 = env35050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35040 == env35050) = true)

theorem identity35050 : scanCanonicalize (H12AffineFastState.compose env35050 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound35050 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35051 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,4096,4365,276,276,65536,277,65665,65842,277,4097,396,17,69649,69810,65830,65821,277,69943,67602,4352,65830,257,69927,276,66358]

theorem envBound35051 : H12AffineFastState.Bounded env35051 := by
  intro p hp
  have h : env35051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35050_35051 : H12AffineEnvironment.transform 9 4 env35050 = env35051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env35050 == env35051) = true)

theorem identity35051 : scanCanonicalize (H12AffineFastState.compose env35051 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound35051 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env35052 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,276,25,276,276,65536,277,65665,65842,277,277,396,17,65797,65958,65830,65821,277,65571,67602,20,65830,257,65587,276,66358]

theorem envBound35052 : H12AffineFastState.Bounded env35052 := by
  intro p hp
  have h : env35052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35051_35052 : H12AffineEnvironment.transform 11 276 env35051 = env35052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env35051 == env35052) = true)

theorem identity35052 : scanCanonicalize (H12AffineFastState.compose env35052 (packedSelected [0,1,2,3,5,7,8,18] rootPS)) = affineNative (2^(15+1) ^^^ 546) := by decide +kernel

theorem selectedBound35052 : packedSelected [0,1,2,3,5,7,8,18] rootPS < 2^1333 := by decide +kernel

def env35053 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,276,25,276,276,546,277,675,784,277,277,396,17,807,900,772,831,277,513,2608,20,772,257,529,276,276]

theorem envBound35053 : H12AffineFastState.Bounded env35053 := by
  intro p hp
  have h : env35053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35052_35053 : H12AffineEnvironment.transform 15 546 env35052 = env35053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 546 env35052 == env35053) = true)

theorem identity35053 : scanCanonicalize (H12AffineFastState.compose env35053 (packedSelected [2,3,8,10,12,15,17,19] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound35053 : packedSelected [2,3,8,10,12,15,17,19] rootPS < 2^1333 := by decide +kernel

def env35054 : List Nat := [2,4,8,16,32,17,128,256,512,4,561,276,25,276,276,546,277,675,784,277,277,396,17,807,900,772,831,277,513,1,20,772,257,529,276,276]

theorem envBound35054 : H12AffineFastState.Bounded env35054 := by
  intro p hp
  have h : env35054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35053_35054 : H12AffineEnvironment.transform 10 561 env35053 = env35054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env35053 == env35054) = true)

theorem identity35054 : scanCanonicalize (H12AffineFastState.compose env35054 (packedSelected [0,1,7,8,10,11,13,15] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound35054 : packedSelected [0,1,7,8,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env35055 : List Nat := [2,4,8,16,32,17,128,256,48,4,1,276,25,276,276,18,277,147,288,277,277,396,17,279,436,308,271,277,49,1,20,308,257,33,276,276]

theorem envBound35055 : H12AffineFastState.Bounded env35055 := by
  intro p hp
  have h : env35055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35054_35055 : H12AffineEnvironment.transform 8 48 env35054 = env35055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env35054 == env35055) = true)

theorem identity35055 : scanCanonicalize (H12AffineFastState.compose env35055 (packedSelected [0,3,5,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound35055 : packedSelected [0,3,5,9,10] rootPS < 2^1333 := by decide +kernel

def env35056 : List Nat := [2,4,8,16,32,17,128,21,48,4,1,1,25,1,1,18,0,147,53,0,0,153,17,2,161,33,26,0,49,1,20,33,20,33,1,1]

theorem envBound35056 : H12AffineFastState.Bounded env35056 := by
  intro p hp
  have h : env35056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35055_35056 : H12AffineEnvironment.transform 7 21 env35055 = env35056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env35055 == env35056) = true)

theorem identity35056 : scanCanonicalize (H12AffineFastState.compose env35056 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound35056 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env35057 : List Nat := [2,4,8,16,32,17,46,21,48,4,1,1,25,1,1,18,0,61,53,0,0,55,17,2,15,33,26,0,49,1,20,33,20,33,1,1]

theorem envBound35057 : H12AffineFastState.Bounded env35057 := by
  intro p hp
  have h : env35057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35056_35057 : H12AffineEnvironment.transform 6 46 env35056 = env35057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env35056 == env35057) = true)

theorem identity35057 : scanCanonicalize (H12AffineFastState.compose env35057 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound35057 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35058 : List Nat := [2,4,8,16,17,17,31,21,1,4,1,1,25,1,1,18,0,12,4,0,0,6,17,2,15,16,26,0,0,1,20,16,20,16,1,1]

theorem envBound35058 : H12AffineFastState.Bounded env35058 := by
  intro p hp
  have h : env35058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35057_35058 : H12AffineEnvironment.transform 4 17 env35057 = env35058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env35057 == env35058) = true)

theorem identity35058 : scanCanonicalize (H12AffineFastState.compose env35058 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound35058 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35059 : List Nat := [2,4,8,10,11,11,5,15,1,4,1,1,3,1,1,8,0,12,4,0,0,6,11,2,15,10,0,0,0,1,14,10,14,10,1,1]

theorem envBound35059 : H12AffineFastState.Bounded env35059 := by
  intro p hp
  have h : env35059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35058_35059 : H12AffineEnvironment.transform 3 10 env35058 = env35059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env35058 == env35059) = true)

theorem identity35059 : scanCanonicalize (H12AffineFastState.compose env35059 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound35059 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35060 : List Nat := [2,4,4,6,7,7,5,3,1,4,1,1,3,1,1,4,0,0,4,0,0,6,7,2,3,6,0,0,0,1,2,6,2,6,1,1]

theorem envBound35060 : H12AffineFastState.Bounded env35060 := by
  intro p hp
  have h : env35060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35059_35060 : H12AffineEnvironment.transform 2 4 env35059 = env35060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env35059 == env35060) = true)

def env35061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77935,32769,4097,46529,17,266385,70886,78894,77840,1297,74814,81227,365712,308667,257,74798,1345,79471]

theorem envBound35061 : H12AffineFastState.Bounded env35061 := by
  intro p hp
  have h : env35061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35013_35061 : H12AffineEnvironment.transform 13 1297 env35013 = env35061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env35013 == env35061) = true)

theorem identity35061 : scanCanonicalize (H12AffineFastState.compose env35061 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound35061 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env35062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1345,262144,45084,32769,4097,46529,17,266385,38037,46173,45155,1297,42061,48440,267491,308667,257,42077,1345,46620]

theorem envBound35062 : H12AffineFastState.Bounded env35062 := by
  intro p hp
  have h : env35062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35061_35062 : H12AffineEnvironment.transform 15 32883 env35061 = env35062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env35061 == env35062) = true)

def env35063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1345,262144,42332,32769,1345,41089,17,263633,33237,41245,42275,1297,42061,43128,262563,303355,257,42077,1345,41820]

theorem envBound35063 : H12AffineFastState.Bounded env35063 := by
  intro p hp
  have h : env35063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35062_35063 : H12AffineEnvironment.transform 11 1344 env35062 = env35063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env35062 == env35063) = true)

theorem identity35063 : scanCanonicalize (H12AffineFastState.compose env35063 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 9455) := by decide +kernel

theorem selectedBound35063 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1345,9455,42332,32769,1345,41089,17,8510,33237,41245,42275,1297,42061,43128,9548,33812,257,42077,1345,41820]

theorem envBound35064 : H12AffineFastState.Bounded env35064 := by
  intro p hp
  have h : env35064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35063_35064 : H12AffineEnvironment.transform 17 9455 env35063 = env35064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9455 env35063 == env35064) = true)

theorem identity35064 : scanCanonicalize (H12AffineFastState.compose env35064 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 828) := by decide +kernel

theorem selectedBound35064 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env35065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,828,1297,32768,32883,1345,2003,34400,32769,1345,33725,17,514,33237,33313,34335,1297,34673,35652,1648,33812,257,34657,1345,32864]

theorem envBound35065 : H12AffineFastState.Bounded env35065 := by
  intro p hp
  have h : env35065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35064_35065 : H12AffineEnvironment.transform 12 828 env35064 = env35065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 828 env35064 == env35065) = true)

def env35066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1345,262144,42333,32769,1344,41088,17,263632,33236,41244,42274,1297,42061,43129,262562,303354,257,42077,1345,41821]

theorem envBound35066 : H12AffineFastState.Bounded env35066 := by
  intro p hp
  have h : env35066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35062_35066 : H12AffineEnvironment.transform 11 1345 env35062 = env35066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env35062 == env35066) = true)

theorem identity35066 : scanCanonicalize (H12AffineFastState.compose env35066 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9244) := by decide +kernel

theorem selectedBound35066 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35067 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,9244,9327,1345,262144,321,9245,1344,1180,17,263632,9672,1280,318,1297,81,3173,262562,263398,257,65,1345,1857]

theorem envBound35067 : H12AffineFastState.Bounded env35067 := by
  intro p hp
  have h : env35067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35066_35067 : H12AffineEnvironment.transform 14 9244 env35066 = env35067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9244 env35066 == env35067) = true)

theorem identity35067 : scanCanonicalize (H12AffineFastState.compose env35067 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound35067 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env35068 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,80,8541,8494,0,262144,321,8540,1,477,17,262289,8329,65,318,80,81,2340,262562,262567,257,65,0,512]

theorem envBound35068 : H12AffineFastState.Bounded env35068 := by
  intro p hp
  have h : env35068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35067_35068 : H12AffineEnvironment.transform 9 321 env35067 = env35068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env35067 == env35068) = true)

theorem identity35068 : scanCanonicalize (H12AffineFastState.compose env35068 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound35068 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35069 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,0,8192,80,8264,8251,0,262144,84,8265,1,200,17,262289,8329,65,43,80,81,2097,262327,262322,20,65,0,512]

theorem envBound35069 : H12AffineFastState.Bounded env35069 := by
  intro p hp
  have h : env35069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35068_35069 : H12AffineEnvironment.transform 7 21 env35068 = env35069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env35068 == env35069) = true)

theorem identity35069 : scanCanonicalize (H12AffineFastState.compose env35069 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound35069 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35070 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,0,656,80,728,683,0,262144,84,729,1,200,17,262289,537,65,43,80,81,2097,262327,262322,20,65,0,512]

theorem envBound35070 : H12AffineFastState.Bounded env35070 := by
  intro p hp
  have h : env35070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35069_35070 : H12AffineEnvironment.transform 12 656 env35069 = env35070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env35069 == env35070) = true)

theorem identity35070 : scanCanonicalize (H12AffineFastState.compose env35070 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35070 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env35071 : List Nat := [2,4,8,16,32,17,128,21,512,5,2048,0,656,1,649,683,0,262144,5,648,1,153,17,262289,537,16,43,1,0,2097,262327,262322,20,16,0,512]

theorem envBound35071 : H12AffineFastState.Bounded env35071 := by
  intro p hp
  have h : env35071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35070_35071 : H12AffineEnvironment.transform 5 17 env35070 = env35071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35070 == env35071) = true)

theorem identity35071 : scanCanonicalize (H12AffineFastState.compose env35071 (packedSelected [1,3,13] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound35071 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env35072 : List Nat := [2,4,8,16,32,17,128,21,512,5,43,0,656,1,649,683,0,262144,5,648,1,153,17,262289,537,16,43,1,0,26,262327,262322,20,16,0,512]

theorem envBound35072 : H12AffineFastState.Bounded env35072 := by
  intro p hp
  have h : env35072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35071_35072 : H12AffineEnvironment.transform 10 43 env35071 = env35072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env35071 == env35072) = true)

theorem identity35072 : scanCanonicalize (H12AffineFastState.compose env35072 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound35072 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env35073 : List Nat := [2,4,8,16,32,17,57,21,512,5,43,0,553,1,560,530,0,262144,5,561,1,32,17,262184,537,16,43,1,0,26,262158,262155,20,16,0,512]

theorem envBound35073 : H12AffineFastState.Bounded env35073 := by
  intro p hp
  have h : env35073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35072_35073 : H12AffineEnvironment.transform 6 57 env35072 = env35073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env35072 == env35073) = true)

theorem identity35073 : scanCanonicalize (H12AffineFastState.compose env35073 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound35073 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env35074 : List Nat := [2,4,8,16,32,17,57,21,48,5,43,0,25,1,0,34,0,262144,5,1,1,32,17,262184,41,16,43,1,0,26,262158,262155,20,16,0,48]

theorem envBound35074 : H12AffineFastState.Bounded env35074 := by
  intro p hp
  have h : env35074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35073_35074 : H12AffineEnvironment.transform 8 48 env35073 = env35074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env35073 == env35074) = true)

theorem identity35074 : scanCanonicalize (H12AffineFastState.compose env35074 (packedSelected [2] rootPS)) = affineNative (2^(17+1) ^^^ 49) := by decide +kernel

theorem selectedBound35074 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35075 : List Nat := [2,4,8,16,32,17,57,21,48,5,43,0,25,1,0,34,0,49,5,1,1,32,17,25,41,16,43,1,0,26,63,58,20,16,0,48]

theorem envBound35075 : H12AffineFastState.Bounded env35075 := by
  intro p hp
  have h : env35075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35074_35075 : H12AffineEnvironment.transform 17 49 env35074 = env35075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 49 env35074 == env35075) = true)

theorem identity35075 : scanCanonicalize (H12AffineFastState.compose env35075 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound35075 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env35076 : List Nat := [2,4,8,16,16,17,9,21,0,5,27,0,25,1,0,18,0,1,5,1,1,16,17,25,25,16,27,1,0,26,15,10,20,16,0,0]

theorem envBound35076 : H12AffineFastState.Bounded env35076 := by
  intro p hp
  have h : env35076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35075_35076 : H12AffineEnvironment.transform 4 16 env35075 = env35076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env35075 == env35076) = true)

theorem identity35076 : scanCanonicalize (H12AffineFastState.compose env35076 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound35076 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env35077 : List Nat := [2,4,8,10,10,11,9,15,0,5,1,0,3,1,0,8,0,1,5,1,1,10,11,3,3,10,1,1,0,0,15,10,14,10,0,0]

theorem envBound35077 : H12AffineFastState.Bounded env35077 := by
  intro p hp
  have h : env35077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35076_35077 : H12AffineEnvironment.transform 3 10 env35076 = env35077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env35076 == env35077) = true)

theorem identity35077 : scanCanonicalize (H12AffineFastState.compose env35077 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound35077 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35078 : List Nat := [2,3,8,10,10,11,9,8,0,2,1,0,3,1,0,8,0,1,2,1,1,10,11,3,3,10,1,1,0,0,8,10,9,10,0,0]

theorem envBound35078 : H12AffineFastState.Bounded env35078 := by
  intro p hp
  have h : env35078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35077_35078 : H12AffineEnvironment.transform 1 3 env35077 = env35078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env35077 == env35078) = true)

def env35079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95614,32769,4097,61648,16,284032,86519,94526,77841,1296,74814,96346,381313,323754,257,74798,1345,95102]

theorem envBound35079 : H12AffineFastState.Bounded env35079 := by
  intro p hp
  have h : env35079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35012_35079 : H12AffineEnvironment.transform 16 16465 env35012 = env35079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env35012 == env35079) = true)

def env35080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77934,32769,4097,46528,16,266384,70887,78894,77841,1296,74814,81226,365713,308666,257,74798,1345,79470]

theorem envBound35080 : H12AffineFastState.Bounded env35080 := by
  intro p hp
  have h : env35080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35079_35080 : H12AffineEnvironment.transform 13 1296 env35079 = env35080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env35079 == env35080) = true)

theorem identity35080 : scanCanonicalize (H12AffineFastState.compose env35080 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound35080 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env35081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1345,262144,45084,32769,4097,46528,16,266384,38037,46172,45155,1296,42060,48440,267491,308666,257,42076,1345,46620]

theorem envBound35081 : H12AffineFastState.Bounded env35081 := by
  intro p hp
  have h : env35081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35080_35081 : H12AffineEnvironment.transform 15 32882 env35080 = env35081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env35080 == env35081) = true)

def env35082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1345,262144,42332,32769,1345,41088,16,263632,33237,41244,42275,1296,42060,43128,262563,303354,257,42076,1345,41820]

theorem envBound35082 : H12AffineFastState.Bounded env35082 := by
  intro p hp
  have h : env35082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35081_35082 : H12AffineEnvironment.transform 11 1344 env35081 = env35082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env35081 == env35082) = true)

theorem identity35082 : scanCanonicalize (H12AffineFastState.compose env35082 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 41146) := by decide +kernel

theorem selectedBound35082 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1345,41146,42332,32769,1345,41088,16,42346,33237,41244,42275,1296,42060,43128,41241,64,257,42076,1345,41820]

theorem envBound35083 : H12AffineFastState.Bounded env35083 := by
  intro p hp
  have h : env35083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35082_35083 : H12AffineEnvironment.transform 17 41146 env35082 = env35083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41146 env35082 == env35083) = true)

theorem identity35083 : scanCanonicalize (H12AffineFastState.compose env35083 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound35083 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env35084 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,8540,8494,1345,486,1024,8541,1345,476,16,1078,8329,64,1151,1296,1296,2340,69,64,257,1280,1345,512]

theorem envBound35084 : H12AffineFastState.Bounded env35084 := by
  intro p hp
  have h : env35084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35083_35084 : H12AffineEnvironment.transform 14 8540 env35083 = env35084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env35083 == env35084) = true)

theorem identity35084 : scanCanonicalize (H12AffineFastState.compose env35084 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound35084 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35085 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,276,8192,324,8540,8494,277,486,84,8541,277,476,16,98,8329,64,43,324,324,2340,69,64,257,340,277,512]

theorem envBound35085 : H12AffineFastState.Bounded env35085 := by
  intro p hp
  have h : env35085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35084_35085 : H12AffineEnvironment.transform 9 84 env35084 = env35085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env35084 == env35085) = true)

theorem identity35085 : scanCanonicalize (H12AffineFastState.compose env35085 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 900) := by decide +kernel

theorem selectedBound35085 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35086 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,276,900,324,728,682,277,486,84,729,277,476,16,98,781,64,43,324,324,2340,69,64,257,340,277,512]

theorem envBound35086 : H12AffineFastState.Bounded env35086 := by
  intro p hp
  have h : env35086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35085_35086 : H12AffineEnvironment.transform 12 900 env35085 = env35086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 900 env35085 == env35086) = true)

theorem identity35086 : scanCanonicalize (H12AffineFastState.compose env35086 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35086 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env35087 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,276,900,277,649,682,277,439,5,648,277,397,16,51,781,17,43,277,277,2340,20,17,257,261,277,512]

theorem envBound35087 : H12AffineFastState.Bounded env35087 := by
  intro p hp
  have h : env35087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35086_35087 : H12AffineEnvironment.transform 5 17 env35086 = env35087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35086 == env35087) = true)

theorem identity35087 : scanCanonicalize (H12AffineFastState.compose env35087 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 319) := by decide +kernel

theorem selectedBound35087 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env35088 : List Nat := [2,4,8,16,32,17,128,256,512,5,319,276,900,277,649,682,277,439,5,648,277,397,16,51,781,17,43,277,277,27,20,17,257,261,277,512]

theorem envBound35088 : H12AffineFastState.Bounded env35088 := by
  intro p hp
  have h : env35088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35087_35088 : H12AffineEnvironment.transform 10 319 env35087 = env35088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 319 env35087 == env35088) = true)

theorem identity35088 : scanCanonicalize (H12AffineFastState.compose env35088 (packedSelected [1,4,5,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound35088 : packedSelected [1,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env35089 : List Nat := [2,4,8,16,32,17,128,157,512,5,162,137,537,136,649,682,136,42,5,648,136,16,16,51,656,17,43,136,136,27,20,17,156,152,136,512]

theorem envBound35089 : H12AffineFastState.Bounded env35089 := by
  intro p hp
  have h : env35089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35088_35089 : H12AffineEnvironment.transform 7 157 env35088 = env35089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env35088 == env35089) = true)

theorem identity35089 : scanCanonicalize (H12AffineFastState.compose env35089 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound35089 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35090 : List Nat := [2,4,8,16,16,17,128,157,512,5,146,137,537,136,649,666,136,26,5,648,136,16,16,3,656,17,27,136,136,27,20,17,156,152,136,512]

theorem envBound35090 : H12AffineFastState.Bounded env35090 := by
  intro p hp
  have h : env35090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35089_35090 : H12AffineEnvironment.transform 4 16 env35089 = env35090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env35089 == env35090) = true)

theorem identity35090 : scanCanonicalize (H12AffineFastState.compose env35090 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound35090 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env35091 : List Nat := [2,4,8,16,16,17,128,157,147,5,146,137,138,136,26,9,136,26,5,27,136,16,16,3,3,17,27,136,136,27,20,17,156,152,136,147]

theorem envBound35091 : H12AffineFastState.Bounded env35091 := by
  intro p hp
  have h : env35091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35090_35091 : H12AffineEnvironment.transform 8 147 env35090 = env35091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env35090 == env35091) = true)

theorem identity35091 : scanCanonicalize (H12AffineFastState.compose env35091 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound35091 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env35092 : List Nat := [2,4,8,10,10,11,128,135,137,5,136,137,138,136,0,9,136,0,5,1,136,10,10,3,3,11,1,136,136,1,14,11,134,130,136,137]

theorem envBound35092 : H12AffineFastState.Bounded env35092 := by
  intro p hp
  have h : env35092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35091_35092 : H12AffineEnvironment.transform 3 10 env35091 = env35092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env35091 == env35092) = true)

theorem identity35092 : scanCanonicalize (H12AffineFastState.compose env35092 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound35092 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35093 : List Nat := [2,4,8,10,10,11,8,15,1,5,0,1,2,0,0,9,0,0,5,1,0,10,10,3,3,11,1,0,0,1,14,11,14,10,0,1]

theorem envBound35093 : H12AffineFastState.Bounded env35093 := by
  intro p hp
  have h : env35093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35092_35093 : H12AffineEnvironment.transform 6 8 env35092 = env35093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35092 == env35093) = true)

theorem identity35093 : scanCanonicalize (H12AffineFastState.compose env35093 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound35093 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35094 : List Nat := [2,4,4,6,6,7,4,3,1,5,0,1,2,0,0,5,0,0,5,1,0,6,6,3,3,7,1,0,0,1,2,7,2,6,0,1]

theorem envBound35094 : H12AffineFastState.Bounded env35094 := by
  intro p hp
  have h : env35094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35093_35094 : H12AffineEnvironment.transform 2 4 env35093 = env35094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env35093 == env35094) = true)

def env35095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1345,262144,42333,32769,1344,41089,16,263633,33236,41245,42274,1296,42060,43129,262562,303355,257,42076,1345,41821]

theorem envBound35095 : H12AffineFastState.Bounded env35095 := by
  intro p hp
  have h : env35095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35081_35095 : H12AffineEnvironment.transform 11 1345 env35081 = env35095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env35081 == env35095) = true)

theorem identity35095 : scanCanonicalize (H12AffineFastState.compose env35095 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound35095 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,72,1296,32768,32882,1345,262144,34069,32769,1344,32969,16,263633,33236,33109,34154,1296,33796,34865,262562,295091,257,33812,1345,33557]

theorem envBound35096 : H12AffineFastState.Bounded env35096 := by
  intro p hp
  have h : env35096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35095_35096 : H12AffineEnvironment.transform 12 72 env35095 = env35096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env35095 == env35096) = true)

theorem identity35096 : scanCanonicalize (H12AffineFastState.compose env35096 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 2003) := by decide +kernel

theorem selectedBound35096 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env35097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,72,1296,32768,32882,1345,2003,34069,32769,1344,32969,16,514,33236,33109,34154,1296,33796,34865,1649,34656,257,33812,1345,33557]

theorem envBound35097 : H12AffineFastState.Bounded env35097 := by
  intro p hp
  have h : env35097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35096_35097 : H12AffineEnvironment.transform 17 2003 env35096 = env35097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2003 env35096 == env35097) = true)

def env35098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77935,32769,4097,46529,16,266385,70886,78895,77841,1296,74814,81227,365712,308667,257,74798,1345,79471]

theorem envBound35098 : H12AffineFastState.Bounded env35098 := by
  intro p hp
  have h : env35098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35079_35098 : H12AffineEnvironment.transform 13 1297 env35079 = env35098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env35079 == env35098) = true)

theorem identity35098 : scanCanonicalize (H12AffineFastState.compose env35098 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound35098 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env35099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,262144,77935,13340,4097,476,16,266385,70886,78895,77841,1296,74814,81227,336013,262566,257,74798,1345,79471]

theorem envBound35099 : H12AffineFastState.Bounded env35099 := by
  intro p hp
  have h : env35099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35098_35099 : H12AffineEnvironment.transform 14 13341 env35098 = env35099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env35098 == env35099) = true)

def env35100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65664,77935,13340,4097,476,16,69649,70886,78895,77841,1296,74814,81227,8205,65830,257,74798,1345,79471]

theorem envBound35100 : H12AffineFastState.Bounded env35100 := by
  intro p hp
  have h : env35100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35099_35100 : H12AffineEnvironment.transform 17 65664 env35099 = env35100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env35099 == env35100) = true)

theorem identity35100 : scanCanonicalize (H12AffineFastState.compose env35100 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound35100 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,9245,65536,1344,65664,73839,9244,1,476,16,65553,66790,74799,73745,1296,74814,77131,8205,65830,257,74798,1345,75375]

theorem envBound35101 : H12AffineFastState.Bounded env35101 := by
  intro p hp
  have h : env35101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35100_35101 : H12AffineEnvironment.transform 11 0 env35100 = env35101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env35100 == env35101) = true)

def env35102 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,0,8192,1297,9245,65536,1296,65664,73791,9244,1,396,16,65553,66742,74799,73745,1296,74814,77083,8205,65830,257,74798,1297,75327]

theorem envBound35102 : H12AffineFastState.Bounded env35102 := by
  intro p hp
  have h : env35102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35101_35102 : H12AffineEnvironment.transform 5 16 env35101 = env35102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35101 == env35102) = true)

theorem identity35102 : scanCanonicalize (H12AffineFastState.compose env35102 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound35102 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35103 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,0,8192,276,8216,65536,277,65664,73791,8217,1,396,16,65553,65715,73770,73745,277,73787,76062,8205,65830,257,73771,276,74298]

theorem envBound35103 : H12AffineFastState.Bounded env35103 := by
  intro p hp
  have h : env35103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35102_35103 : H12AffineEnvironment.transform 9 5 env35102 = env35103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env35102 == env35103) = true)

theorem identity35103 : scanCanonicalize (H12AffineFastState.compose env35103 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound35103 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env35104 : List Nat := [2,4,8,16,32,16,128,20,512,5,2048,0,8192,0,8216,65536,1,65664,73791,8217,1,152,16,65553,65715,73770,73745,1,73787,75786,8205,65586,21,73771,0,74298]

theorem envBound35104 : H12AffineFastState.Bounded env35104 := by
  intro p hp
  have h : env35104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35103_35104 : H12AffineEnvironment.transform 7 20 env35103 = env35104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env35103 == env35104) = true)

theorem identity35104 : scanCanonicalize (H12AffineFastState.compose env35104 (packedSelected [0,1,3,7,10,11,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 10883) := by decide +kernel

theorem selectedBound35104 : packedSelected [0,1,3,7,10,11,17,19] rootPS < 2^1333 := by decide +kernel

def env35105 : List Nat := [2,4,8,16,32,16,128,20,512,5,2048,0,8192,0,8216,10883,1,10755,2748,8217,1,152,16,10898,10800,2729,2706,1,2744,649,8205,10929,21,2728,0,2233]

theorem envBound35105 : H12AffineFastState.Bounded env35105 := by
  intro p hp
  have h : env35105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35104_35105 : H12AffineEnvironment.transform 15 10883 env35104 = env35105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10883 env35104 == env35105) = true)

theorem identity35105 : scanCanonicalize (H12AffineFastState.compose env35105 (packedSelected [0,1,5,7,11,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound35105 : packedSelected [0,1,5,7,11,13,17] rootPS < 2^1333 := by decide +kernel

def env35106 : List Nat := [2,4,8,16,32,16,128,20,512,5,1,0,8192,0,8216,8834,1,8706,701,8217,1,152,16,8851,8753,680,659,1,697,649,8205,8880,21,681,0,184]

theorem envBound35106 : H12AffineFastState.Bounded env35106 := by
  intro p hp
  have h : env35106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35105_35106 : H12AffineEnvironment.transform 10 1 env35105 = env35106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env35105 == env35106) = true)

theorem identity35106 : scanCanonicalize (H12AffineFastState.compose env35106 (packedSelected [0,1,2,7,8,11,13] rootPS)) = affineNative (2^(12+1) ^^^ 514) := by decide +kernel

theorem selectedBound35106 : packedSelected [0,1,2,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env35107 : List Nat := [2,4,8,16,32,16,128,20,512,5,1,0,514,0,538,128,1,0,701,539,1,152,16,145,51,680,659,1,697,649,527,178,21,681,0,184]

theorem envBound35107 : H12AffineFastState.Bounded env35107 := by
  intro p hp
  have h : env35107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35106_35107 : H12AffineEnvironment.transform 12 514 env35106 = env35107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 514 env35106 == env35107) = true)

theorem identity35107 : scanCanonicalize (H12AffineFastState.compose env35107 (packedSelected [0,5,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound35107 : packedSelected [0,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env35108 : List Nat := [2,4,8,16,32,16,128,20,1,5,1,0,3,0,27,128,1,0,188,26,1,152,16,145,51,169,146,1,184,136,14,178,21,168,0,184]

theorem envBound35108 : H12AffineFastState.Bounded env35108 := by
  intro p hp
  have h : env35108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35107_35108 : H12AffineEnvironment.transform 8 1 env35107 = env35108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env35107 == env35108) = true)

theorem identity35108 : scanCanonicalize (H12AffineFastState.compose env35108 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound35108 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env35109 : List Nat := [2,4,8,16,32,16,18,20,1,5,1,0,3,0,27,18,1,0,46,26,1,10,16,3,51,59,0,1,42,26,14,32,21,58,0,42]

theorem envBound35109 : H12AffineFastState.Bounded env35109 := by
  intro p hp
  have h : env35109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35108_35109 : H12AffineEnvironment.transform 6 18 env35108 = env35109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env35108 == env35109) = true)

theorem identity35109 : scanCanonicalize (H12AffineFastState.compose env35109 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound35109 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35110 : List Nat := [2,4,8,10,32,10,8,14,1,5,1,0,3,0,1,8,1,0,46,0,1,10,10,3,41,33,0,1,42,0,14,32,15,32,0,42]

theorem envBound35110 : H12AffineFastState.Bounded env35110 := by
  intro p hp
  have h : env35110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35109_35110 : H12AffineEnvironment.transform 3 10 env35109 = env35110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env35109 == env35110) = true)

theorem identity35110 : scanCanonicalize (H12AffineFastState.compose env35110 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound35110 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35111 : List Nat := [2,4,5,7,32,7,5,3,1,5,1,0,3,0,1,5,1,0,35,0,1,7,7,3,36,33,0,1,39,0,3,32,2,32,0,39]

theorem envBound35111 : H12AffineFastState.Bounded env35111 := by
  intro p hp
  have h : env35111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35110_35111 : H12AffineEnvironment.transform 2 5 env35110 = env35111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env35110 == env35111) = true)

def env35112 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,0,8192,1297,9245,65536,1297,65664,73790,9244,1,397,16,65553,66743,74799,73745,1296,74814,77082,8205,65830,257,74798,1296,75326]

theorem envBound35112 : H12AffineFastState.Bounded env35112 := by
  intro p hp
  have h : env35112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35101_35112 : H12AffineEnvironment.transform 5 17 env35101 = env35112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35101 == env35112) = true)

theorem identity35112 : scanCanonicalize (H12AffineFastState.compose env35112 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound35112 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35113 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,0,8192,1297,9245,8250,1297,8378,4,9244,1,397,16,8235,9357,1045,43,1296,1028,3360,8205,8476,257,1044,1296,1540]

theorem envBound35113 : H12AffineFastState.Bounded env35113 := by
  intro p hp
  have h : env35113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35112_35113 : H12AffineEnvironment.transform 15 8250 env35112 = env35113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env35112 == env35113) = true)

theorem identity35113 : scanCanonicalize (H12AffineFastState.compose env35113 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound35113 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env35114 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,0,8192,1028,9245,8250,1028,8378,4,9244,1,152,16,8235,9357,1045,43,1029,1028,3125,8205,8201,20,1044,1029,1540]

theorem envBound35114 : H12AffineFastState.Bounded env35114 := by
  intro p hp
  have h : env35114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35113_35114 : H12AffineEnvironment.transform 7 21 env35113 = env35114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env35113 == env35114) = true)

theorem identity35114 : scanCanonicalize (H12AffineFastState.compose env35114 (packedSelected [10,11,13,17,18,19] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound35114 : packedSelected [10,11,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env35115 : List Nat := [2,4,8,16,32,17,35,21,512,1024,2048,0,8192,1028,9245,8250,1028,8217,4,9244,1,59,16,8235,9262,1045,43,1029,1028,3125,8205,8201,20,1044,1029,1540]

theorem envBound35115 : H12AffineFastState.Bounded env35115 := by
  intro p hp
  have h : env35115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35114_35115 : H12AffineEnvironment.transform 6 35 env35114 = env35115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env35114 == env35115) = true)

theorem identity35115 : scanCanonicalize (H12AffineFastState.compose env35115 (packedSelected [1,3,5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound35115 : packedSelected [1,3,5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env35116 : List Nat := [2,4,8,16,32,17,35,21,512,47,2048,0,8192,43,8242,8250,43,8217,4,8243,1,59,16,8235,8193,58,43,42,43,2074,8205,8201,20,59,42,555]

theorem envBound35116 : H12AffineFastState.Bounded env35116 := by
  intro p hp
  have h : env35116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35115_35116 : H12AffineEnvironment.transform 9 47 env35115 = env35116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env35115 == env35116) = true)

theorem identity35116 : scanCanonicalize (H12AffineFastState.compose env35116 (packedSelected [1,2,5,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound35116 : packedSelected [1,2,5,7,9] rootPS < 2^1333 := by decide +kernel

def env35117 : List Nat := [2,4,8,16,32,17,35,21,512,47,2048,0,24,43,42,34,43,1,4,43,1,59,16,51,25,58,43,42,43,2074,21,17,20,59,42,555]

theorem envBound35117 : H12AffineFastState.Bounded env35117 := by
  intro p hp
  have h : env35117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35116_35117 : H12AffineEnvironment.transform 12 24 env35116 = env35117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env35116 == env35117) = true)

theorem identity35117 : scanCanonicalize (H12AffineFastState.compose env35117 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound35117 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env35118 : List Nat := [2,4,8,11,32,10,35,14,512,47,2048,0,3,43,42,34,43,1,4,43,1,32,11,40,2,33,43,42,43,2049,14,10,15,32,42,555]

theorem envBound35118 : H12AffineFastState.Bounded env35118 := by
  intro p hp
  have h : env35118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35117_35118 : H12AffineEnvironment.transform 3 11 env35117 = env35118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env35117 == env35118) = true)

theorem identity35118 : scanCanonicalize (H12AffineFastState.compose env35118 (packedSelected [0,1,4] rootPS)) = affineNative (2^(8+1) ^^^ 45) := by decide +kernel

theorem selectedBound35118 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env35119 : List Nat := [2,4,8,11,32,10,35,14,45,47,2048,0,3,43,42,34,43,1,4,43,1,32,11,40,2,33,43,42,43,2049,14,10,15,32,42,6]

theorem envBound35119 : H12AffineFastState.Bounded env35119 := by
  intro p hp
  have h : env35119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35118_35119 : H12AffineEnvironment.transform 8 45 env35118 = env35119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 45 env35118 == env35119) = true)

theorem identity35119 : scanCanonicalize (H12AffineFastState.compose env35119 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound35119 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env35120 : List Nat := [2,4,8,11,12,10,15,14,1,3,2048,0,3,7,6,14,7,1,4,7,1,12,11,4,2,13,7,6,7,2049,14,10,15,12,6,6]

theorem envBound35120 : H12AffineFastState.Bounded env35120 := by
  intro p hp
  have h : env35120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35119_35120 : H12AffineEnvironment.transform 4 12 env35119 = env35120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env35119 == env35120) = true)

def env35121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65665,77935,13340,4097,476,16,69648,70886,78895,77841,1296,74814,81227,8204,65831,257,74798,1345,79471]

theorem envBound35121 : H12AffineFastState.Bounded env35121 := by
  intro p hp
  have h : env35121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35099_35121 : H12AffineEnvironment.transform 17 65665 env35099 = env35121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env35099 == env35121) = true)

theorem identity35121 : scanCanonicalize (H12AffineFastState.compose env35121 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound35121 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35122 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,12637,65536,0,65665,77935,12636,4097,476,16,69648,70054,78191,77841,80,74110,79883,8204,65831,257,74094,1,78639]

theorem envBound35122 : H12AffineFastState.Bounded env35122 := by
  intro p hp
  have h : env35122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35121_35122 : H12AffineEnvironment.transform 9 320 env35121 = env35122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env35121 == env35122) = true)

def env35123 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,8192,1,12557,65536,0,65665,77887,12556,4097,396,16,69648,70054,78143,77841,0,74030,79883,8204,65831,257,74046,1,78639]

theorem envBound35123 : H12AffineFastState.Bounded env35123 := by
  intro p hp
  have h : env35123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35122_35123 : H12AffineEnvironment.transform 5 16 env35122 = env35123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35122 == env35123) = true)

theorem identity35123 : scanCanonicalize (H12AffineFastState.compose env35123 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound35123 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35124 : List Nat := [2,4,8,16,32,16,128,21,512,5,2048,4096,8192,1,12312,65536,0,65665,77887,12313,4097,153,16,69648,69811,77866,77841,0,73787,79883,8204,65586,20,73771,1,78394]

theorem envBound35124 : H12AffineFastState.Bounded env35124 := by
  intro p hp
  have h : env35124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35123_35124 : H12AffineEnvironment.transform 7 21 env35123 = env35124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env35123 == env35124) = true)

theorem identity35124 : scanCanonicalize (H12AffineFastState.compose env35124 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8251) := by decide +kernel

theorem selectedBound35124 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env35125 : List Nat := [2,4,8,16,32,16,128,21,512,5,2048,4096,8192,1,12312,8251,0,8378,4100,12313,4097,153,16,12331,12424,4113,4138,0,0,6192,8204,8201,20,16,1,4609]

theorem envBound35125 : H12AffineFastState.Bounded env35125 := by
  intro p hp
  have h : env35125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35124_35125 : H12AffineEnvironment.transform 15 8251 env35124 = env35125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8251 env35124 == env35125) = true)

theorem identity35125 : scanCanonicalize (H12AffineFastState.compose env35125 (packedSelected [10,11,13,17,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 6330) := by decide +kernel

theorem selectedBound35125 : packedSelected [10,11,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env35126 : List Nat := [2,4,8,16,32,16,128,21,512,5,2048,4096,6330,1,2210,6273,0,6144,4100,2211,4097,153,16,2193,2098,4113,4138,0,0,6192,6326,6323,20,16,1,4609]

theorem envBound35126 : H12AffineFastState.Bounded env35126 := by
  intro p hp
  have h : env35126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35125_35126 : H12AffineEnvironment.transform 12 6330 env35125 = env35126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6330 env35125 == env35126) = true)

theorem identity35126 : scanCanonicalize (H12AffineFastState.compose env35126 (packedSelected [0,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2090) := by decide +kernel

theorem selectedBound35126 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env35127 : List Nat := [2,4,8,16,32,16,128,21,512,5,2048,2090,144,1,2210,171,0,42,2094,2211,2091,153,16,2193,2098,2107,2048,0,0,26,156,153,20,16,1,2603]

theorem envBound35127 : H12AffineFastState.Bounded env35127 := by
  intro p hp
  have h : env35127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35126_35127 : H12AffineEnvironment.transform 11 2090 env35126 = env35127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2090 env35126 == env35127) = true)

theorem identity35127 : scanCanonicalize (H12AffineFastState.compose env35127 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 696) := by decide +kernel

theorem selectedBound35127 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env35128 : List Nat := [2,4,8,16,32,16,128,21,512,5,696,658,144,1,538,171,0,42,662,539,659,153,16,553,650,643,696,0,0,26,156,153,20,16,1,147]

theorem envBound35128 : H12AffineFastState.Bounded env35128 := by
  intro p hp
  have h : env35128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35127_35128 : H12AffineEnvironment.transform 10 696 env35127 = env35128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 696 env35127 == env35128) = true)

theorem identity35128 : scanCanonicalize (H12AffineFastState.compose env35128 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound35128 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env35129 : List Nat := [2,4,8,16,32,16,56,21,512,5,512,554,40,1,538,19,0,42,558,539,555,33,16,553,562,571,512,0,0,26,36,33,20,16,1,43]

theorem envBound35129 : H12AffineFastState.Bounded env35129 := by
  intro p hp
  have h : env35129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35128_35129 : H12AffineEnvironment.transform 6 56 env35128 = env35129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env35128 == env35129) = true)

theorem identity35129 : scanCanonicalize (H12AffineFastState.compose env35129 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound35129 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35130 : List Nat := [2,4,8,16,32,16,56,21,49,5,49,27,40,1,43,19,0,42,31,42,26,33,16,24,3,10,49,0,0,26,36,33,20,16,1,43]

theorem envBound35130 : H12AffineFastState.Bounded env35130 := by
  intro p hp
  have h : env35130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35129_35130 : H12AffineEnvironment.transform 8 49 env35129 = env35130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env35129 == env35130) = true)

theorem identity35130 : scanCanonicalize (H12AffineFastState.compose env35130 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound35130 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env35131 : List Nat := [2,4,8,16,10,16,18,21,27,5,27,27,2,1,1,19,0,0,31,0,26,11,16,24,3,10,27,0,0,26,14,11,20,16,1,1]

theorem envBound35131 : H12AffineFastState.Bounded env35131 := by
  intro p hp
  have h : env35131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35130_35131 : H12AffineEnvironment.transform 4 10 env35130 = env35131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env35130 == env35131) = true)

theorem identity35131 : scanCanonicalize (H12AffineFastState.compose env35131 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound35131 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env35132 : List Nat := [2,4,8,12,10,12,14,9,7,5,7,7,2,1,1,15,0,0,3,0,6,11,12,4,3,10,7,0,0,6,14,11,8,12,1,1]

theorem envBound35132 : H12AffineFastState.Bounded env35132 := by
  intro p hp
  have h : env35132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35131_35132 : H12AffineEnvironment.transform 3 12 env35131 = env35132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env35131 == env35132) = true)

theorem identity35132 : scanCanonicalize (H12AffineFastState.compose env35132 (packedSelected [1,10] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound35132 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env35133 : List Nat := [2,3,8,11,10,11,9,9,0,2,0,0,2,1,1,8,0,0,3,0,1,11,11,3,3,10,0,0,0,1,9,11,8,11,1,1]

theorem envBound35133 : H12AffineFastState.Bounded env35133 := by
  intro p hp
  have h : env35133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35132_35133 : H12AffineEnvironment.transform 1 3 env35132 = env35133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env35132 == env35133) = true)

theorem identity35133 : scanCanonicalize (H12AffineFastState.compose env35133 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound35133 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35134 : List Nat := [1,0,8,8,9,8,9,9,0,1,0,0,1,1,1,8,0,0,0,0,1,8,8,0,0,9,0,0,0,1,9,8,8,8,1,1]

theorem envBound35134 : H12AffineFastState.Bounded env35134 := by
  intro p hp
  have h : env35134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35133_35134 : H12AffineEnvironment.transform 0 1 env35133 = env35134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env35133 == env35134) = true)

theorem identity35134 : scanCanonicalize (H12AffineFastState.compose env35134 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound35134 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35135 : List Nat := [1,0,1,1,0,1,0,0,0,1,0,0,1,1,1,1,0,0,0,0,1,1,1,0,0,0,0,0,0,1,0,1,1,1,1,1]

theorem envBound35135 : H12AffineFastState.Bounded env35135 := by
  intro p hp
  have h : env35135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35134_35135 : H12AffineEnvironment.transform 2 1 env35134 = env35135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env35134 == env35135) = true)

def env35136 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,8192,0,12556,65536,0,65665,77886,12557,4097,397,16,69648,70054,78142,77841,1,74031,79883,8204,65831,257,74047,1,78639]

theorem envBound35136 : H12AffineFastState.Bounded env35136 := by
  intro p hp
  have h : env35136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35122_35136 : H12AffineEnvironment.transform 5 17 env35122 = env35136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35122 == env35136) = true)

theorem identity35136 : scanCanonicalize (H12AffineFastState.compose env35136 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 12346) := by decide +kernel

theorem selectedBound35136 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35137 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,8192,0,12556,12346,0,12475,4,12557,4097,397,16,8234,8604,260,43,1,4373,2097,8204,12573,257,4357,1,789]

theorem envBound35137 : H12AffineFastState.Bounded env35137 := by
  intro p hp
  have h : env35137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35136_35137 : H12AffineEnvironment.transform 15 12346 env35136 = env35137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12346 env35136 == env35137) = true)

theorem identity35137 : scanCanonicalize (H12AffineFastState.compose env35137 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound35137 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env35138 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,8192,0,8460,8250,0,8379,4,8461,1,397,16,8234,8604,260,43,1,277,2097,8204,8477,257,261,1,789]

theorem envBound35138 : H12AffineFastState.Bounded env35138 := by
  intro p hp
  have h : env35138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35137_35138 : H12AffineEnvironment.transform 11 0 env35137 = env35138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env35137 == env35138) = true)

theorem identity35138 : scanCanonicalize (H12AffineFastState.compose env35138 (packedSelected [0,2,5,7,8,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 2876) := by decide +kernel

theorem selectedBound35138 : packedSelected [0,2,5,7,8,17,18] rootPS < 2^1333 := by decide +kernel

def env35139 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,2876,0,2608,2822,0,2951,4,2609,1,397,16,2838,2720,260,43,1,277,2097,2864,2593,257,261,1,789]

theorem envBound35139 : H12AffineFastState.Bounded env35139 := by
  intro p hp
  have h : env35139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35138_35139 : H12AffineEnvironment.transform 12 2876 env35138 = env35139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2876 env35138 == env35139) = true)

theorem identity35139 : scanCanonicalize (H12AffineFastState.compose env35139 (packedSelected [3,8,10,13,17,19] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound35139 : packedSelected [3,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env35140 : List Nat := [2,4,8,16,32,17,128,172,512,189,2048,0,2704,0,2608,2730,0,2603,4,2609,1,33,16,2746,2720,168,43,1,185,2097,2716,2593,173,169,1,697]

theorem envBound35140 : H12AffineFastState.Bounded env35140 := by
  intro p hp
  have h : env35140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35139_35140 : H12AffineEnvironment.transform 7 172 env35139 = env35140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env35139 == env35140) = true)

theorem identity35140 : scanCanonicalize (H12AffineFastState.compose env35140 (packedSelected [1,3,13] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound35140 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env35141 : List Nat := [2,4,8,16,32,17,128,172,512,189,146,0,514,0,674,568,0,697,4,675,1,33,16,552,562,168,43,1,185,163,526,691,173,169,1,697]

theorem envBound35141 : H12AffineFastState.Bounded env35141 := by
  intro p hp
  have h : env35141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35140_35141 : H12AffineEnvironment.transform 10 146 env35140 = env35141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env35140 == env35141) = true)

theorem identity35141 : scanCanonicalize (H12AffineFastState.compose env35141 (packedSelected [4,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound35141 : packedSelected [4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env35142 : List Nat := [2,4,8,16,11,17,128,135,512,150,146,0,514,0,649,531,0,658,4,648,1,10,16,515,537,131,0,1,146,136,526,664,134,130,1,658]

theorem envBound35142 : H12AffineFastState.Bounded env35142 := by
  intro p hp
  have h : env35142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35141_35142 : H12AffineEnvironment.transform 4 11 env35141 = env35142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env35141 == env35142) = true)

theorem identity35142 : scanCanonicalize (H12AffineFastState.compose env35142 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound35142 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env35143 : List Nat := [2,4,8,10,11,11,128,135,512,140,136,0,514,0,649,521,0,648,4,648,1,10,10,515,515,131,0,1,136,136,526,642,134,130,1,648]

theorem envBound35143 : H12AffineFastState.Bounded env35143 := by
  intro p hp
  have h : env35143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35142_35143 : H12AffineEnvironment.transform 3 10 env35142 = env35143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env35142 == env35143) = true)

theorem identity35143 : scanCanonicalize (H12AffineFastState.compose env35143 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35143 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35144 : List Nat := [2,4,8,10,11,11,9,14,512,5,1,0,514,0,512,521,0,513,4,513,1,10,10,515,515,10,0,1,1,1,526,523,15,11,1,513]

theorem envBound35144 : H12AffineFastState.Bounded env35144 := by
  intro p hp
  have h : env35144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35143_35144 : H12AffineEnvironment.transform 6 9 env35143 = env35144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35143 == env35144) = true)

theorem identity35144 : scanCanonicalize (H12AffineFastState.compose env35144 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound35144 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env35145 : List Nat := [2,4,8,10,11,11,9,14,8,5,1,0,10,0,8,1,0,9,4,9,1,10,10,11,11,10,0,1,1,1,6,3,15,11,1,9]

theorem envBound35145 : H12AffineFastState.Bounded env35145 := by
  intro p hp
  have h : env35145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35144_35145 : H12AffineEnvironment.transform 8 8 env35144 = env35145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env35144 == env35145) = true)

theorem identity35145 : scanCanonicalize (H12AffineFastState.compose env35145 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound35145 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35146 : List Nat := [2,4,1,3,2,2,0,7,1,5,1,0,3,0,1,1,0,0,4,0,1,3,3,2,2,3,0,1,1,1,6,3,6,2,1,0]

theorem envBound35146 : H12AffineFastState.Bounded env35146 := by
  intro p hp
  have h : env35146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35145_35146 : H12AffineEnvironment.transform 2 1 env35145 = env35146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env35145 == env35146) = true)

theorem identity35146 : scanCanonicalize (H12AffineFastState.compose env35146 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound35146 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35147 : List Nat := [2,2,1,3,2,2,0,1,1,3,1,0,3,0,1,1,0,0,2,0,1,3,3,2,2,3,0,1,1,1,0,3,0,2,1,0]

theorem envBound35147 : H12AffineFastState.Bounded env35147 := by
  intro p hp
  have h : env35147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35146_35147 : H12AffineEnvironment.transform 1 2 env35146 = env35147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env35146 == env35147) = true)

theorem identity35147 : scanCanonicalize (H12AffineFastState.compose env35147 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound35147 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env35148 : List Nat := [1,1,1,0,1,1,0,1,1,0,1,0,0,0,1,1,0,0,1,0,1,0,0,1,1,0,0,1,1,1,0,0,0,1,1,0]

theorem envBound35148 : H12AffineFastState.Bounded env35148 := by
  intro p hp
  have h : env35148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35147_35148 : H12AffineEnvironment.transform 0 1 env35147 = env35148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env35147 == env35148) = true)

def env35149 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147521,284033,86519,209263,225345,148801,74814,96346,381312,323755,257,74798,1345,95102]

theorem envBound35149 : H12AffineFastState.Bounded env35149 := by
  intro p hp
  have h : env35149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35011_35149 : H12AffineEnvironment.transform 23 284033 env35011 = env35149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env35011 == env35149) = true)

def env35150 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95614,32769,4097,61648,17,284033,86519,94527,77841,1297,74814,96346,381312,323755,257,74798,1345,95102]

theorem envBound35150 : H12AffineFastState.Bounded env35150 := by
  intro p hp
  have h : env35150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35149_35150 : H12AffineEnvironment.transform 16 16464 env35149 = env35150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env35149 == env35150) = true)

def env35151 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77934,32769,4097,46528,17,266385,70887,78895,77841,1297,74814,81226,365712,308667,257,74798,1345,79470]

theorem envBound35151 : H12AffineFastState.Bounded env35151 := by
  intro p hp
  have h : env35151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35150_35151 : H12AffineEnvironment.transform 13 1296 env35150 = env35151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env35150 == env35151) = true)

theorem identity35151 : scanCanonicalize (H12AffineFastState.compose env35151 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound35151 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env35152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,262144,77934,13340,4097,477,17,266385,70887,78895,77841,1297,74814,81226,336013,262566,257,74798,1345,79470]

theorem envBound35152 : H12AffineFastState.Bounded env35152 := by
  intro p hp
  have h : env35152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35151_35152 : H12AffineEnvironment.transform 14 13341 env35151 = env35152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env35151 == env35152) = true)

def env35153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65664,77934,13340,4097,477,17,69649,70887,78895,77841,1297,74814,81226,8205,65830,257,74798,1345,79470]

theorem envBound35153 : H12AffineFastState.Bounded env35153 := by
  intro p hp
  have h : env35153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35152_35153 : H12AffineEnvironment.transform 17 65664 env35152 = env35153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env35152 == env35153) = true)

theorem identity35153 : scanCanonicalize (H12AffineFastState.compose env35153 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 358) := by decide +kernel

theorem selectedBound35153 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,358,1344,486,12552,13340,4097,477,17,4471,5505,13641,12663,1297,9560,15404,8205,64,257,9544,1345,14088]

theorem envBound35154 : H12AffineFastState.Bounded env35154 := by
  intro p hp
  have h : env35154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35153_35154 : H12AffineEnvironment.transform 15 358 env35153 = env35154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 358 env35153 == env35154) = true)

def env35155 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1296,13341,310,1296,438,12552,13340,4097,397,17,4391,5505,13593,12583,1297,9480,15404,8205,16,257,9496,1297,14088]

theorem envBound35155 : H12AffineFastState.Bounded env35155 := by
  intro p hp
  have h : env35155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35154_35155 : H12AffineEnvironment.transform 5 16 env35154 = env35155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35154 == env35155) = true)

theorem identity35155 : scanCanonicalize (H12AffineFastState.compose env35155 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4365) := by decide +kernel

theorem selectedBound35155 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35156 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,4365,1296,1296,310,1296,438,5,1297,4097,397,17,4391,5505,1044,42,1297,5125,3361,4352,16,257,5141,1297,1541]

theorem envBound35156 : H12AffineFastState.Bounded env35156 := by
  intro p hp
  have h : env35156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35155_35156 : H12AffineEnvironment.transform 12 4365 env35155 = env35156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4365 env35155 == env35156) = true)

theorem identity35156 : scanCanonicalize (H12AffineFastState.compose env35156 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound35156 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env35157 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,277,24,1296,1296,310,1296,438,5,1297,276,397,17,50,1172,1044,42,1297,1296,3361,21,16,257,1280,1297,1541]

theorem envBound35157 : H12AffineFastState.Bounded env35157 := by
  intro p hp
  have h : env35157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35156_35157 : H12AffineEnvironment.transform 11 277 env35156 = env35157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env35156 == env35157) = true)

theorem identity35157 : scanCanonicalize (H12AffineFastState.compose env35157 (packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound35157 : packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env35158 : List Nat := [2,4,8,16,32,16,128,256,163,1024,2048,277,24,1296,1296,310,1296,438,5,1297,276,397,17,50,1172,1044,42,1297,1296,3361,21,16,257,1280,1297,1190]

theorem envBound35158 : H12AffineFastState.Bounded env35158 := by
  intro p hp
  have h : env35158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35157_35158 : H12AffineEnvironment.transform 8 163 env35157 = env35158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env35157 == env35158) = true)

theorem identity35158 : scanCanonicalize (H12AffineFastState.compose env35158 (packedSelected [1,2,8,11,12,13,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1029) := by decide +kernel

theorem selectedBound35158 : packedSelected [1,2,8,11,12,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env35159 : List Nat := [2,4,8,16,32,16,128,256,163,1024,1029,277,24,1296,1296,310,1296,438,5,1297,276,397,17,50,1172,1044,42,1297,1296,292,21,16,257,1280,1297,1190]

theorem envBound35159 : H12AffineFastState.Bounded env35159 := by
  intro p hp
  have h : env35159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35158_35159 : H12AffineEnvironment.transform 10 1029 env35158 = env35159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1029 env35158 == env35159) = true)

theorem identity35159 : scanCanonicalize (H12AffineFastState.compose env35159 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound35159 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env35160 : List Nat := [2,4,8,16,16,16,128,256,147,1024,1029,277,24,1296,1296,262,1296,390,5,1297,276,397,17,2,1172,1044,26,1297,1296,276,21,16,257,1280,1297,1174]

theorem envBound35160 : H12AffineFastState.Bounded env35160 := by
  intro p hp
  have h : env35160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35159_35160 : H12AffineEnvironment.transform 4 16 env35159 = env35160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env35159 == env35160) = true)

theorem identity35160 : scanCanonicalize (H12AffineFastState.compose env35160 (packedSelected [1,4,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound35160 : packedSelected [1,4,8,9] rootPS < 2^1333 := by decide +kernel

def env35161 : List Nat := [2,4,8,16,16,16,128,20,147,1024,1029,1,24,1028,1028,18,1028,146,5,1029,0,153,17,2,1172,1044,26,1029,1028,0,21,16,21,1044,1029,1174]

theorem envBound35161 : H12AffineFastState.Bounded env35161 := by
  intro p hp
  have h : env35161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35160_35161 : H12AffineEnvironment.transform 7 20 env35160 = env35161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env35160 == env35161) = true)

theorem identity35161 : scanCanonicalize (H12AffineFastState.compose env35161 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35161 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env35162 : List Nat := [2,4,8,16,16,16,9,20,26,1024,1029,1,24,1028,1028,18,1028,27,5,1029,0,16,17,2,1053,1044,26,1029,1028,0,21,16,21,1044,1029,1055]

theorem envBound35162 : H12AffineFastState.Bounded env35162 := by
  intro p hp
  have h : env35162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35161_35162 : H12AffineEnvironment.transform 6 9 env35161 = env35162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35161 == env35162) = true)

theorem identity35162 : scanCanonicalize (H12AffineFastState.compose env35162 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound35162 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35163 : List Nat := [2,4,8,16,16,16,9,20,26,31,26,1,24,27,27,18,27,27,5,26,0,16,17,2,2,11,26,26,27,0,21,16,21,11,26,0]

theorem envBound35163 : H12AffineFastState.Bounded env35163 := by
  intro p hp
  have h : env35163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35162_35163 : H12AffineEnvironment.transform 9 31 env35162 = env35163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env35162 == env35163) = true)

theorem identity35163 : scanCanonicalize (H12AffineFastState.compose env35163 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound35163 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env35164 : List Nat := [2,3,8,16,16,16,9,19,26,24,26,1,24,27,27,18,27,27,2,26,0,16,17,2,2,11,26,26,27,0,18,16,18,11,26,0]

theorem envBound35164 : H12AffineFastState.Bounded env35164 := by
  intro p hp
  have h : env35164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35163_35164 : H12AffineEnvironment.transform 1 3 env35163 = env35164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env35163 == env35164) = true)

def env35165 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1296,13341,311,1297,439,12552,13340,4097,396,17,4390,5505,13592,12582,1297,9481,15404,8205,17,257,9497,1296,14088]

theorem envBound35165 : H12AffineFastState.Bounded env35165 := by
  intro p hp
  have h : env35165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35154_35165 : H12AffineEnvironment.transform 5 17 env35154 = env35165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35154 == env35165) = true)

theorem identity35165 : scanCanonicalize (H12AffineFastState.compose env35165 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound35165 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35166 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,4096,8192,276,12313,311,277,439,12552,12312,4097,396,17,4390,4485,12572,12582,277,8461,14376,8205,17,257,8477,276,13068]

theorem envBound35166 : H12AffineFastState.Bounded env35166 := by
  intro p hp
  have h : env35166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35165_35166 : H12AffineEnvironment.transform 9 4 env35165 = env35166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env35165 == env35166) = true)

theorem identity35166 : scanCanonicalize (H12AffineFastState.compose env35166 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound35166 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env35167 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,276,8192,276,8461,311,277,439,8220,8460,277,396,17,50,145,8200,8242,277,8461,10556,8205,17,257,8477,276,8728]

theorem envBound35167 : H12AffineFastState.Bounded env35167 := by
  intro p hp
  have h : env35167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35166_35167 : H12AffineEnvironment.transform 11 276 env35166 = env35167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env35166 == env35167) = true)

theorem identity35167 : scanCanonicalize (H12AffineFastState.compose env35167 (packedSelected [0,1,2,3,7,10,13,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 185) := by decide +kernel

theorem selectedBound35167 : packedSelected [0,1,2,3,7,10,13,18,19] rootPS < 2^1333 := by decide +kernel

def env35168 : List Nat := [2,4,8,16,32,17,128,256,185,4,2048,276,8192,276,8461,311,277,439,8220,8460,277,396,17,50,145,8200,8242,277,8461,10556,8205,17,257,8477,276,8353]

theorem envBound35168 : H12AffineFastState.Bounded env35168 := by
  intro p hp
  have h : env35168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35167_35168 : H12AffineEnvironment.transform 8 185 env35167 = env35168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 185 env35167 == env35168) = true)

theorem identity35168 : scanCanonicalize (H12AffineFastState.compose env35168 (packedSelected [3,5,11,12,13,15,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound35168 : packedSelected [3,5,11,12,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env35169 : List Nat := [2,4,8,16,32,17,128,256,185,4,2048,276,2317,276,2048,311,277,439,2321,2049,277,396,17,50,145,2309,2367,277,2048,49,2304,17,257,2064,276,2476]

theorem envBound35169 : H12AffineFastState.Bounded env35169 := by
  intro p hp
  have h : env35169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35168_35169 : H12AffineEnvironment.transform 12 2317 env35168 = env35169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env35168 == env35169) = true)

theorem identity35169 : scanCanonicalize (H12AffineFastState.compose env35169 (packedSelected [1,2,3,10,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 271) := by decide +kernel

theorem selectedBound35169 : packedSelected [1,2,3,10,12,13] rootPS < 2^1333 := by decide +kernel

def env35170 : List Nat := [2,4,8,16,32,17,128,256,185,4,271,276,2,276,271,311,277,439,30,270,277,396,17,50,145,10,48,277,271,49,15,17,257,287,276,163]

theorem envBound35170 : H12AffineFastState.Bounded env35170 := by
  intro p hp
  have h : env35170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35169_35170 : H12AffineEnvironment.transform 10 271 env35169 = env35170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 271 env35169 == env35170) = true)

theorem identity35170 : scanCanonicalize (H12AffineFastState.compose env35170 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound35170 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env35171 : List Nat := [2,4,8,16,10,17,128,256,147,4,271,276,2,276,271,285,277,413,30,270,277,396,17,24,145,10,26,277,271,27,15,17,257,287,276,137]

theorem envBound35171 : H12AffineFastState.Bounded env35171 := by
  intro p hp
  have h : env35171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35170_35171 : H12AffineEnvironment.transform 4 10 env35170 = env35171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env35170 == env35171) = true)

theorem identity35171 : scanCanonicalize (H12AffineFastState.compose env35171 (packedSelected [1,2,8] rootPS)) = affineNative (2^(7+1) ^^^ 135) := by decide +kernel

theorem selectedBound35171 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env35172 : List Nat := [2,4,8,16,10,17,128,135,147,4,136,147,2,147,136,154,146,26,30,137,146,11,17,24,145,10,26,146,136,27,15,17,134,152,147,137]

theorem envBound35172 : H12AffineFastState.Bounded env35172 := by
  intro p hp
  have h : env35172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35171_35172 : H12AffineEnvironment.transform 7 135 env35171 = env35172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 135 env35171 == env35172) = true)

theorem identity35172 : scanCanonicalize (H12AffineFastState.compose env35172 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound35172 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35173 : List Nat := [2,4,8,16,10,17,19,20,0,4,27,0,2,0,27,9,1,26,30,26,1,11,17,24,2,10,26,1,27,27,15,17,21,11,0,26]

theorem envBound35173 : H12AffineFastState.Bounded env35173 := by
  intro p hp
  have h : env35173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35172_35173 : H12AffineEnvironment.transform 6 19 env35172 = env35173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env35172 == env35173) = true)

theorem identity35173 : scanCanonicalize (H12AffineFastState.compose env35173 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound35173 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35174 : List Nat := [2,4,8,10,10,11,9,14,0,4,1,0,2,0,1,9,1,0,4,0,1,11,11,2,2,10,0,1,1,1,15,11,15,11,0,0]

theorem envBound35174 : H12AffineFastState.Bounded env35174 := by
  intro p hp
  have h : env35174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35173_35174 : H12AffineEnvironment.transform 3 10 env35173 = env35174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env35173 == env35174) = true)

theorem identity35174 : scanCanonicalize (H12AffineFastState.compose env35174 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound35174 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35175 : List Nat := [2,4,5,7,7,6,4,3,0,4,1,0,2,0,1,4,1,0,4,0,1,6,6,2,2,7,0,1,1,1,2,6,2,6,0,0]

theorem envBound35175 : H12AffineFastState.Bounded env35175 := by
  intro p hp
  have h : env35175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35174_35175 : H12AffineEnvironment.transform 2 5 env35174 = env35175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env35174 == env35175) = true)

def env35176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65665,77934,13340,4097,477,17,69648,70887,78895,77841,1297,74814,81226,8204,65831,257,74798,1345,79470]

theorem envBound35176 : H12AffineFastState.Bounded env35176 := by
  intro p hp
  have h : env35176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35152_35176 : H12AffineEnvironment.transform 17 65665 env35152 = env35176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env35152 == env35176) = true)

theorem identity35176 : scanCanonicalize (H12AffineFastState.compose env35176 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5158) := by decide +kernel

theorem selectedBound35176 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,5158,1344,5287,9288,13340,4097,477,17,1078,193,8201,9271,1297,12312,10604,8204,5377,257,12296,1345,8776]

theorem envBound35177 : H12AffineFastState.Bounded env35177 := by
  intro p hp
  have h : env35177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35176_35177 : H12AffineEnvironment.transform 15 5158 env35176 = env35177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5158 env35176 == env35177) = true)

def env35178 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1296,13341,5158,1296,5287,9240,13340,4097,397,17,1078,145,8201,9271,1297,12312,10556,8204,5377,257,12296,1297,8728]

theorem envBound35178 : H12AffineFastState.Bounded env35178 := by
  intro p hp
  have h : env35178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35177_35178 : H12AffineEnvironment.transform 5 16 env35177 = env35178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35177 == env35178) = true)

theorem identity35178 : scanCanonicalize (H12AffineFastState.compose env35178 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound35178 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35179 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1053,1296,4096,5158,1296,5287,5,4097,4097,397,17,1078,145,1044,42,1297,5125,3361,1041,5377,257,5141,1297,1541]

theorem envBound35179 : H12AffineFastState.Bounded env35179 := by
  intro p hp
  have h : env35179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35178_35179 : H12AffineEnvironment.transform 12 1053 env35178 = env35179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env35178 == env35179) = true)

theorem identity35179 : scanCanonicalize (H12AffineFastState.compose env35179 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound35179 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env35180 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,1053,1296,1296,310,1296,439,5,1297,1297,397,17,1078,145,1044,42,1297,277,3361,1041,17,257,261,1297,1541]

theorem envBound35180 : H12AffineFastState.Bounded env35180 := by
  intro p hp
  have h : env35180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35179_35180 : H12AffineEnvironment.transform 11 1296 env35179 = env35180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env35179 == env35180) = true)

theorem identity35180 : scanCanonicalize (H12AffineFastState.compose env35180 (packedSelected [0,1,3,7,10,11,13,19] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound35180 : packedSelected [0,1,3,7,10,11,13,19] rootPS < 2^1333 := by decide +kernel

def env35181 : List Nat := [2,4,8,16,32,16,128,256,293,1024,2048,1296,1053,1296,1296,310,1296,439,5,1297,1297,397,17,1078,145,1044,42,1297,277,3361,1041,17,257,261,1297,1312]

theorem envBound35181 : H12AffineFastState.Bounded env35181 := by
  intro p hp
  have h : env35181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35180_35181 : H12AffineEnvironment.transform 8 293 env35180 = env35181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env35180 == env35181) = true)

theorem identity35181 : scanCanonicalize (H12AffineFastState.compose env35181 (packedSelected [0,1,2,5,7,11,12,15,17] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound35181 : packedSelected [0,1,2,5,7,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env35182 : List Nat := [2,4,8,16,32,16,128,256,293,272,2048,0,269,0,0,310,0,439,5,1,1,397,17,294,145,260,42,1,277,2097,257,17,257,261,1,48]

theorem envBound35182 : H12AffineFastState.Bounded env35182 := by
  intro p hp
  have h : env35182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35181_35182 : H12AffineEnvironment.transform 9 272 env35181 = env35182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env35181 == env35182) = true)

theorem identity35182 : scanCanonicalize (H12AffineFastState.compose env35182 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 185) := by decide +kernel

theorem selectedBound35182 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env35183 : List Nat := [2,4,8,16,32,16,128,256,293,272,185,0,269,0,0,310,0,439,5,1,1,397,17,294,145,260,42,1,277,136,257,17,257,261,1,48]

theorem envBound35183 : H12AffineFastState.Bounded env35183 := by
  intro p hp
  have h : env35183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35182_35183 : H12AffineEnvironment.transform 10 185 env35182 = env35183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 185 env35182 == env35183) = true)

theorem identity35183 : scanCanonicalize (H12AffineFastState.compose env35183 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound35183 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env35184 : List Nat := [2,4,8,16,32,16,128,21,48,5,185,0,24,0,0,35,0,162,5,1,1,152,17,51,145,17,42,1,0,136,20,17,20,16,1,48]

theorem envBound35184 : H12AffineFastState.Bounded env35184 := by
  intro p hp
  have h : env35184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35183_35184 : H12AffineEnvironment.transform 7 21 env35183 = env35184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env35183 == env35184) = true)

theorem identity35184 : scanCanonicalize (H12AffineFastState.compose env35184 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound35184 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35185 : List Nat := [2,4,8,16,32,16,15,21,48,5,54,0,24,0,0,35,0,45,5,1,1,23,17,51,30,17,42,1,0,7,20,17,20,16,1,48]

theorem envBound35185 : H12AffineFastState.Bounded env35185 := by
  intro p hp
  have h : env35185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35184_35185 : H12AffineEnvironment.transform 6 15 env35184 = env35185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env35184 == env35185) = true)

theorem identity35185 : scanCanonicalize (H12AffineFastState.compose env35185 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound35185 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env35186 : List Nat := [2,2,8,16,32,16,9,19,48,3,48,0,24,0,0,35,0,43,3,1,1,17,17,51,24,17,42,1,0,1,18,17,18,16,1,48]

theorem envBound35186 : H12AffineFastState.Bounded env35186 := by
  intro p hp
  have h : env35186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35185_35186 : H12AffineEnvironment.transform 1 2 env35185 = env35186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env35185 == env35186) = true)

theorem identity35186 : scanCanonicalize (H12AffineFastState.compose env35186 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound35186 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35187 : List Nat := [2,2,8,16,10,16,9,19,26,3,26,0,24,0,0,9,0,1,3,1,1,17,17,25,24,17,0,1,0,1,18,17,18,16,1,26]

theorem envBound35187 : H12AffineFastState.Bounded env35187 := by
  intro p hp
  have h : env35187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35186_35187 : H12AffineEnvironment.transform 4 10 env35186 = env35187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env35186 == env35187) = true)

theorem identity35187 : scanCanonicalize (H12AffineFastState.compose env35187 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound35187 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env35188 : List Nat := [2,2,8,11,10,11,9,8,1,3,1,0,3,0,0,9,0,1,3,1,1,10,10,2,3,10,0,1,0,1,9,10,9,11,1,1]

theorem envBound35188 : H12AffineFastState.Bounded env35188 := by
  intro p hp
  have h : env35188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35187_35188 : H12AffineEnvironment.transform 3 11 env35187 = env35188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env35187 == env35188) = true)

def env35189 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1296,13341,5158,1297,5287,9241,13340,4097,396,17,1078,144,8201,9271,1297,12312,10557,8204,5377,257,12296,1296,8729]

theorem envBound35189 : H12AffineFastState.Bounded env35189 := by
  intro p hp
  have h : env35189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35177_35189 : H12AffineEnvironment.transform 5 17 env35177 = env35189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35177 == env35189) = true)

theorem identity35189 : scanCanonicalize (H12AffineFastState.compose env35189 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound35189 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35190 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,4096,8192,276,12313,4130,277,4259,8221,12312,4097,396,17,50,144,8201,8243,277,12312,10557,8204,4357,257,12296,276,8729]

theorem envBound35190 : H12AffineFastState.Bounded env35190 := by
  intro p hp
  have h : env35190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35189_35190 : H12AffineEnvironment.transform 9 4 env35189 = env35190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env35189 == env35190) = true)

theorem identity35190 : scanCanonicalize (H12AffineFastState.compose env35190 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 4365) := by decide +kernel

theorem selectedBound35190 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env35191 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,4096,4365,276,276,4130,277,4259,4368,277,4097,396,17,50,144,4356,4414,277,277,6192,4353,4357,257,261,276,4884]

theorem envBound35191 : H12AffineFastState.Bounded env35191 := by
  intro p hp
  have h : env35191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35190_35191 : H12AffineEnvironment.transform 12 4365 env35190 = env35191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4365 env35190 == env35191) = true)

theorem identity35191 : scanCanonicalize (H12AffineFastState.compose env35191 (packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound35191 : packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env35192 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,136,389,276,276,170,277,43,408,277,137,396,17,50,144,396,438,277,277,2232,393,397,257,261,276,924]

theorem envBound35192 : H12AffineFastState.Bounded env35192 := by
  intro p hp
  have h : env35192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35191_35192 : H12AffineEnvironment.transform 11 136 env35191 = env35192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env35191 == env35192) = true)

theorem identity35192 : scanCanonicalize (H12AffineFastState.compose env35192 (packedSelected [2,13] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound35192 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env35193 : List Nat := [2,4,8,16,32,17,128,256,512,4,512,136,389,276,276,170,277,43,408,277,137,396,17,50,144,396,438,277,277,696,393,397,257,261,276,924]

theorem envBound35193 : H12AffineFastState.Bounded env35193 := by
  intro p hp
  have h : env35193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35192_35193 : H12AffineEnvironment.transform 10 512 env35192 = env35193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env35192 == env35193) = true)

theorem identity35193 : scanCanonicalize (H12AffineFastState.compose env35193 (packedSelected [1,5,12,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound35193 : packedSelected [1,5,12,15,17] rootPS < 2^1333 := by decide +kernel

def env35194 : List Nat := [2,4,8,16,32,17,128,62,512,4,512,136,187,42,42,170,43,43,166,43,137,178,17,50,144,178,136,43,43,696,183,179,63,59,42,674]

theorem envBound35194 : H12AffineFastState.Bounded env35194 := by
  intro p hp
  have h : env35194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35193_35194 : H12AffineEnvironment.transform 7 62 env35193 = env35194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env35193 == env35194) = true)

theorem identity35194 : scanCanonicalize (H12AffineFastState.compose env35194 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound35194 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env35195 : List Nat := [2,4,8,16,17,17,128,15,512,4,512,136,138,27,27,155,26,26,151,26,137,131,17,3,144,131,136,26,26,649,134,130,14,10,27,659]

theorem envBound35195 : H12AffineFastState.Bounded env35195 := by
  intro p hp
  have h : env35195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35194_35195 : H12AffineEnvironment.transform 4 17 env35194 = env35195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env35194 == env35195) = true)

theorem identity35195 : scanCanonicalize (H12AffineFastState.compose env35195 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound35195 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env35196 : List Nat := [2,4,8,16,17,17,19,15,512,4,512,27,25,27,27,8,26,26,4,26,26,16,17,3,3,16,27,26,26,538,21,17,14,10,27,512]

theorem envBound35196 : H12AffineFastState.Bounded env35196 := by
  intro p hp
  have h : env35196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35195_35196 : H12AffineEnvironment.transform 6 19 env35195 = env35196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env35195 == env35196) = true)

def env35197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77935,32769,4097,46529,17,266384,70886,78894,77841,1297,74814,81227,365713,308666,257,74798,1345,79471]

theorem envBound35197 : H12AffineFastState.Bounded env35197 := by
  intro p hp
  have h : env35197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35150_35197 : H12AffineEnvironment.transform 13 1297 env35150 = env35197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env35150 == env35197) = true)

theorem identity35197 : scanCanonicalize (H12AffineFastState.compose env35197 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound35197 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env35198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1345,262144,45084,32769,4097,46529,17,266384,38037,46173,45154,1297,42061,48440,267490,308666,257,42077,1345,46620]

theorem envBound35198 : H12AffineFastState.Bounded env35198 := by
  intro p hp
  have h : env35198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35197_35198 : H12AffineEnvironment.transform 15 32883 env35197 = env35198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env35197 == env35198) = true)

def env35199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1345,262144,42332,32769,1345,41089,17,263632,33237,41245,42274,1297,42061,43128,262562,303354,257,42077,1345,41820]

theorem envBound35199 : H12AffineFastState.Bounded env35199 := by
  intro p hp
  have h : env35199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35198_35199 : H12AffineEnvironment.transform 11 1344 env35198 = env35199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env35198 == env35199) = true)

theorem identity35199 : scanCanonicalize (H12AffineFastState.compose env35199 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 34227) := by decide +kernel

theorem selectedBound35199 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35200 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1345,34227,42332,32769,1345,41089,17,32867,33237,41245,42274,1297,42061,43128,33809,9545,257,42077,1345,41820]

theorem envBound35200 : H12AffineFastState.Bounded env35200 := by
  intro p hp
  have h : env35200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35199_35200 : H12AffineEnvironment.transform 17 34227 env35199 = env35200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34227 env35199 == env35200) = true)

theorem identity35200 : scanCanonicalize (H12AffineFastState.compose env35200 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 608) := by decide +kernel

theorem selectedBound35200 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env35201 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,608,531,1345,2003,10044,609,1345,8929,17,515,949,9085,10050,1297,9773,10776,1649,9545,257,9789,1345,8508]

theorem envBound35201 : H12AffineFastState.Bounded env35201 := by
  intro p hp
  have h : env35201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35200_35201 : H12AffineEnvironment.transform 14 608 env35200 = env35201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 608 env35200 == env35201) = true)

def env35202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1345,262144,42333,32769,1344,41088,17,263633,33236,41244,42275,1297,42061,43129,262563,303355,257,42077,1345,41821]

theorem envBound35202 : H12AffineFastState.Bounded env35202 := by
  intro p hp
  have h : env35202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35198_35202 : H12AffineEnvironment.transform 11 1345 env35198 = env35202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env35198 == env35202) = true)

theorem identity35202 : scanCanonicalize (H12AffineFastState.compose env35202 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound35202 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35203 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,81,32768,32883,1,262144,40989,32769,0,41088,17,262289,33236,41244,41059,81,41229,43129,262563,303355,257,41245,1,41821]

theorem envBound35203 : H12AffineFastState.Bounded env35203 := by
  intro p hp
  have h : env35203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35202_35203 : H12AffineEnvironment.transform 9 320 env35202 = env35203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env35202 == env35203) = true)

theorem identity35203 : scanCanonicalize (H12AffineFastState.compose env35203 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound35203 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env35204 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,81,8541,8494,1,262144,320,8540,0,477,17,262289,8329,65,318,81,80,2340,262563,262566,257,64,1,512]

theorem envBound35204 : H12AffineFastState.Bounded env35204 := by
  intro p hp
  have h : env35204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35203_35204 : H12AffineEnvironment.transform 14 8541 env35203 = env35204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env35203 == env35204) = true)

theorem identity35204 : scanCanonicalize (H12AffineFastState.compose env35204 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound35204 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35205 : List Nat := [2,4,8,16,32,64,128,20,512,84,2048,1,8192,81,8265,8250,1,262144,84,8264,0,201,17,262289,8329,65,42,81,80,2096,262327,262322,21,64,1,512]

theorem envBound35205 : H12AffineFastState.Bounded env35205 := by
  intro p hp
  have h : env35205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35204_35205 : H12AffineEnvironment.transform 7 20 env35204 = env35205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env35204 == env35205) = true)

theorem identity35205 : scanCanonicalize (H12AffineFastState.compose env35205 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound35205 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35206 : List Nat := [2,4,8,16,32,64,128,20,512,84,2048,1,656,81,729,682,1,262144,84,728,0,201,17,262289,537,65,42,81,80,2096,262327,262322,21,64,1,512]

theorem envBound35206 : H12AffineFastState.Bounded env35206 := by
  intro p hp
  have h : env35206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35205_35206 : H12AffineEnvironment.transform 12 656 env35205 = env35206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env35205 == env35206) = true)

theorem identity35206 : scanCanonicalize (H12AffineFastState.compose env35206 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35206 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env35207 : List Nat := [2,4,8,16,32,17,128,20,512,5,2048,1,656,0,648,682,1,262144,5,649,0,152,17,262289,537,16,42,0,1,2096,262327,262322,21,17,1,512]

theorem envBound35207 : H12AffineFastState.Bounded env35207 := by
  intro p hp
  have h : env35207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35206_35207 : H12AffineEnvironment.transform 5 17 env35206 = env35207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35206 == env35207) = true)

theorem identity35207 : scanCanonicalize (H12AffineFastState.compose env35207 (packedSelected [1,3,13] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound35207 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env35208 : List Nat := [2,4,8,16,32,17,128,20,512,5,42,1,656,0,648,682,1,262144,5,649,0,152,17,262289,537,16,42,0,1,26,262327,262322,21,17,1,512]

theorem envBound35208 : H12AffineFastState.Bounded env35208 := by
  intro p hp
  have h : env35208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35207_35208 : H12AffineEnvironment.transform 10 42 env35207 = env35208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env35207 == env35208) = true)

theorem identity35208 : scanCanonicalize (H12AffineFastState.compose env35208 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound35208 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env35209 : List Nat := [2,4,8,16,32,17,56,20,512,5,42,1,552,0,560,530,1,262144,5,561,0,32,17,262185,537,16,42,0,1,26,262159,262154,21,17,1,512]

theorem envBound35209 : H12AffineFastState.Bounded env35209 := by
  intro p hp
  have h : env35209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35208_35209 : H12AffineEnvironment.transform 6 56 env35208 = env35209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env35208 == env35209) = true)

theorem identity35209 : scanCanonicalize (H12AffineFastState.compose env35209 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound35209 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env35210 : List Nat := [2,4,8,16,32,17,56,20,49,5,42,1,25,0,1,35,1,262144,5,0,0,32,17,262185,40,16,42,0,1,26,262159,262154,21,17,1,49]

theorem envBound35210 : H12AffineFastState.Bounded env35210 := by
  intro p hp
  have h : env35210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35209_35210 : H12AffineEnvironment.transform 8 49 env35209 = env35210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env35209 == env35210) = true)

theorem identity35210 : scanCanonicalize (H12AffineFastState.compose env35210 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound35210 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35211 : List Nat := [2,4,8,16,11,17,19,20,26,5,1,1,25,0,1,8,1,262144,5,0,0,11,17,262146,3,16,1,0,1,26,262159,262154,21,17,1,26]

theorem envBound35211 : H12AffineFastState.Bounded env35211 := by
  intro p hp
  have h : env35211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35210_35211 : H12AffineEnvironment.transform 4 11 env35210 = env35211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env35210 == env35211) = true)

theorem identity35211 : scanCanonicalize (H12AffineFastState.compose env35211 (packedSelected [0,1] rootPS)) = affineNative (2^(17+1) ^^^ 1) := by decide +kernel

theorem selectedBound35211 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env35212 : List Nat := [2,4,8,16,11,17,19,20,26,5,1,1,25,0,1,8,1,1,5,0,0,11,17,3,3,16,1,0,1,26,14,11,21,17,1,26]

theorem envBound35212 : H12AffineFastState.Bounded env35212 := by
  intro p hp
  have h : env35212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35211_35212 : H12AffineEnvironment.transform 17 1 env35211 = env35212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env35211 == env35212) = true)

def env35213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95614,32769,4097,61648,16,284033,86519,94526,77840,1296,74814,96346,381312,323755,257,74798,1345,95102]

theorem envBound35213 : H12AffineFastState.Bounded env35213 := by
  intro p hp
  have h : env35213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35149_35213 : H12AffineEnvironment.transform 16 16465 env35149 = env35213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env35149 == env35213) = true)

def env35214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77934,32769,4097,46528,16,266385,70887,78894,77840,1296,74814,81226,365712,308667,257,74798,1345,79470]

theorem envBound35214 : H12AffineFastState.Bounded env35214 := by
  intro p hp
  have h : env35214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35213_35214 : H12AffineEnvironment.transform 13 1296 env35213 = env35214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env35213 == env35214) = true)

theorem identity35214 : scanCanonicalize (H12AffineFastState.compose env35214 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound35214 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env35215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1345,262144,45084,32769,4097,46528,16,266385,38037,46172,45154,1296,42060,48440,267490,308667,257,42076,1345,46620]

theorem envBound35215 : H12AffineFastState.Bounded env35215 := by
  intro p hp
  have h : env35215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35214_35215 : H12AffineEnvironment.transform 15 32882 env35214 = env35215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env35214 == env35215) = true)

def env35216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1345,262144,42332,32769,1345,41088,16,263633,33237,41244,42274,1296,42060,43128,262562,303355,257,42076,1345,41820]

theorem envBound35216 : H12AffineFastState.Bounded env35216 := by
  intro p hp
  have h : env35216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35215_35216 : H12AffineEnvironment.transform 11 1344 env35215 = env35216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env35215 == env35216) = true)

theorem identity35216 : scanCanonicalize (H12AffineFastState.compose env35216 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 486) := by decide +kernel

theorem selectedBound35216 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1345,486,42332,32769,1345,41088,16,1079,33237,41244,42274,1296,42060,43128,68,41245,257,42076,1345,41820]

theorem envBound35217 : H12AffineFastState.Bounded env35217 := by
  intro p hp
  have h : env35217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35216_35217 : H12AffineEnvironment.transform 17 486 env35216 = env35217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 486 env35216 == env35217) = true)

theorem identity35217 : scanCanonicalize (H12AffineFastState.compose env35217 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound35217 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env35218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,8540,8494,1345,486,1024,8541,1345,476,16,1079,8329,64,1150,1296,1296,2340,68,65,257,1280,1345,512]

theorem envBound35218 : H12AffineFastState.Bounded env35218 := by
  intro p hp
  have h : env35218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35217_35218 : H12AffineEnvironment.transform 14 8540 env35217 = env35218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env35217 == env35218) = true)

theorem identity35218 : scanCanonicalize (H12AffineFastState.compose env35218 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound35218 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35219 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,276,8192,324,8540,8494,277,486,84,8541,277,476,16,99,8329,64,42,324,324,2340,68,65,257,340,277,512]

theorem envBound35219 : H12AffineFastState.Bounded env35219 := by
  intro p hp
  have h : env35219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35218_35219 : H12AffineEnvironment.transform 9 84 env35218 = env35219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env35218 == env35219) = true)

theorem identity35219 : scanCanonicalize (H12AffineFastState.compose env35219 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 901) := by decide +kernel

theorem selectedBound35219 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35220 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,276,901,324,729,683,277,486,84,728,277,476,16,99,780,64,42,324,324,2340,68,65,257,340,277,512]

theorem envBound35220 : H12AffineFastState.Bounded env35220 := by
  intro p hp
  have h : env35220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35219_35220 : H12AffineEnvironment.transform 12 901 env35219 = env35220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 901 env35219 == env35220) = true)

theorem identity35220 : scanCanonicalize (H12AffineFastState.compose env35220 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35220 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env35221 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,276,901,277,648,683,277,439,5,649,277,397,16,50,780,17,42,277,277,2340,21,16,257,261,277,512]

theorem envBound35221 : H12AffineFastState.Bounded env35221 := by
  intro p hp
  have h : env35221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35220_35221 : H12AffineEnvironment.transform 5 17 env35220 = env35221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35220 == env35221) = true)

theorem identity35221 : scanCanonicalize (H12AffineFastState.compose env35221 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 391) := by decide +kernel

theorem selectedBound35221 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env35222 : List Nat := [2,4,8,16,32,17,128,256,512,5,391,276,901,277,648,683,277,439,5,649,277,397,16,50,780,17,42,277,277,163,21,16,257,261,277,512]

theorem envBound35222 : H12AffineFastState.Bounded env35222 := by
  intro p hp
  have h : env35222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35221_35222 : H12AffineEnvironment.transform 10 391 env35221 = env35222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 391 env35221 == env35222) = true)

theorem identity35222 : scanCanonicalize (H12AffineFastState.compose env35222 (packedSelected [0,1,2,5,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 135) := by decide +kernel

theorem selectedBound35222 : packedSelected [0,1,2,5,7,11] rootPS < 2^1333 := by decide +kernel

def env35223 : List Nat := [2,4,8,16,32,17,128,135,512,5,0,147,514,146,648,683,146,48,5,649,146,10,16,50,651,17,42,146,146,163,21,16,134,130,146,512]

theorem envBound35223 : H12AffineFastState.Bounded env35223 := by
  intro p hp
  have h : env35223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35222_35223 : H12AffineEnvironment.transform 7 135 env35222 = env35223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 135 env35222 == env35223) = true)

theorem identity35223 : scanCanonicalize (H12AffineFastState.compose env35223 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound35223 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env35224 : List Nat := [2,4,8,16,32,17,35,36,512,5,0,48,514,49,555,520,49,48,5,554,49,10,16,50,552,17,42,49,49,0,21,16,37,33,49,512]

theorem envBound35224 : H12AffineFastState.Bounded env35224 := by
  intro p hp
  have h : env35224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35223_35224 : H12AffineEnvironment.transform 6 35 env35223 = env35224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env35223 == env35224) = true)

theorem identity35224 : scanCanonicalize (H12AffineFastState.compose env35224 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound35224 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env35225 : List Nat := [2,4,8,16,32,17,35,36,1,5,0,48,3,49,42,9,49,48,5,43,49,10,16,50,41,17,42,49,49,0,21,16,37,33,49,1]

theorem envBound35225 : H12AffineFastState.Bounded env35225 := by
  intro p hp
  have h : env35225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35224_35225 : H12AffineEnvironment.transform 8 1 env35224 = env35225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env35224 == env35225) = true)

theorem identity35225 : scanCanonicalize (H12AffineFastState.compose env35225 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound35225 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35226 : List Nat := [2,4,8,16,17,17,18,21,1,5,0,1,3,0,27,9,0,1,5,26,0,10,16,3,24,17,27,0,0,0,21,16,20,16,0,1]

theorem envBound35226 : H12AffineFastState.Bounded env35226 := by
  intro p hp
  have h : env35226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35225_35226 : H12AffineEnvironment.transform 4 17 env35225 = env35226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env35225 == env35226) = true)

theorem identity35226 : scanCanonicalize (H12AffineFastState.compose env35226 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound35226 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35227 : List Nat := [2,3,8,16,17,17,18,18,1,2,0,1,3,0,27,9,0,1,2,26,0,10,16,3,24,17,27,0,0,0,18,16,19,16,0,1]

theorem envBound35227 : H12AffineFastState.Bounded env35227 := by
  intro p hp
  have h : env35227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35226_35227 : H12AffineEnvironment.transform 1 3 env35226 = env35227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env35226 == env35227) = true)

theorem identity35227 : scanCanonicalize (H12AffineFastState.compose env35227 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound35227 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35228 : List Nat := [2,3,8,11,10,10,9,9,1,2,0,1,3,0,0,9,0,1,2,1,0,10,11,3,3,10,0,0,0,0,9,11,8,11,0,1]

theorem envBound35228 : H12AffineFastState.Bounded env35228 := by
  intro p hp
  have h : env35228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35227_35228 : H12AffineEnvironment.transform 3 11 env35227 = env35228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env35227 == env35228) = true)

def env35229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1345,262144,42333,32769,1344,41089,16,263632,33236,41245,42275,1296,42060,43129,262563,303354,257,42076,1345,41821]

theorem envBound35229 : H12AffineFastState.Bounded env35229 := by
  intro p hp
  have h : env35229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35215_35229 : H12AffineEnvironment.transform 11 1345 env35215 = env35229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env35215 == env35229) = true)

theorem identity35229 : scanCanonicalize (H12AffineFastState.compose env35229 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 276) := by decide +kernel

theorem selectedBound35229 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,276,358,1345,262144,9289,277,1344,8597,16,263632,192,8201,9271,1296,9560,10605,262563,270830,257,9544,1345,8777]

theorem envBound35230 : H12AffineFastState.Bounded env35230 := by
  intro p hp
  have h : env35230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35229_35230 : H12AffineEnvironment.transform 14 276 env35229 = env35230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 276 env35229 == env35230) = true)

theorem identity35230 : scanCanonicalize (H12AffineFastState.compose env35230 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 2003) := by decide +kernel

theorem selectedBound35230 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env35231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,276,358,1345,2003,9289,277,1344,8597,16,515,192,8201,9271,1296,9560,10605,1648,9789,257,9544,1345,8777]

theorem envBound35231 : H12AffineFastState.Bounded env35231 := by
  intro p hp
  have h : env35231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35230_35231 : H12AffineEnvironment.transform 17 2003 env35230 = env35231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2003 env35230 == env35231) = true)

def env35232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77935,32769,4097,46529,16,266384,70886,78895,77840,1296,74814,81227,365713,308666,257,74798,1345,79471]

theorem envBound35232 : H12AffineFastState.Bounded env35232 := by
  intro p hp
  have h : env35232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35213_35232 : H12AffineEnvironment.transform 13 1297 env35213 = env35232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env35213 == env35232) = true)

theorem identity35232 : scanCanonicalize (H12AffineFastState.compose env35232 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound35232 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env35233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,262144,77935,13340,4097,476,16,266384,70886,78895,77840,1296,74814,81227,336012,262567,257,74798,1345,79471]

theorem envBound35233 : H12AffineFastState.Bounded env35233 := by
  intro p hp
  have h : env35233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35232_35233 : H12AffineEnvironment.transform 14 13341 env35232 = env35233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env35232 == env35233) = true)

def env35234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65664,77935,13340,4097,476,16,69648,70886,78895,77840,1296,74814,81227,8204,65831,257,74798,1345,79471]

theorem envBound35234 : H12AffineFastState.Bounded env35234 := by
  intro p hp
  have h : env35234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35233_35234 : H12AffineEnvironment.transform 17 65664 env35233 = env35234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env35233 == env35234) = true)

theorem identity35234 : scanCanonicalize (H12AffineFastState.compose env35234 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound35234 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,12590,1344,12718,321,13340,4097,476,16,8510,9672,1281,318,1296,5392,3173,8204,12297,257,5376,1345,1857]

theorem envBound35235 : H12AffineFastState.Bounded env35235 := by
  intro p hp
  have h : env35235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35234_35235 : H12AffineEnvironment.transform 15 12590 env35234 = env35235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env35234 == env35235) = true)

def env35236 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,12637,12590,0,12718,321,12636,4097,476,16,8510,8328,65,318,80,4176,2341,8204,12297,257,4160,1,513]

theorem envBound35236 : H12AffineFastState.Bounded env35236 := by
  intro p hp
  have h : env35236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35235_35236 : H12AffineEnvironment.transform 9 320 env35235 = env35236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env35235 == env35236) = true)

theorem identity35236 : scanCanonicalize (H12AffineFastState.compose env35236 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound35236 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35237 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,4096,8192,81,12312,12395,0,12523,4,12313,4097,153,16,8315,8328,65,123,80,4176,2144,8204,12297,68,4160,1,513]

theorem envBound35237 : H12AffineFastState.Bounded env35237 := by
  intro p hp
  have h : env35237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35236_35237 : H12AffineEnvironment.transform 7 69 env35236 = env35237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env35236 == env35237) = true)

theorem identity35237 : scanCanonicalize (H12AffineFastState.compose env35237 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound35237 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35238 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,4096,25,81,4097,4210,0,4338,4,4096,4097,153,16,98,145,65,123,80,4176,2144,21,4112,68,4160,1,513]

theorem envBound35238 : H12AffineFastState.Bounded env35238 := by
  intro p hp
  have h : env35238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35237_35238 : H12AffineEnvironment.transform 12 25 env35237 = env35238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env35237 == env35238) = true)

theorem identity35238 : scanCanonicalize (H12AffineFastState.compose env35238 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound35238 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35239 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,17,25,81,16,99,0,227,4,17,16,153,16,98,145,65,123,80,65,2144,21,1,68,81,1,513]

theorem envBound35239 : H12AffineFastState.Bounded env35239 := by
  intro p hp
  have h : env35239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35238_35239 : H12AffineEnvironment.transform 11 17 env35238 = env35239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env35238 == env35239) = true)

theorem identity35239 : scanCanonicalize (H12AffineFastState.compose env35239 (packedSelected [0,1,7,8,11,15] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound35239 : packedSelected [0,1,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env35240 : List Nat := [2,4,8,16,32,1,128,4,512,5,2048,17,25,16,16,34,0,162,4,17,16,153,16,35,145,0,58,17,0,2081,21,1,5,16,1,513]

theorem envBound35240 : H12AffineFastState.Bounded env35240 := by
  intro p hp
  have h : env35240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35239_35240 : H12AffineEnvironment.transform 5 1 env35239 = env35240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env35239 == env35240) = true)

theorem identity35240 : scanCanonicalize (H12AffineFastState.compose env35240 (packedSelected [1,2] rootPS)) = affineNative (2^(10+1) ^^^ 158) := by decide +kernel

theorem selectedBound35240 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env35241 : List Nat := [2,4,8,16,32,1,128,4,512,5,158,17,25,16,16,34,0,162,4,17,16,153,16,35,145,0,58,17,0,191,21,1,5,16,1,513]

theorem envBound35241 : H12AffineFastState.Bounded env35241 := by
  intro p hp
  have h : env35241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35240_35241 : H12AffineEnvironment.transform 10 158 env35240 = env35241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 158 env35240 == env35241) = true)

theorem identity35241 : scanCanonicalize (H12AffineFastState.compose env35241 (packedSelected [0,7,8,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound35241 : packedSelected [0,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env35242 : List Nat := [2,4,8,16,32,1,128,4,147,5,158,17,25,16,16,34,0,162,4,17,16,153,16,35,145,0,58,17,0,191,21,1,5,16,1,146]

theorem envBound35242 : H12AffineFastState.Bounded env35242 := by
  intro p hp
  have h : env35242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35241_35242 : H12AffineEnvironment.transform 8 147 env35241 = env35242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env35241 == env35242) = true)

theorem identity35242 : scanCanonicalize (H12AffineFastState.compose env35242 (packedSelected [0,1,5,7,11] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound35242 : packedSelected [0,1,5,7,11] rootPS < 2^1333 := by decide +kernel

def env35243 : List Nat := [2,4,8,16,10,1,128,4,147,5,158,17,25,16,16,8,0,136,4,17,16,153,16,9,145,0,16,17,0,149,21,1,5,16,1,146]

theorem envBound35243 : H12AffineFastState.Bounded env35243 := by
  intro p hp
  have h : env35243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35242_35243 : H12AffineEnvironment.transform 4 10 env35242 = env35243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env35242 == env35243) = true)

theorem identity35243 : scanCanonicalize (H12AffineFastState.compose env35243 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound35243 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env35244 : List Nat := [2,4,8,16,10,1,31,4,12,5,1,17,25,16,16,8,0,23,4,17,16,6,16,9,14,0,16,17,0,10,21,1,5,16,1,13]

theorem envBound35244 : H12AffineFastState.Bounded env35244 := by
  intro p hp
  have h : env35244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35243_35244 : H12AffineEnvironment.transform 6 31 env35243 = env35244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env35243 == env35244) = true)

theorem identity35244 : scanCanonicalize (H12AffineFastState.compose env35244 (packedSelected [0,1,3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound35244 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env35245 : List Nat := [2,4,0,16,2,1,23,4,4,5,1,17,17,16,16,0,0,23,4,17,16,6,16,1,6,0,16,17,0,2,21,1,5,16,1,5]

theorem envBound35245 : H12AffineFastState.Bounded env35245 := by
  intro p hp
  have h : env35245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35244_35245 : H12AffineEnvironment.transform 2 0 env35244 = env35245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env35244 == env35245) = true)

theorem identity35245 : scanCanonicalize (H12AffineFastState.compose env35245 (packedSelected [1,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound35245 : packedSelected [1,7] rootPS < 2^1333 := by decide +kernel

def env35246 : List Nat := [2,4,0,1,2,1,6,4,4,5,1,0,0,1,1,0,0,6,4,0,1,6,1,1,6,0,1,0,0,2,4,1,5,1,1,5]

theorem envBound35246 : H12AffineFastState.Bounded env35246 := by
  intro p hp
  have h : env35246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35245_35246 : H12AffineEnvironment.transform 3 1 env35245 = env35246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env35245 == env35246) = true)

theorem identity35246 : scanCanonicalize (H12AffineFastState.compose env35246 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound35246 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35247 : List Nat := [0,4,0,1,0,1,4,4,4,5,1,0,0,1,1,0,0,4,4,0,1,4,1,1,4,0,1,0,0,0,4,1,5,1,1,5]

theorem envBound35247 : H12AffineFastState.Bounded env35247 := by
  intro p hp
  have h : env35247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35246_35247 : H12AffineEnvironment.transform 0 0 env35246 = env35247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env35246 == env35247) = true)

theorem identity35247 : scanCanonicalize (H12AffineFastState.compose env35247 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound35247 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35248 : List Nat := [0,0,0,1,0,1,0,0,0,1,1,0,0,1,1,0,0,0,0,0,1,0,1,1,0,0,1,0,0,0,0,1,1,1,1,1]

theorem envBound35248 : H12AffineFastState.Bounded env35248 := by
  intro p hp
  have h : env35248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35247_35248 : H12AffineEnvironment.transform 1 0 env35247 = env35248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env35247 == env35248) = true)

def env35249 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,12636,12590,1,12718,321,12637,4097,476,16,8510,8329,64,318,81,4177,2340,8204,12297,257,4161,0,512]

theorem envBound35249 : H12AffineFastState.Bounded env35249 := by
  intro p hp
  have h : env35249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35235_35249 : H12AffineEnvironment.transform 9 321 env35235 = env35249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env35235 == env35249) = true)

theorem identity35249 : scanCanonicalize (H12AffineFastState.compose env35249 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound35249 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35250 : List Nat := [2,4,8,16,32,64,128,20,512,85,2048,4096,8192,80,12360,12346,1,12474,85,12361,4097,200,16,8234,8329,64,42,81,4177,2096,8204,12297,21,4161,0,512]

theorem envBound35250 : H12AffineFastState.Bounded env35250 := by
  intro p hp
  have h : env35250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35249_35250 : H12AffineEnvironment.transform 7 20 env35249 = env35250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env35249 == env35250) = true)

theorem identity35250 : scanCanonicalize (H12AffineFastState.compose env35250 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound35250 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env35251 : List Nat := [2,4,8,16,32,64,128,20,512,85,2048,80,8192,80,8216,8298,1,8426,85,8217,81,200,16,8234,8329,64,42,81,1,2096,8204,8281,21,17,0,512]

theorem envBound35251 : H12AffineFastState.Bounded env35251 := by
  intro p hp
  have h : env35251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35250_35251 : H12AffineEnvironment.transform 11 80 env35250 = env35251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env35250 == env35251) = true)

theorem identity35251 : scanCanonicalize (H12AffineFastState.compose env35251 (packedSelected [0,1,3,5,7,8,10,11,13] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound35251 : packedSelected [0,1,3,5,7,8,10,11,13] rootPS < 2^1333 := by decide +kernel

def env35252 : List Nat := [2,4,8,16,32,64,128,20,512,85,2048,80,161,80,185,203,1,75,85,184,81,200,16,139,40,64,42,81,1,2096,173,248,21,17,0,512]

theorem envBound35252 : H12AffineFastState.Bounded env35252 := by
  intro p hp
  have h : env35252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35251_35252 : H12AffineEnvironment.transform 12 161 env35251 = env35252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env35251 == env35252) = true)

theorem identity35252 : scanCanonicalize (H12AffineFastState.compose env35252 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound35252 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env35253 : List Nat := [2,4,8,16,32,64,128,20,97,85,2048,80,161,80,185,203,1,75,85,184,81,200,16,139,40,64,42,81,1,2096,173,248,21,17,0,97]

theorem envBound35253 : H12AffineFastState.Bounded env35253 := by
  intro p hp
  have h : env35253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35252_35253 : H12AffineEnvironment.transform 8 97 env35252 = env35253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env35252 == env35253) = true)

theorem identity35253 : scanCanonicalize (H12AffineFastState.compose env35253 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound35253 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env35254 : List Nat := [2,4,8,16,32,64,128,20,97,85,42,80,161,80,185,203,1,75,85,184,81,200,16,139,40,64,42,81,1,26,173,248,21,17,0,97]

theorem envBound35254 : H12AffineFastState.Bounded env35254 := by
  intro p hp
  have h : env35254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35253_35254 : H12AffineEnvironment.transform 10 42 env35253 = env35254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env35253 == env35254) = true)

theorem identity35254 : scanCanonicalize (H12AffineFastState.compose env35254 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35254 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env35255 : List Nat := [2,4,8,16,32,64,9,20,97,85,42,80,40,80,48,66,1,75,85,49,81,65,16,2,40,64,42,81,1,26,36,113,21,17,0,97]

theorem envBound35255 : H12AffineFastState.Bounded env35255 := by
  intro p hp
  have h : env35255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35254_35255 : H12AffineEnvironment.transform 6 9 env35254 = env35255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35254 == env35255) = true)

theorem identity35255 : scanCanonicalize (H12AffineFastState.compose env35255 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound35255 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35256 : List Nat := [2,4,8,16,16,64,9,20,81,85,26,80,24,80,0,66,1,75,85,1,81,65,16,2,24,64,26,81,1,26,20,65,21,17,0,81]

theorem envBound35256 : H12AffineFastState.Bounded env35256 := by
  intro p hp
  have h : env35256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35255_35256 : H12AffineEnvironment.transform 4 16 env35255 = env35256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env35255 == env35256) = true)

theorem identity35256 : scanCanonicalize (H12AffineFastState.compose env35256 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35256 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env35257 : List Nat := [2,4,8,16,16,17,9,20,0,4,26,1,24,1,0,19,1,26,4,1,0,16,16,2,24,17,26,0,1,26,20,16,21,17,0,0]

theorem envBound35257 : H12AffineFastState.Bounded env35257 := by
  intro p hp
  have h : env35257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35256_35257 : H12AffineEnvironment.transform 5 17 env35256 = env35257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35256 == env35257) = true)

theorem identity35257 : scanCanonicalize (H12AffineFastState.compose env35257 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound35257 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35258 : List Nat := [2,3,8,16,16,17,9,19,0,3,26,1,24,1,0,19,1,26,3,1,0,16,16,2,24,17,26,0,1,26,19,16,18,17,0,0]

theorem envBound35258 : H12AffineFastState.Bounded env35258 := by
  intro p hp
  have h : env35258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35257_35258 : H12AffineEnvironment.transform 1 3 env35257 = env35258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env35257 == env35258) = true)

theorem identity35258 : scanCanonicalize (H12AffineFastState.compose env35258 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound35258 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35259 : List Nat := [2,3,8,10,10,11,9,9,0,3,0,1,2,1,0,9,1,0,3,1,0,10,10,2,2,11,0,0,1,0,9,10,8,11,0,0]

theorem envBound35259 : H12AffineFastState.Bounded env35259 := by
  intro p hp
  have h : env35259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35258_35259 : H12AffineEnvironment.transform 3 10 env35258 = env35259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env35258 == env35259) = true)

def env35260 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65665,77935,13340,4097,476,16,69649,70886,78895,77840,1296,74814,81227,8205,65830,257,74798,1345,79471]

theorem envBound35260 : H12AffineFastState.Bounded env35260 := by
  intro p hp
  have h : env35260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35233_35260 : H12AffineEnvironment.transform 17 65665 env35233 = env35260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env35233 == env35260) = true)

theorem identity35260 : scanCanonicalize (H12AffineFastState.compose env35260 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9326) := by decide +kernel

theorem selectedBound35260 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,9326,1344,9455,5121,13340,4097,476,16,13439,12424,4161,5246,1296,80,6437,8205,9544,257,64,1345,4609]

theorem envBound35261 : H12AffineFastState.Bounded env35261 := by
  intro p hp
  have h : env35261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35260_35261 : H12AffineEnvironment.transform 15 9326 env35260 = env35261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9326 env35260 == env35261) = true)

def env35262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,9245,9326,1344,9455,1025,9244,1,476,16,9343,8328,65,1150,1296,80,2341,8205,9544,257,64,1345,513]

theorem envBound35262 : H12AffineFastState.Bounded env35262 := by
  intro p hp
  have h : env35262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35261_35262 : H12AffineEnvironment.transform 11 0 env35261 = env35262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env35261 == env35262) = true)

theorem identity35262 : scanCanonicalize (H12AffineFastState.compose env35262 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound35262 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35263 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,0,8192,276,8216,8299,325,8426,4,8217,1,476,16,8314,8328,65,123,277,80,2341,8205,8525,257,64,324,513]

theorem envBound35263 : H12AffineFastState.Bounded env35263 := by
  intro p hp
  have h : env35263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35262_35263 : H12AffineEnvironment.transform 9 5 env35262 = env35263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env35262 == env35263) = true)

theorem identity35263 : scanCanonicalize (H12AffineFastState.compose env35263 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound35263 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35264 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,0,349,276,325,310,325,439,4,324,1,476,16,295,469,65,123,277,80,2341,336,16,257,64,324,513]

theorem envBound35264 : H12AffineFastState.Bounded env35264 := by
  intro p hp
  have h : env35264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35263_35264 : H12AffineEnvironment.transform 12 349 env35263 = env35264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env35263 == env35264) = true)

theorem identity35264 : scanCanonicalize (H12AffineFastState.compose env35264 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound35264 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35265 : List Nat := [2,4,8,16,32,64,128,85,512,5,2048,0,8,65,16,99,16,226,4,17,1,137,16,114,128,65,123,64,80,2160,5,16,84,64,17,513]

theorem envBound35265 : H12AffineFastState.Bounded env35265 := by
  intro p hp
  have h : env35265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35264_35265 : H12AffineEnvironment.transform 7 85 env35264 = env35265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env35264 == env35265) = true)

theorem identity35265 : scanCanonicalize (H12AffineFastState.compose env35265 (packedSelected [1,2,3,5,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 229) := by decide +kernel

theorem selectedBound35265 : packedSelected [1,2,3,5,15,17] rootPS < 2^1333 := by decide +kernel

def env35266 : List Nat := [2,4,8,16,32,64,128,85,512,5,229,0,8,65,16,99,16,226,4,17,1,137,16,114,128,65,123,64,80,149,5,16,84,64,17,513]

theorem envBound35266 : H12AffineFastState.Bounded env35266 := by
  intro p hp
  have h : env35266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35265_35266 : H12AffineEnvironment.transform 10 229 env35265 = env35266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 229 env35265 == env35266) = true)

theorem identity35266 : scanCanonicalize (H12AffineFastState.compose env35266 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound35266 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env35267 : List Nat := [2,4,8,16,32,64,128,85,137,5,229,0,8,65,16,99,16,226,4,17,1,137,16,114,128,65,123,64,80,149,5,16,84,64,17,136]

theorem envBound35267 : H12AffineFastState.Bounded env35267 := by
  intro p hp
  have h : env35267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35266_35267 : H12AffineEnvironment.transform 8 137 env35266 = env35267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env35266 == env35267) = true)

theorem identity35267 : scanCanonicalize (H12AffineFastState.compose env35267 (packedSelected [0,2,3,7,8,11,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 95) := by decide +kernel

theorem selectedBound35267 : packedSelected [0,2,3,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env35268 : List Nat := [2,4,8,16,32,64,95,85,86,5,58,0,8,65,16,99,16,61,4,17,1,86,16,114,95,65,123,64,80,74,5,16,84,64,17,87]

theorem envBound35268 : H12AffineFastState.Bounded env35268 := by
  intro p hp
  have h : env35268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35267_35268 : H12AffineEnvironment.transform 6 95 env35267 = env35268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 95 env35267 == env35268) = true)

theorem identity35268 : scanCanonicalize (H12AffineFastState.compose env35268 (packedSelected [3,4,8,9,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound35268 : packedSelected [3,4,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env35269 : List Nat := [2,4,8,16,22,64,95,85,86,5,12,0,8,65,16,85,16,11,4,17,1,86,16,68,95,65,77,64,80,74,5,16,84,64,17,87]

theorem envBound35269 : H12AffineFastState.Bounded env35269 := by
  intro p hp
  have h : env35269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35268_35269 : H12AffineEnvironment.transform 4 22 env35268 = env35269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env35268 == env35269) = true)

theorem identity35269 : scanCanonicalize (H12AffineFastState.compose env35269 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound35269 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env35270 : List Nat := [2,4,8,16,22,27,4,14,13,5,12,0,8,26,16,14,16,11,4,17,1,13,16,31,4,26,22,27,11,17,5,16,15,27,17,12]

theorem envBound35270 : H12AffineFastState.Bounded env35270 := by
  intro p hp
  have h : env35270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35269_35270 : H12AffineEnvironment.transform 5 27 env35269 = env35270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env35269 == env35270) = true)

theorem identity35270 : scanCanonicalize (H12AffineFastState.compose env35270 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound35270 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35271 : List Nat := [2,4,8,2,4,9,4,14,13,5,12,0,8,8,2,14,2,11,4,3,1,13,2,13,4,8,4,9,11,3,5,2,15,9,3,12]

theorem envBound35271 : H12AffineFastState.Bounded env35271 := by
  intro p hp
  have h : env35271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35270_35271 : H12AffineEnvironment.transform 3 2 env35270 = env35271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env35270 == env35271) = true)

theorem identity35271 : scanCanonicalize (H12AffineFastState.compose env35271 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound35271 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env35272 : List Nat := [2,1,8,2,1,9,1,11,8,0,9,0,8,8,2,11,2,11,1,3,1,8,2,8,1,8,1,9,11,3,0,2,10,9,3,9]

theorem envBound35272 : H12AffineFastState.Bounded env35272 := by
  intro p hp
  have h : env35272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35271_35272 : H12AffineEnvironment.transform 1 1 env35271 = env35272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env35271 == env35272) = true)

theorem identity35272 : scanCanonicalize (H12AffineFastState.compose env35272 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound35272 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35273 : List Nat := [2,1,3,2,1,2,1,0,3,0,2,0,3,3,2,0,2,0,1,3,1,3,2,3,1,3,1,2,0,3,0,2,1,2,3,2]

theorem envBound35273 : H12AffineFastState.Bounded env35273 := by
  intro p hp
  have h : env35273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35272_35273 : H12AffineEnvironment.transform 2 3 env35272 = env35273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env35272 == env35273) = true)

def env35274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,9244,9326,1344,9455,1024,9245,0,476,16,9342,8329,64,1151,1296,80,2340,8205,9544,257,64,1345,512]

theorem envBound35274 : H12AffineFastState.Bounded env35274 := by
  intro p hp
  have h : env35274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35261_35274 : H12AffineEnvironment.transform 11 1 env35261 = env35274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env35261 == env35274) = true)

theorem identity35274 : scanCanonicalize (H12AffineFastState.compose env35274 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound35274 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35275 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,1,8192,324,8265,8251,277,8378,85,8264,0,476,16,8235,8329,64,42,325,80,2340,8205,8477,257,64,276,512]

theorem envBound35275 : H12AffineFastState.Bounded env35275 := by
  intro p hp
  have h : env35275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35274_35275 : H12AffineEnvironment.transform 9 85 env35274 = env35275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env35274 == env35275) = true)

theorem identity35275 : scanCanonicalize (H12AffineFastState.compose env35275 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound35275 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env35276 : List Nat := [2,4,8,16,32,64,128,69,512,85,2048,1,8192,1,8265,8251,80,8378,85,8264,0,153,16,8235,8329,64,42,0,80,2145,8205,8280,68,64,81,512]

theorem envBound35276 : H12AffineFastState.Bounded env35276 := by
  intro p hp
  have h : env35276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35275_35276 : H12AffineEnvironment.transform 7 69 env35275 = env35276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env35275 == env35276) = true)

theorem identity35276 : scanCanonicalize (H12AffineFastState.compose env35276 (packedSelected [0,1,3,5,7,8,13,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound35276 : packedSelected [0,1,3,5,7,8,13,17,18] rootPS < 2^1333 := by decide +kernel

def env35277 : List Nat := [2,4,8,16,32,64,128,69,512,85,2048,1,161,1,232,154,80,27,85,233,0,153,16,138,40,64,42,0,80,2145,172,249,68,64,81,512]

theorem envBound35277 : H12AffineFastState.Bounded env35277 := by
  intro p hp
  have h : env35277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35276_35277 : H12AffineEnvironment.transform 12 161 env35276 = env35277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env35276 == env35277) = true)

theorem identity35277 : scanCanonicalize (H12AffineFastState.compose env35277 (packedSelected [0,1,2,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 195) := by decide +kernel

theorem selectedBound35277 : packedSelected [0,1,2,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env35278 : List Nat := [2,4,8,16,32,64,128,69,512,85,195,1,161,1,232,154,80,27,85,233,0,153,16,138,40,64,42,0,80,162,172,249,68,64,81,512]

theorem envBound35278 : H12AffineFastState.Bounded env35278 := by
  intro p hp
  have h : env35278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35277_35278 : H12AffineEnvironment.transform 10 195 env35277 = env35278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 195 env35277 == env35278) = true)

theorem identity35278 : scanCanonicalize (H12AffineFastState.compose env35278 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound35278 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env35279 : List Nat := [2,4,8,16,32,64,128,69,216,85,195,1,161,1,232,154,80,27,85,233,0,153,16,138,40,64,42,0,80,162,172,249,68,64,81,216]

theorem envBound35279 : H12AffineFastState.Bounded env35279 := by
  intro p hp
  have h : env35279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35278_35279 : H12AffineEnvironment.transform 8 216 env35278 = env35279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env35278 == env35279) = true)

theorem identity35279 : scanCanonicalize (H12AffineFastState.compose env35279 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound35279 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env35280 : List Nat := [2,4,8,11,32,64,128,69,195,78,195,1,161,1,232,129,75,0,78,233,0,130,11,138,40,64,42,0,75,162,172,226,68,64,74,195]

theorem envBound35280 : H12AffineFastState.Bounded env35280 := by
  intro p hp
  have h : env35280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35279_35280 : H12AffineEnvironment.transform 3 11 env35279 = env35280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env35279 == env35280) = true)

theorem identity35280 : scanCanonicalize (H12AffineFastState.compose env35280 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound35280 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env35281 : List Nat := [2,4,8,11,32,64,8,69,75,78,75,1,41,1,96,9,75,0,78,97,0,10,11,2,40,64,42,0,75,42,36,106,68,64,74,75]

theorem envBound35281 : H12AffineFastState.Bounded env35281 := by
  intro p hp
  have h : env35281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35280_35281 : H12AffineEnvironment.transform 6 8 env35280 = env35281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35280 == env35281) = true)

theorem identity35281 : scanCanonicalize (H12AffineFastState.compose env35281 (packedSelected [0,1,2] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound35281 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env35282 : List Nat := [2,4,8,11,32,11,8,14,0,5,0,1,41,1,43,9,0,0,5,42,0,10,11,2,40,11,42,0,0,42,36,33,15,11,1,0]

theorem envBound35282 : H12AffineFastState.Bounded env35282 := by
  intro p hp
  have h : env35282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35281_35282 : H12AffineEnvironment.transform 5 11 env35281 = env35282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env35281 == env35282) = true)

def env35283 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533641,672785,17245633,148801,545088,96346,16876545,16819499,257,545105,1344,525824]

theorem envBound35283 : H12AffineFastState.Bounded env35283 := by
  intro p hp
  have h : env35283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35009_35283 : H12AffineEnvironment.transform 26 17245633 env35009 = env35283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env35009 == env35283) = true)

theorem identity35283 : scanCanonicalize (H12AffineFastState.compose env35283 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74862) := by decide +kernel

theorem selectedBound35283 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env35284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4097,61648,91183,16777216,533641,614527,17039791,90415,545088,96346,16876545,16819499,257,545105,1344,525824]

theorem envBound35284 : H12AffineFastState.Bounded env35284 := by
  intro p hp
  have h : env35284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35283_35284 : H12AffineEnvironment.transform 16 74862 env35283 = env35284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74862 env35283 == env35284) = true)

def env35285 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4097,61648,91183,123164,533641,614527,385203,90415,545088,96346,25885,82999,257,545105,1344,525824]

theorem envBound35285 : H12AffineFastState.Bounded env35285 := by
  intro p hp
  have h : env35285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35284_35285 : H12AffineEnvironment.transform 23 123164 env35284 = env35285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env35284 == env35285) = true)

def env35286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4097,61648,91183,123164,28889,78895,385203,90415,1296,96346,25885,82999,257,1281,1344,21072]

theorem envBound35286 : H12AffineFastState.Bounded env35286 := by
  intro p hp
  have h : env35286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35285_35286 : H12AffineEnvironment.transform 18 21584 env35285 = env35286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env35285 == env35286) = true)

theorem identity35286 : scanCanonicalize (H12AffineFastState.compose env35286 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound35286 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env35287 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74862,262144,21584,25677,4097,5276,91183,66896,28889,78895,328959,90415,1296,96346,25885,82999,257,1281,1344,21072]

theorem envBound35287 : H12AffineFastState.Bounded env35287 := by
  intro p hp
  have h : env35287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35286_35287 : H12AffineEnvironment.transform 14 25676 env35286 = env35287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env35286 == env35287) = true)

def env35288 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,262144,4416,8541,4097,5276,74047,66896,13769,78895,328959,74815,1296,81226,8205,65831,257,1281,1344,5952]

theorem envBound35288 : H12AffineFastState.Bounded env35288 := by
  intro p hp
  have h : env35288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35287_35288 : H12AffineEnvironment.transform 13 1296 env35287 = env35288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env35287 == env35288) = true)

def env35289 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,65664,4416,8541,4097,5276,74047,66896,13769,78895,1151,74815,1296,81226,8205,65831,257,1281,1344,5952]

theorem envBound35289 : H12AffineFastState.Bounded env35289 := by
  intro p hp
  have h : env35289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35288_35289 : H12AffineEnvironment.transform 17 65664 env35288 = env35289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env35288 == env35289) = true)

theorem identity35289 : scanCanonicalize (H12AffineFastState.compose env35289 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound35289 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35290 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,8540,65536,74862,65664,320,8541,1,1180,74047,66896,9673,74799,1151,74815,1296,77130,8205,65831,257,1281,1344,1856]

theorem envBound35290 : H12AffineFastState.Bounded env35290 := by
  intro p hp
  have h : env35290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35289_35290 : H12AffineEnvironment.transform 11 0 env35289 = env35290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env35289 == env35290) = true)

def env35291 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,80,8540,65536,74030,65664,320,8541,1,476,74047,65552,8329,74095,319,74111,80,75786,8205,65831,257,65,0,512]

theorem envBound35291 : H12AffineFastState.Bounded env35291 := by
  intro p hp
  have h : env35291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35290_35291 : H12AffineEnvironment.transform 9 320 env35290 = env35291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env35290 == env35291) = true)

theorem identity35291 : scanCanonicalize (H12AffineFastState.compose env35291 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8251) := by decide +kernel

theorem selectedBound35291 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35292 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,80,8540,8251,277,8379,320,8541,1,476,260,8235,8329,340,319,324,80,2097,8205,8476,257,65,0,512]

theorem envBound35292 : H12AffineFastState.Bounded env35292 := by
  intro p hp
  have h : env35292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35291_35292 : H12AffineEnvironment.transform 15 8251 env35291 = env35292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8251 env35291 == env35292) = true)

theorem identity35292 : scanCanonicalize (H12AffineFastState.compose env35292 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35292 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env35293 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,8192,1,8461,8251,277,8379,273,8460,1,397,260,8235,8329,261,319,277,1,2097,8205,8476,257,16,0,512]

theorem envBound35293 : H12AffineFastState.Bounded env35293 := by
  intro p hp
  have h : env35293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35292_35293 : H12AffineEnvironment.transform 5 17 env35292 = env35293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35292 == env35293) = true)

theorem identity35293 : scanCanonicalize (H12AffineFastState.compose env35293 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound35293 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env35294 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,2088,1,2341,2067,277,2195,273,2340,1,397,260,2051,2209,261,319,277,1,2097,2085,2356,257,16,0,512]

theorem envBound35294 : H12AffineFastState.Bounded env35294 := by
  intro p hp
  have h : env35294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35293_35294 : H12AffineEnvironment.transform 12 2088 env35293 = env35294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env35293 == env35294) = true)

theorem identity35294 : scanCanonicalize (H12AffineFastState.compose env35294 (packedSelected [0,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 135) := by decide +kernel

theorem selectedBound35294 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env35295 : List Nat := [2,4,8,16,32,17,128,135,512,150,2048,0,2088,1,2210,2067,146,2195,150,2211,1,10,131,2051,2209,130,184,146,1,2097,2085,2227,134,16,0,512]

theorem envBound35295 : H12AffineFastState.Bounded env35295 := by
  intro p hp
  have h : env35295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35294_35295 : H12AffineEnvironment.transform 7 135 env35294 = env35295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 135 env35294 == env35295) = true)

theorem identity35295 : scanCanonicalize (H12AffineFastState.compose env35295 (packedSelected [1,2,3,7,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 184) := by decide +kernel

theorem selectedBound35295 : packedSelected [1,2,3,7,9,12] rootPS < 2^1333 := by decide +kernel

def env35296 : List Nat := [2,4,8,16,32,17,128,135,512,150,184,0,144,1,26,171,146,43,150,27,1,10,131,187,25,130,184,146,1,137,157,11,134,16,0,512]

theorem envBound35296 : H12AffineFastState.Bounded env35296 := by
  intro p hp
  have h : env35296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35295_35296 : H12AffineEnvironment.transform 10 184 env35295 = env35296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 184 env35295 == env35296) = true)

theorem identity35296 : scanCanonicalize (H12AffineFastState.compose env35296 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound35296 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env35297 : List Nat := [2,4,8,16,32,17,128,135,26,150,184,0,144,1,26,171,146,43,150,27,1,10,131,187,25,130,184,146,1,137,157,11,134,16,0,26]

theorem envBound35297 : H12AffineFastState.Bounded env35297 := by
  intro p hp
  have h : env35297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35296_35297 : H12AffineEnvironment.transform 8 26 env35296 = env35297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env35296 == env35297) = true)

theorem identity35297 : scanCanonicalize (H12AffineFastState.compose env35297 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound35297 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env35298 : List Nat := [2,4,8,16,17,17,128,135,26,150,137,0,144,1,26,154,146,26,150,27,1,10,131,138,25,130,137,146,1,137,157,11,134,16,0,26]

theorem envBound35298 : H12AffineFastState.Bounded env35298 := by
  intro p hp
  have h : env35298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35297_35298 : H12AffineEnvironment.transform 4 17 env35297 = env35298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env35297 == env35298) = true)

theorem identity35298 : scanCanonicalize (H12AffineFastState.compose env35298 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound35298 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env35299 : List Nat := [2,4,8,10,11,11,128,135,0,140,137,0,138,1,0,128,136,0,140,1,1,10,131,138,3,130,137,136,1,137,135,11,134,10,0,0]

theorem envBound35299 : H12AffineFastState.Bounded env35299 := by
  intro p hp
  have h : env35299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35298_35299 : H12AffineEnvironment.transform 3 10 env35298 = env35299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env35298 == env35299) = true)

theorem identity35299 : scanCanonicalize (H12AffineFastState.compose env35299 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound35299 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35300 : List Nat := [2,4,8,10,11,11,14,9,0,2,7,0,4,1,0,14,6,0,2,1,1,10,13,4,3,12,7,6,1,7,9,11,8,10,0,0]

theorem envBound35300 : H12AffineFastState.Bounded env35300 := by
  intro p hp
  have h : env35300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35299_35300 : H12AffineEnvironment.transform 6 14 env35299 = env35300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env35299 == env35300) = true)

theorem identity35300 : scanCanonicalize (H12AffineFastState.compose env35300 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound35300 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35301 : List Nat := [2,3,8,10,11,11,9,9,0,2,0,0,3,1,0,9,1,0,2,1,1,10,10,3,3,11,0,1,1,0,9,11,8,10,0,0]

theorem envBound35301 : H12AffineFastState.Bounded env35301 := by
  intro p hp
  have h : env35301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35300_35301 : H12AffineEnvironment.transform 1 3 env35300 = env35301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env35300 == env35301) = true)

def env35302 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,81,8540,65536,74031,65664,320,8541,1,477,74047,65553,8328,74094,318,74110,81,75787,8205,65831,257,64,1,513]

theorem envBound35302 : H12AffineFastState.Bounded env35302 := by
  intro p hp
  have h : env35302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35290_35302 : H12AffineEnvironment.transform 9 321 env35290 = env35302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env35290 == env35302) = true)

theorem identity35302 : scanCanonicalize (H12AffineFastState.compose env35302 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound35302 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35303 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,0,8192,81,8216,65536,73835,65664,4,8217,1,153,73851,65553,8328,73770,122,73786,81,75787,8205,65635,69,64,1,513]

theorem envBound35303 : H12AffineFastState.Bounded env35303 := by
  intro p hp
  have h : env35303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35302_35303 : H12AffineEnvironment.transform 7 68 env35302 = env35303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env35302 == env35303) = true)

theorem identity35303 : scanCanonicalize (H12AffineFastState.compose env35303 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound35303 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35304 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,0,8192,81,8216,114,8217,242,4,8217,1,153,8201,99,8328,8280,122,8264,81,10361,8205,17,69,64,1,513]

theorem envBound35304 : H12AffineFastState.Bounded env35304 := by
  intro p hp
  have h : env35304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35303_35304 : H12AffineEnvironment.transform 15 114 env35303 = env35304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env35303 == env35304) = true)

theorem identity35304 : scanCanonicalize (H12AffineFastState.compose env35304 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound35304 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35305 : List Nat := [2,4,8,16,32,1,128,5,512,5,2048,0,8192,16,8216,51,8217,179,4,8217,1,153,8201,34,8328,8217,59,8201,16,10296,8205,17,4,1,1,513]

theorem envBound35305 : H12AffineFastState.Bounded env35305 := by
  intro p hp
  have h : env35305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35304_35305 : H12AffineEnvironment.transform 5 1 env35304 = env35305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env35304 == env35305) = true)

theorem identity35305 : scanCanonicalize (H12AffineFastState.compose env35305 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound35305 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env35306 : List Nat := [2,4,8,16,32,1,128,5,512,5,2048,0,656,16,648,51,649,179,4,649,1,153,665,34,536,649,59,665,16,2728,669,17,4,1,1,513]

theorem envBound35306 : H12AffineFastState.Bounded env35306 := by
  intro p hp
  have h : env35306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2