import H12CloudChart2Data203

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans51333_51334 : H12AffineEnvironment.transform 11 80 env51333 = env51334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env51333 == env51334) = true)

theorem identity51334 : scanCanonicalize (H12AffineFastState.compose env51334 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound51334 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env51335 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1052,1297,1344,1331,1345,1459,273,1345,81,1229,17,98,389,1361,1151,1297,1297,3124,1040,1281,256,1044,1344,1808]

theorem envBound51335 : H12AffineFastState.Bounded env51335 := by
  intro p hp
  have h : env51335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51334_51335 : H12AffineEnvironment.transform 12 1052 env51334 = env51335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env51334 == env51335) = true)

theorem identity51335 : scanCanonicalize (H12AffineFastState.compose env51335 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound51335 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env51336 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,80,268,1,80,35,81,163,273,81,81,477,17,98,389,65,367,1,1,2340,256,17,256,260,80,512]

theorem envBound51336 : H12AffineFastState.Bounded env51336 := by
  intro p hp
  have h : env51336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51335_51336 : H12AffineEnvironment.transform 9 272 env51335 = env51336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env51335 == env51336) = true)

theorem identity51336 : scanCanonicalize (H12AffineFastState.compose env51336 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 391) := by decide +kernel

theorem selectedBound51336 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env51337 : List Nat := [2,4,8,16,32,64,128,256,512,272,391,80,268,1,80,35,81,163,273,81,81,477,17,98,389,65,367,1,1,163,256,17,256,260,80,512]

theorem envBound51337 : H12AffineFastState.Bounded env51337 := by
  intro p hp
  have h : env51337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51336_51337 : H12AffineEnvironment.transform 10 391 env51336 = env51337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 391 env51336 == env51337) = true)

theorem identity51337 : scanCanonicalize (H12AffineFastState.compose env51337 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound51337 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51338 : List Nat := [2,4,8,16,32,64,128,256,96,272,391,80,268,1,80,35,81,163,273,81,81,477,17,98,389,65,367,1,1,163,256,17,256,260,80,96]

theorem envBound51338 : H12AffineFastState.Bounded env51338 := by
  intro p hp
  have h : env51338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51337_51338 : H12AffineEnvironment.transform 8 96 env51337 = env51338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env51337 == env51338) = true)

theorem identity51338 : scanCanonicalize (H12AffineFastState.compose env51338 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound51338 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env51339 : List Nat := [2,4,8,16,32,64,105,256,96,272,366,80,268,1,80,35,81,74,273,81,81,308,17,98,364,65,367,1,1,74,256,17,256,260,80,96]

theorem envBound51339 : H12AffineFastState.Bounded env51339 := by
  intro p hp
  have h : env51339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51338_51339 : H12AffineEnvironment.transform 6 105 env51338 = env51339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env51338 == env51339) = true)

theorem identity51339 : scanCanonicalize (H12AffineFastState.compose env51339 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound51339 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51340 : List Nat := [2,4,8,16,32,58,19,256,26,272,276,42,268,1,42,35,43,48,273,43,43,308,17,24,278,59,277,1,1,48,256,17,256,260,42,26]

theorem envBound51340 : H12AffineFastState.Bounded env51340 := by
  intro p hp
  have h : env51340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51339_51340 : H12AffineEnvironment.transform 5 58 env51339 = env51340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env51339 == env51340) = true)

theorem identity51340 : scanCanonicalize (H12AffineFastState.compose env51340 (packedSelected [3,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound51340 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env51341 : List Nat := [2,4,8,16,10,16,19,256,26,272,276,0,268,1,0,9,1,26,273,1,1,286,17,24,278,17,277,1,1,26,256,17,256,260,0,26]

theorem envBound51341 : H12AffineFastState.Bounded env51341 := by
  intro p hp
  have h : env51341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51340_51341 : H12AffineEnvironment.transform 4 10 env51340 = env51341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env51340 == env51341) = true)

theorem identity51341 : scanCanonicalize (H12AffineFastState.compose env51341 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound51341 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51342 : List Nat := [2,4,8,16,10,16,19,14,26,30,26,0,2,1,0,9,1,26,31,1,1,16,17,24,24,17,27,1,1,26,14,17,14,10,0,26]

theorem envBound51342 : H12AffineFastState.Bounded env51342 := by
  intro p hp
  have h : env51342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51341_51342 : H12AffineEnvironment.transform 7 14 env51341 = env51342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env51341 == env51342) = true)

theorem identity51342 : scanCanonicalize (H12AffineFastState.compose env51342 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound51342 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env51343 : List Nat := [2,4,8,11,10,11,8,14,1,5,1,0,2,1,0,9,1,1,4,1,1,11,10,3,3,10,0,1,1,1,14,10,14,10,0,1]

theorem envBound51343 : H12AffineFastState.Bounded env51343 := by
  intro p hp
  have h : env51343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51342_51343 : H12AffineEnvironment.transform 3 11 env51342 = env51343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env51342 == env51343) = true)

theorem identity51343 : scanCanonicalize (H12AffineFastState.compose env51343 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound51343 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51344 : List Nat := [2,4,5,6,7,6,5,3,1,5,1,0,2,1,0,4,1,1,4,1,1,6,7,3,3,7,0,1,1,1,3,7,3,7,0,1]

theorem envBound51344 : H12AffineFastState.Bounded env51344 := by
  intro p hp
  have h : env51344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51343_51344 : H12AffineEnvironment.transform 2 5 env51343 = env51344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env51343 == env51344) = true)

def env51345 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,8540,8494,1344,8622,272,8541,80,1228,16,9343,9624,1361,1151,1296,1297,3124,8204,1281,256,8201,1344,1809]

theorem envBound51345 : H12AffineFastState.Bounded env51345 := by
  intro p hp
  have h : env51345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51333_51345 : H12AffineEnvironment.transform 11 81 env51333 = env51345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env51333 == env51345) = true)

theorem identity51345 : scanCanonicalize (H12AffineFastState.compose env51345 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound51345 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env51346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,72,1297,276,358,1344,486,272,277,80,1228,16,1079,1488,1361,1151,1296,1297,3124,68,1281,256,65,1344,1809]

theorem envBound51346 : H12AffineFastState.Bounded env51346 := by
  intro p hp
  have h : env51346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51345_51346 : H12AffineEnvironment.transform 12 72 env51345 = env51346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env51345 == env51346) = true)

theorem identity51346 : scanCanonicalize (H12AffineFastState.compose env51346 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 412) := by decide +kernel

theorem selectedBound51346 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env51347 : List Nat := [2,4,8,16,32,64,128,256,412,1024,2048,81,72,1297,276,358,1344,486,272,277,80,1228,16,1079,1488,1361,1151,1296,1297,3124,68,1281,256,65,1344,1165]

theorem envBound51347 : H12AffineFastState.Bounded env51347 := by
  intro p hp
  have h : env51347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51346_51347 : H12AffineEnvironment.transform 8 412 env51346 = env51347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 412 env51346 == env51347) = true)

theorem identity51347 : scanCanonicalize (H12AffineFastState.compose env51347 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound51347 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env51348 : List Nat := [2,4,8,16,32,64,128,20,136,1024,2048,81,72,1029,0,114,1108,242,4,1,80,1228,16,1079,1220,1093,1151,1028,1029,3124,68,1045,20,65,1108,1165]

theorem envBound51348 : H12AffineFastState.Bounded env51348 := by
  intro p hp
  have h : env51348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51347_51348 : H12AffineEnvironment.transform 7 20 env51347 = env51348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env51347 == env51348) = true)

theorem identity51348 : scanCanonicalize (H12AffineFastState.compose env51348 (packedSelected [2,3,4,5,9,10,15,16,17] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound51348 : packedSelected [2,3,4,5,9,10,15,16,17] rootPS < 2^1333 := by decide +kernel

def env51349 : List Nat := [2,4,8,16,32,59,128,20,136,1024,2048,42,51,1029,0,9,1071,137,4,1,43,1207,16,1079,1215,1086,1028,1028,1029,3124,63,1045,20,58,1071,1165]

theorem envBound51349 : H12AffineFastState.Bounded env51349 := by
  intro p hp
  have h : env51349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51348_51349 : H12AffineEnvironment.transform 5 59 env51348 = env51349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env51348 == env51349) = true)

theorem identity51349 : scanCanonicalize (H12AffineFastState.compose env51349 (packedSelected [0,1,5,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound51349 : packedSelected [0,1,5,7,11] rootPS < 2^1333 := by decide +kernel

def env51350 : List Nat := [2,4,8,16,32,59,128,20,136,31,2048,42,51,26,0,9,48,137,4,1,43,168,16,40,160,33,27,27,26,2091,63,10,20,58,48,146]

theorem envBound51350 : H12AffineFastState.Bounded env51350 := by
  intro p hp
  have h : env51350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51349_51350 : H12AffineEnvironment.transform 9 31 env51349 = env51350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env51349 == env51350) = true)

theorem identity51350 : scanCanonicalize (H12AffineFastState.compose env51350 (packedSelected [2,5,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound51350 : packedSelected [2,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env51351 : List Nat := [2,4,8,16,32,59,35,20,43,31,2048,42,51,26,0,9,48,42,4,1,43,11,16,40,3,33,27,27,26,2091,63,10,20,58,48,49]

theorem envBound51351 : H12AffineFastState.Bounded env51351 := by
  intro p hp
  have h : env51351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51350_51351 : H12AffineEnvironment.transform 6 35 env51350 = env51351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env51350 == env51351) = true)

theorem identity51351 : scanCanonicalize (H12AffineFastState.compose env51351 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound51351 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env51352 : List Nat := [2,4,8,16,32,59,35,20,43,31,49,42,51,26,0,9,48,42,4,1,43,11,16,40,3,33,27,27,26,26,63,10,20,58,48,49]

theorem envBound51352 : H12AffineFastState.Bounded env51352 := by
  intro p hp
  have h : env51352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51351_51352 : H12AffineEnvironment.transform 10 49 env51351 = env51352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env51351 == env51352) = true)

def env51353 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65665,4417,8541,4097,5277,74046,66897,13769,78894,1150,74814,1297,81227,8204,1281,256,65831,1344,5952]

theorem envBound51353 : H12AffineFastState.Bounded env51353 := by
  intro p hp
  have h : env51353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51331_51353 : H12AffineEnvironment.transform 17 65665 env51331 = env51353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env51331 == env51353) = true)

theorem identity51353 : scanCanonicalize (H12AffineFastState.compose env51353 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9278) := by decide +kernel

theorem selectedBound51353 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51354 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,9278,80,9407,4417,8541,4097,5277,1280,8559,13769,4112,1150,0,1297,6517,8204,1281,256,9497,1344,5952]

theorem envBound51354 : H12AffineFastState.Bounded env51354 := by
  intro p hp
  have h : env51354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51353_51354 : H12AffineEnvironment.transform 15 9278 env51353 = env51354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9278 env51353 == env51354) = true)

def env51355 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,8540,8494,80,8623,4417,8541,4097,4493,16,8559,12505,4112,366,0,1,6517,8204,17,256,8201,80,4688]

theorem envBound51355 : H12AffineFastState.Bounded env51355 := by
  intro p hp
  have h : env51355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51354_51355 : H12AffineEnvironment.transform 9 272 env51354 = env51355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env51354 == env51355) = true)

theorem identity51355 : scanCanonicalize (H12AffineFastState.compose env51355 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4121) := by decide +kernel

theorem selectedBound51355 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env51356 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,4121,1,4421,4407,80,4534,4417,4420,4097,4493,16,4470,192,4112,366,0,1,6517,4117,17,256,4112,80,4688]

theorem envBound51356 : H12AffineFastState.Bounded env51356 := by
  intro p hp
  have h : env51356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51355_51356 : H12AffineEnvironment.transform 12 4121 env51355 = env51356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4121 env51355 == env51356) = true)

theorem identity51356 : scanCanonicalize (H12AffineFastState.compose env51356 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 973) := by decide +kernel

theorem selectedBound51356 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env51357 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,973,980,1,648,762,80,635,652,649,972,576,16,699,192,989,366,0,1,2744,984,17,256,989,80,413]

theorem envBound51357 : H12AffineFastState.Bounded env51357 := by
  intro p hp
  have h : env51357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51356_51357 : H12AffineEnvironment.transform 11 973 env51356 = env51357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 973 env51356 == env51357) = true)

theorem identity51357 : scanCanonicalize (H12AffineFastState.compose env51357 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound51357 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env51358 : List Nat := [2,4,8,16,32,64,128,256,136,272,2048,325,348,1,0,114,80,243,4,1,324,200,16,51,192,341,366,0,1,2096,336,17,256,341,80,413]

theorem envBound51358 : H12AffineFastState.Bounded env51358 := by
  intro p hp
  have h : env51358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51357_51358 : H12AffineEnvironment.transform 8 136 env51357 = env51358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env51357 == env51358) = true)

theorem identity51358 : scanCanonicalize (H12AffineFastState.compose env51358 (packedSelected [0,1,2,3,7,10,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound51358 : packedSelected [0,1,2,3,7,10,11,15] rootPS < 2^1333 := by decide +kernel

def env51359 : List Nat := [2,4,8,16,32,64,89,256,81,272,2048,325,348,1,0,114,80,42,4,1,324,17,16,51,25,341,366,0,1,2096,336,17,256,341,80,324]

theorem envBound51359 : H12AffineFastState.Bounded env51359 := by
  intro p hp
  have h : env51359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51358_51359 : H12AffineEnvironment.transform 6 89 env51358 = env51359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env51358 == env51359) = true)

theorem identity51359 : scanCanonicalize (H12AffineFastState.compose env51359 (packedSelected [0,1,2,5,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound51359 : packedSelected [0,1,2,5,7,11] rootPS < 2^1333 := by decide +kernel

def env51360 : List Nat := [2,4,8,16,32,64,89,20,81,4,2048,81,72,1,0,114,80,42,4,1,80,17,16,51,25,65,122,0,1,2096,68,17,20,65,80,80]

theorem envBound51360 : H12AffineFastState.Bounded env51360 := by
  intro p hp
  have h : env51360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51359_51360 : H12AffineEnvironment.transform 7 20 env51359 = env51360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env51359 == env51360) = true)

theorem identity51360 : scanCanonicalize (H12AffineFastState.compose env51360 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound51360 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51361 : List Nat := [2,4,8,16,32,33,56,20,48,4,2048,48,41,1,0,19,49,42,4,1,49,17,16,51,25,32,27,0,1,2096,37,17,20,32,49,49]

theorem envBound51361 : H12AffineFastState.Bounded env51361 := by
  intro p hp
  have h : env51361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51360_51361 : H12AffineEnvironment.transform 5 33 env51360 = env51361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env51360 == env51361) = true)

theorem identity51361 : scanCanonicalize (H12AffineFastState.compose env51361 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 35) := by decide +kernel

theorem selectedBound51361 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env51362 : List Nat := [2,4,8,16,32,33,56,20,48,4,35,48,41,1,0,19,49,42,4,1,49,17,16,51,25,32,27,0,1,19,37,17,20,32,49,49]

theorem envBound51362 : H12AffineFastState.Bounded env51362 := by
  intro p hp
  have h : env51362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51361_51362 : H12AffineEnvironment.transform 10 35 env51361 = env51362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 35 env51361 == env51362) = true)

theorem identity51362 : scanCanonicalize (H12AffineFastState.compose env51362 (packedSelected [3,7] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound51362 : packedSelected [3,7] rootPS < 2^1333 := by decide +kernel

def env51363 : List Nat := [2,4,8,16,8,9,16,20,24,4,11,24,1,1,0,19,25,2,4,1,25,17,16,27,25,8,27,0,1,19,13,17,20,8,25,25]

theorem envBound51363 : H12AffineFastState.Bounded env51363 := by
  intro p hp
  have h : env51363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51362_51363 : H12AffineEnvironment.transform 4 8 env51362 = env51363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env51362 == env51363) = true)

theorem identity51363 : scanCanonicalize (H12AffineFastState.compose env51363 (packedSelected [0,3,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound51363 : packedSelected [0,3,5] rootPS < 2^1333 := by decide +kernel

def env51364 : List Nat := [2,4,4,16,4,5,16,20,20,4,7,20,1,1,0,19,21,2,4,1,21,17,16,23,21,4,23,0,1,19,1,17,20,4,21,21]

theorem envBound51364 : H12AffineFastState.Bounded env51364 := by
  intro p hp
  have h : env51364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51363_51364 : H12AffineEnvironment.transform 2 4 env51363 = env51364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env51363 == env51364) = true)

theorem identity51364 : scanCanonicalize (H12AffineFastState.compose env51364 (packedSelected [0,3,8] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound51364 : packedSelected [0,3,8] rootPS < 2^1333 := by decide +kernel

def env51365 : List Nat := [2,1,1,16,1,0,16,17,17,1,2,17,1,1,0,19,16,2,1,1,16,17,16,18,16,1,18,0,1,19,1,17,17,1,16,16]

theorem envBound51365 : H12AffineFastState.Bounded env51365 := by
  intro p hp
  have h : env51365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51364_51365 : H12AffineEnvironment.transform 1 1 env51364 = env51365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env51364 == env51365) = true)

theorem identity51365 : scanCanonicalize (H12AffineFastState.compose env51365 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound51365 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env51366 : List Nat := [2,1,1,2,1,0,2,3,3,1,2,3,1,1,0,1,2,2,1,1,2,3,2,0,2,1,0,0,1,1,1,3,3,1,2,2]

theorem envBound51366 : H12AffineFastState.Bounded env51366 := by
  intro p hp
  have h : env51366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51365_51366 : H12AffineEnvironment.transform 3 2 env51365 = env51366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env51365 == env51366) = true)

theorem identity51366 : scanCanonicalize (H12AffineFastState.compose env51366 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound51366 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51367 : List Nat := [1,1,1,1,1,0,1,0,0,1,1,0,1,1,0,1,1,1,1,1,1,0,1,0,1,1,0,0,1,1,1,0,0,1,1,1]

theorem envBound51367 : H12AffineFastState.Bounded env51367 := by
  intro p hp
  have h : env51367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51366_51367 : H12AffineEnvironment.transform 0 1 env51366 = env51367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env51366 == env51367) = true)

def env51368 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,8540,8495,80,8622,4417,8541,4097,4492,17,8559,12504,4112,367,0,0,6517,8204,16,256,8200,81,4689]

theorem envBound51368 : H12AffineFastState.Bounded env51368 := by
  intro p hp
  have h : env51368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51354_51368 : H12AffineEnvironment.transform 9 273 env51354 = env51368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env51354 == env51368) = true)

theorem identity51368 : scanCanonicalize (H12AffineFastState.compose env51368 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4445) := by decide +kernel

theorem selectedBound51368 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env51369 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,4445,0,4097,4210,80,4339,4417,4096,4097,4492,17,4146,389,4112,367,0,0,6517,4433,16,256,4437,81,4689]

theorem envBound51369 : H12AffineFastState.Bounded env51369 := by
  intro p hp
  have h : env51369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51368_51369 : H12AffineEnvironment.transform 12 4445 env51368 = env51369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4445 env51368 == env51369) = true)

theorem identity51369 : scanCanonicalize (H12AffineFastState.compose env51369 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound51369 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env51370 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,81,268,0,80,35,80,162,272,81,80,477,17,99,389,65,367,0,0,2340,256,16,256,260,81,512]

theorem envBound51370 : H12AffineFastState.Bounded env51370 := by
  intro p hp
  have h : env51370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51369_51370 : H12AffineEnvironment.transform 11 81 env51369 = env51370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env51369 == env51370) = true)

theorem identity51370 : scanCanonicalize (H12AffineFastState.compose env51370 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 366) := by decide +kernel

theorem selectedBound51370 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env51371 : List Nat := [2,4,8,16,32,64,128,256,512,273,366,81,268,0,80,35,80,162,272,81,80,477,17,99,389,65,367,0,0,74,256,16,256,260,81,512]

theorem envBound51371 : H12AffineFastState.Bounded env51371 := by
  intro p hp
  have h : env51371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51370_51371 : H12AffineEnvironment.transform 10 366 env51370 = env51371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 366 env51370 == env51371) = true)

theorem identity51371 : scanCanonicalize (H12AffineFastState.compose env51371 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound51371 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51372 : List Nat := [2,4,8,16,32,64,128,256,136,273,366,81,268,0,80,35,80,162,272,81,80,477,17,99,389,65,367,0,0,74,256,16,256,260,81,136]

theorem envBound51372 : H12AffineFastState.Bounded env51372 := by
  intro p hp
  have h : env51372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51371_51372 : H12AffineEnvironment.transform 8 136 env51371 = env51372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env51371 == env51372) = true)

theorem identity51372 : scanCanonicalize (H12AffineFastState.compose env51372 (packedSelected [1,2,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound51372 : packedSelected [1,2,8,10] rootPS < 2^1333 := by decide +kernel

def env51373 : List Nat := [2,4,8,16,32,64,128,172,136,189,194,81,160,0,80,35,80,162,188,81,80,113,17,99,41,65,195,0,0,74,172,16,172,168,81,136]

theorem envBound51373 : H12AffineFastState.Bounded env51373 := by
  intro p hp
  have h : env51373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51372_51373 : H12AffineEnvironment.transform 7 172 env51372 = env51373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env51372 == env51373) = true)

theorem identity51373 : scanCanonicalize (H12AffineFastState.compose env51373 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound51373 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env51374 : List Nat := [2,4,8,16,32,64,88,116,80,101,26,81,120,0,80,35,80,122,100,81,80,113,17,99,41,65,27,0,0,74,116,16,116,112,81,80]

theorem envBound51374 : H12AffineFastState.Bounded env51374 := by
  intro p hp
  have h : env51374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51373_51374 : H12AffineEnvironment.transform 6 88 env51373 = env51374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env51373 == env51374) = true)

theorem identity51374 : scanCanonicalize (H12AffineFastState.compose env51374 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound51374 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env51375 : List Nat := [2,4,8,16,32,11,19,63,27,46,26,26,51,0,27,35,27,49,47,26,27,58,17,40,41,10,27,0,0,1,63,16,63,59,26,27]

theorem envBound51375 : H12AffineFastState.Bounded env51375 := by
  intro p hp
  have h : env51375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51374_51375 : H12AffineEnvironment.transform 5 11 env51374 = env51375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env51374 == env51375) = true)

theorem identity51375 : scanCanonicalize (H12AffineFastState.compose env51375 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound51375 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51376 : List Nat := [2,4,8,16,11,11,19,20,27,5,26,26,24,0,27,8,27,26,4,26,27,17,17,3,2,10,27,0,0,1,20,16,20,16,26,27]

theorem envBound51376 : H12AffineFastState.Bounded env51376 := by
  intro p hp
  have h : env51376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51375_51376 : H12AffineEnvironment.transform 4 11 env51375 = env51376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env51375 == env51376) = true)

theorem identity51376 : scanCanonicalize (H12AffineFastState.compose env51376 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound51376 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51377 : List Nat := [2,4,5,16,6,6,19,20,22,5,23,23,21,0,22,5,22,23,4,23,22,17,17,3,2,7,22,0,0,1,20,16,20,16,23,22]

theorem envBound51377 : H12AffineFastState.Bounded env51377 := by
  intro p hp
  have h : env51377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51376_51377 : H12AffineEnvironment.transform 2 5 env51376 = env51377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env51376 == env51377) = true)

theorem identity51377 : scanCanonicalize (H12AffineFastState.compose env51377 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound51377 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env51378 : List Nat := [2,4,5,6,6,6,5,2,0,5,1,1,3,0,0,5,0,1,4,1,0,7,7,3,2,7,0,0,0,1,2,6,2,6,1,0]

theorem envBound51378 : H12AffineFastState.Bounded env51378 := by
  intro p hp
  have h : env51378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51377_51378 : H12AffineEnvironment.transform 3 6 env51377 = env51378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env51377 == env51378) = true)

def env51379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4097,61648,91183,123164,28889,78895,385202,90415,1296,96346,25885,1281,256,82999,1344,21072]

theorem envBound51379 : H12AffineFastState.Bounded env51379 := by
  intro p hp
  have h : env51379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51287_51379 : H12AffineEnvironment.transform 18 21585 env51287 = env51379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env51287 == env51379) = true)

theorem identity51379 : scanCanonicalize (H12AffineFastState.compose env51379 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound51379 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env51380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74862,262144,21585,13340,4097,17613,91183,87297,28889,78895,349359,90415,1296,96346,25885,1281,256,82999,1344,21072]

theorem envBound51380 : H12AffineFastState.Bounded env51380 := by
  intro p hp
  have h : env51380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51379_51380 : H12AffineEnvironment.transform 14 13341 env51379 = env51380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env51379 == env51380) = true)

def env51381 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,262144,4417,13340,4097,477,74047,69649,13769,78895,332223,74815,1296,81226,8205,1281,256,65831,1344,5952]

theorem envBound51381 : H12AffineFastState.Bounded env51381 := by
  intro p hp
  have h : env51381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51380_51381 : H12AffineEnvironment.transform 13 1296 env51380 = env51381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env51380 == env51381) = true)

def env51382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65664,4417,13340,4097,477,74047,69649,13769,78895,4415,74815,1296,81226,8205,1281,256,65831,1344,5952]

theorem envBound51382 : H12AffineFastState.Bounded env51382 := by
  intro p hp
  have h : env51382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51381_51382 : H12AffineEnvironment.transform 17 65664 env51381 = env51382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env51381 == env51382) = true)

theorem identity51382 : scanCanonicalize (H12AffineFastState.compose env51382 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5238) := by decide +kernel

theorem selectedBound51382 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,5238,12312,5366,4417,13340,4097,477,13641,1127,13769,8281,4415,12361,1296,10556,8205,1281,256,5457,1344,5952]

theorem envBound51383 : H12AffineFastState.Bounded env51383 := by
  intro p hp
  have h : env51383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51382_51383 : H12AffineEnvironment.transform 15 5238 env51382 = env51383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5238 env51382 == env51383) = true)

def env51384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,9293,1062,8264,1190,273,9292,81,477,9497,1127,9625,8281,367,8217,1296,10556,8205,1281,256,1281,1344,1808]

theorem envBound51384 : H12AffineFastState.Bounded env51384 := by
  intro p hp
  have h : env51384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51383_51384 : H12AffineEnvironment.transform 11 80 env51383 = env51384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env51383 == env51384) = true)

theorem identity51384 : scanCanonicalize (H12AffineFastState.compose env51384 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 1369) := by decide +kernel

theorem selectedBound51384 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env51385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1369,1296,276,1062,1297,1190,273,277,81,477,64,1127,192,1280,367,1344,1296,3173,1364,1281,256,1281,1344,1808]

theorem envBound51385 : H12AffineFastState.Bounded env51385 := by
  intro p hp
  have h : env51385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51384_51385 : H12AffineEnvironment.transform 12 1369 env51384 = env51385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1369 env51384 == env51385) = true)

theorem identity51385 : scanCanonicalize (H12AffineFastState.compose env51385 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound51385 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51386 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,80,1101,1028,0,1062,1029,1190,5,1,81,201,64,1127,192,1044,123,1108,1028,3173,1088,1045,20,1045,1108,1540]

theorem envBound51386 : H12AffineFastState.Bounded env51386 := by
  intro p hp
  have h : env51386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51385_51386 : H12AffineEnvironment.transform 7 20 env51385 = env51386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env51385 == env51386) = true)

theorem identity51386 : scanCanonicalize (H12AffineFastState.compose env51386 (packedSelected [0,1,7,8,12,17,18,19] rootPS)) = affineNative (2^(9+1) ^^^ 78) := by decide +kernel

theorem selectedBound51386 : packedSelected [0,1,7,8,12,17,18,19] rootPS < 2^1333 := by decide +kernel

def env51387 : List Nat := [2,4,8,16,32,64,128,20,512,78,2048,80,3,74,0,104,75,232,5,1,81,201,64,41,192,90,123,26,74,2091,14,91,20,91,26,586]

theorem envBound51387 : H12AffineFastState.Bounded env51387 := by
  intro p hp
  have h : env51387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51386_51387 : H12AffineEnvironment.transform 9 78 env51386 = env51387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 78 env51386 == env51387) = true)

theorem identity51387 : scanCanonicalize (H12AffineFastState.compose env51387 (packedSelected [0,1,2,5,7,8,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 661) := by decide +kernel

theorem selectedBound51387 : packedSelected [0,1,2,5,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env51388 : List Nat := [2,4,8,16,32,64,128,20,512,78,661,80,3,74,0,104,75,232,5,1,81,201,64,41,192,90,123,26,74,702,14,91,20,91,26,586]

theorem envBound51388 : H12AffineFastState.Bounded env51388 := by
  intro p hp
  have h : env51388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51387_51388 : H12AffineEnvironment.transform 10 661 env51387 = env51388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 661 env51387 == env51388) = true)

theorem identity51388 : scanCanonicalize (H12AffineFastState.compose env51388 (packedSelected [5,10,15] rootPS)) = affineNative (2^(6+1) ^^^ 111) := by decide +kernel

theorem selectedBound51388 : packedSelected [5,10,15] rootPS < 2^1333 := by decide +kernel

def env51389 : List Nat := [2,4,8,16,32,64,111,20,512,78,634,80,3,74,0,104,75,7,5,1,81,38,64,41,47,90,123,26,74,593,14,91,20,91,26,586]

theorem envBound51389 : H12AffineFastState.Bounded env51389 := by
  intro p hp
  have h : env51389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51388_51389 : H12AffineEnvironment.transform 6 111 env51388 = env51389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 111 env51388 == env51389) = true)

theorem identity51389 : scanCanonicalize (H12AffineFastState.compose env51389 (packedSelected [1,2,8] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound51389 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env51390 : List Nat := [2,3,8,16,32,64,104,19,512,73,634,80,3,74,0,104,75,0,2,1,81,33,64,41,40,90,123,26,74,593,9,91,19,91,26,586]

theorem envBound51390 : H12AffineFastState.Bounded env51390 := by
  intro p hp
  have h : env51390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51389_51390 : H12AffineEnvironment.transform 1 3 env51389 = env51390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env51389 == env51390) = true)

theorem identity51390 : scanCanonicalize (H12AffineFastState.compose env51390 (packedSelected [0,1,4,7,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound51390 : packedSelected [0,1,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env51391 : List Nat := [2,3,8,16,32,64,104,19,27,73,97,80,3,74,0,104,75,0,2,1,81,33,64,41,40,90,123,26,74,74,9,91,19,91,26,81]

theorem envBound51391 : H12AffineFastState.Bounded env51391 := by
  intro p hp
  have h : env51391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51390_51391 : H12AffineEnvironment.transform 8 27 env51390 = env51391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env51390 == env51391) = true)

theorem identity51391 : scanCanonicalize (H12AffineFastState.compose env51391 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound51391 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env51392 : List Nat := [2,3,8,11,32,64,104,8,0,73,97,75,3,74,0,104,75,0,2,1,74,33,64,41,40,65,96,1,74,74,9,64,8,64,1,74]

theorem envBound51392 : H12AffineFastState.Bounded env51392 := by
  intro p hp
  have h : env51392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51391_51392 : H12AffineEnvironment.transform 3 11 env51391 = env51392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env51391 == env51392) = true)

theorem identity51392 : scanCanonicalize (H12AffineFastState.compose env51392 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound51392 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51393 : List Nat := [2,3,8,11,32,11,35,8,0,2,42,0,3,1,0,35,0,0,2,1,1,33,11,41,40,10,43,1,1,1,9,11,8,11,1,1]

theorem envBound51393 : H12AffineFastState.Bounded env51393 := by
  intro p hp
  have h : env51393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51392_51393 : H12AffineEnvironment.transform 5 11 env51392 = env51393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env51392 == env51393) = true)

theorem identity51393 : scanCanonicalize (H12AffineFastState.compose env51393 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound51393 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51394 : List Nat := [2,3,1,2,32,2,35,1,0,2,35,0,3,1,0,35,0,0,2,1,1,33,2,32,33,3,34,1,1,1,0,2,1,2,1,1]

theorem envBound51394 : H12AffineFastState.Bounded env51394 := by
  intro p hp
  have h : env51394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51393_51394 : H12AffineEnvironment.transform 2 1 env51393 = env51394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env51393 == env51394) = true)

theorem identity51394 : scanCanonicalize (H12AffineFastState.compose env51394 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51394 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51395 : List Nat := [2,3,1,2,0,2,3,1,0,2,3,0,3,1,0,3,0,0,2,1,1,1,2,0,1,3,2,1,1,1,0,2,1,2,1,1]

theorem envBound51395 : H12AffineFastState.Bounded env51395 := by
  intro p hp
  have h : env51395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51394_51395 : H12AffineEnvironment.transform 4 0 env51394 = env51395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51394 == env51395) = true)

def env51396 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,9292,1063,8265,1191,272,9293,80,477,9496,1127,9624,8281,366,8216,1296,10556,8205,1281,256,1280,1344,1809]

theorem envBound51396 : H12AffineFastState.Bounded env51396 := by
  intro p hp
  have h : env51396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51383_51396 : H12AffineEnvironment.transform 11 81 env51383 = env51396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env51383 == env51396) = true)

theorem identity51396 : scanCanonicalize (H12AffineFastState.compose env51396 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound51396 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env51397 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,81,8192,1028,9292,1063,8265,1191,4,9293,80,201,9228,1127,9356,8281,122,8216,1028,10280,8205,1045,20,1044,1108,1541]

theorem envBound51397 : H12AffineFastState.Bounded env51397 := by
  intro p hp
  have h : env51397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51396_51397 : H12AffineEnvironment.transform 7 20 env51396 = env51397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env51396 == env51397) = true)

theorem identity51397 : scanCanonicalize (H12AffineFastState.compose env51397 (packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound51397 : packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS < 2^1333 := by decide +kernel

def env51398 : List Nat := [2,4,8,16,32,64,128,20,512,236,2048,81,8192,232,8352,203,8265,75,4,8353,80,201,8416,139,8288,8281,122,8216,232,10280,8205,249,20,248,184,745]

theorem envBound51398 : H12AffineFastState.Bounded env51398 := by
  intro p hp
  have h : env51398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51397_51398 : H12AffineEnvironment.transform 9 236 env51397 = env51398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env51397 == env51398) = true)

theorem identity51398 : scanCanonicalize (H12AffineFastState.compose env51398 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound51398 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env51399 : List Nat := [2,4,8,16,32,64,128,20,512,236,538,81,8192,232,8352,203,8265,75,4,8353,80,201,8416,139,8288,8281,122,8216,232,8754,8205,249,20,248,184,745]

theorem envBound51399 : H12AffineFastState.Bounded env51399 := by
  intro p hp
  have h : env51399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51398_51399 : H12AffineEnvironment.transform 10 538 env51398 = env51399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env51398 == env51399) = true)

theorem identity51399 : scanCanonicalize (H12AffineFastState.compose env51399 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 552) := by decide +kernel

theorem selectedBound51399 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env51400 : List Nat := [2,4,8,16,32,64,128,20,512,236,538,81,552,232,648,203,609,75,4,649,80,201,712,139,584,625,122,560,232,26,549,249,20,248,184,745]

theorem envBound51400 : H12AffineFastState.Bounded env51400 := by
  intro p hp
  have h : env51400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51399_51400 : H12AffineEnvironment.transform 12 552 env51399 = env51400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 552 env51399 == env51400) = true)

theorem identity51400 : scanCanonicalize (H12AffineFastState.compose env51400 (packedSelected [0,1,2,5,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 100) := by decide +kernel

theorem selectedBound51400 : packedSelected [0,1,2,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env51401 : List Nat := [2,4,8,16,32,64,100,20,512,8,538,81,552,12,620,47,609,75,4,621,80,45,556,111,584,625,122,560,12,26,549,29,20,28,92,525]

theorem envBound51401 : H12AffineFastState.Bounded env51401 := by
  intro p hp
  have h : env51401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51400_51401 : H12AffineEnvironment.transform 6 100 env51400 = env51401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 100 env51400 == env51401) = true)

theorem identity51401 : scanCanonicalize (H12AffineFastState.compose env51401 (packedSelected [1,2,3,5,8,10,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound51401 : packedSelected [1,2,3,5,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env51402 : List Nat := [2,4,8,16,32,64,100,20,26,8,0,81,50,12,118,47,123,75,4,119,80,45,54,111,82,107,122,42,12,26,63,29,20,28,92,23]

theorem envBound51402 : H12AffineFastState.Bounded env51402 := by
  intro p hp
  have h : env51402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51401_51402 : H12AffineEnvironment.transform 8 26 env51401 = env51402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env51401 == env51402) = true)

theorem identity51402 : scanCanonicalize (H12AffineFastState.compose env51402 (packedSelected [0,4,8,10] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound51402 : packedSelected [0,4,8,10] rootPS < 2^1333 := by decide +kernel

def env51403 : List Nat := [2,4,8,7,32,64,100,3,13,8,0,70,37,12,97,47,108,75,4,96,71,45,33,111,69,107,109,42,12,13,40,10,3,11,75,0]

theorem envBound51403 : H12AffineFastState.Bounded env51403 := by
  intro p hp
  have h : env51403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51402_51403 : H12AffineEnvironment.transform 3 7 env51402 = env51403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env51402 == env51403) = true)

theorem identity51403 : scanCanonicalize (H12AffineFastState.compose env51403 (packedSelected [1,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound51403 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env51404 : List Nat := [2,4,8,7,32,11,47,3,13,8,0,13,37,12,42,47,39,0,4,43,12,45,33,36,14,32,38,42,12,13,40,10,3,11,0,0]

theorem envBound51404 : H12AffineFastState.Bounded env51404 := by
  intro p hp
  have h : env51404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51403_51404 : H12AffineEnvironment.transform 5 11 env51403 = env51404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env51403 == env51404) = true)

theorem identity51404 : scanCanonicalize (H12AffineFastState.compose env51404 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound51404 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51405 : List Nat := [2,4,5,7,32,6,34,3,0,5,0,0,37,1,39,34,39,0,4,38,1,32,33,36,3,32,38,39,1,0,37,7,3,6,0,0]

theorem envBound51405 : H12AffineFastState.Bounded env51405 := by
  intro p hp
  have h : env51405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51404_51405 : H12AffineEnvironment.transform 2 5 env51404 = env51405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env51404 == env51405) = true)

theorem identity51405 : scanCanonicalize (H12AffineFastState.compose env51405 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound51405 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51406 : List Nat := [2,4,5,7,6,6,4,3,0,5,0,0,3,1,1,4,1,0,4,0,1,6,7,2,3,6,0,1,1,0,3,7,3,6,0,0]

theorem envBound51406 : H12AffineFastState.Bounded env51406 := by
  intro p hp
  have h : env51406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51405_51406 : H12AffineEnvironment.transform 4 6 env51405 = env51406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env51405 == env51406) = true)

def env51407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65665,4417,13340,4097,477,74047,69649,13769,78895,4414,74815,1296,81226,8205,1281,256,65831,1344,5952]

theorem envBound51407 : H12AffineFastState.Bounded env51407 := by
  intro p hp
  have h : env51407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51381_51407 : H12AffineEnvironment.transform 17 65665 env51381 = env51407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env51381 == env51407) = true)

theorem identity51407 : scanCanonicalize (H12AffineFastState.compose env51407 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound51407 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51408 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,311,9561,438,4417,13340,4097,477,8200,4390,13769,13592,4414,9480,1296,15485,8205,1281,256,16,1344,5952]

theorem envBound51408 : H12AffineFastState.Bounded env51408 := by
  intro p hp
  have h : env51408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51407_51408 : H12AffineEnvironment.transform 15 311 env51407 = env51408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env51407 == env51408) = true)

def env51409 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,12557,311,8265,438,4417,12556,4097,477,8200,4390,12505,12296,4414,8216,0,14701,8205,17,256,16,80,4688]

theorem envBound51409 : H12AffineFastState.Bounded env51409 := by
  intro p hp
  have h : env51409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51408_51409 : H12AffineEnvironment.transform 9 272 env51408 = env51409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env51408 == env51409) = true)

theorem identity51409 : scanCanonicalize (H12AffineFastState.compose env51409 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound51409 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env51410 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,325,8192,0,8264,311,8265,438,4,8265,324,477,8200,99,8604,8525,123,8216,0,10280,8205,17,256,16,80,789]

theorem envBound51410 : H12AffineFastState.Bounded env51410 := by
  intro p hp
  have h : env51410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51409_51410 : H12AffineEnvironment.transform 11 325 env51409 = env51410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env51409 == env51410) = true)

theorem identity51410 : scanCanonicalize (H12AffineFastState.compose env51410 (packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound51410 : packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS < 2^1333 := by decide +kernel

def env51411 : List Nat := [2,4,8,16,32,64,128,172,512,188,2048,233,8192,0,8264,155,8265,26,4,8265,232,113,8200,99,8240,8417,123,8216,0,10280,8205,17,172,16,80,697]

theorem envBound51411 : H12AffineFastState.Bounded env51411 := by
  intro p hp
  have h : env51411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51410_51411 : H12AffineEnvironment.transform 7 172 env51410 = env51411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env51410 == env51411) = true)

theorem identity51411 : scanCanonicalize (H12AffineFastState.compose env51411 (packedSelected [0,3,5,7,10,12,13,18] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound51411 : packedSelected [0,3,5,7,10,12,13,18] rootPS < 2^1333 := by decide +kernel

def env51412 : List Nat := [2,4,8,16,32,32,128,172,512,188,2048,137,8192,0,8232,155,8233,26,4,8233,136,17,8200,3,8240,8321,27,8216,0,10280,8205,17,172,16,48,697]

theorem envBound51412 : H12AffineFastState.Bounded env51412 := by
  intro p hp
  have h : env51412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51411_51412 : H12AffineEnvironment.transform 5 32 env51411 = env51412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env51411 == env51412) = true)

theorem identity51412 : scanCanonicalize (H12AffineFastState.compose env51412 (packedSelected [2,3,13,16] rootPS)) = affineNative (2^(8+1) ^^^ 133) := by decide +kernel

theorem selectedBound51412 : packedSelected [2,3,13,16] rootPS < 2^1333 := by decide +kernel

def env51413 : List Nat := [2,4,8,16,32,32,128,172,133,188,2048,137,8192,0,8232,155,8233,26,4,8233,136,17,8200,3,8240,8321,27,8216,0,10280,8205,17,172,16,48,60]

theorem envBound51413 : H12AffineFastState.Bounded env51413 := by
  intro p hp
  have h : env51413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51412_51413 : H12AffineEnvironment.transform 8 133 env51412 = env51413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 133 env51412 == env51413) = true)

theorem identity51413 : scanCanonicalize (H12AffineFastState.compose env51413 (packedSelected [4,9,11,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound51413 : packedSelected [4,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env51414 : List Nat := [2,4,8,16,32,32,128,172,133,188,0,137,8192,0,8232,155,8233,26,4,8233,136,17,8200,3,8240,8321,27,8216,0,8232,8205,17,172,16,48,60]

theorem envBound51414 : H12AffineFastState.Bounded env51414 := by
  intro p hp
  have h : env51414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51413_51414 : H12AffineEnvironment.transform 10 0 env51413 = env51414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env51413 == env51414) = true)

theorem identity51414 : scanCanonicalize (H12AffineFastState.compose env51414 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound51414 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env51415 : List Nat := [2,4,8,16,32,32,128,172,133,188,0,137,161,0,137,155,136,26,4,136,136,17,169,3,145,32,27,185,0,137,172,17,172,16,48,60]

theorem envBound51415 : H12AffineFastState.Bounded env51415 := by
  intro p hp
  have h : env51415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51414_51415 : H12AffineEnvironment.transform 12 161 env51414 = env51415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env51414 == env51415) = true)

theorem identity51415 : scanCanonicalize (H12AffineFastState.compose env51415 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 53) := by decide +kernel

theorem selectedBound51415 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51416 : List Nat := [2,4,8,16,32,32,53,25,48,9,0,60,20,0,60,46,61,26,4,61,61,17,28,3,36,32,27,12,0,60,25,17,25,16,48,60]

theorem envBound51416 : H12AffineFastState.Bounded env51416 := by
  intro p hp
  have h : env51416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51415_51416 : H12AffineEnvironment.transform 6 53 env51415 = env51416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 53 env51415 == env51416) = true)

theorem identity51416 : scanCanonicalize (H12AffineFastState.compose env51416 (packedSelected [4,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound51416 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env51417 : List Nat := [2,4,8,16,10,10,31,25,26,9,0,22,20,0,22,4,23,26,4,23,23,17,28,3,14,10,27,12,0,22,25,17,25,16,26,22]

theorem envBound51417 : H12AffineFastState.Bounded env51417 := by
  intro p hp
  have h : env51417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51416_51417 : H12AffineEnvironment.transform 4 10 env51416 = env51417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env51416 == env51417) = true)

theorem identity51417 : scanCanonicalize (H12AffineFastState.compose env51417 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound51417 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51418 : List Nat := [2,4,8,11,10,10,4,2,1,9,0,13,15,0,13,4,12,1,4,12,12,10,7,3,14,10,0,12,0,13,2,10,2,11,1,13]

theorem envBound51418 : H12AffineFastState.Bounded env51418 := by
  intro p hp
  have h : env51418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51417_51418 : H12AffineEnvironment.transform 3 11 env51417 = env51418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env51417 == env51418) = true)

theorem identity51418 : scanCanonicalize (H12AffineFastState.compose env51418 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound51418 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env51419 : List Nat := [2,4,5,6,7,7,4,2,1,4,0,0,2,0,0,4,1,1,4,1,1,7,7,3,3,7,0,1,0,0,2,7,2,6,1,0]

theorem envBound51419 : H12AffineFastState.Bounded env51419 := by
  intro p hp
  have h : env51419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51418_51419 : H12AffineEnvironment.transform 2 5 env51418 = env51419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env51418 == env51419) = true)

theorem identity51419 : scanCanonicalize (H12AffineFastState.compose env51419 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound51419 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51420 : List Nat := [2,0,1,2,3,3,0,2,1,0,0,0,2,0,0,0,1,1,0,1,1,3,3,3,3,3,0,1,0,0,2,3,2,2,1,0]

theorem envBound51420 : H12AffineFastState.Bounded env51420 := by
  intro p hp
  have h : env51420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51419_51420 : H12AffineEnvironment.transform 1 0 env51419 = env51420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env51419 == env51420) = true)

theorem identity51420 : scanCanonicalize (H12AffineFastState.compose env51420 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound51420 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51421 : List Nat := [1,0,1,1,0,0,0,1,1,0,0,0,1,0,0,0,1,1,0,1,1,0,0,0,0,0,0,1,0,0,1,0,1,1,1,0]

theorem envBound51421 : H12AffineFastState.Bounded env51421 := by
  intro p hp
  have h : env51421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51420_51421 : H12AffineEnvironment.transform 0 1 env51420 = env51421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env51420 == env51421) = true)

def env51422 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,1,12556,311,8264,438,4417,12557,4097,477,8200,4390,12504,12297,4414,8217,1,14700,8205,16,256,16,81,4689]

theorem envBound51422 : H12AffineFastState.Bounded env51422 := by
  intro p hp
  have h : env51422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51408_51422 : H12AffineEnvironment.transform 9 273 env51408 = env51422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env51408 == env51422) = true)

theorem identity51422 : scanCanonicalize (H12AffineFastState.compose env51422 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound51422 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env51423 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,72,1,4420,311,0,438,4417,4421,4097,477,64,4390,4240,4161,4414,81,1,6436,69,16,256,16,81,4689]

theorem envBound51423 : H12AffineFastState.Bounded env51423 := by
  intro p hp
  have h : env51423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51422_51423 : H12AffineEnvironment.transform 12 72 env51422 = env51423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env51422 == env51423) = true)

theorem identity51423 : scanCanonicalize (H12AffineFastState.compose env51423 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound51423 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51424 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,324,72,1,0,311,0,438,5,1,325,477,64,98,468,261,122,81,1,2144,69,16,256,16,81,789]

theorem envBound51424 : H12AffineFastState.Bounded env51424 := by
  intro p hp
  have h : env51424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51423_51424 : H12AffineEnvironment.transform 11 324 env51423 = env51424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env51423 == env51424) = true)

theorem identity51424 : scanCanonicalize (H12AffineFastState.compose env51424 (packedSelected [0,2,3,7,10,11,12,13,15,19] rootPS)) = affineNative (2^(8+1) ^^^ 465) := by decide +kernel

theorem selectedBound51424 : packedSelected [0,2,3,7,10,11,12,13,15,19] rootPS < 2^1333 := by decide +kernel

def env51425 : List Nat := [2,4,8,16,32,64,128,256,465,273,2048,324,72,1,0,311,0,438,5,1,325,477,64,98,468,261,122,81,1,2144,69,16,256,16,81,196]

theorem envBound51425 : H12AffineFastState.Bounded env51425 := by
  intro p hp
  have h : env51425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51424_51425 : H12AffineEnvironment.transform 8 465 env51424 = env51425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 465 env51424 == env51425) = true)

theorem identity51425 : scanCanonicalize (H12AffineFastState.compose env51425 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound51425 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env51426 : List Nat := [2,4,8,16,32,64,128,21,196,4,2048,81,72,1,0,34,0,163,5,1,80,200,64,98,193,16,122,81,1,2144,69,16,21,16,81,196]

theorem envBound51426 : H12AffineFastState.Bounded env51426 := by
  intro p hp
  have h : env51426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51425_51426 : H12AffineEnvironment.transform 7 21 env51425 = env51426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env51425 == env51426) = true)

theorem identity51426 : scanCanonicalize (H12AffineFastState.compose env51426 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound51426 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51427 : List Nat := [2,4,8,12,32,64,128,9,196,4,2048,77,72,1,0,34,0,163,5,1,76,200,64,98,193,12,102,77,1,2144,69,12,9,12,77,196]

theorem envBound51427 : H12AffineFastState.Bounded env51427 := by
  intro p hp
  have h : env51427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51426_51427 : H12AffineEnvironment.transform 3 12 env51426 = env51427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env51426 == env51427) = true)

theorem identity51427 : scanCanonicalize (H12AffineFastState.compose env51427 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound51427 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env51428 : List Nat := [2,4,8,12,32,10,128,9,142,4,2048,7,2,1,0,34,0,163,5,1,6,130,10,40,139,12,44,7,1,2090,15,12,9,12,7,142]

theorem envBound51428 : H12AffineFastState.Bounded env51428 := by
  intro p hp
  have h : env51428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51427_51428 : H12AffineEnvironment.transform 5 10 env51427 = env51428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env51427 == env51428) = true)

theorem identity51428 : scanCanonicalize (H12AffineFastState.compose env51428 (packedSelected [1,2,8] rootPS)) = affineNative (2^(10+1) ^^^ 143) := by decide +kernel

theorem selectedBound51428 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env51429 : List Nat := [2,4,8,12,32,10,128,9,142,4,143,7,2,1,0,34,0,163,5,1,6,130,10,40,139,12,44,7,1,165,15,12,9,12,7,142]

theorem envBound51429 : H12AffineFastState.Bounded env51429 := by
  intro p hp
  have h : env51429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51428_51429 : H12AffineEnvironment.transform 10 143 env51428 = env51429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 143 env51428 == env51429) = true)

theorem identity51429 : scanCanonicalize (H12AffineFastState.compose env51429 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound51429 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51430 : List Nat := [2,4,8,12,12,10,128,9,142,4,143,7,2,1,0,14,0,143,5,1,6,130,10,4,139,12,0,7,1,137,15,12,9,12,7,142]

theorem envBound51430 : H12AffineFastState.Bounded env51430 := by
  intro p hp
  have h : env51430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51429_51430 : H12AffineEnvironment.transform 4 12 env51429 = env51430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env51429 == env51430) = true)

theorem identity51430 : scanCanonicalize (H12AffineFastState.compose env51430 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound51430 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51431 : List Nat := [2,4,8,12,12,10,14,9,0,4,1,7,2,1,0,14,0,1,5,1,6,12,10,4,5,12,0,7,1,7,15,12,9,12,7,0]

theorem envBound51431 : H12AffineFastState.Bounded env51431 := by
  intro p hp
  have h : env51431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51430_51431 : H12AffineEnvironment.transform 6 14 env51430 = env51431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env51430 == env51431) = true)

theorem identity51431 : scanCanonicalize (H12AffineFastState.compose env51431 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound51431 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51432 : List Nat := [2,2,8,10,10,10,8,9,0,2,1,1,2,1,0,8,0,1,3,1,0,10,10,2,3,10,0,1,1,1,9,10,9,10,1,0]

theorem envBound51432 : H12AffineFastState.Bounded env51432 := by
  intro p hp
  have h : env51432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51431_51432 : H12AffineEnvironment.transform 1 2 env51431 = env51432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env51431 == env51432) = true)

def env51433 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,262144,4416,13340,4097,476,74046,69648,13768,78895,332222,74814,1296,81227,8204,1281,256,65830,1344,5953]

theorem envBound51433 : H12AffineFastState.Bounded env51433 := by
  intro p hp
  have h : env51433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51380_51433 : H12AffineEnvironment.transform 13 1297 env51380 = env51433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env51380 == env51433) = true)

def env51434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65664,4416,13340,4097,476,74046,69648,13768,78895,4414,74814,1296,81227,8204,1281,256,65830,1344,5953]

theorem envBound51434 : H12AffineFastState.Bounded env51434 := by
  intro p hp
  have h : env51434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51433_51434 : H12AffineEnvironment.transform 17 65664 env51433 = env51434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env51433 == env51434) = true)

theorem identity51434 : scanCanonicalize (H12AffineFastState.compose env51434 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9279) := by decide +kernel

theorem selectedBound51434 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,9279,81,9407,4416,13340,4097,476,1281,13359,13768,4112,4414,1,1296,6516,8204,1281,256,9497,1344,5953]

theorem envBound51435 : H12AffineFastState.Bounded env51435 := by
  intro p hp
  have h : env51435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51434_51435 : H12AffineEnvironment.transform 15 9279 env51434 = env51435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9279 env51434 == env51435) = true)

def env51436 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,12557,8495,81,8623,4416,12556,4097,476,17,12607,12504,4112,4414,1,0,6516,8204,17,256,8201,80,4689]

theorem envBound51436 : H12AffineFastState.Bounded env51436 := by
  intro p hp
  have h : env51436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51435_51436 : H12AffineEnvironment.transform 9 272 env51435 = env51436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env51435 == env51436) = true)

theorem identity51436 : scanCanonicalize (H12AffineFastState.compose env51436 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound51436 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env51437 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,72,1,4421,359,81,487,4416,4420,4097,476,17,4471,4240,4112,4414,1,0,6516,68,17,256,65,80,4689]

theorem envBound51437 : H12AffineFastState.Bounded env51437 := by
  intro p hp
  have h : env51437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51436_51437 : H12AffineEnvironment.transform 12 72 env51436 = env51437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env51436 == env51437) = true)

theorem identity51437 : scanCanonicalize (H12AffineFastState.compose env51437 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 509) := by decide +kernel

theorem selectedBound51437 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env51438 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,509,72,1,184,359,81,487,189,185,508,476,17,138,365,493,195,1,0,2185,68,17,256,65,80,940]

theorem envBound51438 : H12AffineFastState.Bounded env51438 := by
  intro p hp
  have h : env51438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51437_51438 : H12AffineEnvironment.transform 11 509 env51437 = env51438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 509 env51437 == env51438) = true)

theorem identity51438 : scanCanonicalize (H12AffineFastState.compose env51438 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound51438 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env51439 : List Nat := [2,4,8,16,32,64,128,256,372,272,2048,509,72,1,184,359,81,487,189,185,508,476,17,138,365,493,195,1,0,2185,68,17,256,65,80,216]

theorem envBound51439 : H12AffineFastState.Bounded env51439 := by
  intro p hp
  have h : env51439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51438_51439 : H12AffineEnvironment.transform 8 372 env51438 = env51439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env51438 == env51439) = true)

theorem identity51439 : scanCanonicalize (H12AffineFastState.compose env51439 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound51439 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env51440 : List Nat := [2,4,8,16,32,64,66,256,372,272,2048,319,72,1,122,359,81,293,127,123,318,286,17,72,365,303,1,1,0,2123,68,17,256,65,80,26]

theorem envBound51440 : H12AffineFastState.Bounded env51440 := by
  intro p hp
  have h : env51440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51439_51440 : H12AffineEnvironment.transform 6 66 env51439 = env51440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env51439 == env51440) = true)

theorem identity51440 : scanCanonicalize (H12AffineFastState.compose env51440 (packedSelected [0,3,4,7,8,9,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound51440 : packedSelected [0,3,4,7,8,9,12,13] rootPS < 2^1333 := by decide +kernel

def env51441 : List Nat := [2,4,8,16,32,64,66,68,48,84,2048,123,72,1,122,35,81,97,127,123,122,90,17,72,41,107,1,1,0,2123,68,17,68,65,80,26]

theorem envBound51441 : H12AffineFastState.Bounded env51441 := by
  intro p hp
  have h : env51441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51440_51441 : H12AffineEnvironment.transform 7 68 env51440 = env51441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env51440 == env51441) = true)

theorem identity51441 : scanCanonicalize (H12AffineFastState.compose env51441 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound51441 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env51442 : List Nat := [2,4,8,16,32,58,56,62,48,46,2048,1,50,1,0,35,43,27,5,1,0,32,17,50,41,17,1,1,0,2097,62,17,62,59,42,26]

theorem envBound51442 : H12AffineFastState.Bounded env51442 := by
  intro p hp
  have h : env51442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51441_51442 : H12AffineEnvironment.transform 5 58 env51441 = env51442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env51441 == env51442) = true)

theorem identity51442 : scanCanonicalize (H12AffineFastState.compose env51442 (packedSelected [0,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 28) := by decide +kernel

theorem selectedBound51442 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env51443 : List Nat := [2,4,8,16,32,58,56,62,48,46,28,1,50,1,0,35,43,27,5,1,0,32,17,50,41,17,1,1,0,45,62,17,62,59,42,26]

theorem envBound51443 : H12AffineFastState.Bounded env51443 := by
  intro p hp
  have h : env51443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51442_51443 : H12AffineEnvironment.transform 10 28 env51442 = env51443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 28 env51442 == env51443) = true)

theorem identity51443 : scanCanonicalize (H12AffineFastState.compose env51443 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound51443 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env51444 : List Nat := [2,4,8,11,32,33,35,37,43,46,7,1,41,1,0,35,43,0,5,1,0,32,10,41,41,10,1,1,0,45,37,10,37,32,42,1]

theorem envBound51444 : H12AffineFastState.Bounded env51444 := by
  intro p hp
  have h : env51444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51443_51444 : H12AffineEnvironment.transform 3 11 env51443 = env51444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env51443 == env51444) = true)

theorem identity51444 : scanCanonicalize (H12AffineFastState.compose env51444 (packedSelected [1,2,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound51444 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env51445 : List Nat := [2,2,8,11,32,33,35,35,43,40,1,1,41,1,0,35,43,0,3,1,0,32,10,41,41,10,1,1,0,43,35,10,35,32,42,1]

theorem envBound51445 : H12AffineFastState.Bounded env51445 := by
  intro p hp
  have h : env51445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51444_51445 : H12AffineEnvironment.transform 1 2 env51444 = env51445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env51444 == env51445) = true)

theorem identity51445 : scanCanonicalize (H12AffineFastState.compose env51445 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound51445 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51446 : List Nat := [2,2,8,11,11,10,8,8,0,3,1,1,2,1,0,8,0,0,3,1,0,11,10,2,2,10,1,1,0,0,8,10,8,11,1,1]

theorem envBound51446 : H12AffineFastState.Bounded env51446 := by
  intro p hp
  have h : env51446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51445_51446 : H12AffineEnvironment.transform 4 11 env51445 = env51446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env51445 == env51446) = true)

theorem identity51446 : scanCanonicalize (H12AffineFastState.compose env51446 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound51446 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51447 : List Nat := [0,0,8,9,9,8,8,8,0,1,1,1,0,1,0,8,0,0,1,1,0,9,8,0,0,8,1,1,0,0,8,8,8,9,1,1]

theorem envBound51447 : H12AffineFastState.Bounded env51447 := by
  intro p hp
  have h : env51447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51446_51447 : H12AffineEnvironment.transform 0 0 env51446 = env51447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env51446 == env51447) = true)

theorem identity51447 : scanCanonicalize (H12AffineFastState.compose env51447 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound51447 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51448 : List Nat := [0,0,0,1,1,0,0,0,0,1,1,1,0,1,0,0,0,0,1,1,0,1,0,0,0,0,1,1,0,0,0,0,0,1,1,1]

theorem envBound51448 : H12AffineFastState.Bounded env51448 := by
  intro p hp
  have h : env51448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51447_51448 : H12AffineEnvironment.transform 2 0 env51447 = env51448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env51447 == env51448) = true)

def env51449 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,12556,8494,81,8622,4416,12557,4097,476,16,12606,12505,4112,4414,1,1,6516,8204,16,256,8200,81,4688]

theorem envBound51449 : H12AffineFastState.Bounded env51449 := by
  intro p hp
  have h : env51449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51435_51449 : H12AffineEnvironment.transform 9 273 env51435 = env51449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env51435 == env51449) = true)

theorem identity51449 : scanCanonicalize (H12AffineFastState.compose env51449 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4445) := by decide +kernel

theorem selectedBound51449 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env51450 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,4445,0,81,4211,81,4339,4416,80,4097,476,16,99,388,4112,4414,1,1,6516,4433,16,256,4437,81,4688]

theorem envBound51450 : H12AffineFastState.Bounded env51450 := by
  intro p hp
  have h : env51450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51449_51450 : H12AffineEnvironment.transform 12 4445 env51449 = env51450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4445 env51449 == env51450) = true)

theorem identity51450 : scanCanonicalize (H12AffineFastState.compose env51450 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound51450 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env51451 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,80,269,0,81,35,81,163,272,80,81,476,16,99,388,64,366,1,1,2340,257,16,256,261,81,512]

theorem envBound51451 : H12AffineFastState.Bounded env51451 := by
  intro p hp
  have h : env51451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51450_51451 : H12AffineEnvironment.transform 11 80 env51450 = env51451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env51450 == env51451) = true)

theorem identity51451 : scanCanonicalize (H12AffineFastState.compose env51451 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound51451 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env51452 : List Nat := [2,4,8,16,32,64,104,256,512,273,2048,80,269,0,81,35,81,75,272,80,81,308,16,99,364,64,366,1,1,2340,257,16,256,261,81,512]

theorem envBound51452 : H12AffineFastState.Bounded env51452 := by
  intro p hp
  have h : env51452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51451_51452 : H12AffineEnvironment.transform 6 104 env51451 = env51452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env51451 == env51452) = true)

theorem identity51452 : scanCanonicalize (H12AffineFastState.compose env51452 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound51452 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51453 : List Nat := [2,4,8,16,32,64,104,256,48,273,2048,80,269,0,81,35,81,75,272,80,81,308,16,99,364,64,366,1,1,2340,257,16,256,261,81,48]

theorem envBound51453 : H12AffineFastState.Bounded env51453 := by
  intro p hp
  have h : env51453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51452_51453 : H12AffineEnvironment.transform 8 48 env51452 = env51453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env51452 == env51453) = true)

theorem identity51453 : scanCanonicalize (H12AffineFastState.compose env51453 (packedSelected [0,7,10,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 366) := by decide +kernel

theorem selectedBound51453 : packedSelected [0,7,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env51454 : List Nat := [2,4,8,16,32,64,104,256,48,273,366,80,269,0,81,35,81,75,272,80,81,308,16,99,364,64,366,1,1,74,257,16,256,261,81,48]

theorem envBound51454 : H12AffineFastState.Bounded env51454 := by
  intro p hp
  have h : env51454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51453_51454 : H12AffineEnvironment.transform 10 366 env51453 = env51454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 366 env51453 == env51454) = true)

theorem identity51454 : scanCanonicalize (H12AffineFastState.compose env51454 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound51454 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51455 : List Nat := [2,4,8,16,32,10,34,256,48,273,292,26,269,0,27,35,27,1,272,26,27,308,16,41,294,10,292,1,1,0,257,16,256,261,27,48]

theorem envBound51455 : H12AffineFastState.Bounded env51455 := by
  intro p hp
  have h : env51455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51454_51455 : H12AffineEnvironment.transform 5 10 env51454 = env51455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env51454 == env51455) = true)

theorem identity51455 : scanCanonicalize (H12AffineFastState.compose env51455 (packedSelected [0,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound51455 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env51456 : List Nat := [2,4,8,16,11,10,9,256,27,273,271,26,269,0,27,8,27,1,272,26,27,287,16,2,269,10,271,1,1,0,257,16,256,261,27,27]

theorem envBound51456 : H12AffineFastState.Bounded env51456 := by
  intro p hp
  have h : env51456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51455_51456 : H12AffineEnvironment.transform 4 11 env51455 = env51456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env51455 == env51456) = true)

theorem identity51456 : scanCanonicalize (H12AffineFastState.compose env51456 (packedSelected [0,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound51456 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env51457 : List Nat := [2,4,8,16,11,10,9,15,27,30,0,26,2,0,27,8,27,1,31,26,27,16,16,2,2,10,0,1,1,0,14,16,15,10,27,27]

theorem envBound51457 : H12AffineFastState.Bounded env51457 := by
  intro p hp
  have h : env51457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51456_51457 : H12AffineEnvironment.transform 7 15 env51456 = env51457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env51456 == env51457) = true)

theorem identity51457 : scanCanonicalize (H12AffineFastState.compose env51457 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound51457 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51458 : List Nat := [2,4,8,11,11,10,9,15,0,5,0,1,2,0,0,8,0,1,4,1,0,11,11,2,2,10,0,1,1,0,14,11,15,10,0,0]

theorem envBound51458 : H12AffineFastState.Bounded env51458 := by
  intro p hp
  have h : env51458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51457_51458 : H12AffineEnvironment.transform 3 11 env51457 = env51458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env51457 == env51458) = true)

theorem identity51458 : scanCanonicalize (H12AffineFastState.compose env51458 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound51458 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51459 : List Nat := [2,4,5,6,6,7,4,2,0,5,0,1,2,0,0,5,0,1,4,1,0,6,6,2,2,7,0,1,1,0,3,6,2,7,0,0]

theorem envBound51459 : H12AffineFastState.Bounded env51459 := by
  intro p hp
  have h : env51459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51458_51459 : H12AffineEnvironment.transform 2 5 env51458 = env51459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env51458 == env51459) = true)

def env51460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65665,4416,13340,4097,476,74046,69648,13768,78895,4415,74814,1296,81227,8204,1281,256,65830,1344,5953]

theorem envBound51460 : H12AffineFastState.Bounded env51460 := by
  intro p hp
  have h : env51460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51433_51460 : H12AffineEnvironment.transform 17 65665 env51433 = env51460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env51433 == env51460) = true)

theorem identity51460 : scanCanonicalize (H12AffineFastState.compose env51460 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12671) := by decide +kernel

theorem selectedBound51460 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,12671,5393,12798,4416,13340,4097,476,4161,8559,13768,1360,4415,5441,1296,3124,8204,1281,256,12377,1344,5953]

theorem envBound51461 : H12AffineFastState.Bounded env51461 := by
  intro p hp
  have h : env51461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51460_51461 : H12AffineEnvironment.transform 15 12671 env51460 = env51461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12671 env51460 == env51461) = true)

def env51462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,9293,8495,1345,8622,272,9292,81,476,17,8559,9624,1360,367,1297,1296,3124,8204,1281,256,8201,1344,1809]

theorem envBound51462 : H12AffineFastState.Bounded env51462 := by
  intro p hp
  have h : env51462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51461_51462 : H12AffineEnvironment.transform 11 80 env51461 = env51462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env51461 == env51462) = true)

theorem identity51462 : scanCanonicalize (H12AffineFastState.compose env51462 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1368) := by decide +kernel

theorem selectedBound51462 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env51463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1368,1297,277,1143,1345,1270,272,276,81,476,17,1079,192,1360,367,1297,1296,3124,1364,1281,256,1361,1344,1809]

theorem envBound51463 : H12AffineFastState.Bounded env51463 := by
  intro p hp
  have h : env51463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51462_51463 : H12AffineEnvironment.transform 12 1368 env51462 = env51463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1368 env51462 == env51463) = true)

theorem identity51463 : scanCanonicalize (H12AffineFastState.compose env51463 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound51463 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env51464 : List Nat := [2,4,8,16,32,64,128,256,512,189,2048,80,485,428,277,202,508,75,272,276,81,476,17,138,192,493,367,428,429,2185,489,444,256,492,509,940]

theorem envBound51464 : H12AffineFastState.Bounded env51464 := by
  intro p hp
  have h : env51464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51463_51464 : H12AffineEnvironment.transform 9 189 env51463 = env51464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env51463 == env51464) = true)

theorem identity51464 : scanCanonicalize (H12AffineFastState.compose env51464 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound51464 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env51465 : List Nat := [2,4,8,16,32,64,128,256,372,189,2048,80,485,428,277,202,508,75,272,276,81,476,17,138,192,493,367,428,429,2185,489,444,256,492,509,216]

theorem envBound51465 : H12AffineFastState.Bounded env51465 := by
  intro p hp
  have h : env51465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51464_51465 : H12AffineEnvironment.transform 8 372 env51464 = env51465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env51464 == env51465) = true)

theorem identity51465 : scanCanonicalize (H12AffineFastState.compose env51465 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(7+1) ^^^ 111) := by decide +kernel

theorem selectedBound51465 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env51466 : List Nat := [2,4,8,16,32,64,128,111,27,189,2048,80,138,195,122,202,147,75,127,123,81,179,17,138,192,130,0,195,194,2185,134,211,111,131,146,216]

theorem envBound51466 : H12AffineFastState.Bounded env51466 := by
  intro p hp
  have h : env51466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51465_51466 : H12AffineEnvironment.transform 7 111 env51465 = env51466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 111 env51465 == env51466) = true)

theorem identity51466 : scanCanonicalize (H12AffineFastState.compose env51466 (packedSelected [0,2,4,7,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound51466 : packedSelected [0,2,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env51467 : List Nat := [2,4,8,16,32,64,128,111,27,189,146,80,138,195,122,202,147,75,127,123,81,179,17,138,192,130,0,195,194,27,134,211,111,131,146,216]

theorem envBound51467 : H12AffineFastState.Bounded env51467 := by
  intro p hp
  have h : env51467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51466_51467 : H12AffineEnvironment.transform 10 146 env51466 = env51467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env51466 == env51467) = true)

theorem identity51467 : scanCanonicalize (H12AffineFastState.compose env51467 (packedSelected [1,2,4,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound51467 : packedSelected [1,2,4,5,9] rootPS < 2^1333 := by decide +kernel

def env51468 : List Nat := [2,4,8,16,32,33,128,14,27,189,146,49,138,162,27,171,147,42,30,26,48,179,17,138,161,130,0,162,163,27,134,178,14,131,146,185]

theorem envBound51468 : H12AffineFastState.Bounded env51468 := by
  intro p hp
  have h : env51468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51467_51468 : H12AffineEnvironment.transform 5 33 env51467 = env51468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env51467 == env51468) = true)

theorem identity51468 : scanCanonicalize (H12AffineFastState.compose env51468 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound51468 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env51469 : List Nat := [2,4,8,16,10,11,128,14,27,151,146,27,138,136,27,129,147,0,30,26,26,153,17,138,139,130,0,136,137,27,134,152,14,131,146,147]

theorem envBound51469 : H12AffineFastState.Bounded env51469 := by
  intro p hp
  have h : env51469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51468_51469 : H12AffineEnvironment.transform 4 10 env51468 = env51469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env51468 == env51469) = true)

theorem identity51469 : scanCanonicalize (H12AffineFastState.compose env51469 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound51469 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51470 : List Nat := [2,4,8,16,10,11,9,14,27,30,27,27,3,1,27,8,26,0,30,26,26,16,17,3,2,11,0,1,0,27,15,17,14,10,27,26]

theorem envBound51470 : H12AffineFastState.Bounded env51470 := by
  intro p hp
  have h : env51470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51469_51470 : H12AffineEnvironment.transform 6 9 env51469 = env51470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51469 == env51470) = true)

theorem identity51470 : scanCanonicalize (H12AffineFastState.compose env51470 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound51470 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env51471 : List Nat := [2,4,1,16,3,2,0,7,18,23,18,18,3,1,18,1,19,0,23,19,19,16,17,3,2,2,0,1,0,18,6,17,7,3,18,19]

theorem envBound51471 : H12AffineFastState.Bounded env51471 := by
  intro p hp
  have h : env51471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51470_51471 : H12AffineEnvironment.transform 2 1 env51470 = env51471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env51470 == env51471) = true)

theorem identity51471 : scanCanonicalize (H12AffineFastState.compose env51471 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound51471 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env51472 : List Nat := [2,4,1,3,3,2,0,7,1,4,1,1,3,1,1,1,0,0,4,0,0,3,2,3,2,2,0,1,0,1,6,2,7,3,1,0]

theorem envBound51472 : H12AffineFastState.Bounded env51472 := by
  intro p hp
  have h : env51472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51471_51472 : H12AffineEnvironment.transform 3 3 env51471 = env51472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env51471 == env51472) = true)

theorem identity51472 : scanCanonicalize (H12AffineFastState.compose env51472 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound51472 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51473 : List Nat := [2,0,1,3,3,2,0,3,1,0,1,1,3,1,1,1,0,0,0,0,0,3,2,3,2,2,0,1,0,1,2,2,3,3,1,0]

theorem envBound51473 : H12AffineFastState.Bounded env51473 := by
  intro p hp
  have h : env51473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51472_51473 : H12AffineEnvironment.transform 1 0 env51472 = env51473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env51472 == env51473) = true)

theorem identity51473 : scanCanonicalize (H12AffineFastState.compose env51473 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound51473 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51474 : List Nat := [1,0,1,0,0,1,0,0,1,0,1,1,0,1,1,1,0,0,0,0,0,0,1,0,1,1,0,1,0,1,1,1,0,0,1,0]

theorem envBound51474 : H12AffineFastState.Bounded env51474 := by
  intro p hp
  have h : env51474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51473_51474 : H12AffineEnvironment.transform 0 1 env51473 = env51474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env51473 == env51474) = true)

def env51475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,9292,8494,1344,8623,273,9293,80,476,16,8559,9625,1360,366,1296,1296,3124,8204,1281,256,8200,1344,1808]

theorem envBound51475 : H12AffineFastState.Bounded env51475 := by
  intro p hp
  have h : env51475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51461_51475 : H12AffineEnvironment.transform 11 81 env51461 = env51475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env51461 == env51475) = true)

theorem identity51475 : scanCanonicalize (H12AffineFastState.compose env51475 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound51475 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env51476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,1053,1297,81,1331,1344,1458,273,80,80,476,16,1394,388,1360,366,1296,1296,3124,1041,1281,256,1045,1344,1808]

theorem envBound51476 : H12AffineFastState.Bounded env51476 := by
  intro p hp
  have h : env51476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51475_51476 : H12AffineEnvironment.transform 12 1053 env51475 = env51476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env51475 == env51476) = true)

theorem identity51476 : scanCanonicalize (H12AffineFastState.compose env51476 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound51476 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env51477 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,81,269,1,81,35,80,162,273,80,80,476,16,98,388,64,366,0,0,2340,257,17,256,261,80,512]

theorem envBound51477 : H12AffineFastState.Bounded env51477 := by
  intro p hp
  have h : env51477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51476_51477 : H12AffineEnvironment.transform 9 272 env51476 = env51477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env51476 == env51477) = true)

theorem identity51477 : scanCanonicalize (H12AffineFastState.compose env51477 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51477 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51478 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,269,1,0,35,1,162,273,1,1,397,16,51,388,17,319,0,0,2340,257,17,256,261,1,512]

theorem envBound51478 : H12AffineFastState.Bounded env51478 := by
  intro p hp
  have h : env51478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51477_51478 : H12AffineEnvironment.transform 5 17 env51477 = env51478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51477 == env51478) = true)

theorem identity51478 : scanCanonicalize (H12AffineFastState.compose env51478 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound51478 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env51479 : List Nat := [2,4,8,16,32,17,128,256,0,272,2048,0,269,1,0,35,1,162,273,1,1,397,16,51,388,17,319,0,0,2340,257,17,256,261,1,0]

theorem envBound51479 : H12AffineFastState.Bounded env51479 := by
  intro p hp
  have h : env51479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51478_51479 : H12AffineEnvironment.transform 8 0 env51478 = env51479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env51478 == env51479) = true)

theorem identity51479 : scanCanonicalize (H12AffineFastState.compose env51479 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound51479 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env51480 : List Nat := [2,4,8,16,32,17,128,256,0,272,27,0,269,1,0,35,1,162,273,1,1,397,16,51,388,17,319,0,0,319,257,17,256,261,1,0]

theorem envBound51480 : H12AffineFastState.Bounded env51480 := by
  intro p hp
  have h : env51480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51479_51480 : H12AffineEnvironment.transform 10 27 env51479 = env51480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env51479 == env51480) = true)

theorem identity51480 : scanCanonicalize (H12AffineFastState.compose env51480 (packedSelected [0,2,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound51480 : packedSelected [0,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env51481 : List Nat := [2,4,8,16,17,17,128,256,0,272,27,0,269,1,0,18,1,147,273,1,1,397,16,2,388,17,270,0,0,270,257,17,256,261,1,0]

theorem envBound51481 : H12AffineFastState.Bounded env51481 := by
  intro p hp
  have h : env51481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51480_51481 : H12AffineEnvironment.transform 4 17 env51480 = env51481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env51480 == env51481) = true)

def env51482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4097,61648,91183,123165,533640,614526,385203,90415,545089,96346,25884,1281,256,594023,1344,525825]

theorem envBound51482 : H12AffineFastState.Bounded env51482 := by
  intro p hp
  have h : env51482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51286_51482 : H12AffineEnvironment.transform 23 123165 env51286 = env51482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env51286 == env51482) = true)

def env51483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4097,61648,91183,123165,28888,78894,385203,90415,1297,96346,25884,1281,256,82999,1344,21073]

theorem envBound51483 : H12AffineFastState.Bounded env51483 := by
  intro p hp
  have h : env51483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51482_51483 : H12AffineEnvironment.transform 18 21584 env51482 = env51483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env51482 == env51483) = true)

theorem identity51483 : scanCanonicalize (H12AffineFastState.compose env51483 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound51483 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env51484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74862,262144,21584,25676,4097,5277,91183,66896,28888,78894,328958,90415,1297,96346,25884,1281,256,82999,1344,21073]

theorem envBound51484 : H12AffineFastState.Bounded env51484 := by
  intro p hp
  have h : env51484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51483_51484 : H12AffineEnvironment.transform 14 25677 env51483 = env51484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env51483 == env51484) = true)

def env51485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,262144,4416,8540,4097,5277,74047,66896,13768,78894,328958,74815,1297,81226,8204,1281,256,65831,1344,5953]

theorem envBound51485 : H12AffineFastState.Bounded env51485 := by
  intro p hp
  have h : env51485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51484_51485 : H12AffineEnvironment.transform 13 1296 env51484 = env51485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env51484 == env51485) = true)

def env51486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65664,4416,8540,4097,5277,74047,66896,13768,78894,1150,74815,1297,81226,8204,1281,256,65831,1344,5953]

theorem envBound51486 : H12AffineFastState.Bounded env51486 := by
  intro p hp
  have h : env51486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51485_51486 : H12AffineEnvironment.transform 17 65664 env51485 = env51486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env51485 == env51486) = true)

theorem identity51486 : scanCanonicalize (H12AffineFastState.compose env51486 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound51486 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1296,324,65536,66679,65664,4416,325,4097,5277,65830,66896,5585,70711,1150,66598,1297,73043,21,1281,256,65831,1344,5953]

theorem envBound51487 : H12AffineFastState.Bounded env51487 := by
  intro p hp
  have h : env51487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51486_51487 : H12AffineEnvironment.transform 12 25 env51486 = env51487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env51486 == env51487) = true)

def env51488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,25,1296,324,65536,66679,65664,1876,325,1557,649,65830,66896,965,66083,1150,66598,1297,68423,21,1281,256,65831,1344,341]

theorem envBound51488 : H12AffineFastState.Bounded env51488 := by
  intro p hp
  have h : env51488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51487_51488 : H12AffineEnvironment.transform 11 1556 env51487 = env51488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env51487 == env51488) = true)

def env51489 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1556,25,1296,260,65536,66615,65664,1812,261,1557,649,65830,66832,901,66083,1086,66598,1297,68359,21,1281,256,65831,1280,277]

theorem envBound51489 : H12AffineFastState.Bounded env51489 := by
  intro p hp
  have h : env51489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51488_51489 : H12AffineEnvironment.transform 5 0 env51488 = env51489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env51488 == env51489) = true)

theorem identity51489 : scanCanonicalize (H12AffineFastState.compose env51489 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 182) := by decide +kernel

theorem selectedBound51489 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env51490 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1556,25,1296,260,182,1153,54,1812,261,1557,649,400,1446,901,661,1086,1168,1297,2993,21,1281,256,401,1280,277]

theorem envBound51490 : H12AffineFastState.Bounded env51490 := by
  intro p hp
  have h : env51490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51489_51490 : H12AffineEnvironment.transform 15 182 env51489 = env51490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 182 env51489 == env51490) = true)

def env51491 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,772,25,0,260,182,401,54,516,261,773,649,400,182,901,661,302,384,1,2993,21,17,256,401,16,277]

theorem envBound51491 : H12AffineFastState.Bounded env51491 := by
  intro p hp
  have h : env51491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51490_51491 : H12AffineEnvironment.transform 9 272 env51490 = env51491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env51490 == env51491) = true)

theorem identity51491 : scanCanonicalize (H12AffineFastState.compose env51491 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound51491 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51492 : List Nat := [2,4,8,16,32,0,128,256,16,272,2048,276,25,0,260,182,401,54,20,261,277,153,400,182,405,133,302,384,1,2465,21,17,256,401,16,277]

theorem envBound51492 : H12AffineFastState.Bounded env51492 := by
  intro p hp
  have h : env51492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51491_51492 : H12AffineEnvironment.transform 8 16 env51491 = env51492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env51491 == env51492) = true)

theorem identity51492 : scanCanonicalize (H12AffineFastState.compose env51492 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound51492 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env51493 : List Nat := [2,4,8,16,32,0,128,5,16,21,2048,17,25,0,1,182,148,54,20,0,16,153,149,182,144,133,43,133,1,2212,21,17,5,148,16,16]

theorem envBound51493 : H12AffineFastState.Bounded env51493 := by
  intro p hp
  have h : env51493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51492_51493 : H12AffineEnvironment.transform 7 5 env51492 = env51493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env51492 == env51493) = true)

theorem identity51493 : scanCanonicalize (H12AffineFastState.compose env51493 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound51493 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51494 : List Nat := [2,4,8,13,32,0,128,5,13,8,2048,12,4,0,1,171,137,43,9,0,13,132,136,171,141,133,43,133,1,2212,8,12,5,137,13,13]

theorem envBound51494 : H12AffineFastState.Bounded env51494 := by
  intro p hp
  have h : env51494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51493_51494 : H12AffineEnvironment.transform 3 13 env51493 = env51494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env51493 == env51494) = true)

theorem identity51494 : scanCanonicalize (H12AffineFastState.compose env51494 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound51494 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env51495 : List Nat := [2,4,8,13,11,0,128,5,13,8,2048,12,4,0,1,128,137,0,9,0,13,132,136,128,141,133,0,133,1,2191,8,12,5,137,13,13]

theorem envBound51495 : H12AffineFastState.Bounded env51495 := by
  intro p hp
  have h : env51495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51494_51495 : H12AffineEnvironment.transform 4 11 env51494 = env51495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env51494 == env51495) = true)

theorem identity51495 : scanCanonicalize (H12AffineFastState.compose env51495 (packedSelected [2,4] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound51495 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env51496 : List Nat := [2,4,8,13,11,0,128,5,13,8,136,12,4,0,1,128,137,0,9,0,13,132,136,128,141,133,0,133,1,7,8,12,5,137,13,13]

theorem envBound51496 : H12AffineFastState.Bounded env51496 := by
  intro p hp
  have h : env51496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51495_51496 : H12AffineEnvironment.transform 10 136 env51495 = env51496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env51495 == env51496) = true)

theorem identity51496 : scanCanonicalize (H12AffineFastState.compose env51496 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound51496 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env51497 : List Nat := [2,4,8,13,11,0,5,5,13,8,13,12,4,0,1,5,12,0,9,0,13,1,13,5,8,0,0,0,1,7,8,12,5,12,13,13]

theorem envBound51497 : H12AffineFastState.Bounded env51497 := by
  intro p hp
  have h : env51497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51496_51497 : H12AffineEnvironment.transform 6 5 env51496 = env51497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env51496 == env51497) = true)

theorem identity51497 : scanCanonicalize (H12AffineFastState.compose env51497 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound51497 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env51498 : List Nat := [2,4,3,6,0,0,5,5,6,3,6,7,4,0,1,5,7,0,2,0,6,1,6,5,3,0,0,0,1,7,3,7,5,7,6,6]

theorem envBound51498 : H12AffineFastState.Bounded env51498 := by
  intro p hp
  have h : env51498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51497_51498 : H12AffineEnvironment.transform 2 3 env51497 = env51498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env51497 == env51498) = true)

theorem identity51498 : scanCanonicalize (H12AffineFastState.compose env51498 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound51498 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51499 : List Nat := [2,2,3,0,0,0,3,3,0,3,0,1,2,0,1,3,1,0,2,0,0,1,0,3,3,0,0,0,1,1,3,1,3,1,0,0]

theorem envBound51499 : H12AffineFastState.Bounded env51499 := by
  intro p hp
  have h : env51499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51498_51499 : H12AffineEnvironment.transform 1 2 env51498 = env51499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env51498 == env51499) = true)

def env51500 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,773,25,1,260,182,400,54,517,261,772,649,400,183,901,661,303,385,0,2993,21,16,256,401,17,277]

theorem envBound51500 : H12AffineFastState.Bounded env51500 := by
  intro p hp
  have h : env51500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51490_51500 : H12AffineEnvironment.transform 9 273 env51490 = env51500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env51490 == env51500) = true)

theorem identity51500 : scanCanonicalize (H12AffineFastState.compose env51500 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound51500 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51501 : List Nat := [2,4,8,16,32,0,128,5,512,20,2048,512,25,1,1,182,149,54,517,0,513,649,149,183,640,661,42,132,0,2740,21,16,5,148,17,16]

theorem envBound51501 : H12AffineFastState.Bounded env51501 := by
  intro p hp
  have h : env51501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51500_51501 : H12AffineEnvironment.transform 7 5 env51500 = env51501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env51500 == env51501) = true)

theorem identity51501 : scanCanonicalize (H12AffineFastState.compose env51501 (packedSelected [3,11,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 60) := by decide +kernel

theorem selectedBound51501 : packedSelected [3,11,15,18] rootPS < 2^1333 := by decide +kernel

def env51502 : List Nat := [2,4,8,16,32,0,128,5,512,20,60,512,25,1,1,182,149,54,517,0,513,649,149,183,640,661,42,132,0,648,21,16,5,148,17,16]

theorem envBound51502 : H12AffineFastState.Bounded env51502 := by
  intro p hp
  have h : env51502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51501_51502 : H12AffineEnvironment.transform 10 60 env51501 = env51502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 60 env51501 == env51502) = true)

theorem identity51502 : scanCanonicalize (H12AffineFastState.compose env51502 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound51502 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env51503 : List Nat := [2,4,8,16,32,0,128,5,0,20,60,0,25,1,1,182,149,54,5,0,1,137,149,183,128,149,42,132,0,136,21,16,5,148,17,16]

theorem envBound51503 : H12AffineFastState.Bounded env51503 := by
  intro p hp
  have h : env51503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51502_51503 : H12AffineEnvironment.transform 8 0 env51502 = env51503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env51502 == env51503) = true)

theorem identity51503 : scanCanonicalize (H12AffineFastState.compose env51503 (packedSelected [0,2,5,7,8,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound51503 : packedSelected [0,2,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env51504 : List Nat := [2,4,8,16,32,0,15,5,0,20,60,0,25,1,1,57,26,54,5,0,1,6,26,56,15,26,42,11,0,7,21,16,5,27,17,16]

theorem envBound51504 : H12AffineFastState.Bounded env51504 := by
  intro p hp
  have h : env51504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51503_51504 : H12AffineEnvironment.transform 6 15 env51503 = env51504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env51503 == env51504) = true)

theorem identity51504 : scanCanonicalize (H12AffineFastState.compose env51504 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound51504 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env51505 : List Nat := [2,4,3,16,32,0,4,5,0,20,55,0,18,1,1,50,17,54,5,0,1,6,17,51,4,17,33,0,0,7,21,16,5,16,17,16]

theorem envBound51505 : H12AffineFastState.Bounded env51505 := by
  intro p hp
  have h : env51505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51504_51505 : H12AffineEnvironment.transform 2 3 env51504 = env51505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env51504 == env51505) = true)

theorem identity51505 : scanCanonicalize (H12AffineFastState.compose env51505 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound51505 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env51506 : List Nat := [2,4,3,0,32,0,4,5,0,4,39,0,2,1,1,34,1,38,5,0,1,6,1,35,4,1,33,0,0,7,5,0,5,0,1,0]

theorem envBound51506 : H12AffineFastState.Bounded env51506 := by
  intro p hp
  have h : env51506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51505_51506 : H12AffineEnvironment.transform 3 0 env51505 = env51506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env51505 == env51506) = true)

theorem identity51506 : scanCanonicalize (H12AffineFastState.compose env51506 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound51506 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51507 : List Nat := [2,2,3,0,32,0,2,3,0,2,33,0,2,1,1,34,1,32,3,0,1,0,1,35,2,1,33,0,0,1,3,0,3,0,1,0]

theorem envBound51507 : H12AffineFastState.Bounded env51507 := by
  intro p hp
  have h : env51507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51506_51507 : H12AffineEnvironment.transform 1 2 env51506 = env51507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env51506 == env51507) = true)

theorem identity51507 : scanCanonicalize (H12AffineFastState.compose env51507 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51507 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51508 : List Nat := [2,2,3,0,1,0,2,3,0,2,0,0,2,1,1,3,1,1,3,0,1,0,1,2,2,1,0,0,0,1,3,0,3,0,1,0]

theorem envBound51508 : H12AffineFastState.Bounded env51508 := by
  intro p hp
  have h : env51508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51507_51508 : H12AffineEnvironment.transform 4 1 env51507 = env51508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51507 == env51508) = true)

def env51509 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1556,25,1296,261,65536,66614,65664,1813,260,1557,649,65830,66833,900,66083,1087,66598,1297,68358,21,1281,256,65831,1281,276]

theorem envBound51509 : H12AffineFastState.Bounded env51509 := by
  intro p hp
  have h : env51509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51488_51509 : H12AffineEnvironment.transform 5 1 env51488 = env51509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env51488 == env51509) = true)

theorem identity51509 : scanCanonicalize (H12AffineFastState.compose env51509 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1446) := by decide +kernel

theorem selectedBound51509 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env51510 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1556,25,1296,261,1446,400,1318,1813,260,1557,649,1152,183,900,1925,1087,384,1297,3744,21,1281,256,1153,1281,276]

theorem envBound51510 : H12AffineFastState.Bounded env51510 := by
  intro p hp
  have h : env51510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51509_51510 : H12AffineEnvironment.transform 15 1446 env51509 = env51510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1446 env51509 == env51510) = true)

def env51511 : List Nat := [2,4,8,16,32,1,128,128,512,1024,2048,1556,25,1168,133,1062,16,1190,1685,132,1557,649,1152,183,516,1541,1087,0,1169,3744,21,1153,128,1153,1153,148]

theorem envBound51511 : H12AffineFastState.Bounded env51511 := by
  intro p hp
  have h : env51511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51510_51511 : H12AffineEnvironment.transform 7 128 env51510 = env51511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env51510 == env51511) = true)

theorem identity51511 : scanCanonicalize (H12AffineFastState.compose env51511 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound51511 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env51512 : List Nat := [2,4,8,16,32,1,128,128,1,1024,2048,1045,25,1168,133,1062,16,1190,1172,132,1044,136,1152,183,5,1028,1087,0,1169,3233,21,1153,128,1153,1153,148]

theorem envBound51512 : H12AffineFastState.Bounded env51512 := by
  intro p hp
  have h : env51512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51511_51512 : H12AffineEnvironment.transform 8 1 env51511 = env51512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env51511 == env51512) = true)

theorem identity51512 : scanCanonicalize (H12AffineFastState.compose env51512 (packedSelected [1,3,4,9,13,15,16,17,19] rootPS)) = affineNative (2^(10+1) ^^^ 1207) := by decide +kernel

theorem selectedBound51512 : packedSelected [1,3,4,9,13,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env51513 : List Nat := [2,4,8,16,32,1,128,128,1,1024,1207,1045,25,1168,133,1062,16,1190,1172,132,1044,136,1152,183,5,1028,1087,0,1169,22,21,1153,128,1153,1153,148]

theorem envBound51513 : H12AffineFastState.Bounded env51513 := by
  intro p hp
  have h : env51513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51512_51513 : H12AffineEnvironment.transform 10 1207 env51512 = env51513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1207 env51512 == env51513) = true)

theorem identity51513 : scanCanonicalize (H12AffineFastState.compose env51513 (packedSelected [0,2,3,4,7,8,9,11,13,16] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound51513 : packedSelected [0,2,3,4,7,8,9,11,13,16] rootPS < 2^1333 := by decide +kernel

def env51514 : List Nat := [2,4,8,16,32,1,128,128,1,141,58,152,25,29,133,171,16,43,25,132,153,136,13,183,5,137,178,0,28,22,21,12,128,12,12,148]

theorem envBound51514 : H12AffineFastState.Bounded env51514 := by
  intro p hp
  have h : env51514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51513_51514 : H12AffineEnvironment.transform 9 141 env51513 = env51514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env51513 == env51514) = true)

theorem identity51514 : scanCanonicalize (H12AffineFastState.compose env51514 (packedSelected [0,5,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound51514 : packedSelected [0,5,8,9] rootPS < 2^1333 := by decide +kernel

def env51515 : List Nat := [2,4,8,0,32,1,128,128,1,141,42,136,9,13,133,171,0,43,9,132,137,136,13,167,5,137,162,0,12,6,5,12,128,12,12,132]

theorem envBound51515 : H12AffineFastState.Bounded env51515 := by
  intro p hp
  have h : env51515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51514_51515 : H12AffineEnvironment.transform 3 0 env51514 = env51515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env51514 == env51515) = true)

theorem identity51515 : scanCanonicalize (H12AffineFastState.compose env51515 (packedSelected [1,2,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound51515 : packedSelected [1,2,4,7] rootPS < 2^1333 := by decide +kernel

def env51516 : List Nat := [2,4,8,0,32,1,36,36,1,41,42,44,9,13,33,15,0,43,9,32,45,44,13,3,5,45,6,0,12,6,5,12,36,12,12,32]

theorem envBound51516 : H12AffineFastState.Bounded env51516 := by
  intro p hp
  have h : env51516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51515_51516 : H12AffineEnvironment.transform 6 36 env51515 = env51516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env51515 == env51516) = true)

theorem identity51516 : scanCanonicalize (H12AffineFastState.compose env51516 (packedSelected [1,3,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound51516 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env51517 : List Nat := [2,4,4,0,32,1,36,36,1,37,38,32,5,1,33,3,0,39,5,32,33,32,1,3,5,33,6,0,0,6,5,0,36,0,0,32]

theorem envBound51517 : H12AffineFastState.Bounded env51517 := by
  intro p hp
  have h : env51517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51516_51517 : H12AffineEnvironment.transform 2 4 env51516 = env51517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env51516 == env51517) = true)

def env51518 : List Nat := [2,4,8,16,32,1,128,129,512,1024,2048,1556,25,1169,132,1063,17,1191,1684,133,1557,649,1152,183,517,1540,1087,1,1168,3744,21,1152,129,1153,1152,149]

theorem envBound51518 : H12AffineFastState.Bounded env51518 := by
  intro p hp
  have h : env51518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51510_51518 : H12AffineEnvironment.transform 7 129 env51510 = env51518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 129 env51510 == env51518) = true)

theorem identity51518 : scanCanonicalize (H12AffineFastState.compose env51518 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 132) := by decide +kernel

theorem selectedBound51518 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env51519 : List Nat := [2,4,8,16,32,1,128,129,132,1024,2048,1168,25,1169,132,1063,17,1191,1040,133,1169,13,1152,183,129,1152,1087,1,1168,3108,21,1152,129,1153,1152,149]

theorem envBound51519 : H12AffineFastState.Bounded env51519 := by
  intro p hp
  have h : env51519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51518_51519 : H12AffineEnvironment.transform 8 132 env51518 = env51519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 132 env51518 == env51519) = true)

theorem identity51519 : scanCanonicalize (H12AffineFastState.compose env51519 (packedSelected [4,5,8,9,10,13,16,17] rootPS)) = affineNative (2^(9+1) ^^^ 173) := by decide +kernel

theorem selectedBound51519 : packedSelected [4,5,8,9,10,13,16,17] rootPS < 2^1333 := by decide +kernel

def env51520 : List Nat := [2,4,8,16,32,1,128,129,132,173,2048,61,25,60,132,138,17,10,189,133,60,13,45,183,129,45,146,1,61,2185,21,45,129,44,45,149]

theorem envBound51520 : H12AffineFastState.Bounded env51520 := by
  intro p hp
  have h : env51520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51519_51520 : H12AffineEnvironment.transform 9 173 env51519 = env51520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env51519 == env51520) = true)

theorem identity51520 : scanCanonicalize (H12AffineFastState.compose env51520 (packedSelected [0,1,2,4,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 61) := by decide +kernel

theorem selectedBound51520 : packedSelected [0,1,2,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env51521 : List Nat := [2,4,8,16,32,1,128,129,132,173,61,61,25,60,132,138,17,10,189,133,60,13,45,183,129,45,146,1,61,180,21,45,129,44,45,149]

theorem envBound51521 : H12AffineFastState.Bounded env51521 := by
  intro p hp
  have h : env51521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51520_51521 : H12AffineEnvironment.transform 10 61 env51520 = env51521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 61 env51520 == env51521) = true)

theorem identity51521 : scanCanonicalize (H12AffineFastState.compose env51521 (packedSelected [1,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound51521 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env51522 : List Nat := [2,4,8,16,32,1,47,46,43,2,61,61,25,60,43,37,17,10,18,42,60,13,45,24,46,45,61,1,61,27,21,45,46,44,45,58]

theorem envBound51522 : H12AffineFastState.Bounded env51522 := by
  intro p hp
  have h : env51522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51521_51522 : H12AffineEnvironment.transform 6 47 env51521 = env51522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env51521 == env51522) = true)

def env51523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,25,1296,324,65536,66679,65664,1877,325,1556,648,65830,66896,964,66082,1150,66598,1297,68422,21,1281,256,65831,1344,340]

theorem envBound51523 : H12AffineFastState.Bounded env51523 := by
  intro p hp
  have h : env51523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51487_51523 : H12AffineEnvironment.transform 11 1557 env51487 = env51523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env51487 == env51523) = true)

def env51524 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1557,25,1296,260,65536,66615,65664,1813,261,1556,648,65830,66832,900,66082,1086,66598,1297,68358,21,1281,256,65831,1280,276]

theorem envBound51524 : H12AffineFastState.Bounded env51524 := by
  intro p hp
  have h : env51524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51523_51524 : H12AffineEnvironment.transform 5 0 env51523 = env51524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env51523 == env51524) = true)

theorem identity51524 : scanCanonicalize (H12AffineFastState.compose env51524 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 129) := by decide +kernel

theorem selectedBound51524 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env51525 : List Nat := [2,4,8,16,32,0,128,129,512,1024,2048,1557,25,1169,133,65536,66615,65664,1684,132,1556,648,65703,66705,517,66082,1086,66598,1168,68231,21,1152,129,65702,1153,149]

theorem envBound51525 : H12AffineFastState.Bounded env51525 := by
  intro p hp
  have h : env51525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51524_51525 : H12AffineEnvironment.transform 7 129 env51524 = env51525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 129 env51524 == env51525) = true)

def env51526 : List Nat := [2,4,8,16,32,0,128,129,512,144,2048,645,25,1,133,65536,65703,65664,516,132,644,648,65703,65537,517,66082,174,65718,0,68231,21,16,129,65702,17,149]

theorem envBound51526 : H12AffineFastState.Bounded env51526 := by
  intro p hp
  have h : env51526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51525_51526 : H12AffineEnvironment.transform 9 144 env51525 = env51526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 144 env51525 == env51526) = true)

theorem identity51526 : scanCanonicalize (H12AffineFastState.compose env51526 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound51526 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51527 : List Nat := [2,4,8,16,32,0,4,5,512,20,2048,513,25,1,1,65536,65571,65540,516,0,512,524,65571,65537,517,66082,42,65586,0,68099,21,16,5,65570,17,17]

theorem envBound51527 : H12AffineFastState.Bounded env51527 := by
  intro p hp
  have h : env51527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51526_51527 : H12AffineEnvironment.transform 6 4 env51526 = env51527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env51526 == env51527) = true)

theorem identity51527 : scanCanonicalize (H12AffineFastState.compose env51527 (packedSelected [3,11,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 557) := by decide +kernel

theorem selectedBound51527 : packedSelected [3,11,15,18] rootPS < 2^1333 := by decide +kernel

def env51528 : List Nat := [2,4,8,16,32,0,4,5,512,20,557,513,25,1,1,65536,65571,65540,516,0,512,524,65571,65537,517,66082,42,65586,0,65582,21,16,5,65570,17,17]

theorem envBound51528 : H12AffineFastState.Bounded env51528 := by
  intro p hp
  have h : env51528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51527_51528 : H12AffineEnvironment.transform 10 557 env51527 = env51528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 557 env51527 == env51528) = true)

theorem identity51528 : scanCanonicalize (H12AffineFastState.compose env51528 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound51528 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env51529 : List Nat := [2,4,8,16,32,0,4,5,1,20,44,0,25,1,1,65536,65571,65540,5,0,1,13,65571,65537,4,65571,42,65586,0,65582,21,16,5,65570,17,17]

theorem envBound51529 : H12AffineFastState.Bounded env51529 := by
  intro p hp
  have h : env51529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51528_51529 : H12AffineEnvironment.transform 8 1 env51528 = env51529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env51528 == env51529) = true)

theorem identity51529 : scanCanonicalize (H12AffineFastState.compose env51529 (packedSelected [1,2,5,8] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound51529 : packedSelected [1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env51530 : List Nat := [2,4,8,16,32,0,4,5,1,20,44,0,25,1,1,51,16,55,5,0,1,13,16,50,4,16,42,1,0,29,21,16,5,17,17,17]

theorem envBound51530 : H12AffineFastState.Bounded env51530 := by
  intro p hp
  have h : env51530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51529_51530 : H12AffineEnvironment.transform 15 51 env51529 = env51530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env51529 == env51530) = true)

theorem identity51530 : scanCanonicalize (H12AffineFastState.compose env51530 (packedSelected [1,2,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound51530 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env51531 : List Nat := [2,2,8,16,32,0,2,3,1,18,42,0,25,1,1,51,16,49,3,0,1,11,16,50,2,16,42,1,0,27,19,16,3,17,17,17]

theorem envBound51531 : H12AffineFastState.Bounded env51531 := by
  intro p hp
  have h : env51531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51530_51531 : H12AffineEnvironment.transform 1 2 env51530 = env51531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env51530 == env51531) = true)

def env51532 : List Nat := [2,4,8,16,32,0,128,129,512,145,2048,644,25,0,133,65536,65702,65664,517,132,645,648,65703,65536,517,66082,175,65719,1,68231,21,17,129,65702,16,149]

theorem envBound51532 : H12AffineFastState.Bounded env51532 := by
  intro p hp
  have h : env51532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51525_51532 : H12AffineEnvironment.transform 9 145 env51525 = env51532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 145 env51525 == env51532) = true)

theorem identity51532 : scanCanonicalize (H12AffineFastState.compose env51532 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound51532 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51533 : List Nat := [2,4,8,16,32,0,128,129,17,145,2048,149,25,0,133,65536,65702,65664,20,132,148,153,65703,65536,20,65587,175,65719,1,67734,21,17,129,65702,16,149]

theorem envBound51533 : H12AffineFastState.Bounded env51533 := by
  intro p hp
  have h : env51533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51532_51533 : H12AffineEnvironment.transform 8 17 env51532 = env51533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env51532 == env51533) = true)

theorem identity51533 : scanCanonicalize (H12AffineFastState.compose env51533 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound51533 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env51534 : List Nat := [2,4,8,16,32,0,4,5,17,21,2048,17,25,0,1,65536,65570,65540,20,0,16,29,65571,65536,20,65587,43,65587,1,67602,21,17,5,65570,16,17]

theorem envBound51534 : H12AffineFastState.Bounded env51534 := by
  intro p hp
  have h : env51534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51533_51534 : H12AffineEnvironment.transform 6 4 env51533 = env51534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env51533 == env51534) = true)

theorem identity51534 : scanCanonicalize (H12AffineFastState.compose env51534 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 46) := by decide +kernel

theorem selectedBound51534 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51535 : List Nat := [2,4,8,16,32,0,4,5,17,21,2048,17,25,0,1,46,12,42,20,0,16,29,13,46,20,29,43,29,1,2108,21,17,5,12,16,17]

theorem envBound51535 : H12AffineFastState.Bounded env51535 := by
  intro p hp
  have h : env51535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51534_51535 : H12AffineEnvironment.transform 15 46 env51534 = env51535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 46 env51534 == env51535) = true)

theorem identity51535 : scanCanonicalize (H12AffineFastState.compose env51535 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound51535 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env51536 : List Nat := [2,4,8,0,32,0,4,5,1,5,2048,1,9,0,1,46,12,42,4,0,0,13,13,46,4,13,43,13,1,2092,5,1,5,12,0,1]

theorem envBound51536 : H12AffineFastState.Bounded env51536 := by
  intro p hp
  have h : env51536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51535_51536 : H12AffineEnvironment.transform 3 0 env51535 = env51536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env51535 == env51536) = true)

theorem identity51536 : scanCanonicalize (H12AffineFastState.compose env51536 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound51536 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env51537 : List Nat := [2,4,8,0,10,0,4,5,1,5,2048,1,9,0,1,4,12,0,4,0,0,13,13,4,4,13,1,13,1,2054,5,1,5,12,0,1]

theorem envBound51537 : H12AffineFastState.Bounded env51537 := by
  intro p hp
  have h : env51537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51536_51537 : H12AffineEnvironment.transform 4 10 env51536 = env51537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env51536 == env51537) = true)

theorem identity51537 : scanCanonicalize (H12AffineFastState.compose env51537 (packedSelected [2,4] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound51537 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env51538 : List Nat := [2,4,8,0,10,0,4,5,1,5,10,1,9,0,1,4,12,0,4,0,0,13,13,4,4,13,1,13,1,12,5,1,5,12,0,1]

theorem envBound51538 : H12AffineFastState.Bounded env51538 := by
  intro p hp
  have h : env51538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51537_51538 : H12AffineEnvironment.transform 10 10 env51537 = env51538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env51537 == env51538) = true)

theorem identity51538 : scanCanonicalize (H12AffineFastState.compose env51538 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound51538 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51539 : List Nat := [2,4,2,0,0,0,4,5,1,5,0,1,3,0,1,4,6,0,4,0,0,7,7,4,4,7,1,7,1,6,5,1,5,6,0,1]

theorem envBound51539 : H12AffineFastState.Bounded env51539 := by
  intro p hp
  have h : env51539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51538_51539 : H12AffineEnvironment.transform 2 2 env51538 = env51539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env51538 == env51539) = true)

theorem identity51539 : scanCanonicalize (H12AffineFastState.compose env51539 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound51539 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51540 : List Nat := [2,2,2,0,0,0,2,3,1,3,0,1,3,0,1,2,0,0,2,0,0,1,1,2,2,1,1,1,1,0,3,1,3,0,0,1]

theorem envBound51540 : H12AffineFastState.Bounded env51540 := by
  intro p hp
  have h : env51540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51539_51540 : H12AffineEnvironment.transform 1 2 env51539 = env51540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env51539 == env51540) = true)

def env51541 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1557,25,1296,261,65536,66614,65664,1812,260,1556,648,65830,66833,901,66082,1087,66598,1297,68359,21,1281,256,65831,1281,277]

theorem envBound51541 : H12AffineFastState.Bounded env51541 := by
  intro p hp
  have h : env51541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51523_51541 : H12AffineEnvironment.transform 5 1 env51523 = env51541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env51523 == env51541) = true)

theorem identity51541 : scanCanonicalize (H12AffineFastState.compose env51541 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 145) := by decide +kernel

theorem selectedBound51541 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env51542 : List Nat := [2,4,8,16,32,1,128,256,512,145,2048,644,25,385,261,65536,65703,65664,901,260,645,648,65830,65920,901,66082,174,65719,384,68359,21,400,256,65831,400,277]

theorem envBound51542 : H12AffineFastState.Bounded env51542 := by
  intro p hp
  have h : env51542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51541_51542 : H12AffineEnvironment.transform 9 145 env51541 = env51542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 145 env51541 == env51542) = true)

def env51543 : List Nat := [2,4,8,16,32,1,128,128,512,145,2048,644,25,1,133,65536,65703,65664,517,132,645,648,65702,65536,517,66082,174,65719,0,68231,21,16,128,65703,16,149]

theorem envBound51543 : H12AffineFastState.Bounded env51543 := by
  intro p hp
  have h : env51543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51542_51543 : H12AffineEnvironment.transform 7 128 env51542 = env51543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env51542 == env51543) = true)

theorem identity51543 : scanCanonicalize (H12AffineFastState.compose env51543 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound51543 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51544 : List Nat := [2,4,8,16,32,1,4,4,512,21,2048,512,25,1,1,65536,65571,65540,517,0,513,524,65570,65536,517,66082,42,65587,0,68099,21,16,4,65571,16,17]

theorem envBound51544 : H12AffineFastState.Bounded env51544 := by
  intro p hp
  have h : env51544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51543_51544 : H12AffineEnvironment.transform 6 4 env51543 = env51544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env51543 == env51544) = true)

theorem identity51544 : scanCanonicalize (H12AffineFastState.compose env51544 (packedSelected [3,11,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 2590) := by decide +kernel

theorem selectedBound51544 : packedSelected [3,11,15,18] rootPS < 2^1333 := by decide +kernel

def env51545 : List Nat := [2,4,8,16,32,1,4,4,512,21,2048,512,25,1,1,2590,2621,2586,517,0,513,524,2620,2590,517,2108,42,2605,0,29,21,16,4,2621,16,17]

theorem envBound51545 : H12AffineFastState.Bounded env51545 := by
  intro p hp
  have h : env51545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51544_51545 : H12AffineEnvironment.transform 15 2590 env51544 = env51545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2590 env51544 == env51545) = true)

theorem identity51545 : scanCanonicalize (H12AffineFastState.compose env51545 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound51545 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env51546 : List Nat := [2,4,8,16,32,1,4,4,0,21,2048,0,25,1,1,2078,2109,2074,5,0,1,12,2108,2078,5,2108,42,2093,0,29,21,16,4,2109,16,17]

theorem envBound51546 : H12AffineFastState.Bounded env51546 := by
  intro p hp
  have h : env51546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51545_51546 : H12AffineEnvironment.transform 8 0 env51545 = env51546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env51545 == env51546) = true)

theorem identity51546 : scanCanonicalize (H12AffineFastState.compose env51546 (packedSelected [0,1,7,10,11,12] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound51546 : packedSelected [0,1,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env51547 : List Nat := [2,4,8,10,32,1,4,4,0,15,2048,0,3,1,1,2052,2087,2048,5,0,1,12,2086,2052,5,2086,42,2093,0,7,15,10,4,2087,10,11]

theorem envBound51547 : H12AffineFastState.Bounded env51547 := by
  intro p hp
  have h : env51547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51546_51547 : H12AffineEnvironment.transform 3 10 env51546 = env51547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env51546 == env51547) = true)

theorem identity51547 : scanCanonicalize (H12AffineFastState.compose env51547 (packedSelected [2,4,7] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound51547 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env51548 : List Nat := [2,4,4,6,32,1,4,4,0,3,2048,0,3,1,1,2052,2087,2048,5,0,1,0,2086,2052,5,2086,38,2081,0,7,3,6,4,2087,6,7]

theorem envBound51548 : H12AffineFastState.Bounded env51548 := by
  intro p hp
  have h : env51548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51547_51548 : H12AffineEnvironment.transform 2 4 env51547 = env51548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env51547 == env51548) = true)

theorem identity51548 : scanCanonicalize (H12AffineFastState.compose env51548 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound51548 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51549 : List Nat := [2,2,2,0,32,1,2,2,0,3,2048,0,3,1,1,2050,2081,2048,3,0,1,0,2080,2050,3,2080,32,2081,0,1,3,0,2,2081,0,1]

theorem envBound51549 : H12AffineFastState.Bounded env51549 := by
  intro p hp
  have h : env51549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51548_51549 : H12AffineEnvironment.transform 1 2 env51548 = env51549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env51548 == env51549) = true)

theorem identity51549 : scanCanonicalize (H12AffineFastState.compose env51549 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 3) := by decide +kernel

theorem selectedBound51549 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51550 : List Nat := [2,2,2,0,32,1,2,2,0,3,3,0,3,1,1,1,34,3,3,0,1,0,35,1,3,35,32,34,0,1,3,0,2,34,0,1]

theorem envBound51550 : H12AffineFastState.Bounded env51550 := by
  intro p hp
  have h : env51550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51549_51550 : H12AffineEnvironment.transform 10 3 env51549 = env51550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 3 env51549 == env51550) = true)

theorem identity51550 : scanCanonicalize (H12AffineFastState.compose env51550 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound51550 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env51551 : List Nat := [2,2,2,0,3,1,2,2,0,3,3,0,3,1,1,1,1,3,3,0,1,0,0,1,3,0,3,1,0,1,3,0,2,1,0,1]

theorem envBound51551 : H12AffineFastState.Bounded env51551 := by
  intro p hp
  have h : env51551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51550_51551 : H12AffineEnvironment.transform 4 3 env51550 = env51551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env51550 == env51551) = true)

theorem identity51551 : scanCanonicalize (H12AffineFastState.compose env51551 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound51551 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51552 : List Nat := [1,1,1,0,0,1,1,1,0,0,0,0,0,1,1,1,1,0,0,0,1,0,0,1,0,0,0,1,0,1,0,0,1,1,0,1]

theorem envBound51552 : H12AffineFastState.Bounded env51552 := by
  intro p hp
  have h : env51552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51551_51552 : H12AffineEnvironment.transform 0 1 env51551 = env51552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env51551 == env51552) = true)

def env51553 : List Nat := [2,4,8,16,32,1,128,129,512,145,2048,644,25,0,132,65536,65703,65664,516,133,645,648,65703,65537,516,66082,174,65719,1,68230,21,17,129,65702,17,148]

theorem envBound51553 : H12AffineFastState.Bounded env51553 := by
  intro p hp
  have h : env51553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51542_51553 : H12AffineEnvironment.transform 7 129 env51542 = env51553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 129 env51542 == env51553) = true)

theorem identity51553 : scanCanonicalize (H12AffineFastState.compose env51553 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound51553 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51554 : List Nat := [2,4,8,16,32,1,128,129,17,145,2048,149,25,0,132,65536,65703,65664,21,133,148,153,65703,65537,21,65587,174,65719,1,67735,21,17,129,65702,17,148]

theorem envBound51554 : H12AffineFastState.Bounded env51554 := by
  intro p hp
  have h : env51554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51553_51554 : H12AffineEnvironment.transform 8 17 env51553 = env51554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env51553 == env51554) = true)

theorem identity51554 : scanCanonicalize (H12AffineFastState.compose env51554 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound51554 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env51555 : List Nat := [2,4,8,16,32,1,5,4,17,20,2048,16,25,0,1,65536,65570,65541,21,0,17,28,65570,65537,21,65587,43,65586,1,67602,21,17,4,65571,17,17]

theorem envBound51555 : H12AffineFastState.Bounded env51555 := by
  intro p hp
  have h : env51555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51554_51555 : H12AffineEnvironment.transform 6 5 env51554 = env51555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env51554 == env51555) = true)

theorem identity51555 : scanCanonicalize (H12AffineFastState.compose env51555 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 46) := by decide +kernel

theorem selectedBound51555 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51556 : List Nat := [2,4,8,16,32,1,5,4,17,20,2048,16,25,0,1,46,12,43,21,0,17,28,12,47,21,29,43,28,1,2108,21,17,4,13,17,17]

theorem envBound51556 : H12AffineFastState.Bounded env51556 := by
  intro p hp
  have h : env51556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51555_51556 : H12AffineEnvironment.transform 15 46 env51555 = env51556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 46 env51555 == env51556) = true)

theorem identity51556 : scanCanonicalize (H12AffineFastState.compose env51556 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound51556 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env51557 : List Nat := [2,4,8,16,11,1,5,4,17,20,2048,16,25,0,1,5,12,0,21,0,17,28,12,4,21,29,0,28,1,2071,21,17,4,13,17,17]

theorem envBound51557 : H12AffineFastState.Bounded env51557 := by
  intro p hp
  have h : env51557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51556_51557 : H12AffineEnvironment.transform 4 11 env51556 = env51557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env51556 == env51557) = true)

theorem identity51557 : scanCanonicalize (H12AffineFastState.compose env51557 (packedSelected [2,4] rootPS)) = affineNative (2^(10+1) ^^^ 13) := by decide +kernel

theorem selectedBound51557 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env51558 : List Nat := [2,4,8,16,11,1,5,4,17,20,13,16,25,0,1,5,12,0,21,0,17,28,12,4,21,29,0,28,1,26,21,17,4,13,17,17]

theorem envBound51558 : H12AffineFastState.Bounded env51558 := by
  intro p hp
  have h : env51558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51557_51558 : H12AffineEnvironment.transform 10 13 env51557 = env51558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 13 env51557 == env51558) = true)

theorem identity51558 : scanCanonicalize (H12AffineFastState.compose env51558 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound51558 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env51559 : List Nat := [2,4,8,12,11,1,5,4,13,8,13,12,5,0,1,5,12,0,9,0,13,0,12,4,9,1,0,0,1,6,9,13,4,13,13,13]

theorem envBound51559 : H12AffineFastState.Bounded env51559 := by
  intro p hp
  have h : env51559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51558_51559 : H12AffineEnvironment.transform 3 12 env51558 = env51559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env51558 == env51559) = true)

theorem identity51559 : scanCanonicalize (H12AffineFastState.compose env51559 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound51559 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env51560 : List Nat := [2,4,2,6,1,1,5,4,7,2,7,6,5,0,1,5,6,0,3,0,7,0,6,4,3,1,0,0,1,6,3,7,4,7,7,7]

theorem envBound51560 : H12AffineFastState.Bounded env51560 := by
  intro p hp
  have h : env51560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51559_51560 : H12AffineEnvironment.transform 2 2 env51559 = env51560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env51559 == env51560) = true)

theorem identity51560 : scanCanonicalize (H12AffineFastState.compose env51560 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound51560 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51561 : List Nat := [2,3,2,1,1,1,2,3,0,2,0,1,2,0,1,2,1,0,3,0,0,0,1,3,3,1,0,0,1,1,3,0,3,0,0,0]

theorem envBound51561 : H12AffineFastState.Bounded env51561 := by
  intro p hp
  have h : env51561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51560_51561 : H12AffineEnvironment.transform 1 3 env51560 = env51561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env51560 == env51561) = true)

def env51562 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65665,4416,8540,4097,5277,74047,66896,13768,78894,1151,74815,1297,81226,8204,1281,256,65831,1344,5953]

theorem envBound51562 : H12AffineFastState.Bounded env51562 := by
  intro p hp
  have h : env51562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51485_51562 : H12AffineEnvironment.transform 17 65665 env51485 = env51562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env51485 == env51562) = true)

theorem identity51562 : scanCanonicalize (H12AffineFastState.compose env51562 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5465) := by decide +kernel

theorem selectedBound51562 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51563 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1296,5124,65536,69943,65665,4416,5125,4097,5277,70758,66896,145,65911,1151,69990,1297,67603,5461,1281,256,65831,1344,5953]

theorem envBound51563 : H12AffineFastState.Bounded env51563 := by
  intro p hp
  have h : env51563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51562_51563 : H12AffineEnvironment.transform 12 5465 env51562 = env51563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env51562 == env51563) = true)

def env51564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,845,1296,528,65536,67363,65665,1876,529,1557,649,66162,66896,145,65911,1151,67442,1297,67603,833,1281,256,65831,1344,341]

theorem envBound51564 : H12AffineFastState.Bounded env51564 := by
  intro p hp
  have h : env51564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51563_51564 : H12AffineEnvironment.transform 11 1556 env51563 = env51564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env51563 == env51564) = true)

def env51565 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,845,64,528,65536,66163,65665,516,529,837,649,66162,65536,145,65911,303,66082,65,67603,833,81,256,65831,16,341]

theorem envBound51565 : H12AffineFastState.Bounded env51565 := by
  intro p hp
  have h : env51565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51564_51565 : H12AffineEnvironment.transform 9 336 env51564 = env51565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env51564 == env51565) = true)

theorem identity51565 : scanCanonicalize (H12AffineFastState.compose env51565 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 930) := by decide +kernel

theorem selectedBound51565 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env51566 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,845,64,528,930,465,803,516,529,837,649,464,930,145,725,303,384,65,2993,833,81,256,645,16,341]

theorem envBound51566 : H12AffineFastState.Bounded env51566 := by
  intro p hp
  have h : env51566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51565_51566 : H12AffineEnvironment.transform 15 930 env51565 = env51566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 930 env51565 == env51566) = true)

def env51567 : List Nat := [2,4,8,16,32,64,128,256,212,336,2048,400,409,64,196,374,465,503,208,197,401,93,464,374,145,1,303,384,65,2405,405,81,256,81,16,341]

theorem envBound51567 : H12AffineFastState.Bounded env51567 := by
  intro p hp
  have h : env51567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51566_51567 : H12AffineEnvironment.transform 8 212 env51566 = env51567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 212 env51566 == env51567) = true)

theorem identity51567 : scanCanonicalize (H12AffineFastState.compose env51567 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound51567 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env51568 : List Nat := [2,4,8,16,32,64,128,20,212,68,2048,132,141,64,196,98,197,227,208,197,133,93,196,98,145,1,59,148,65,2161,129,81,20,81,16,65]

theorem envBound51568 : H12AffineFastState.Bounded env51568 := by
  intro p hp
  have h : env51568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51567_51568 : H12AffineEnvironment.transform 7 20 env51567 = env51568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env51567 == env51568) = true)

theorem identity51568 : scanCanonicalize (H12AffineFastState.compose env51568 (packedSelected [4,5,8,9,10,13,15,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound51568 : packedSelected [4,5,8,9,10,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env51569 : List Nat := [2,4,8,16,32,64,128,20,212,68,162,132,141,64,196,98,197,227,208,197,133,93,196,98,145,1,59,148,65,211,129,81,20,81,16,65]

theorem envBound51569 : H12AffineFastState.Bounded env51569 := by
  intro p hp
  have h : env51569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51568_51569 : H12AffineEnvironment.transform 10 162 env51568 = env51569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env51568 == env51569) = true)

theorem identity51569 : scanCanonicalize (H12AffineFastState.compose env51569 (packedSelected [0,1,2,3,4,7,9,11,13,16,19] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound51569 : packedSelected [0,1,2,3,4,7,9,11,13,16,19] rootPS < 2^1333 := by decide +kernel

def env51570 : List Nat := [2,4,8,16,32,12,128,20,152,8,162,132,141,12,136,46,137,175,156,137,133,17,136,46,145,1,59,148,13,159,129,29,20,29,16,13]

theorem envBound51570 : H12AffineFastState.Bounded env51570 := by
  intro p hp
  have h : env51570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51569_51570 : H12AffineEnvironment.transform 5 12 env51569 = env51570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env51569 == env51570) = true)

theorem identity51570 : scanCanonicalize (H12AffineFastState.compose env51570 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound51570 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51571 : List Nat := [2,4,8,12,32,12,128,8,132,8,162,132,141,12,136,46,137,175,128,137,133,13,136,46,141,1,39,136,13,131,129,1,8,1,12,13]

theorem envBound51571 : H12AffineFastState.Bounded env51571 := by
  intro p hp
  have h : env51571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51570_51571 : H12AffineEnvironment.transform 3 12 env51570 = env51571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env51570 == env51571) = true)

theorem identity51571 : scanCanonicalize (H12AffineFastState.compose env51571 (packedSelected [3,5,8] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound51571 : packedSelected [3,5,8] rootPS < 2^1333 := by decide +kernel

def env51572 : List Nat := [2,4,5,1,32,1,128,5,132,5,162,132,128,1,133,35,132,162,128,132,133,0,133,35,128,1,39,133,0,131,129,1,5,1,1,0]

theorem envBound51572 : H12AffineFastState.Bounded env51572 := by
  intro p hp
  have h : env51572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51571_51572 : H12AffineEnvironment.transform 2 5 env51571 = env51572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env51571 == env51572) = true)

theorem identity51572 : scanCanonicalize (H12AffineFastState.compose env51572 (packedSelected [2,3] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound51572 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env51573 : List Nat := [2,4,5,1,32,1,36,5,32,5,6,32,36,1,33,35,32,6,36,32,33,0,33,35,36,1,39,33,0,39,37,1,5,1,1,0]

theorem envBound51573 : H12AffineFastState.Bounded env51573 := by
  intro p hp
  have h : env51573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51572_51573 : H12AffineEnvironment.transform 6 36 env51572 = env51573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env51572 == env51573) = true)

theorem identity51573 : scanCanonicalize (H12AffineFastState.compose env51573 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound51573 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51574 : List Nat := [2,3,2,1,32,1,35,2,32,2,1,32,35,1,33,35,32,1,35,32,33,0,33,35,35,1,32,33,0,32,34,1,2,1,1,0]

theorem envBound51574 : H12AffineFastState.Bounded env51574 := by
  intro p hp
  have h : env51574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51573_51574 : H12AffineEnvironment.transform 1 3 env51573 = env51574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env51573 == env51574) = true)

def env51575 : List Nat := [2,4,8,16,32,64,128,256,213,336,2048,401,408,64,197,375,465,502,209,196,400,92,464,375,145,0,303,384,65,2404,404,81,256,80,16,341]

theorem envBound51575 : H12AffineFastState.Bounded env51575 := by
  intro p hp
  have h : env51575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51566_51575 : H12AffineEnvironment.transform 8 213 env51566 = env51575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 213 env51566 == env51575) = true)

theorem identity51575 : scanCanonicalize (H12AffineFastState.compose env51575 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 208) := by decide +kernel

theorem selectedBound51575 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env51576 : List Nat := [2,4,8,16,32,64,128,208,213,128,2048,65,72,64,197,167,1,38,209,196,64,92,0,167,145,0,255,80,65,2228,68,81,208,80,16,133]

theorem envBound51576 : H12AffineFastState.Bounded env51576 := by
  intro p hp
  have h : env51576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51575_51576 : H12AffineEnvironment.transform 7 208 env51575 = env51576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 208 env51575 == env51576) = true)

theorem identity51576 : scanCanonicalize (H12AffineFastState.compose env51576 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 102) := by decide +kernel

theorem selectedBound51576 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env51577 : List Nat := [2,4,8,16,32,64,128,208,213,128,102,65,72,64,197,167,1,38,209,196,64,92,0,167,145,0,255,80,65,210,68,81,208,80,16,133]

theorem envBound51577 : H12AffineFastState.Bounded env51577 := by
  intro p hp
  have h : env51577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51576_51577 : H12AffineEnvironment.transform 10 102 env51576 = env51577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 102 env51576 == env51577) = true)

def env51578 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,845,65,528,65536,66162,65665,517,529,836,649,66162,65537,145,65911,302,66083,64,67603,833,80,256,65831,17,341]

theorem envBound51578 : H12AffineFastState.Bounded env51578 := by
  intro p hp
  have h : env51578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51564_51578 : H12AffineEnvironment.transform 9 337 env51564 = env51578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env51564 == env51578) = true)

theorem identity51578 : scanCanonicalize (H12AffineFastState.compose env51578 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 182) := by decide +kernel

theorem selectedBound51578 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env51579 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,845,65,528,182,708,55,517,529,836,649,708,183,145,449,302,661,64,2213,833,80,256,401,17,341]

theorem envBound51579 : H12AffineFastState.Bounded env51579 := by
  intro p hp
  have h : env51579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51578_51579 : H12AffineEnvironment.transform 15 182 env51578 = env51579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 182 env51578 == env51579) = true)

def env51580 : List Nat := [2,4,8,16,32,64,128,192,512,145,2048,645,653,65,528,182,708,55,517,529,644,649,708,183,145,1,238,661,64,2213,641,80,192,81,17,149]

theorem envBound51580 : H12AffineFastState.Bounded env51580 := by
  intro p hp
  have h : env51580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51579_51580 : H12AffineEnvironment.transform 7 192 env51579 = env51580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 192 env51579 == env51580) = true)

theorem identity51580 : scanCanonicalize (H12AffineFastState.compose env51580 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 197) := by decide +kernel

theorem selectedBound51580 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env51581 : List Nat := [2,4,8,16,32,64,128,192,197,145,2048,64,72,65,213,182,1,55,192,212,65,76,1,183,145,1,238,80,64,2213,68,80,192,81,17,149]

theorem envBound51581 : H12AffineFastState.Bounded env51581 := by
  intro p hp
  have h : env51581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51580_51581 : H12AffineEnvironment.transform 8 197 env51580 = env51581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 197 env51580 == env51581) = true)

theorem identity51581 : scanCanonicalize (H12AffineFastState.compose env51581 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 119) := by decide +kernel

theorem selectedBound51581 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env51582 : List Nat := [2,4,8,16,32,64,128,192,197,145,119,64,72,65,213,182,1,55,192,212,65,76,1,183,145,1,238,80,64,210,68,80,192,81,17,149]

theorem envBound51582 : H12AffineFastState.Bounded env51582 := by
  intro p hp
  have h : env51582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51581_51582 : H12AffineEnvironment.transform 10 119 env51581 = env51582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 119 env51581 == env51582) = true)

theorem identity51582 : scanCanonicalize (H12AffineFastState.compose env51582 (packedSelected [1,4,8,9,12,13,15,16,17] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound51582 : packedSelected [1,4,8,9,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env51583 : List Nat := [2,4,8,16,32,1,128,129,132,145,54,1,9,0,148,182,1,55,129,149,0,13,1,183,145,1,175,17,1,147,5,17,129,16,17,149]

theorem envBound51583 : H12AffineFastState.Bounded env51583 := by
  intro p hp
  have h : env51583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51582_51583 : H12AffineEnvironment.transform 5 1 env51582 = env51583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env51582 == env51583) = true)

def env51584 : List Nat := [2,4,8,16,32,64,128,193,512,144,2048,644,652,65,528,182,708,55,517,529,645,649,708,183,145,0,239,661,64,2213,640,80,193,80,17,148]

theorem envBound51584 : H12AffineFastState.Bounded env51584 := by
  intro p hp
  have h : env51584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51579_51584 : H12AffineEnvironment.transform 7 193 env51579 = env51584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 193 env51579 == env51584) = true)

theorem identity51584 : scanCanonicalize (H12AffineFastState.compose env51584 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 85) := by decide +kernel

theorem selectedBound51584 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env51585 : List Nat := [2,4,8,16,32,64,85,20,512,69,2048,593,601,65,528,99,529,55,517,529,592,604,529,98,68,0,58,576,64,2160,597,80,20,80,17,65]

theorem envBound51585 : H12AffineFastState.Bounded env51585 := by
  intro p hp
  have h : env51585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51584_51585 : H12AffineEnvironment.transform 6 85 env51584 = env51585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 85 env51584 == env51585) = true)

theorem identity51585 : scanCanonicalize (H12AffineFastState.compose env51585 (packedSelected [4,5,8,9,10,13,15,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 630) := by decide +kernel

theorem selectedBound51585 : packedSelected [4,5,8,9,10,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env51586 : List Nat := [2,4,8,16,32,64,85,20,512,69,630,593,601,65,528,99,529,55,517,529,592,604,529,98,68,0,58,576,64,518,597,80,20,80,17,65]

theorem envBound51586 : H12AffineFastState.Bounded env51586 := by
  intro p hp
  have h : env51586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51585_51586 : H12AffineEnvironment.transform 10 630 env51585 = env51586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 630 env51585 == env51586) = true)

theorem identity51586 : scanCanonicalize (H12AffineFastState.compose env51586 (packedSelected [0,2,3,4,7,8,9,12,16,18,19] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound51586 : packedSelected [0,2,3,4,7,8,9,12,16,18,19] rootPS < 2^1333 := by decide +kernel

def env51587 : List Nat := [2,4,8,16,32,22,3,20,512,19,544,519,527,23,528,53,529,55,517,529,518,522,529,52,18,0,58,534,22,518,515,6,20,6,17,23]

theorem envBound51587 : H12AffineFastState.Bounded env51587 := by
  intro p hp
  have h : env51587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51586_51587 : H12AffineEnvironment.transform 5 22 env51586 = env51587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env51586 == env51587) = true)

theorem identity51587 : scanCanonicalize (H12AffineFastState.compose env51587 (packedSelected [0,1,2,5,8,9,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound51587 : packedSelected [0,1,2,5,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env51588 : List Nat := [2,4,8,16,32,22,3,20,43,19,11,44,36,23,59,53,58,55,46,58,45,33,58,52,18,0,58,61,22,45,40,6,20,6,17,23]

theorem envBound51588 : H12AffineFastState.Bounded env51588 := by
  intro p hp
  have h : env51588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51587_51588 : H12AffineEnvironment.transform 8 43 env51587 = env51588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env51587 == env51588) = true)

theorem identity51588 : scanCanonicalize (H12AffineFastState.compose env51588 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound51588 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env51589 : List Nat := [2,4,8,16,29,22,3,20,22,19,11,17,25,23,6,8,7,10,19,7,16,28,7,9,18,0,7,0,22,16,21,6,20,6,17,23]

theorem envBound51589 : H12AffineFastState.Bounded env51589 := by
  intro p hp
  have h : env51589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51588_51589 : H12AffineEnvironment.transform 4 29 env51588 = env51589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env51588 == env51589) = true)

theorem identity51589 : scanCanonicalize (H12AffineFastState.compose env51589 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound51589 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51590 : List Nat := [2,4,8,10,7,12,3,14,12,9,11,11,3,13,6,8,7,10,9,7,10,6,7,9,8,0,7,0,12,10,15,6,14,6,11,13]

theorem envBound51590 : H12AffineFastState.Bounded env51590 := by
  intro p hp
  have h : env51590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51589_51590 : H12AffineEnvironment.transform 3 10 env51589 = env51590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env51589 == env51590) = true)

theorem identity51590 : scanCanonicalize (H12AffineFastState.compose env51590 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound51590 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env51591 : List Nat := [2,4,7,5,7,3,3,1,3,6,4,4,3,2,6,7,7,5,6,7,5,6,7,6,7,0,7,0,3,5,0,6,1,6,4,2]

theorem envBound51591 : H12AffineFastState.Bounded env51591 := by
  intro p hp
  have h : env51591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51590_51591 : H12AffineEnvironment.transform 2 7 env51590 = env51591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env51590 == env51591) = true)

theorem identity51591 : scanCanonicalize (H12AffineFastState.compose env51591 (packedSelected [0,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound51591 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env51592 : List Nat := [2,3,0,2,0,3,3,1,3,1,3,3,3,2,1,0,0,2,1,0,2,1,0,1,0,0,0,0,3,2,0,1,1,1,3,2]

theorem envBound51592 : H12AffineFastState.Bounded env51592 := by
  intro p hp
  have h : env51592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2