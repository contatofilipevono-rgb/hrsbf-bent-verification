import H12CloudChart2Data108

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound26771 : H12AffineFastState.Bounded env26771 := by
  intro p hp
  have h : env26771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26770_26771 : H12AffineEnvironment.transform 11 2745 env26770 = env26771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2745 env26770 == env26771) = true)

theorem identity26771 : scanCanonicalize (H12AffineFastState.compose env26771 (packedSelected [0,1,5,7,11,12,15,17] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound26771 : packedSelected [0,1,5,7,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env26772 : List Nat := [2,4,8,16,11,17,128,256,512,5,2048,2706,25,276,2707,285,276,413,2946,2706,2706,396,17,2974,2839,2967,2951,276,276,648,20,17,257,261,276,2439]

theorem envBound26772 : H12AffineFastState.Bounded env26772 := by
  intro p hp
  have h : env26772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26771_26772 : H12AffineEnvironment.transform 4 11 env26771 = env26772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env26771 == env26772) = true)

theorem identity26772 : scanCanonicalize (H12AffineFastState.compose env26772 (packedSelected [1,3,10,11,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound26772 : packedSelected [1,3,10,11,15,18] rootPS < 2^1333 := by decide +kernel

def env26773 : List Nat := [2,4,8,16,11,17,128,134,512,5,2048,2706,25,146,2707,155,146,27,2564,2706,2706,10,17,2584,2705,2577,2561,146,146,648,20,17,135,131,146,2049]

theorem envBound26773 : H12AffineFastState.Bounded env26773 := by
  intro p hp
  have h : env26773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26772_26773 : H12AffineEnvironment.transform 7 134 env26772 = env26773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env26772 == env26773) = true)

theorem identity26773 : scanCanonicalize (H12AffineFastState.compose env26773 (packedSelected [4,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound26773 : packedSelected [4,7,10,11] rootPS < 2^1333 := by decide +kernel

def env26774 : List Nat := [2,4,8,16,11,17,128,134,512,5,137,539,25,146,538,155,146,27,653,539,539,10,17,657,536,664,648,146,146,648,20,17,135,131,146,136]

theorem envBound26774 : H12AffineFastState.Bounded env26774 := by
  intro p hp
  have h : env26774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26773_26774 : H12AffineEnvironment.transform 10 137 env26773 = env26774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env26773 == env26774) = true)

def env26775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65665,77934,13340,4096,477,17,69648,70887,78895,77841,1297,74814,81226,8204,8201,257,1280,1344,79470]

theorem envBound26775 : H12AffineFastState.Bounded env26775 := by
  intro p hp
  have h : env26775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26755_26775 : H12AffineEnvironment.transform 17 65665 env26755 = env26775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env26755 == env26775) = true)

theorem identity26775 : scanCanonicalize (H12AffineFastState.compose env26775 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5384) := by decide +kernel

theorem selectedBound26775 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1297,277,65536,1344,65665,66918,276,4096,477,17,69648,70887,65831,66841,1297,69942,67650,5380,5377,257,1280,1344,66406]

theorem envBound26776 : H12AffineFastState.Bounded env26776 := by
  intro p hp
  have h : env26776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26775_26776 : H12AffineEnvironment.transform 12 5384 env26775 = env26776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env26775 == env26776) = true)

def env26777 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5384,1297,277,65536,1296,65665,66870,276,4096,397,17,69648,70839,65831,66841,1297,69942,67602,5380,5377,257,1280,1296,66358]

theorem envBound26777 : H12AffineFastState.Bounded env26777 := by
  intro p hp
  have h : env26777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26776_26777 : H12AffineEnvironment.transform 5 16 env26776 = env26777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26776 == env26777) = true)

theorem identity26777 : scanCanonicalize (H12AffineFastState.compose env26777 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound26777 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env26778 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,277,1053,1297,277,65536,1296,65665,66870,276,277,397,17,65797,66978,65831,66841,1297,65571,67602,1041,1044,257,1280,1296,66358]

theorem envBound26778 : H12AffineFastState.Bounded env26778 := by
  intro p hp
  have h : env26778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26777_26778 : H12AffineEnvironment.transform 11 277 env26777 = env26778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env26777 == env26778) = true)

theorem identity26778 : scanCanonicalize (H12AffineFastState.compose env26778 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound26778 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env26779 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,277,1053,1297,277,1331,1296,1458,5,276,277,397,17,1078,145,1044,42,1297,1296,3361,1041,1044,257,1280,1296,1541]

theorem envBound26779 : H12AffineFastState.Bounded env26779 := by
  intro p hp
  have h : env26779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26778_26779 : H12AffineEnvironment.transform 15 1331 env26778 = env26779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env26778 == env26779) = true)

theorem identity26779 : scanCanonicalize (H12AffineFastState.compose env26779 (packedSelected [0,2,3,7,8,11,12,15,17] rootPS)) = affineNative (2^(9+1) ^^^ 559) := by decide +kernel

theorem selectedBound26779 : packedSelected [0,2,3,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env26780 : List Nat := [2,4,8,16,32,16,128,256,512,559,2048,277,562,830,277,796,831,925,5,276,277,397,17,537,145,571,42,830,831,2830,574,571,257,815,831,42]

theorem envBound26780 : H12AffineFastState.Bounded env26780 := by
  intro p hp
  have h : env26780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26779_26780 : H12AffineEnvironment.transform 9 559 env26779 = env26780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 559 env26779 == env26780) = true)

theorem identity26780 : scanCanonicalize (H12AffineFastState.compose env26780 (packedSelected [2,10,19] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound26780 : packedSelected [2,10,19] rootPS < 2^1333 := by decide +kernel

def env26781 : List Nat := [2,4,8,16,10,16,128,256,512,517,2048,277,536,788,277,796,789,925,5,276,277,397,17,537,145,529,0,788,789,2830,532,529,257,773,789,0]

theorem envBound26781 : H12AffineFastState.Bounded env26781 := by
  intro p hp
  have h : env26781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26780_26781 : H12AffineEnvironment.transform 4 10 env26780 = env26781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env26780 == env26781) = true)

theorem identity26781 : scanCanonicalize (H12AffineFastState.compose env26781 (packedSelected [0,2,5,7,8,10,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound26781 : packedSelected [0,2,5,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env26782 : List Nat := [2,4,8,16,10,16,128,256,512,517,26,277,536,788,277,796,789,925,5,276,277,397,17,537,145,529,0,788,789,788,532,529,257,773,789,0]

theorem envBound26782 : H12AffineFastState.Bounded env26782 := by
  intro p hp
  have h : env26782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26781_26782 : H12AffineEnvironment.transform 10 26 env26781 = env26782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env26781 == env26782) = true)

theorem identity26782 : scanCanonicalize (H12AffineFastState.compose env26782 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound26782 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env26783 : List Nat := [2,4,8,16,10,16,128,157,512,517,26,136,536,649,136,641,648,512,5,137,136,16,17,537,145,529,0,649,648,649,532,529,156,664,648,0]

theorem envBound26783 : H12AffineFastState.Bounded env26783 := by
  intro p hp
  have h : env26783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26782_26783 : H12AffineEnvironment.transform 7 157 env26782 = env26783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env26782 == env26783) = true)

def env26784 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5384,1297,277,65536,1297,65665,66871,276,4096,396,17,69648,70838,65831,66841,1297,69942,67603,5380,5377,257,1280,1297,66359]

theorem envBound26784 : H12AffineFastState.Bounded env26784 := by
  intro p hp
  have h : env26784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26776_26784 : H12AffineEnvironment.transform 5 17 env26776 = env26784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26776 == env26784) = true)

theorem identity26784 : scanCanonicalize (H12AffineFastState.compose env26784 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4130) := by decide +kernel

theorem selectedBound26784 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env26785 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5384,1297,277,4130,1297,4259,5397,276,4096,396,17,50,1172,4357,5435,1297,276,6193,5380,5377,257,1280,1297,4885]

theorem envBound26785 : H12AffineFastState.Bounded env26785 := by
  intro p hp
  have h : env26785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26784_26785 : H12AffineEnvironment.transform 15 4130 env26784 = env26785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4130 env26784 == env26785) = true)

theorem identity26785 : scanCanonicalize (H12AffineFastState.compose env26785 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound26785 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env26786 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,24,1297,277,1330,1297,1459,5,276,1296,396,17,50,1172,1045,43,1297,276,3361,20,17,257,1280,1297,1541]

theorem envBound26786 : H12AffineFastState.Bounded env26786 := by
  intro p hp
  have h : env26786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26785_26786 : H12AffineEnvironment.transform 11 1296 env26785 = env26786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env26785 == env26786) = true)

theorem identity26786 : scanCanonicalize (H12AffineFastState.compose env26786 (packedSelected [0,1,3,5,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound26786 : packedSelected [0,1,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env26787 : List Nat := [2,4,8,16,32,17,128,256,512,1024,26,1296,24,1297,277,1330,1297,1459,5,276,1296,396,17,50,1172,1045,43,1297,276,1339,20,17,257,1280,1297,1541]

theorem envBound26787 : H12AffineFastState.Bounded env26787 := by
  intro p hp
  have h : env26787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26786_26787 : H12AffineEnvironment.transform 10 26 env26786 = env26787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env26786 == env26787) = true)

theorem identity26787 : scanCanonicalize (H12AffineFastState.compose env26787 (packedSelected [1,2,3,5,8,12,13,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 390) := by decide +kernel

theorem selectedBound26787 : packedSelected [1,2,3,5,8,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env26788 : List Nat := [2,4,8,16,32,17,128,256,390,1024,26,1296,24,1297,277,1330,1297,1459,5,276,1296,396,17,50,1172,1045,43,1297,276,1339,20,17,257,1280,1297,1411]

theorem envBound26788 : H12AffineFastState.Bounded env26788 := by
  intro p hp
  have h : env26788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26787_26788 : H12AffineEnvironment.transform 8 390 env26787 = env26788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 390 env26787 == env26788) = true)

theorem identity26788 : scanCanonicalize (H12AffineFastState.compose env26788 (packedSelected [2,3,8,13] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound26788 : packedSelected [2,3,8,13] rootPS < 2^1333 := by decide +kernel

def env26789 : List Nat := [2,4,8,16,32,17,18,256,276,1024,26,1296,24,1297,277,1330,1297,1313,5,276,1296,286,17,50,1030,1045,43,1297,276,1339,20,17,257,1280,1297,1297]

theorem envBound26789 : H12AffineFastState.Bounded env26789 := by
  intro p hp
  have h : env26789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26788_26789 : H12AffineEnvironment.transform 6 18 env26788 = env26789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env26788 == env26789) = true)

theorem identity26789 : scanCanonicalize (H12AffineFastState.compose env26789 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound26789 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env26790 : List Nat := [2,4,8,16,32,17,18,15,27,1024,26,1055,24,1054,26,1085,1054,1070,5,27,1055,17,17,50,1030,1045,43,1054,27,1076,20,17,14,1039,1054,1054]

theorem envBound26790 : H12AffineFastState.Bounded env26790 := by
  intro p hp
  have h : env26790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26789_26790 : H12AffineEnvironment.transform 7 15 env26789 = env26790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env26789 == env26790) = true)

theorem identity26790 : scanCanonicalize (H12AffineFastState.compose env26790 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound26790 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env26791 : List Nat := [2,4,8,16,32,17,18,15,27,5,26,26,24,27,26,56,27,43,5,27,26,17,17,50,3,16,43,27,27,49,20,17,14,10,27,27]

theorem envBound26791 : H12AffineFastState.Bounded env26791 := by
  intro p hp
  have h : env26791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26790_26791 : H12AffineEnvironment.transform 9 5 env26790 = env26791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env26790 == env26791) = true)

theorem identity26791 : scanCanonicalize (H12AffineFastState.compose env26791 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound26791 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26792 : List Nat := [2,4,8,16,17,17,18,15,27,5,26,26,24,27,26,9,27,26,5,27,26,17,17,3,3,16,26,27,27,0,20,17,14,10,27,27]

theorem envBound26792 : H12AffineFastState.Bounded env26792 := by
  intro p hp
  have h : env26792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26791_26792 : H12AffineEnvironment.transform 4 17 env26791 = env26792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env26791 == env26792) = true)

theorem identity26792 : scanCanonicalize (H12AffineFastState.compose env26792 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound26792 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26793 : List Nat := [2,4,8,11,10,10,9,15,0,5,1,1,3,0,1,9,0,1,5,0,1,10,10,3,3,11,1,0,0,0,15,10,14,10,0,0]

theorem envBound26793 : H12AffineFastState.Bounded env26793 := by
  intro p hp
  have h : env26793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26792_26793 : H12AffineEnvironment.transform 3 11 env26792 = env26793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env26792 == env26793) = true)

theorem identity26793 : scanCanonicalize (H12AffineFastState.compose env26793 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound26793 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26794 : List Nat := [2,4,4,7,6,6,5,3,0,5,1,1,3,0,1,5,0,1,5,0,1,6,6,3,3,7,1,0,0,0,3,6,2,6,0,0]

theorem envBound26794 : H12AffineFastState.Bounded env26794 := by
  intro p hp
  have h : env26794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26793_26794 : H12AffineEnvironment.transform 2 4 env26793 = env26794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env26793 == env26794) = true)

def env26795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147520,284033,86518,209263,225345,148800,74814,96347,381312,513221,257,131136,1344,95103]

theorem envBound26795 : H12AffineFastState.Bounded env26795 := by
  intro p hp
  have h : env26795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26664_26795 : H12AffineEnvironment.transform 23 284033 env26664 = env26795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env26664 == env26795) = true)

def env26796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95615,32769,4096,61649,16,284033,86518,94527,77841,1296,74814,96347,381312,365717,257,16400,1344,95103]

theorem envBound26796 : H12AffineFastState.Bounded env26796 := by
  intro p hp
  have h : env26796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26795_26796 : H12AffineEnvironment.transform 16 16464 env26795 = env26796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env26795 == env26796) = true)

def env26797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77935,32769,4096,46529,16,266385,70886,78895,77841,1296,74814,81227,365712,365717,257,1280,1344,79471]

theorem envBound26797 : H12AffineFastState.Bounded env26797 := by
  intro p hp
  have h : env26797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26796_26797 : H12AffineEnvironment.transform 13 1296 env26796 = env26797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env26796 == env26797) = true)

theorem identity26797 : scanCanonicalize (H12AffineFastState.compose env26797 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound26797 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env26798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,262144,77935,13340,4096,476,16,266385,70886,78895,77841,1296,74814,81227,336013,336008,257,1280,1344,79471]

theorem envBound26798 : H12AffineFastState.Bounded env26798 := by
  intro p hp
  have h : env26798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26797_26798 : H12AffineEnvironment.transform 14 13341 env26797 = env26798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env26797 == env26798) = true)

def env26799 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65664,77935,13340,4096,476,16,69649,70886,78895,77841,1296,74814,81227,8205,8200,257,1280,1344,79471]

theorem envBound26799 : H12AffineFastState.Bounded env26799 := by
  intro p hp
  have h : env26799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26798_26799 : H12AffineEnvironment.transform 17 65664 env26798 = env26799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env26798 == env26799) = true)

theorem identity26799 : scanCanonicalize (H12AffineFastState.compose env26799 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound26799 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,12590,1344,12718,321,13340,4096,476,16,8511,9672,1281,319,1296,5392,3173,8205,8200,257,1280,1344,1857]

theorem envBound26800 : H12AffineFastState.Bounded env26800 := by
  intro p hp
  have h : env26800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26799_26800 : H12AffineEnvironment.transform 15 12590 env26799 = env26800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env26799 == env26800) = true)

def env26801 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,12637,12590,0,12718,321,12636,4096,476,16,8511,8328,65,319,80,4176,2341,8205,8200,257,64,0,513]

theorem envBound26801 : H12AffineFastState.Bounded env26801 := by
  intro p hp
  have h : env26801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26800_26801 : H12AffineEnvironment.transform 9 320 env26800 = env26801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env26800 == env26801) = true)

theorem identity26801 : scanCanonicalize (H12AffineFastState.compose env26801 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound26801 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env26802 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,325,8192,80,8216,8299,0,8427,321,8217,325,476,16,8511,8328,65,319,80,277,2341,8205,8200,257,64,0,513]

theorem envBound26802 : H12AffineFastState.Bounded env26802 := by
  intro p hp
  have h : env26802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26801_26802 : H12AffineEnvironment.transform 11 325 env26801 = env26802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env26801 == env26802) = true)

theorem identity26802 : scanCanonicalize (H12AffineFastState.compose env26802 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound26802 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env26803 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,325,24,80,0,115,0,243,321,1,325,476,16,295,144,65,319,80,277,2341,21,16,257,64,0,513]

theorem envBound26803 : H12AffineFastState.Bounded env26803 := by
  intro p hp
  have h : env26803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26802_26803 : H12AffineEnvironment.transform 12 24 env26802 = env26803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env26802 == env26803) = true)

theorem identity26803 : scanCanonicalize (H12AffineFastState.compose env26803 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound26803 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26804 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,325,9,65,0,98,0,226,321,1,325,461,1,295,129,65,302,65,260,2341,4,1,257,64,0,513]

theorem envBound26804 : H12AffineFastState.Bounded env26804 := by
  intro p hp
  have h : env26804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26803_26804 : H12AffineEnvironment.transform 3 1 env26803 = env26804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env26803 == env26804) = true)

theorem identity26804 : scanCanonicalize (H12AffineFastState.compose env26804 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 460) := by decide +kernel

theorem selectedBound26804 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env26805 : List Nat := [2,4,8,1,32,64,128,256,460,320,2048,325,9,65,0,98,0,226,321,1,325,461,1,295,129,65,302,65,260,2341,4,1,257,64,0,461]

theorem envBound26805 : H12AffineFastState.Bounded env26805 := by
  intro p hp
  have h : env26805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26804_26805 : H12AffineEnvironment.transform 8 460 env26804 = env26805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 460 env26804 == env26805) = true)

theorem identity26805 : scanCanonicalize (H12AffineFastState.compose env26805 (packedSelected [0,2,3,7,8,11,12,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound26805 : packedSelected [0,2,3,7,8,11,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env26806 : List Nat := [2,4,8,1,32,64,128,256,460,320,130,325,9,65,0,98,0,226,321,1,325,461,1,295,129,65,302,65,260,423,4,1,257,64,0,461]

theorem envBound26806 : H12AffineFastState.Bounded env26806 := by
  intro p hp
  have h : env26806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26805_26806 : H12AffineEnvironment.transform 10 130 env26805 = env26806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env26805 == env26806) = true)

theorem identity26806 : scanCanonicalize (H12AffineFastState.compose env26806 (packedSelected [0,3,7,8,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound26806 : packedSelected [0,3,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env26807 : List Nat := [2,4,8,1,32,64,128,4,200,68,130,65,9,65,0,98,0,226,69,1,65,201,1,35,129,65,42,65,0,163,4,1,5,64,0,201]

theorem envBound26807 : H12AffineFastState.Bounded env26807 := by
  intro p hp
  have h : env26807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26806_26807 : H12AffineEnvironment.transform 7 4 env26806 = env26807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env26806 == env26807) = true)

theorem identity26807 : scanCanonicalize (H12AffineFastState.compose env26807 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound26807 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env26808 : List Nat := [2,4,8,1,32,64,35,4,107,68,33,65,9,65,0,98,0,65,69,1,65,106,1,35,34,65,42,65,0,0,4,1,5,64,0,106]

theorem envBound26808 : H12AffineFastState.Bounded env26808 := by
  intro p hp
  have h : env26808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26807_26808 : H12AffineEnvironment.transform 6 35 env26807 = env26808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env26807 == env26808) = true)

theorem identity26808 : scanCanonicalize (H12AffineFastState.compose env26808 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound26808 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26809 : List Nat := [2,0,8,1,32,64,35,0,107,64,33,65,9,65,0,98,0,65,65,1,65,106,1,35,34,65,42,65,0,0,0,1,1,64,0,106]

theorem envBound26809 : H12AffineFastState.Bounded env26809 := by
  intro p hp
  have h : env26809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26808_26809 : H12AffineEnvironment.transform 1 0 env26808 = env26809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env26808 == env26809) = true)

theorem identity26809 : scanCanonicalize (H12AffineFastState.compose env26809 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound26809 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env26810 : List Nat := [1,0,8,1,32,64,32,0,104,64,33,65,9,65,0,97,0,65,65,1,65,105,1,32,33,65,41,65,0,0,0,1,1,64,0,105]

theorem envBound26810 : H12AffineFastState.Bounded env26810 := by
  intro p hp
  have h : env26810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26809_26810 : H12AffineEnvironment.transform 0 1 env26809 = env26810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env26809 == env26810) = true)

theorem identity26810 : scanCanonicalize (H12AffineFastState.compose env26810 (packedSelected [2,7] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound26810 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env26811 : List Nat := [1,0,8,1,32,0,32,0,40,0,33,1,9,1,0,33,0,1,1,1,1,41,1,32,33,1,41,1,0,0,0,1,1,0,0,41]

theorem envBound26811 : H12AffineFastState.Bounded env26811 := by
  intro p hp
  have h : env26811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26810_26811 : H12AffineEnvironment.transform 5 0 env26810 = env26811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env26810 == env26811) = true)

theorem identity26811 : scanCanonicalize (H12AffineFastState.compose env26811 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound26811 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26812 : List Nat := [1,0,8,1,8,0,8,0,0,0,9,1,9,1,0,9,0,1,1,1,1,1,1,8,9,1,1,1,0,0,0,1,1,0,0,1]

theorem envBound26812 : H12AffineFastState.Bounded env26812 := by
  intro p hp
  have h : env26812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26811_26812 : H12AffineEnvironment.transform 4 8 env26811 = env26812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env26811 == env26812) = true)

def env26813 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12636,12590,1,12718,321,12637,4096,476,16,8511,8329,64,319,81,4177,2340,8205,8200,257,65,1,512]

theorem envBound26813 : H12AffineFastState.Bounded env26813 := by
  intro p hp
  have h : env26813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26800_26813 : H12AffineEnvironment.transform 9 321 env26800 = env26813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env26800 == env26813) = true)

theorem identity26813 : scanCanonicalize (H12AffineFastState.compose env26813 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound26813 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env26814 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,276,8192,81,8264,8250,1,8378,321,8265,276,476,16,8511,8329,64,319,81,325,2340,8205,8200,257,65,1,512]

theorem envBound26814 : H12AffineFastState.Bounded env26814 := by
  intro p hp
  have h : env26814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26813_26814 : H12AffineEnvironment.transform 11 276 env26813 = env26814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env26813 == env26814) = true)

theorem identity26814 : scanCanonicalize (H12AffineFastState.compose env26814 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound26814 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env26815 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,80,8192,81,8264,8250,1,8378,5,8265,80,152,16,8315,8329,64,123,81,1,2144,8205,8200,69,65,1,512]

theorem envBound26815 : H12AffineFastState.Bounded env26815 := by
  intro p hp
  have h : env26815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26814_26815 : H12AffineEnvironment.transform 7 68 env26814 = env26815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env26814 == env26815) = true)

theorem identity26815 : scanCanonicalize (H12AffineFastState.compose env26815 (packedSelected [10,11,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound26815 : packedSelected [10,11,17,18] rootPS < 2^1333 := by decide +kernel

def env26816 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,80,161,81,233,155,1,27,5,232,80,152,16,218,40,64,123,81,1,2144,172,169,69,65,1,512]

theorem envBound26816 : H12AffineFastState.Bounded env26816 := by
  intro p hp
  have h : env26816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26815_26816 : H12AffineEnvironment.transform 12 161 env26815 = env26816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env26815 == env26816) = true)

theorem identity26816 : scanCanonicalize (H12AffineFastState.compose env26816 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound26816 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env26817 : List Nat := [2,4,8,16,32,64,128,68,512,5,147,80,161,81,233,155,1,27,5,232,80,152,16,218,40,64,123,81,1,243,172,169,69,65,1,512]

theorem envBound26817 : H12AffineFastState.Bounded env26817 := by
  intro p hp
  have h : env26817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26816_26817 : H12AffineEnvironment.transform 10 147 env26816 = env26817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env26816 == env26817) = true)

theorem identity26817 : scanCanonicalize (H12AffineFastState.compose env26817 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound26817 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env26818 : List Nat := [2,4,8,16,32,64,88,68,512,5,75,80,121,81,49,67,1,27,5,48,80,64,16,2,40,64,123,81,1,43,116,113,69,65,1,512]

theorem envBound26818 : H12AffineFastState.Bounded env26818 := by
  intro p hp
  have h : env26818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26817_26818 : H12AffineEnvironment.transform 6 88 env26817 = env26818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env26817 == env26818) = true)

theorem identity26818 : scanCanonicalize (H12AffineFastState.compose env26818 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 74) := by decide +kernel

theorem selectedBound26818 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env26819 : List Nat := [2,4,8,16,32,64,88,68,74,5,75,80,121,81,49,67,1,27,5,48,80,64,16,2,40,64,123,81,1,43,116,113,69,65,1,74]

theorem envBound26819 : H12AffineFastState.Bounded env26819 := by
  intro p hp
  have h : env26819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26818_26819 : H12AffineEnvironment.transform 8 74 env26818 = env26819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 74 env26818 == env26819) = true)

theorem identity26819 : scanCanonicalize (H12AffineFastState.compose env26819 (packedSelected [0,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound26819 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env26820 : List Nat := [2,4,8,16,10,64,88,68,74,5,75,80,83,81,27,67,1,27,5,26,80,64,16,2,2,64,81,81,1,1,94,91,69,65,1,74]

theorem envBound26820 : H12AffineFastState.Bounded env26820 := by
  intro p hp
  have h : env26820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26819_26820 : H12AffineEnvironment.transform 4 10 env26819 = env26820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env26819 == env26820) = true)

theorem identity26820 : scanCanonicalize (H12AffineFastState.compose env26820 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound26820 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env26821 : List Nat := [2,4,8,11,10,64,67,68,74,5,75,75,72,74,0,67,1,0,5,1,75,64,11,2,2,64,74,74,1,1,69,64,69,65,1,74]

theorem envBound26821 : H12AffineFastState.Bounded env26821 := by
  intro p hp
  have h : env26821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26820_26821 : H12AffineEnvironment.transform 3 11 env26820 = env26821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env26820 == env26821) = true)

theorem identity26821 : scanCanonicalize (H12AffineFastState.compose env26821 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound26821 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26822 : List Nat := [2,4,8,11,10,13,14,9,7,5,6,6,5,7,0,14,1,0,5,1,6,13,11,2,2,13,7,7,1,1,8,13,8,12,1,7]

theorem envBound26822 : H12AffineFastState.Bounded env26822 := by
  intro p hp
  have h : env26822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26821_26822 : H12AffineEnvironment.transform 5 13 env26821 = env26822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env26821 == env26822) = true)

theorem identity26822 : scanCanonicalize (H12AffineFastState.compose env26822 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound26822 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26823 : List Nat := [2,2,8,11,10,11,8,9,1,3,0,0,3,1,0,8,1,0,3,1,0,11,11,2,2,11,1,1,1,1,8,11,8,10,1,1]

theorem envBound26823 : H12AffineFastState.Bounded env26823 := by
  intro p hp
  have h : env26823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26822_26823 : H12AffineEnvironment.transform 1 2 env26822 = env26823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env26822 == env26823) = true)

def env26824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65665,77935,13340,4096,476,16,69648,70886,78895,77841,1296,74814,81227,8204,8201,257,1280,1344,79471]

theorem envBound26824 : H12AffineFastState.Bounded env26824 := by
  intro p hp
  have h : env26824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26798_26824 : H12AffineEnvironment.transform 17 65665 env26798 = env26824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env26798 == env26824) = true)

theorem identity26824 : scanCanonicalize (H12AffineFastState.compose env26824 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9326) := by decide +kernel

theorem selectedBound26824 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,9326,1344,9455,5121,13340,4096,476,16,13438,12424,4161,5247,1296,80,6437,8204,8201,257,1280,1344,4609]

theorem envBound26825 : H12AffineFastState.Bounded env26825 := by
  intro p hp
  have h : env26825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26824_26825 : H12AffineEnvironment.transform 15 9326 env26824 = env26825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9326 env26824 == env26825) = true)

def env26826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9245,9326,1344,9455,1025,9244,0,476,16,9342,8328,65,1151,1296,80,2341,8204,8201,257,1280,1344,513]

theorem envBound26826 : H12AffineFastState.Bounded env26826 := by
  intro p hp
  have h : env26826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26825_26826 : H12AffineEnvironment.transform 11 0 env26825 = env26826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env26825 == env26826) = true)

theorem identity26826 : scanCanonicalize (H12AffineFastState.compose env26826 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound26826 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env26827 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,0,8192,1109,9245,9326,1029,9455,1025,9244,0,153,16,9342,8328,65,1151,1109,80,2144,8204,8201,68,1093,1029,513]

theorem envBound26827 : H12AffineFastState.Bounded env26827 := by
  intro p hp
  have h : env26827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26826_26827 : H12AffineEnvironment.transform 7 69 env26826 = env26827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env26826 == env26827) = true)

theorem identity26827 : scanCanonicalize (H12AffineFastState.compose env26827 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound26827 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env26828 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,0,1052,1109,1,114,1029,243,1025,0,0,153,16,98,1172,65,1151,1109,80,2144,1040,1045,68,1093,1029,513]

theorem envBound26828 : H12AffineFastState.Bounded env26828 := by
  intro p hp
  have h : env26828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26827_26828 : H12AffineEnvironment.transform 12 1052 env26827 = env26828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env26827 == env26828) = true)

theorem identity26828 : scanCanonicalize (H12AffineFastState.compose env26828 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound26828 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26829 : List Nat := [2,4,8,0,32,64,128,69,512,1024,2048,0,1036,1093,1,98,1029,227,1025,0,0,137,0,98,1156,65,1135,1093,64,2144,1024,1029,68,1093,1029,513]

theorem envBound26829 : H12AffineFastState.Bounded env26829 := by
  intro p hp
  have h : env26829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26828_26829 : H12AffineEnvironment.transform 3 0 env26828 = env26829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env26828 == env26829) = true)

theorem identity26829 : scanCanonicalize (H12AffineFastState.compose env26829 (packedSelected [1,2,3,5,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 234) := by decide +kernel

theorem selectedBound26829 : packedSelected [1,2,3,5,13,15] rootPS < 2^1333 := by decide +kernel

def env26830 : List Nat := [2,4,8,0,32,64,128,69,512,234,2048,0,230,175,1,98,239,227,235,0,0,137,0,98,110,65,133,175,64,2144,234,239,68,175,239,513]

theorem envBound26830 : H12AffineFastState.Bounded env26830 := by
  intro p hp
  have h : env26830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26829_26830 : H12AffineEnvironment.transform 9 234 env26829 = env26830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 234 env26829 == env26830) = true)

theorem identity26830 : scanCanonicalize (H12AffineFastState.compose env26830 (packedSelected [1,3,5,11,12,18] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound26830 : packedSelected [1,3,5,11,12,18] rootPS < 2^1333 := by decide +kernel

def env26831 : List Nat := [2,4,8,0,32,64,128,69,137,234,2048,0,230,175,1,98,239,227,235,0,0,137,0,98,110,65,133,175,64,2144,234,239,68,175,239,136]

theorem envBound26831 : H12AffineFastState.Bounded env26831 := by
  intro p hp
  have h : env26831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26830_26831 : H12AffineEnvironment.transform 8 137 env26830 = env26831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env26830 == env26831) = true)

theorem identity26831 : scanCanonicalize (H12AffineFastState.compose env26831 (packedSelected [1,2,3,12] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound26831 : packedSelected [1,2,3,12] rootPS < 2^1333 := by decide +kernel

def env26832 : List Nat := [2,4,8,0,32,64,40,69,33,66,2048,0,78,7,1,98,71,75,67,0,0,33,0,98,110,65,45,7,64,2144,66,71,68,7,71,32]

theorem envBound26832 : H12AffineFastState.Bounded env26832 := by
  intro p hp
  have h : env26832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26831_26832 : H12AffineEnvironment.transform 6 40 env26831 = env26832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env26831 == env26832) = true)

theorem identity26832 : scanCanonicalize (H12AffineFastState.compose env26832 (packedSelected [0,1,3,4,5,7,9,13] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound26832 : packedSelected [0,1,3,4,5,7,9,13] rootPS < 2^1333 := by decide +kernel

def env26833 : List Nat := [2,3,8,0,32,64,40,66,33,66,2048,0,73,0,1,98,64,75,67,0,0,33,0,98,105,65,42,0,64,2144,66,64,67,0,64,32]

theorem envBound26833 : H12AffineFastState.Bounded env26833 := by
  intro p hp
  have h : env26833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26832_26833 : H12AffineEnvironment.transform 1 3 env26832 = env26833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env26832 == env26833) = true)

theorem identity26833 : scanCanonicalize (H12AffineFastState.compose env26833 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound26833 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env26834 : List Nat := [2,3,2,0,32,64,34,66,33,66,2048,0,67,0,1,98,64,65,67,0,0,33,0,98,99,65,32,0,64,2144,66,64,67,0,64,32]

theorem envBound26834 : H12AffineFastState.Bounded env26834 := by
  intro p hp
  have h : env26834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26833_26834 : H12AffineEnvironment.transform 2 2 env26833 = env26834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env26833 == env26834) = true)

theorem identity26834 : scanCanonicalize (H12AffineFastState.compose env26834 (packedSelected [1,4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound26834 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env26835 : List Nat := [1,0,1,0,32,64,33,65,33,65,2048,0,64,0,1,97,64,65,64,0,0,33,0,97,96,65,32,0,64,2144,65,64,64,0,64,32]

theorem envBound26835 : H12AffineFastState.Bounded env26835 := by
  intro p hp
  have h : env26835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26834_26835 : H12AffineEnvironment.transform 0 1 env26834 = env26835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env26834 == env26835) = true)

theorem identity26835 : scanCanonicalize (H12AffineFastState.compose env26835 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound26835 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env26836 : List Nat := [1,0,1,0,32,1,33,0,33,0,2048,0,1,0,1,32,1,0,1,0,0,33,0,32,33,0,32,0,1,2081,0,1,1,0,1,32]

theorem envBound26836 : H12AffineFastState.Bounded env26836 := by
  intro p hp
  have h : env26836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26835_26836 : H12AffineEnvironment.transform 5 1 env26835 = env26836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env26835 == env26836) = true)

theorem identity26836 : scanCanonicalize (H12AffineFastState.compose env26836 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound26836 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26837 : List Nat := [1,0,1,0,32,1,33,0,33,0,33,0,1,0,1,32,1,0,1,0,0,33,0,32,33,0,32,0,1,0,0,1,1,0,1,32]

theorem envBound26837 : H12AffineFastState.Bounded env26837 := by
  intro p hp
  have h : env26837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26836_26837 : H12AffineEnvironment.transform 10 33 env26836 = env26837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env26836 == env26837) = true)

theorem identity26837 : scanCanonicalize (H12AffineFastState.compose env26837 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound26837 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26838 : List Nat := [1,0,1,0,1,1,0,0,0,0,0,0,1,0,1,1,1,0,1,0,0,0,0,1,0,0,1,0,1,0,0,1,1,0,1,1]

theorem envBound26838 : H12AffineFastState.Bounded env26838 := by
  intro p hp
  have h : env26838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26837_26838 : H12AffineEnvironment.transform 4 1 env26837 = env26838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env26837 == env26838) = true)

def env26839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9244,9326,1344,9455,1024,9245,1,476,16,9343,8329,64,1150,1296,80,2340,8204,8201,257,1280,1344,512]

theorem envBound26839 : H12AffineFastState.Bounded env26839 := by
  intro p hp
  have h : env26839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26825_26839 : H12AffineEnvironment.transform 11 1 env26825 = env26839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env26825 == env26839) = true)

theorem identity26839 : scanCanonicalize (H12AffineFastState.compose env26839 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound26839 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env26840 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,1,8192,1029,9244,9326,1109,9455,1024,9245,1,201,16,9343,8329,64,1150,1029,80,2097,8204,8201,20,1045,1109,512]

theorem envBound26840 : H12AffineFastState.Bounded env26840 := by
  intro p hp
  have h : env26840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26839_26840 : H12AffineEnvironment.transform 7 21 env26839 = env26840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env26839 == env26840) = true)

theorem identity26840 : scanCanonicalize (H12AffineFastState.compose env26840 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound26840 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env26841 : List Nat := [2,4,8,16,32,64,128,21,512,5,2048,1,8192,0,8217,8299,80,8426,5,8216,1,201,16,8314,8329,64,123,0,80,2097,8204,8201,20,16,80,512]

theorem envBound26841 : H12AffineFastState.Bounded env26841 := by
  intro p hp
  have h : env26841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26840_26841 : H12AffineEnvironment.transform 9 5 env26840 = env26841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env26840 == env26841) = true)

theorem identity26841 : scanCanonicalize (H12AffineFastState.compose env26841 (packedSelected [0,1,2,3,5,7,8,10,13,18] rootPS)) = affineNative (2^(10+1) ^^^ 586) := by decide +kernel

theorem selectedBound26841 : packedSelected [0,1,2,3,5,7,8,10,13,18] rootPS < 2^1333 := by decide +kernel

def env26842 : List Nat := [2,4,8,16,32,64,128,21,512,5,586,1,8192,0,8217,8299,80,8426,5,8216,1,201,16,8314,8329,64,123,0,80,635,8204,8201,20,16,80,512]

theorem envBound26842 : H12AffineFastState.Bounded env26842 := by
  intro p hp
  have h : env26842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26841_26842 : H12AffineEnvironment.transform 10 586 env26841 = env26842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 586 env26841 == env26842) = true)

theorem identity26842 : scanCanonicalize (H12AffineFastState.compose env26842 (packedSelected [1,2,3,10,13,17] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound26842 : packedSelected [1,2,3,10,13,17] rootPS < 2^1333 := by decide +kernel

def env26843 : List Nat := [2,4,8,16,32,64,128,21,137,5,195,1,8192,0,8217,8299,80,8426,5,8216,1,201,16,8314,8329,64,123,0,80,242,8204,8201,20,16,80,137]

theorem envBound26843 : H12AffineFastState.Bounded env26843 := by
  intro p hp
  have h : env26843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26842_26843 : H12AffineEnvironment.transform 8 137 env26842 = env26843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env26842 == env26843) = true)

theorem identity26843 : scanCanonicalize (H12AffineFastState.compose env26843 (packedSelected [0,1,2,4,5,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound26843 : packedSelected [0,1,2,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env26844 : List Nat := [2,4,8,16,32,64,128,21,137,5,195,1,160,0,185,203,80,74,5,184,1,201,16,218,41,64,123,0,80,242,172,169,20,16,80,137]

theorem envBound26844 : H12AffineFastState.Bounded env26844 := by
  intro p hp
  have h : env26844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26843_26844 : H12AffineEnvironment.transform 12 160 env26843 = env26844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env26843 == env26844) = true)

theorem identity26844 : scanCanonicalize (H12AffineFastState.compose env26844 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound26844 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env26845 : List Nat := [2,4,8,16,32,64,105,21,96,5,42,1,73,0,80,34,80,74,5,81,1,32,16,51,41,64,123,0,80,27,69,64,20,16,80,96]

theorem envBound26845 : H12AffineFastState.Bounded env26845 := by
  intro p hp
  have h : env26845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26844_26845 : H12AffineEnvironment.transform 6 105 env26844 = env26845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env26844 == env26845) = true)

theorem identity26845 : scanCanonicalize (H12AffineFastState.compose env26845 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound26845 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env26846 : List Nat := [2,4,8,16,32,10,35,21,42,5,42,1,3,0,26,34,26,0,5,27,1,32,16,51,41,10,49,0,26,27,15,10,20,16,26,42]

theorem envBound26846 : H12AffineFastState.Bounded env26846 := by
  intro p hp
  have h : env26846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26845_26846 : H12AffineEnvironment.transform 5 10 env26845 = env26846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env26845 == env26846) = true)

theorem identity26846 : scanCanonicalize (H12AffineFastState.compose env26846 (packedSelected [1,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound26846 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env26847 : List Nat := [2,4,8,11,32,10,35,14,42,5,42,1,3,0,1,34,1,0,5,0,1,32,11,40,41,10,42,0,1,0,15,10,15,11,1,42]

theorem envBound26847 : H12AffineFastState.Bounded env26847 := by
  intro p hp
  have h : env26847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26846_26847 : H12AffineEnvironment.transform 3 11 env26846 = env26847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env26846 == env26847) = true)

theorem identity26847 : scanCanonicalize (H12AffineFastState.compose env26847 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound26847 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26848 : List Nat := [2,2,8,11,32,10,35,8,42,3,42,1,3,0,1,34,1,0,3,0,1,32,11,40,41,10,42,0,1,0,9,10,9,11,1,42]

theorem envBound26848 : H12AffineFastState.Bounded env26848 := by
  intro p hp
  have h : env26848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26847_26848 : H12AffineEnvironment.transform 1 2 env26847 = env26848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env26847 == env26848) = true)

theorem identity26848 : scanCanonicalize (H12AffineFastState.compose env26848 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound26848 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26849 : List Nat := [2,2,8,11,10,10,9,8,0,3,0,1,3,0,1,8,1,0,3,0,1,10,11,2,3,10,0,0,1,0,9,10,9,11,1,0]

theorem envBound26849 : H12AffineFastState.Bounded env26849 := by
  intro p hp
  have h : env26849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26848_26849 : H12AffineEnvironment.transform 4 10 env26848 = env26849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env26848 == env26849) = true)

def env26850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77934,32769,4096,46528,16,266384,70887,78894,77841,1296,74814,81226,365713,365717,257,1281,1344,79470]

theorem envBound26850 : H12AffineFastState.Bounded env26850 := by
  intro p hp
  have h : env26850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26796_26850 : H12AffineEnvironment.transform 13 1297 env26796 = env26850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env26796 == env26850) = true)

theorem identity26850 : scanCanonicalize (H12AffineFastState.compose env26850 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound26850 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env26851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32882,1345,262144,45084,32769,4096,46528,16,266384,38037,46172,45155,1296,42060,48440,267491,267495,257,1281,1344,46620]

theorem envBound26851 : H12AffineFastState.Bounded env26851 := by
  intro p hp
  have h : env26851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26850_26851 : H12AffineEnvironment.transform 15 32882 env26850 = env26851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env26850 == env26851) = true)

def env26852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1345,262144,42332,32769,1344,41088,16,263632,33237,41244,42275,1296,42060,43128,262563,262567,257,1281,1344,41820]

theorem envBound26852 : H12AffineFastState.Bounded env26852 := by
  intro p hp
  have h : env26852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26851_26852 : H12AffineEnvironment.transform 11 1344 env26851 = env26852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env26851 == env26852) = true)

theorem identity26852 : scanCanonicalize (H12AffineFastState.compose env26852 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 487) := by decide +kernel

theorem selectedBound26852 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1345,487,42332,32769,1344,41088,16,1079,33237,41244,42275,1296,42060,43128,68,64,257,1281,1344,41820]

theorem envBound26853 : H12AffineFastState.Bounded env26853 := by
  intro p hp
  have h : env26853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26852_26853 : H12AffineEnvironment.transform 17 487 env26852 = env26853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 487 env26852 == env26853) = true)

theorem identity26853 : scanCanonicalize (H12AffineFastState.compose env26853 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound26853 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env26854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,8540,8494,1345,487,1024,8541,1344,476,16,1079,8329,64,1151,1296,1296,2340,68,64,257,1281,1344,512]

theorem envBound26854 : H12AffineFastState.Bounded env26854 := by
  intro p hp
  have h : env26854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26853_26854 : H12AffineEnvironment.transform 14 8540 env26853 = env26854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env26853 == env26854) = true)

theorem identity26854 : scanCanonicalize (H12AffineFastState.compose env26854 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound26854 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env26855 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,277,8192,324,8540,8494,276,487,85,8541,277,476,16,98,8329,64,42,325,325,2340,68,64,257,340,277,512]

theorem envBound26855 : H12AffineFastState.Bounded env26855 := by
  intro p hp
  have h : env26855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26854_26855 : H12AffineEnvironment.transform 9 85 env26854 = env26855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env26854 == env26855) = true)

theorem identity26855 : scanCanonicalize (H12AffineFastState.compose env26855 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 901) := by decide +kernel

theorem selectedBound26855 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26856 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,277,901,324,729,683,276,487,85,728,277,476,16,98,780,64,42,325,325,2340,68,64,257,340,277,512]

theorem envBound26856 : H12AffineFastState.Bounded env26856 := by
  intro p hp
  have h : env26856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26855_26856 : H12AffineEnvironment.transform 12 901 env26855 = env26856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 901 env26855 == env26856) = true)

theorem identity26856 : scanCanonicalize (H12AffineFastState.compose env26856 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26856 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env26857 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,277,901,277,648,683,276,438,4,649,277,397,16,51,780,17,42,276,276,2340,21,17,257,261,277,512]

theorem envBound26857 : H12AffineFastState.Bounded env26857 := by
  intro p hp
  have h : env26857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26856_26857 : H12AffineEnvironment.transform 5 17 env26856 = env26857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26856 == env26857) = true)

theorem identity26857 : scanCanonicalize (H12AffineFastState.compose env26857 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 319) := by decide +kernel

theorem selectedBound26857 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env26858 : List Nat := [2,4,8,16,32,17,128,256,512,4,319,277,901,277,648,683,276,438,4,649,277,397,16,51,780,17,42,276,276,27,21,17,257,261,277,512]

theorem envBound26858 : H12AffineFastState.Bounded env26858 := by
  intro p hp
  have h : env26858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26857_26858 : H12AffineEnvironment.transform 10 319 env26857 = env26858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 319 env26857 == env26858) = true)

theorem identity26858 : scanCanonicalize (H12AffineFastState.compose env26858 (packedSelected [1,4,5,9,11] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound26858 : packedSelected [1,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env26859 : List Nat := [2,4,8,16,32,17,128,256,277,4,319,277,144,277,413,446,276,438,4,412,277,397,16,51,25,17,42,276,276,27,21,17,257,261,277,277]

theorem envBound26859 : H12AffineFastState.Bounded env26859 := by
  intro p hp
  have h : env26859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26858_26859 : H12AffineEnvironment.transform 8 277 env26858 = env26859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env26858 == env26859) = true)

theorem identity26859 : scanCanonicalize (H12AffineFastState.compose env26859 (packedSelected [0,3,4,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound26859 : packedSelected [0,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env26860 : List Nat := [2,4,8,16,32,17,57,256,277,4,319,277,41,277,292,263,276,271,4,293,277,308,16,51,25,17,42,276,276,27,21,17,257,261,277,277]

theorem envBound26860 : H12AffineFastState.Bounded env26860 := by
  intro p hp
  have h : env26860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26859_26860 : H12AffineEnvironment.transform 6 57 env26859 = env26860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env26859 == env26860) = true)

theorem identity26860 : scanCanonicalize (H12AffineFastState.compose env26860 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound26860 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26861 : List Nat := [2,4,8,16,32,17,57,15,26,4,48,26,41,26,43,8,27,0,4,42,26,59,16,51,25,17,42,27,27,27,21,17,14,10,26,26]

theorem envBound26861 : H12AffineFastState.Bounded env26861 := by
  intro p hp
  have h : env26861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26860_26861 : H12AffineEnvironment.transform 7 15 env26860 = env26861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env26860 == env26861) = true)

theorem identity26861 : scanCanonicalize (H12AffineFastState.compose env26861 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound26861 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26862 : List Nat := [2,4,8,16,16,17,9,15,26,4,0,26,25,26,27,8,27,0,4,26,26,11,16,3,25,17,26,27,27,27,21,17,14,10,26,26]

theorem envBound26862 : H12AffineFastState.Bounded env26862 := by
  intro p hp
  have h : env26862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26861_26862 : H12AffineEnvironment.transform 4 16 env26861 = env26862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env26861 == env26862) = true)

def env26863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1345,262144,42333,32769,1345,41089,16,263633,33236,41245,42274,1296,42060,43129,262562,262566,257,1281,1344,41821]

theorem envBound26863 : H12AffineFastState.Bounded env26863 := by
  intro p hp
  have h : env26863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26851_26863 : H12AffineEnvironment.transform 11 1345 env26851 = env26863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env26851 == env26863) = true)

theorem identity26863 : scanCanonicalize (H12AffineFastState.compose env26863 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 277) := by decide +kernel

theorem selectedBound26863 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,277,359,1345,262144,9288,276,1345,8596,16,263633,193,8200,9271,1296,9561,10604,262562,262566,257,1281,1344,8776]

theorem envBound26864 : H12AffineFastState.Bounded env26864 := by
  intro p hp
  have h : env26864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26863_26864 : H12AffineEnvironment.transform 14 277 env26863 = env26864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 277 env26863 == env26864) = true)

theorem identity26864 : scanCanonicalize (H12AffineFastState.compose env26864 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound26864 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env26865 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1297,277,359,1345,262144,9288,276,1345,8596,16,263633,193,8200,9271,1296,9561,10604,262562,262566,257,1281,1344,8385]

theorem envBound26865 : H12AffineFastState.Bounded env26865 := by
  intro p hp
  have h : env26865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26864_26865 : H12AffineEnvironment.transform 8 137 env26864 = env26865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env26864 == env26865) = true)

def env26866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95615,32769,4096,61649,17,284033,86518,94526,77840,1297,74814,96347,381312,365716,257,16401,1344,95103]

theorem envBound26866 : H12AffineFastState.Bounded env26866 := by
  intro p hp
  have h : env26866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26795_26866 : H12AffineEnvironment.transform 16 16465 env26795 = env26866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env26795 == env26866) = true)

def env26867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77935,32769,4096,46529,17,266385,70886,78894,77840,1297,74814,81227,365712,365716,257,1281,1344,79471]

theorem envBound26867 : H12AffineFastState.Bounded env26867 := by
  intro p hp
  have h : env26867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26866_26867 : H12AffineEnvironment.transform 13 1296 env26866 = env26867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env26866 == env26867) = true)

theorem identity26867 : scanCanonicalize (H12AffineFastState.compose env26867 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound26867 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env26868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32883,1345,262144,45084,32769,4096,46529,17,266385,38037,46173,45155,1297,42061,48440,267491,267495,257,1281,1344,46620]

theorem envBound26868 : H12AffineFastState.Bounded env26868 := by
  intro p hp
  have h : env26868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26867_26868 : H12AffineEnvironment.transform 15 32883 env26867 = env26868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env26867 == env26868) = true)

def env26869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1345,262144,42332,32769,1344,41089,17,263633,33237,41245,42275,1297,42061,43128,262563,262567,257,1281,1344,41820]

theorem envBound26869 : H12AffineFastState.Bounded env26869 := by
  intro p hp
  have h : env26869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26868_26869 : H12AffineEnvironment.transform 11 1344 env26868 = env26869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env26868 == env26869) = true)

theorem identity26869 : scanCanonicalize (H12AffineFastState.compose env26869 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 34227) := by decide +kernel

theorem selectedBound26869 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1345,34227,42332,32769,1344,41089,17,32866,33237,41245,42275,1297,42061,43128,33808,33812,257,1281,1344,41820]

theorem envBound26870 : H12AffineFastState.Bounded env26870 := by
  intro p hp
  have h : env26870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26869_26870 : H12AffineEnvironment.transform 17 34227 env26869 = env26870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34227 env26869 == env26870) = true)

theorem identity26870 : scanCanonicalize (H12AffineFastState.compose env26870 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound26870 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env26871 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1296,32768,32883,1345,34227,42332,32769,1344,41089,17,32866,33237,41245,42275,1297,42061,43128,33808,33812,257,1281,1344,41429]

theorem envBound26871 : H12AffineFastState.Bounded env26871 := by
  intro p hp
  have h : env26871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26870_26871 : H12AffineEnvironment.transform 8 137 env26870 = env26871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env26870 == env26871) = true)

def env26872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1345,262144,42333,32769,1345,41088,17,263632,33236,41244,42274,1297,42061,43129,262562,262566,257,1281,1344,41821]

theorem envBound26872 : H12AffineFastState.Bounded env26872 := by
  intro p hp
  have h : env26872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26868_26872 : H12AffineEnvironment.transform 11 1345 env26868 = env26872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env26868 == env26872) = true)

theorem identity26872 : scanCanonicalize (H12AffineFastState.compose env26872 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound26872 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26873 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,80,32768,32883,1,262144,40989,32769,1,41088,17,262288,33236,41244,41058,81,41229,43129,262562,262566,257,65,0,41821]

theorem envBound26873 : H12AffineFastState.Bounded env26873 := by
  intro p hp
  have h : env26873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26872_26873 : H12AffineEnvironment.transform 9 320 env26872 = env26873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env26872 == env26873) = true)

theorem identity26873 : scanCanonicalize (H12AffineFastState.compose env26873 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound26873 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env26874 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,80,8541,8494,1,262144,320,8540,1,477,17,262288,8329,65,319,81,80,2340,262562,262566,257,65,0,512]

theorem envBound26874 : H12AffineFastState.Bounded env26874 := by
  intro p hp
  have h : env26874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26873_26874 : H12AffineEnvironment.transform 14 8541 env26873 = env26874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env26873 == env26874) = true)

theorem identity26874 : scanCanonicalize (H12AffineFastState.compose env26874 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound26874 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env26875 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,1,8192,80,8264,8251,1,262144,85,8265,1,200,17,262288,8329,65,42,81,80,2097,262327,262323,20,65,0,512]

theorem envBound26875 : H12AffineFastState.Bounded env26875 := by
  intro p hp
  have h : env26875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26874_26875 : H12AffineEnvironment.transform 7 21 env26874 = env26875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env26874 == env26875) = true)

theorem identity26875 : scanCanonicalize (H12AffineFastState.compose env26875 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound26875 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26876 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,1,657,80,729,682,1,262144,85,728,1,200,17,262288,536,65,42,81,80,2097,262327,262323,20,65,0,512]

theorem envBound26876 : H12AffineFastState.Bounded env26876 := by
  intro p hp
  have h : env26876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26875_26876 : H12AffineEnvironment.transform 12 657 env26875 = env26876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env26875 == env26876) = true)

theorem identity26876 : scanCanonicalize (H12AffineFastState.compose env26876 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26876 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env26877 : List Nat := [2,4,8,16,32,17,128,21,512,4,2048,1,657,1,648,682,1,262144,4,649,1,153,17,262288,536,16,42,0,1,2097,262327,262323,20,16,0,512]

theorem envBound26877 : H12AffineFastState.Bounded env26877 := by
  intro p hp
  have h : env26877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26876_26877 : H12AffineEnvironment.transform 5 17 env26876 = env26877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26876 == env26877) = true)

theorem identity26877 : scanCanonicalize (H12AffineFastState.compose env26877 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 2096) := by decide +kernel

theorem selectedBound26877 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env26878 : List Nat := [2,4,8,16,32,17,128,21,512,4,2048,1,657,1,648,682,1,2096,4,649,1,153,17,2208,536,16,42,0,1,2097,2183,2179,20,16,0,512]

theorem envBound26878 : H12AffineFastState.Bounded env26878 := by
  intro p hp
  have h : env26878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26877_26878 : H12AffineEnvironment.transform 17 2096 env26877 = env26878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2096 env26877 == env26878) = true)

theorem identity26878 : scanCanonicalize (H12AffineFastState.compose env26878 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound26878 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26879 : List Nat := [2,4,8,16,32,17,128,21,512,4,147,1,657,1,648,682,1,163,4,649,1,153,17,51,536,16,42,0,1,162,20,16,20,16,0,512]

theorem envBound26879 : H12AffineFastState.Bounded env26879 := by
  intro p hp
  have h : env26879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26878_26879 : H12AffineEnvironment.transform 10 147 env26878 = env26879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env26878 == env26879) = true)

theorem identity26879 : scanCanonicalize (H12AffineFastState.compose env26879 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound26879 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26880 : List Nat := [2,4,8,16,32,17,128,21,6,4,147,1,151,1,142,172,1,163,4,143,1,153,17,51,30,16,42,0,1,162,20,16,20,16,0,6]

theorem envBound26880 : H12AffineFastState.Bounded env26880 := by
  intro p hp
  have h : env26880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26879_26880 : H12AffineEnvironment.transform 8 6 env26879 = env26880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env26879 == env26880) = true)

theorem identity26880 : scanCanonicalize (H12AffineFastState.compose env26880 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound26880 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env26881 : List Nat := [2,4,8,16,16,17,128,21,6,4,147,1,151,1,142,156,1,147,4,143,1,153,17,3,30,16,26,0,1,146,20,16,20,16,0,6]

theorem envBound26881 : H12AffineFastState.Bounded env26881 := by
  intro p hp
  have h : env26881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26880_26881 : H12AffineEnvironment.transform 4 16 env26880 = env26881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env26880 == env26881) = true)

theorem identity26881 : scanCanonicalize (H12AffineFastState.compose env26881 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26881 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env26882 : List Nat := [2,4,8,16,16,17,8,21,6,4,27,1,31,1,6,20,1,27,4,7,1,17,17,3,30,16,26,0,1,26,20,16,20,16,0,6]

theorem envBound26882 : H12AffineFastState.Bounded env26882 := by
  intro p hp
  have h : env26882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26881_26882 : H12AffineEnvironment.transform 6 8 env26881 = env26882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26881 == env26882) = true)

theorem identity26882 : scanCanonicalize (H12AffineFastState.compose env26882 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound26882 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26883 : List Nat := [2,4,8,13,13,12,8,8,6,4,6,1,2,1,6,9,1,6,4,7,1,12,12,3,3,13,7,0,1,7,9,13,9,13,0,6]

theorem envBound26883 : H12AffineFastState.Bounded env26883 := by
  intro p hp
  have h : env26883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26882_26883 : H12AffineEnvironment.transform 3 13 env26882 = env26883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env26882 == env26883) = true)

theorem identity26883 : scanCanonicalize (H12AffineFastState.compose env26883 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound26883 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env26884 : List Nat := [2,2,8,11,11,10,8,8,0,2,0,1,2,1,0,9,1,0,2,1,1,10,10,3,3,11,1,0,1,1,9,11,9,11,0,0]

theorem envBound26884 : H12AffineFastState.Bounded env26884 := by
  intro p hp
  have h : env26884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26883_26884 : H12AffineEnvironment.transform 1 2 env26883 = env26884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env26883 == env26884) = true)

def env26885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77934,32769,4096,46528,17,266384,70887,78895,77840,1297,74814,81226,365713,365716,257,1280,1344,79470]

theorem envBound26885 : H12AffineFastState.Bounded env26885 := by
  intro p hp
  have h : env26885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26866_26885 : H12AffineEnvironment.transform 13 1297 env26866 = env26885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env26866 == env26885) = true)

theorem identity26885 : scanCanonicalize (H12AffineFastState.compose env26885 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound26885 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env26886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,262144,77934,13340,4096,477,17,266384,70887,78895,77840,1297,74814,81226,336012,336009,257,1280,1344,79470]

theorem envBound26886 : H12AffineFastState.Bounded env26886 := by
  intro p hp
  have h : env26886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26885_26886 : H12AffineEnvironment.transform 14 13341 env26885 = env26886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env26885 == env26886) = true)

def env26887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65664,77934,13340,4096,477,17,69648,70887,78895,77840,1297,74814,81226,8204,8201,257,1280,1344,79470]

theorem envBound26887 : H12AffineFastState.Bounded env26887 := by
  intro p hp
  have h : env26887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26886_26887 : H12AffineEnvironment.transform 17 65664 env26886 = env26887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env26886 == env26887) = true)

theorem identity26887 : scanCanonicalize (H12AffineFastState.compose env26887 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 359) := by decide +kernel

theorem selectedBound26887 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,359,1344,487,12553,13340,4096,477,17,4471,5504,13640,12663,1297,9561,15405,8204,8201,257,1280,1344,14089]

theorem envBound26888 : H12AffineFastState.Bounded env26888 := by
  intro p hp
  have h : env26888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26887_26888 : H12AffineEnvironment.transform 15 359 env26887 = env26888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 359 env26887 == env26888) = true)

def env26889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,7632,1297,2509,359,1344,487,3289,2508,4096,477,17,4471,5504,2200,3239,1297,6281,509,7644,7641,257,1280,1344,2777]

theorem envBound26889 : H12AffineFastState.Bounded env26889 := by
  intro p hp
  have h : env26889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26888_26889 : H12AffineEnvironment.transform 12 7632 env26888 = env26889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7632 env26888 == env26889) = true)

def env26890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1344,4096,4240,1297,1165,359,1344,487,409,1164,4096,477,17,4471,5504,1496,487,1297,5577,509,4252,4249,257,1280,1344,1945]

theorem envBound26890 : H12AffineFastState.Bounded env26890 := by
  intro p hp
  have h : env26890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26889_26890 : H12AffineEnvironment.transform 10 1344 env26889 = env26890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env26889 == env26890) = true)

theorem identity26890 : scanCanonicalize (H12AffineFastState.compose env26890 (packedSelected [13] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound26890 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env26891 : List Nat := [2,4,8,16,32,64,128,256,512,220,412,4096,4240,461,81,359,412,487,409,80,4096,477,17,4471,4444,260,487,461,4373,509,4252,4249,257,476,412,837]

theorem envBound26891 : H12AffineFastState.Bounded env26891 := by
  intro p hp
  have h : env26891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26890_26891 : H12AffineEnvironment.transform 9 220 env26890 = env26891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env26890 == env26891) = true)

theorem identity26891 : scanCanonicalize (H12AffineFastState.compose env26891 (packedSelected [1,3,5,8,12,18,20] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound26891 : packedSelected [1,3,5,8,12,18,20] rootPS < 2^1333 := by decide +kernel

def env26892 : List Nat := [2,4,8,16,32,64,128,62,512,220,162,4096,4240,243,81,89,162,217,167,80,4096,227,17,4169,4194,58,217,243,4139,195,4252,4249,63,226,162,635]

theorem envBound26892 : H12AffineFastState.Bounded env26892 := by
  intro p hp
  have h : env26892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26891_26892 : H12AffineEnvironment.transform 7 62 env26891 = env26892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env26891 == env26892) = true)

theorem identity26892 : scanCanonicalize (H12AffineFastState.compose env26892 (packedSelected [1,2,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 674) := by decide +kernel

theorem selectedBound26892 : packedSelected [1,2,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env26893 : List Nat := [2,4,8,16,32,64,128,62,512,220,162,674,562,243,81,89,162,217,167,80,674,227,17,747,704,58,217,243,649,195,574,571,63,226,162,635]

theorem envBound26893 : H12AffineFastState.Bounded env26893 := by
  intro p hp
  have h : env26893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26892_26893 : H12AffineEnvironment.transform 11 674 env26892 = env26893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 674 env26892 == env26893) = true)

theorem identity26893 : scanCanonicalize (H12AffineFastState.compose env26893 (packedSelected [1,8,16] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound26893 : packedSelected [1,8,16] rootPS < 2^1333 := by decide +kernel

def env26894 : List Nat := [2,4,8,16,32,64,128,62,147,220,162,49,161,243,81,89,162,217,167,80,49,227,17,120,83,58,217,243,26,195,173,168,63,226,162,232]

theorem envBound26894 : H12AffineFastState.Bounded env26894 := by
  intro p hp
  have h : env26894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26893_26894 : H12AffineEnvironment.transform 8 147 env26893 = env26894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env26893 == env26894) = true)

theorem identity26894 : scanCanonicalize (H12AffineFastState.compose env26894 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound26894 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env26895 : List Nat := [2,4,8,16,32,64,114,62,97,46,80,49,83,1,81,89,80,43,85,80,49,17,17,120,83,58,43,1,26,49,95,90,63,16,80,26]

theorem envBound26895 : H12AffineFastState.Bounded env26895 := by
  intro p hp
  have h : env26895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26894_26895 : H12AffineEnvironment.transform 6 114 env26894 = env26895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env26894 == env26895) = true)

def env26896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1345,4096,4241,1297,1164,359,1344,487,408,1165,4096,477,17,4471,5504,1497,486,1297,5576,509,4253,4248,257,1280,1344,1944]

theorem envBound26896 : H12AffineFastState.Bounded env26896 := by
  intro p hp
  have h : env26896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26889_26896 : H12AffineEnvironment.transform 10 1345 env26889 = env26896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env26889 == env26896) = true)

theorem identity26896 : scanCanonicalize (H12AffineFastState.compose env26896 (packedSelected [13] rootPS)) = affineNative (2^(7+1) ^^^ 204) := by decide +kernel

theorem selectedBound26896 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env26897 : List Nat := [2,4,8,16,32,64,128,204,512,1024,1165,4096,4241,1245,1164,171,1164,43,84,1165,4096,17,17,4283,5196,1045,42,1245,5124,49,4253,4248,205,1228,1164,1620]

theorem envBound26897 : H12AffineFastState.Bounded env26897 := by
  intro p hp
  have h : env26897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26896_26897 : H12AffineEnvironment.transform 7 204 env26896 = env26897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 204 env26896 == env26897) = true)

theorem identity26897 : scanCanonicalize (H12AffineFastState.compose env26897 (packedSelected [3,7,8,9,11,16,17,18] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound26897 : packedSelected [3,7,8,9,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env26898 : List Nat := [2,4,8,16,32,64,128,204,512,565,696,4096,4241,744,697,171,697,43,84,696,4096,17,17,4283,4729,544,42,744,4657,49,4253,4248,205,761,697,97]

theorem envBound26898 : H12AffineFastState.Bounded env26898 := by
  intro p hp
  have h : env26898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26897_26898 : H12AffineEnvironment.transform 9 565 env26897 = env26898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env26897 == env26898) = true)

theorem identity26898 : scanCanonicalize (H12AffineFastState.compose env26898 (packedSelected [0,1,2,4,5,7,9,10,11,12,19,21,23] rootPS)) = affineNative (2^(11+1) ^^^ 195) := by decide +kernel

theorem selectedBound26898 : packedSelected [0,1,2,4,5,7,9,10,11,12,19,21,23] rootPS < 2^1333 := by decide +kernel

def env26899 : List Nat := [2,4,8,16,32,64,128,204,512,565,696,195,82,744,697,171,697,43,84,696,195,17,17,120,698,544,42,744,754,49,94,91,205,761,697,97]

theorem envBound26899 : H12AffineFastState.Bounded env26899 := by
  intro p hp
  have h : env26899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26898_26899 : H12AffineEnvironment.transform 11 195 env26898 = env26899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 195 env26898 == env26899) = true)

theorem identity26899 : scanCanonicalize (H12AffineFastState.compose env26899 (packedSelected [0,3,4,8,12] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound26899 : packedSelected [0,3,4,8,12] rootPS < 2^1333 := by decide +kernel

def env26900 : List Nat := [2,4,8,16,32,64,128,204,96,85,216,195,82,136,217,171,217,43,84,216,195,17,17,120,218,64,42,136,146,49,94,91,205,153,217,97]

theorem envBound26900 : H12AffineFastState.Bounded env26900 := by
  intro p hp
  have h : env26900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26899_26900 : H12AffineEnvironment.transform 8 96 env26899 = env26900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env26899 == env26900) = true)

theorem identity26900 : scanCanonicalize (H12AffineFastState.compose env26900 (packedSelected [0,1,2,3,4,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 24) := by decide +kernel

theorem selectedBound26900 : packedSelected [0,1,2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env26901 : List Nat := [2,4,8,16,32,24,128,148,56,13,128,155,10,136,129,171,129,43,12,128,155,17,17,32,130,24,42,136,146,49,6,3,149,153,129,57]

theorem envBound26901 : H12AffineFastState.Bounded env26901 := by
  intro p hp
  have h : env26901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26900_26901 : H12AffineEnvironment.transform 5 24 env26900 = env26901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 24 env26900 == env26901) = true)

theorem identity26901 : scanCanonicalize (H12AffineFastState.compose env26901 (packedSelected [1,2,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound26901 : packedSelected [1,2,9] rootPS < 2^1333 := by decide +kernel

def env26902 : List Nat := [2,4,8,1,32,9,128,133,41,13,128,138,10,136,129,171,129,43,12,128,138,0,0,32,130,9,42,136,131,32,6,3,132,136,129,40]

theorem envBound26902 : H12AffineFastState.Bounded env26902 := by
  intro p hp
  have h : env26902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26901_26902 : H12AffineEnvironment.transform 3 1 env26901 = env26902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env26901 == env26902) = true)

theorem identity26902 : scanCanonicalize (H12AffineFastState.compose env26902 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 38) := by decide +kernel

theorem selectedBound26902 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env26903 : List Nat := [2,4,8,1,32,9,38,35,41,13,38,44,10,46,39,13,39,43,12,38,44,0,0,32,36,9,42,46,37,32,6,3,34,46,39,40]

theorem envBound26903 : H12AffineFastState.Bounded env26903 := by
  intro p hp
  have h : env26903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26902_26903 : H12AffineEnvironment.transform 6 38 env26902 = env26903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 38 env26902 == env26903) = true)

theorem identity26903 : scanCanonicalize (H12AffineFastState.compose env26903 (packedSelected [0,5,7,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26903 : packedSelected [0,5,7,10] rootPS < 2^1333 := by decide +kernel

def env26904 : List Nat := [2,4,8,1,0,9,6,3,9,13,6,12,10,14,7,13,7,11,12,6,12,0,0,0,4,9,10,14,5,0,6,3,2,14,7,8]

theorem envBound26904 : H12AffineFastState.Bounded env26904 := by
  intro p hp
  have h : env26904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26903_26904 : H12AffineEnvironment.transform 4 0 env26903 = env26904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26903 == env26904) = true)

theorem identity26904 : scanCanonicalize (H12AffineFastState.compose env26904 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound26904 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env26905 : List Nat := [2,0,8,1,0,9,2,3,9,9,2,8,10,10,3,9,3,11,8,2,8,0,0,0,0,9,10,10,1,0,2,3,2,10,3,8]

theorem envBound26905 : H12AffineFastState.Bounded env26905 := by
  intro p hp
  have h : env26905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26904_26905 : H12AffineEnvironment.transform 1 0 env26904 = env26905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env26904 == env26905) = true)

theorem identity26905 : scanCanonicalize (H12AffineFastState.compose env26905 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound26905 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26906 : List Nat := [2,0,3,1,0,2,2,3,2,2,2,3,1,1,3,2,3,0,3,2,3,0,0,0,0,2,1,1,1,0,2,3,2,1,3,3]

theorem envBound26906 : H12AffineFastState.Bounded env26906 := by
  intro p hp
  have h : env26906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26905_26906 : H12AffineEnvironment.transform 2 3 env26905 = env26906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env26905 == env26906) = true)

theorem identity26906 : scanCanonicalize (H12AffineFastState.compose env26906 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound26906 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26907 : List Nat := [0,0,1,1,0,0,0,1,0,0,0,1,1,1,1,0,1,0,1,0,1,0,0,0,0,0,1,1,1,0,0,1,0,1,1,1]

theorem envBound26907 : H12AffineFastState.Bounded env26907 := by
  intro p hp
  have h : env26907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26906_26907 : H12AffineEnvironment.transform 0 0 env26906 = env26907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env26906 == env26907) = true)

def env26908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,7633,1297,2508,359,1344,487,3288,2509,4096,477,17,4471,5504,2201,3238,1297,6280,508,7645,7640,257,1280,1344,2776]

theorem envBound26908 : H12AffineFastState.Bounded env26908 := by
  intro p hp
  have h : env26908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26888_26908 : H12AffineEnvironment.transform 12 7633 env26888 = env26908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7633 env26888 == env26908) = true)

def env26909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1344,4096,4241,1297,1164,359,1344,487,408,1165,4096,477,17,4471,5504,1497,486,1297,5576,508,4253,4248,257,1280,1344,1944]

theorem envBound26909 : H12AffineFastState.Bounded env26909 := by
  intro p hp
  have h : env26909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26908_26909 : H12AffineEnvironment.transform 10 1344 env26908 = env26909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env26908 == env26909) = true)

theorem identity26909 : scanCanonicalize (H12AffineFastState.compose env26909 (packedSelected [13] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound26909 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env26910 : List Nat := [2,4,8,16,32,64,128,256,512,84,276,4096,4241,325,216,359,276,487,408,217,4096,477,17,4471,4564,397,486,325,4508,508,4253,4248,257,340,276,972]

theorem envBound26910 : H12AffineFastState.Bounded env26910 := by
  intro p hp
  have h : env26910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26909_26910 : H12AffineEnvironment.transform 9 84 env26909 = env26910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env26909 == env26910) = true)

theorem identity26910 : scanCanonicalize (H12AffineFastState.compose env26910 (packedSelected [0,1,7,8,19,20,21] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound26910 : packedSelected [0,1,7,8,19,20,21] rootPS < 2^1333 := by decide +kernel

def env26911 : List Nat := [2,4,8,16,32,64,89,256,512,84,276,4096,4168,325,1,359,276,318,321,0,4096,260,17,4471,4365,340,319,325,4421,293,4164,4161,257,340,276,789]

theorem envBound26911 : H12AffineFastState.Bounded env26911 := by
  intro p hp
  have h : env26911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26910_26911 : H12AffineEnvironment.transform 6 89 env26910 = env26911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env26910 == env26911) = true)

theorem identity26911 : scanCanonicalize (H12AffineFastState.compose env26911 (packedSelected [0,1,3,5,7,8,11,17] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound26911 : packedSelected [0,1,3,5,7,8,11,17] rootPS < 2^1333 := by decide +kernel

def env26912 : List Nat := [2,4,8,16,32,58,35,256,512,46,276,4096,4146,319,1,285,276,318,315,0,4096,260,17,4365,4365,302,319,319,4415,293,4158,4155,257,302,276,789]

theorem envBound26912 : H12AffineFastState.Bounded env26912 := by
  intro p hp
  have h : env26912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26911_26912 : H12AffineEnvironment.transform 5 58 env26911 = env26912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env26911 == env26912) = true)

theorem identity26912 : scanCanonicalize (H12AffineFastState.compose env26912 (packedSelected [0,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 43) := by decide +kernel

theorem selectedBound26912 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env26913 : List Nat := [2,4,8,16,32,58,35,256,512,46,276,43,25,319,1,285,276,318,315,0,43,260,17,294,294,302,319,319,276,293,21,16,257,302,276,789]

theorem envBound26913 : H12AffineFastState.Bounded env26913 := by
  intro p hp
  have h : env26913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26912_26913 : H12AffineEnvironment.transform 11 43 env26912 = env26913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 43 env26912 == env26913) = true)

theorem identity26913 : scanCanonicalize (H12AffineFastState.compose env26913 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound26913 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env26914 : List Nat := [2,4,8,16,32,58,35,256,277,46,276,43,25,319,1,285,276,318,315,0,43,260,17,294,294,302,319,319,276,293,21,16,257,302,276,0]

theorem envBound26914 : H12AffineFastState.Bounded env26914 := by
  intro p hp
  have h : env26914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26913_26914 : H12AffineEnvironment.transform 8 277 env26913 = env26914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env26913 == env26914) = true)

def env26915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1345,4096,4240,1297,1165,359,1344,487,409,1164,4096,477,17,4471,5504,1496,487,1297,5577,508,4252,4249,257,1280,1344,1945]

theorem envBound26915 : H12AffineFastState.Bounded env26915 := by
  intro p hp
  have h : env26915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26908_26915 : H12AffineEnvironment.transform 10 1345 env26908 = env26915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env26908 == env26915) = true)

theorem identity26915 : scanCanonicalize (H12AffineFastState.compose env26915 (packedSelected [13] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound26915 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env26916 : List Nat := [2,4,8,16,32,64,128,69,512,1024,1028,4096,4240,1108,1165,34,1029,162,220,1164,4096,152,17,4146,5317,1181,162,1108,5260,185,4252,4249,68,1093,1029,1756]

theorem envBound26916 : H12AffineFastState.Bounded env26916 := by
  intro p hp
  have h : env26916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26915_26916 : H12AffineEnvironment.transform 7 69 env26915 = env26916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env26915 == env26916) = true)

theorem identity26916 : scanCanonicalize (H12AffineFastState.compose env26916 (packedSelected [0,1,3,4,11,17,18,19,20,21] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound26916 : packedSelected [0,1,3,4,11,17,18,19,20,21] rootPS < 2^1333 := by decide +kernel

def env26917 : List Nat := [2,4,8,16,32,64,128,69,162,1024,1028,4096,4240,1108,1165,34,1029,162,220,1164,4096,152,17,4146,5317,1181,162,1108,5260,185,4252,4249,68,1093,1029,1150]

theorem envBound26917 : H12AffineFastState.Bounded env26917 := by
  intro p hp
  have h : env26917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26916_26917 : H12AffineEnvironment.transform 8 162 env26916 = env26917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env26916 == env26917) = true)

theorem identity26917 : scanCanonicalize (H12AffineFastState.compose env26917 (packedSelected [3,4,8,9,12,15,18,23] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound26917 : packedSelected [3,4,8,9,12,15,18,23] rootPS < 2^1333 := by decide +kernel

def env26918 : List Nat := [2,4,8,16,32,64,128,69,162,1024,1028,0,144,1108,1165,34,1029,162,220,1164,0,152,17,50,1221,1181,162,1108,1164,185,156,153,68,1093,1029,1150]

theorem envBound26918 : H12AffineFastState.Bounded env26918 := by
  intro p hp
  have h : env26918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26917_26918 : H12AffineEnvironment.transform 11 0 env26917 = env26918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env26917 == env26918) = true)

theorem identity26918 : scanCanonicalize (H12AffineFastState.compose env26918 (packedSelected [4,5,7,8,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound26918 : packedSelected [4,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env26919 : List Nat := [2,4,8,16,32,64,128,69,162,220,216,0,144,136,81,34,217,162,220,80,0,152,17,50,25,65,162,136,80,185,156,153,68,153,217,162]

theorem envBound26919 : H12AffineFastState.Bounded env26919 := by
  intro p hp
  have h : env26919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26918_26919 : H12AffineEnvironment.transform 9 220 env26918 = env26919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env26918 == env26919) = true)

theorem identity26919 : scanCanonicalize (H12AffineFastState.compose env26919 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound26919 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26920 : List Nat := [2,4,8,16,32,58,128,63,162,166,162,0,144,136,43,34,163,162,166,42,0,152,17,50,25,59,162,136,42,185,156,153,62,153,163,162]

theorem envBound26920 : H12AffineFastState.Bounded env26920 := by
  intro p hp
  have h : env26920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26919_26920 : H12AffineEnvironment.transform 5 58 env26919 = env26920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env26919 == env26920) = true)

theorem identity26920 : scanCanonicalize (H12AffineFastState.compose env26920 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound26920 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env26921 : List Nat := [2,4,8,16,32,58,34,63,0,4,0,0,50,42,43,34,1,0,4,42,0,58,17,50,25,59,0,42,42,27,62,59,62,59,1,0]

theorem envBound26921 : H12AffineFastState.Bounded env26921 := by
  intro p hp
  have h : env26921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26920_26921 : H12AffineEnvironment.transform 6 34 env26920 = env26921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env26920 == env26921) = true)

theorem identity26921 : scanCanonicalize (H12AffineFastState.compose env26921 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound26921 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26922 : List Nat := [2,4,8,16,6,28,4,25,0,4,0,0,20,12,13,4,1,0,4,12,0,28,17,20,25,29,0,12,12,27,24,29,24,29,1,0]

theorem envBound26922 : H12AffineFastState.Bounded env26922 := by
  intro p hp
  have h : env26922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26921_26922 : H12AffineEnvironment.transform 4 6 env26921 = env26922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env26921 == env26922) = true)

theorem identity26922 : scanCanonicalize (H12AffineFastState.compose env26922 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound26922 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26923 : List Nat := [2,4,8,10,6,6,4,3,0,4,0,0,14,12,13,4,1,0,4,12,0,6,11,14,3,7,0,12,12,1,2,7,2,7,1,0]

theorem envBound26923 : H12AffineFastState.Bounded env26923 := by
  intro p hp
  have h : env26923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26922_26923 : H12AffineEnvironment.transform 3 10 env26922 = env26923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env26922 == env26923) = true)

def env26924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65665,77934,13340,4096,477,17,69649,70887,78895,77840,1297,74814,81226,8205,8200,257,1280,1344,79470]

theorem envBound26924 : H12AffineFastState.Bounded env26924 := by
  intro p hp
  have h : env26924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26886_26924 : H12AffineEnvironment.transform 17 65665 env26886 = env26924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env26886 == env26924) = true)

theorem identity26924 : scanCanonicalize (H12AffineFastState.compose env26924 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5159) := by decide +kernel

theorem selectedBound26924 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,5159,1344,5286,9289,13340,4096,477,17,1078,192,8200,9271,1297,12313,10605,8205,8200,257,1280,1344,8777]

theorem envBound26925 : H12AffineFastState.Bounded env26925 := by
  intro p hp
  have h : env26925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26924_26925 : H12AffineEnvironment.transform 15 5159 env26924 = env26925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5159 env26924 == env26925) = true)

def env26926 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1297,13341,5159,1296,5286,9241,13340,4096,397,17,1078,144,8200,9271,1297,12313,10557,8205,8200,257,1280,1296,8729]

theorem envBound26926 : H12AffineFastState.Bounded env26926 := by
  intro p hp
  have h : env26926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26925_26926 : H12AffineEnvironment.transform 5 16 env26925 = env26926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26925 == env26926) = true)

theorem identity26926 : scanCanonicalize (H12AffineFastState.compose env26926 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound26926 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env26927 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,277,8192,1297,9480,1330,1296,1459,9241,9481,277,397,17,1078,144,8200,9271,1297,8460,10557,8205,8200,257,1280,1296,8729]

theorem envBound26927 : H12AffineFastState.Bounded env26927 := by
  intro p hp
  have h : env26927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26926_26927 : H12AffineEnvironment.transform 11 277 env26926 = env26927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env26926 == env26927) = true)

theorem identity26927 : scanCanonicalize (H12AffineFastState.compose env26927 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound26927 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env26928 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,277,8192,276,8461,311,277,438,8220,8460,277,397,17,51,144,8200,8242,276,8460,10557,8205,8200,257,261,277,8729]

theorem envBound26928 : H12AffineFastState.Bounded env26928 := by
  intro p hp
  have h : env26928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26927_26928 : H12AffineEnvironment.transform 9 5 env26927 = env26928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env26927 == env26928) = true)

theorem identity26928 : scanCanonicalize (H12AffineFastState.compose env26928 (packedSelected [0,2,5,7,8,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound26928 : packedSelected [0,2,5,7,8,13,18] rootPS < 2^1333 := by decide +kernel

def env26929 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,277,268,276,1,311,277,438,272,0,277,397,17,51,144,260,318,276,0,2097,257,260,257,261,277,789]

theorem envBound26929 : H12AffineFastState.Bounded env26929 := by
  intro p hp
  have h : env26929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26928_26929 : H12AffineEnvironment.transform 12 268 env26928 = env26929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env26928 == env26929) = true)

theorem identity26929 : scanCanonicalize (H12AffineFastState.compose env26929 (packedSelected [8] rootPS)) = affineNative (2^(6+1) ^^^ 62) := by decide +kernel

theorem selectedBound26929 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env26930 : List Nat := [2,4,8,16,32,16,62,256,512,5,2048,277,268,276,1,311,277,264,272,0,277,307,17,51,46,260,318,276,0,2097,257,260,257,261,277,789]

theorem envBound26930 : H12AffineFastState.Bounded env26930 := by
  intro p hp
  have h : env26930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26929_26930 : H12AffineEnvironment.transform 6 62 env26929 = env26930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 62 env26929 == env26930) = true)

theorem identity26930 : scanCanonicalize (H12AffineFastState.compose env26930 (packedSelected [0,1,2,5,7,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound26930 : packedSelected [0,1,2,5,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env26931 : List Nat := [2,4,8,16,32,16,62,63,512,5,2048,42,51,43,1,8,42,55,47,0,42,12,17,51,46,59,1,43,0,2097,62,59,62,58,42,554]

theorem envBound26931 : H12AffineFastState.Bounded env26931 := by
  intro p hp
  have h : env26931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26930_26931 : H12AffineEnvironment.transform 7 63 env26930 = env26931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env26930 == env26931) = true)

theorem identity26931 : scanCanonicalize (H12AffineFastState.compose env26931 (packedSelected [0,5,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 540) := by decide +kernel

theorem selectedBound26931 : packedSelected [0,5,7,11] rootPS < 2^1333 := by decide +kernel

def env26932 : List Nat := [2,4,8,16,32,16,62,63,512,5,540,42,51,43,1,8,42,55,47,0,42,12,17,51,46,59,1,43,0,557,62,59,62,58,42,554]

theorem envBound26932 : H12AffineFastState.Bounded env26932 := by
  intro p hp
  have h : env26932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26931_26932 : H12AffineEnvironment.transform 10 540 env26931 = env26932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 540 env26931 == env26932) = true)

theorem identity26932 : scanCanonicalize (H12AffineFastState.compose env26932 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound26932 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26933 : List Nat := [2,4,8,16,32,16,62,63,7,5,27,42,51,43,1,8,42,55,47,0,42,12,17,51,46,59,1,43,0,42,62,59,62,58,42,45]

theorem envBound26933 : H12AffineFastState.Bounded env26933 := by
  intro p hp
  have h : env26933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26932_26933 : H12AffineEnvironment.transform 8 7 env26932 = env26933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env26932 == env26933) = true)

theorem identity26933 : scanCanonicalize (H12AffineFastState.compose env26933 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound26933 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env26934 : List Nat := [2,4,8,16,12,16,18,19,7,5,27,6,31,7,1,8,6,27,3,0,6,12,17,31,2,23,1,7,0,6,18,23,18,22,6,1]

theorem envBound26934 : H12AffineFastState.Bounded env26934 := by
  intro p hp
  have h : env26934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26933_26934 : H12AffineEnvironment.transform 4 12 env26933 = env26934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env26933 == env26934) = true)

theorem identity26934 : scanCanonicalize (H12AffineFastState.compose env26934 (packedSelected [4,7] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound26934 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env26935 : List Nat := [2,4,8,13,12,13,15,14,7,5,6,6,2,7,1,8,6,6,3,0,6,12,12,2,2,10,1,7,0,6,15,10,15,11,6,1]

theorem envBound26935 : H12AffineFastState.Bounded env26935 := by
  intro p hp
  have h : env26935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26934_26935 : H12AffineEnvironment.transform 3 13 env26934 = env26935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env26934 == env26935) = true)

theorem identity26935 : scanCanonicalize (H12AffineFastState.compose env26935 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound26935 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26936 : List Nat := [2,3,8,10,11,10,8,9,0,2,1,1,2,0,1,8,1,1,3,0,1,11,11,2,2,10,1,0,0,1,8,10,8,11,1,1]

theorem envBound26936 : H12AffineFastState.Bounded env26936 := by
  intro p hp
  have h : env26936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26935_26936 : H12AffineEnvironment.transform 1 3 env26935 = env26936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env26935 == env26936) = true)

theorem identity26936 : scanCanonicalize (H12AffineFastState.compose env26936 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound26936 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26937 : List Nat := [2,3,0,2,3,2,0,1,0,2,1,1,2,0,1,0,1,1,3,0,1,3,3,2,2,2,1,0,0,1,0,2,0,3,1,1]

theorem envBound26937 : H12AffineFastState.Bounded env26937 := by
  intro p hp
  have h : env26937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26936_26937 : H12AffineEnvironment.transform 2 0 env26936 = env26937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env26936 == env26937) = true)

theorem identity26937 : scanCanonicalize (H12AffineFastState.compose env26937 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound26937 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env26938 : List Nat := [0,1,0,0,1,0,0,1,0,0,1,1,0,0,1,0,1,1,1,0,1,1,1,0,0,0,1,0,0,1,0,0,0,1,1,1]

theorem envBound26938 : H12AffineFastState.Bounded env26938 := by
  intro p hp
  have h : env26938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26937_26938 : H12AffineEnvironment.transform 0 0 env26937 = env26938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env26937 == env26938) = true)

def env26939 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,13341,5159,1297,5286,9240,13340,4096,396,17,1078,145,8200,9271,1297,12313,10556,8205,8200,257,1280,1297,8728]

theorem envBound26939 : H12AffineFastState.Bounded env26939 := by
  intro p hp
  have h : env26939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26925_26939 : H12AffineEnvironment.transform 5 17 env26925 = env26939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26925 == env26939) = true)

theorem identity26939 : scanCanonicalize (H12AffineFastState.compose env26939 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4365) := by decide +kernel

theorem selectedBound26939 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env26940 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,4365,1297,1296,5159,1297,5286,5397,1297,4096,396,17,1078,145,4357,5434,1297,276,6193,4352,4357,257,1280,1297,4885]

theorem envBound26940 : H12AffineFastState.Bounded env26940 := by
  intro p hp
  have h : env26940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26939_26940 : H12AffineEnvironment.transform 12 4365 env26939 = env26940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4365 env26939 == env26940) = true)

theorem identity26940 : scanCanonicalize (H12AffineFastState.compose env26940 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound26940 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env26941 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,4096,4365,276,277,4130,276,4259,4368,276,4096,396,17,51,145,4357,4415,276,276,6193,4352,4357,257,261,276,4885]

theorem envBound26941 : H12AffineFastState.Bounded env26941 := by
  intro p hp
  have h : env26941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26940_26941 : H12AffineEnvironment.transform 9 5 env26940 = env26941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env26940 == env26941) = true)

theorem identity26941 : scanCanonicalize (H12AffineFastState.compose env26941 (packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound26941 : packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env26942 : List Nat := [2,4,8,16,32,17,128,256,512,5,26,4096,4365,276,277,4130,276,4259,4368,276,4096,396,17,51,145,4357,4415,276,276,4139,4352,4357,257,261,276,4885]

theorem envBound26942 : H12AffineFastState.Bounded env26942 := by
  intro p hp
  have h : env26942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26941_26942 : H12AffineEnvironment.transform 10 26 env26941 = env26942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env26941 == env26942) = true)

theorem identity26942 : scanCanonicalize (H12AffineFastState.compose env26942 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 390) := by decide +kernel

theorem selectedBound26942 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env26943 : List Nat := [2,4,8,16,32,17,128,256,390,5,26,4096,4365,276,277,4130,276,4259,4368,276,4096,396,17,51,145,4357,4415,276,276,4139,4352,4357,257,261,276,4243]

theorem envBound26943 : H12AffineFastState.Bounded env26943 := by
  intro p hp
  have h : env26943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26942_26943 : H12AffineEnvironment.transform 8 390 env26942 = env26943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 390 env26942 == env26943) = true)

theorem identity26943 : scanCanonicalize (H12AffineFastState.compose env26943 (packedSelected [1,2,5,13] rootPS)) = affineNative (2^(11+1) ^^^ 270) := by decide +kernel

theorem selectedBound26943 : packedSelected [1,2,5,13] rootPS < 2^1333 := by decide +kernel

def env26944 : List Nat := [2,4,8,16,32,17,128,256,390,5,26,270,3,276,277,300,276,429,30,276,270,396,17,51,145,11,49,276,276,293,14,11,257,261,276,413]

theorem envBound26944 : H12AffineFastState.Bounded env26944 := by
  intro p hp
  have h : env26944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26943_26944 : H12AffineEnvironment.transform 11 270 env26943 = env26944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 270 env26943 == env26944) = true)

theorem identity26944 : scanCanonicalize (H12AffineFastState.compose env26944 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound26944 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env26945 : List Nat := [2,4,8,16,32,17,34,256,292,5,26,270,3,276,277,300,276,271,30,276,270,302,17,51,51,11,49,276,276,293,14,11,257,261,276,319]

theorem envBound26945 : H12AffineFastState.Bounded env26945 := by
  intro p hp
  have h : env26945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26944_26945 : H12AffineEnvironment.transform 6 34 env26944 = env26945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env26944 == env26945) = true)

theorem identity26945 : scanCanonicalize (H12AffineFastState.compose env26945 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound26945 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env26946 : List Nat := [2,4,8,16,17,17,19,256,277,5,26,270,3,276,277,285,276,271,30,276,270,287,17,2,2,11,0,276,276,276,14,11,257,261,276,270]

theorem envBound26946 : H12AffineFastState.Bounded env26946 := by
  intro p hp
  have h : env26946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26945_26946 : H12AffineEnvironment.transform 4 17 env26945 = env26946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env26945 == env26946) = true)

def env26947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533641,672784,17245633,148800,545089,96347,16876545,17495099,257,131136,1345,525824]

theorem envBound26947 : H12AffineFastState.Bounded env26947 := by
  intro p hp
  have h : env26947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26662_26947 : H12AffineEnvironment.transform 26 17245633 env26662 = env26947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env26662 == env26947) = true)

theorem identity26947 : scanCanonicalize (H12AffineFastState.compose env26947 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74862) := by decide +kernel

theorem selectedBound26947 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env26948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4096,61649,91182,16777216,533641,614526,17039791,90414,545089,96347,16876545,17420373,257,74798,1345,525824]

theorem envBound26948 : H12AffineFastState.Bounded env26948 := by
  intro p hp
  have h : env26948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26947_26948 : H12AffineEnvironment.transform 16 74862 env26947 = env26948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74862 env26947 == env26948) = true)

def env26949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4096,61649,91182,123164,533641,614526,385203,90414,545089,96347,25885,536905,257,74798,1345,525824]

theorem envBound26949 : H12AffineFastState.Bounded env26949 := by
  intro p hp
  have h : env26949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26948_26949 : H12AffineEnvironment.transform 23 123164 env26948 = env26949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env26948 == env26949) = true)

def env26950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4096,61649,91182,123164,28889,78894,385203,90414,1297,96347,25885,25881,257,74798,1345,21072]

theorem envBound26950 : H12AffineFastState.Bounded env26950 := by
  intro p hp
  have h : env26950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26949_26950 : H12AffineEnvironment.transform 18 21584 env26949 = env26950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env26949 == env26950) = true)

theorem identity26950 : scanCanonicalize (H12AffineFastState.compose env26950 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound26950 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env26951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74862,262144,21584,13340,4096,17612,91182,87297,28889,78894,349358,90414,1297,96347,25885,25881,257,74798,1345,21072]

theorem envBound26951 : H12AffineFastState.Bounded env26951 := by
  intro p hp
  have h : env26951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26950_26951 : H12AffineEnvironment.transform 14 13341 env26950 = env26951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env26950 == env26951) = true)

def env26952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,262144,4416,13340,4096,476,74046,69649,13769,78894,332222,74814,1297,81227,8205,8201,257,74798,1345,5952]

theorem envBound26952 : H12AffineFastState.Bounded env26952 := by
  intro p hp
  have h : env26952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26951_26952 : H12AffineEnvironment.transform 13 1296 env26951 = env26952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env26951 == env26952) = true)

def env26953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65664,4416,13340,4096,476,74046,69649,13769,78894,4414,74814,1297,81227,8205,8201,257,74798,1345,5952]

theorem envBound26953 : H12AffineFastState.Bounded env26953 := by
  intro p hp
  have h : env26953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26952_26953 : H12AffineEnvironment.transform 17 65664 env26952 = env26953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env26952 == env26953) = true)

theorem identity26953 : scanCanonicalize (H12AffineFastState.compose env26953 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound26953 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1296,5205,65536,66598,65664,4416,5204,4096,476,65910,69649,5505,70758,4414,66678,1297,72963,69,65,257,66662,1345,5952]

theorem envBound26954 : H12AffineFastState.Bounded env26954 := by
  intro p hp
  have h : env26954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26953_26954 : H12AffineEnvironment.transform 12 72 env26953 = env26954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env26953 == env26954) = true)

def env26955 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,72,1296,5205,65536,66598,65664,4416,5204,4096,476,65910,69649,5505,70758,4414,66678,1297,72963,69,65,257,66662,1345,5140]

theorem envBound26955 : H12AffineFastState.Bounded env26955 := by
  intro p hp
  have h : env26955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26954_26955 : H12AffineEnvironment.transform 8 340 env26954 = env26955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env26954 == env26955) = true)

def env26956 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,72,80,4373,65536,65894,65664,4416,4372,4096,476,65910,69649,4289,69926,4414,65846,81,71747,69,65,257,65830,1,4436]

theorem envBound26956 : H12AffineFastState.Bounded env26956 := by
  intro p hp
  have h : env26956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26955_26956 : H12AffineEnvironment.transform 9 320 env26955 = env26956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env26955 == env26956) = true)

theorem identity26956 : scanCanonicalize (H12AffineFastState.compose env26956 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound26956 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env26957 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,277,72,80,0,65536,65894,65664,85,1,277,476,65910,65796,468,65587,43,65846,81,67926,69,65,257,65830,1,65]

theorem envBound26957 : H12AffineFastState.Bounded env26957 := by
  intro p hp
  have h : env26957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26956_26957 : H12AffineEnvironment.transform 11 277 env26956 = env26957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env26956 == env26957) = true)

theorem identity26957 : scanCanonicalize (H12AffineFastState.compose env26957 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 334) := by decide +kernel

theorem selectedBound26957 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env26958 : List Nat := [2,4,8,16,32,64,128,256,340,320,334,277,72,80,0,65536,65894,65664,85,1,277,476,65910,65796,468,65587,43,65846,81,65560,69,65,257,65830,1,65]

theorem envBound26958 : H12AffineFastState.Bounded env26958 := by
  intro p hp
  have h : env26958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26957_26958 : H12AffineEnvironment.transform 10 334 env26957 = env26958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 334 env26957 == env26958) = true)

theorem identity26958 : scanCanonicalize (H12AffineFastState.compose env26958 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound26958 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env26959 : List Nat := [2,4,8,16,32,64,128,256,340,320,334,277,72,80,0,310,80,438,85,1,277,476,64,50,468,261,43,0,81,302,69,65,257,16,1,65]

theorem envBound26959 : H12AffineFastState.Bounded env26959 := by
  intro p hp
  have h : env26959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26958_26959 : H12AffineEnvironment.transform 15 310 env26958 = env26959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env26958 == env26959) = true)

theorem identity26959 : scanCanonicalize (H12AffineFastState.compose env26959 (packedSelected [0,1,7,8,10,11,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 246) := by decide +kernel

theorem selectedBound26959 : packedSelected [0,1,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env26960 : List Nat := [2,4,8,16,32,64,128,246,162,182,184,227,72,80,0,192,80,64,85,1,227,42,64,50,34,243,43,0,81,216,69,65,247,16,1,65]

theorem envBound26960 : H12AffineFastState.Bounded env26960 := by
  intro p hp
  have h : env26960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26959_26960 : H12AffineEnvironment.transform 7 246 env26959 = env26960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 246 env26959 == env26960) = true)

theorem identity26960 : scanCanonicalize (H12AffineFastState.compose env26960 (packedSelected [1,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 127) := by decide +kernel

theorem selectedBound26960 : packedSelected [1,5,8] rootPS < 2^1333 := by decide +kernel

def env26961 : List Nat := [2,4,8,16,32,64,127,9,93,73,71,28,72,80,0,63,80,64,85,1,28,42,64,50,34,12,43,0,81,39,69,65,8,16,1,65]

theorem envBound26961 : H12AffineFastState.Bounded env26961 := by
  intro p hp
  have h : env26961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26960_26961 : H12AffineEnvironment.transform 6 127 env26960 = env26961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 127 env26960 == env26961) = true)

theorem identity26961 : scanCanonicalize (H12AffineFastState.compose env26961 (packedSelected [2,3,5,13] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound26961 : packedSelected [2,3,5,13] rootPS < 2^1333 := by decide +kernel

def env26962 : List Nat := [2,4,8,7,32,64,104,9,74,73,71,11,72,71,0,40,71,64,66,1,11,42,64,37,34,12,43,0,70,39,69,65,8,7,1,65]

theorem envBound26962 : H12AffineFastState.Bounded env26962 := by
  intro p hp
  have h : env26962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26961_26962 : H12AffineEnvironment.transform 3 7 env26961 = env26962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env26961 == env26962) = true)

theorem identity26962 : scanCanonicalize (H12AffineFastState.compose env26962 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound26962 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26963 : List Nat := [2,4,8,7,11,64,67,9,74,73,71,11,72,71,0,3,71,64,66,1,11,1,64,14,9,12,0,0,70,12,69,65,8,7,1,65]

theorem envBound26963 : H12AffineFastState.Bounded env26963 := by
  intro p hp
  have h : env26963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26962_26963 : H12AffineEnvironment.transform 4 11 env26962 = env26963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env26962 == env26963) = true)

theorem identity26963 : scanCanonicalize (H12AffineFastState.compose env26963 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound26963 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26964 : List Nat := [2,4,8,7,11,1,2,9,11,8,6,11,9,6,0,3,6,1,3,1,11,1,1,14,9,12,0,0,7,12,4,0,8,7,1,0]

theorem envBound26964 : H12AffineFastState.Bounded env26964 := by
  intro p hp
  have h : env26964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26963_26964 : H12AffineEnvironment.transform 5 1 env26963 = env26964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env26963 == env26964) = true)

theorem identity26964 : scanCanonicalize (H12AffineFastState.compose env26964 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound26964 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env26965 : List Nat := [2,4,2,7,1,1,2,3,1,2,6,1,3,6,0,3,6,1,3,1,1,1,1,4,3,6,0,0,7,6,4,0,2,7,1,0]

theorem envBound26965 : H12AffineFastState.Bounded env26965 := by
  intro p hp
  have h : env26965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26964_26965 : H12AffineEnvironment.transform 2 2 env26964 = env26965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env26964 == env26965) = true)

theorem identity26965 : scanCanonicalize (H12AffineFastState.compose env26965 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound26965 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26966 : List Nat := [1,4,1,4,1,1,1,0,1,1,5,1,0,5,0,0,5,1,0,1,1,1,1,4,0,5,0,0,4,5,4,0,1,4,1,0]

theorem envBound26966 : H12AffineFastState.Bounded env26966 := by
  intro p hp
  have h : env26966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26965_26966 : H12AffineEnvironment.transform 0 1 env26965 = env26966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env26965 == env26966) = true)

def env26967 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,72,81,4372,65536,65895,65664,4416,4373,4096,476,65910,69649,4288,69927,4414,65847,80,71746,69,65,257,65831,0,4437]

theorem envBound26967 : H12AffineFastState.Bounded env26967 := by
  intro p hp
  have h : env26967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26955_26967 : H12AffineEnvironment.transform 9 321 env26955 = env26967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env26955 == env26967) = true)

theorem identity26967 : scanCanonicalize (H12AffineFastState.compose env26967 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound26967 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env26968 : List Nat := [2,4,8,16,32,64,128,20,64,85,2048,4096,72,81,4096,65536,65651,65664,4180,4097,4096,200,65634,69649,4288,69683,4138,65571,80,71746,69,65,21,65587,0,4161]

theorem envBound26968 : H12AffineFastState.Bounded env26968 := by
  intro p hp
  have h : env26968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26967_26968 : H12AffineEnvironment.transform 7 20 env26967 = env26968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env26967 == env26968) = true)

theorem identity26968 : scanCanonicalize (H12AffineFastState.compose env26968 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 2227) := by decide +kernel

theorem selectedBound26968 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env26969 : List Nat := [2,4,8,16,32,64,128,20,64,85,2048,2227,72,81,2227,65536,65651,65664,2279,2226,2227,200,65634,67746,2163,67712,2201,65571,80,65777,69,65,21,65587,0,2290]

theorem envBound26969 : H12AffineFastState.Bounded env26969 := by
  intro p hp
  have h : env26969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26968_26969 : H12AffineEnvironment.transform 11 2227 env26968 = env26969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2227 env26968 == env26969) = true)

theorem identity26969 : scanCanonicalize (H12AffineFastState.compose env26969 (packedSelected [2,11,17,18,21] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound26969 : packedSelected [2,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env26970 : List Nat := [2,4,8,16,32,64,128,20,64,85,2048,2227,72,81,2227,114,1,242,2279,2226,2227,200,16,2256,2163,2290,2201,81,80,131,69,65,21,65,0,2290]

theorem envBound26970 : H12AffineFastState.Bounded env26970 := by
  intro p hp
  have h : env26970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26969_26970 : H12AffineEnvironment.transform 15 114 env26969 = env26970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env26969 == env26970) = true)

theorem identity26970 : scanCanonicalize (H12AffineFastState.compose env26970 (packedSelected [0,2,3,7,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 212) := by decide +kernel

theorem selectedBound26970 : packedSelected [0,2,3,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env26971 : List Nat := [2,4,8,16,32,64,128,20,64,85,212,103,72,81,103,114,1,242,51,102,103,200,16,4,167,38,77,81,80,131,69,65,21,65,0,38]

theorem envBound26971 : H12AffineFastState.Bounded env26971 := by
  intro p hp
  have h : env26971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26970_26971 : H12AffineEnvironment.transform 10 212 env26970 = env26971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 212 env26970 == env26971) = true)

theorem identity26971 : scanCanonicalize (H12AffineFastState.compose env26971 (packedSelected [0,1,2,5,7,10,11,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 82) := by decide +kernel

theorem selectedBound26971 : packedSelected [0,1,2,5,7,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env26972 : List Nat := [2,4,8,16,32,64,82,20,64,85,6,103,72,81,103,114,1,32,51,102,103,26,16,4,117,38,77,81,80,81,69,65,21,65,0,38]

theorem envBound26972 : H12AffineFastState.Bounded env26972 := by
  intro p hp
  have h : env26972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26971_26972 : H12AffineEnvironment.transform 6 82 env26971 = env26972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 82 env26971 == env26972) = true)

theorem identity26972 : scanCanonicalize (H12AffineFastState.compose env26972 (packedSelected [2,5,10] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound26972 : packedSelected [2,5,10] rootPS < 2^1333 := by decide +kernel

def env26973 : List Nat := [2,4,2,16,32,64,82,20,64,85,6,103,66,81,103,114,1,32,51,102,103,16,16,4,117,38,71,81,80,81,69,65,21,65,0,38]

theorem envBound26973 : H12AffineFastState.Bounded env26973 := by
  intro p hp
  have h : env26973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26972_26973 : H12AffineEnvironment.transform 2 2 env26972 = env26973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env26972 == env26973) = true)

theorem identity26973 : scanCanonicalize (H12AffineFastState.compose env26973 (packedSelected [2,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound26973 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env26974 : List Nat := [2,4,2,16,32,32,50,20,32,53,6,7,34,49,7,18,1,32,51,6,7,16,16,4,21,38,39,49,48,49,37,33,21,33,0,38]

theorem envBound26974 : H12AffineFastState.Bounded env26974 := by
  intro p hp
  have h : env26974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26973_26974 : H12AffineEnvironment.transform 5 32 env26973 = env26974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env26973 == env26974) = true)

theorem identity26974 : scanCanonicalize (H12AffineFastState.compose env26974 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound26974 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env26975 : List Nat := [2,2,2,16,32,32,50,18,32,51,0,1,34,49,1,18,1,32,51,0,1,16,16,2,19,32,33,49,48,49,35,33,19,33,0,32]

theorem envBound26975 : H12AffineFastState.Bounded env26975 := by
  intro p hp
  have h : env26975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26974_26975 : H12AffineEnvironment.transform 1 2 env26974 = env26975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env26974 == env26975) = true)

theorem identity26975 : scanCanonicalize (H12AffineFastState.compose env26975 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound26975 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26976 : List Nat := [2,2,2,16,17,17,3,18,17,2,0,1,19,0,1,18,1,17,2,0,1,16,16,2,19,17,16,0,1,0,18,16,19,16,0,17]

theorem envBound26976 : H12AffineFastState.Bounded env26976 := by
  intro p hp
  have h : env26976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26975_26976 : H12AffineEnvironment.transform 4 17 env26975 = env26976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env26975 == env26976) = true)

theorem identity26976 : scanCanonicalize (H12AffineFastState.compose env26976 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound26976 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26977 : List Nat := [2,2,2,1,0,0,3,3,0,2,0,1,2,0,1,3,1,0,2,0,1,1,1,2,2,0,1,0,1,0,3,1,2,1,0,0]

theorem envBound26977 : H12AffineFastState.Bounded env26977 := by
  intro p hp
  have h : env26977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26976_26977 : H12AffineEnvironment.transform 3 1 env26976 = env26977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env26976 == env26977) = true)

def env26978 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,72,1296,5205,65536,66598,65664,4416,5204,4096,476,65910,69649,5505,70758,4414,66678,1297,72963,69,65,257,66662,1345,5141]

theorem envBound26978 : H12AffineFastState.Bounded env26978 := by
  intro p hp
  have h : env26978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26954_26978 : H12AffineEnvironment.transform 8 341 env26954 = env26978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env26954 == env26978) = true)

def env26979 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,72,80,4373,65536,65894,65664,4416,4372,4096,476,65910,69649,4289,69926,4414,65846,81,71747,69,65,257,65830,1,4437]

theorem envBound26979 : H12AffineFastState.Bounded env26979 := by
  intro p hp
  have h : env26979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26978_26979 : H12AffineEnvironment.transform 9 320 env26978 = env26979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env26978 == env26979) = true)

theorem identity26979 : scanCanonicalize (H12AffineFastState.compose env26979 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound26979 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env26980 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,277,72,80,0,65536,65894,65664,85,1,277,476,65910,65796,468,65587,43,65846,81,67926,69,65,257,65830,1,64]

theorem envBound26980 : H12AffineFastState.Bounded env26980 := by
  intro p hp
  have h : env26980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26979_26980 : H12AffineEnvironment.transform 11 277 env26979 = env26980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env26979 == env26980) = true)

theorem identity26980 : scanCanonicalize (H12AffineFastState.compose env26980 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 335) := by decide +kernel

theorem selectedBound26980 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env26981 : List Nat := [2,4,8,16,32,64,128,256,341,320,335,277,72,80,0,65536,65894,65664,85,1,277,476,65910,65796,468,65587,43,65846,81,65561,69,65,257,65830,1,64]

theorem envBound26981 : H12AffineFastState.Bounded env26981 := by
  intro p hp
  have h : env26981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26980_26981 : H12AffineEnvironment.transform 10 335 env26980 = env26981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 335 env26980 == env26981) = true)

theorem identity26981 : scanCanonicalize (H12AffineFastState.compose env26981 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound26981 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env26982 : List Nat := [2,4,8,16,32,64,128,256,341,320,335,277,72,80,0,310,80,438,85,1,277,476,64,50,468,261,43,0,81,303,69,65,257,16,1,64]

theorem envBound26982 : H12AffineFastState.Bounded env26982 := by
  intro p hp
  have h : env26982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26981_26982 : H12AffineEnvironment.transform 15 310 env26981 = env26982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env26981 == env26982) = true)

theorem identity26982 : scanCanonicalize (H12AffineFastState.compose env26982 (packedSelected [0,1,7,8,10,11,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 98) := by decide +kernel

theorem selectedBound26982 : packedSelected [0,1,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env26983 : List Nat := [2,4,8,16,32,64,98,256,341,320,335,277,72,80,0,310,80,340,85,1,277,318,64,50,310,261,43,0,81,303,69,65,257,16,1,64]

theorem envBound26983 : H12AffineFastState.Bounded env26983 := by
  intro p hp
  have h : env26983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26982_26983 : H12AffineEnvironment.transform 6 98 env26982 = env26983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 98 env26982 == env26983) = true)

theorem identity26983 : scanCanonicalize (H12AffineFastState.compose env26983 (packedSelected [2,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 66) := by decide +kernel

theorem selectedBound26983 : packedSelected [2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env26984 : List Nat := [2,4,8,16,32,64,98,66,23,2,13,87,72,80,0,116,80,22,85,1,87,124,64,50,116,71,43,0,81,109,69,65,67,16,1,64]

theorem envBound26984 : H12AffineFastState.Bounded env26984 := by
  intro p hp
  have h : env26984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26983_26984 : H12AffineEnvironment.transform 7 66 env26983 = env26984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 66 env26983 == env26984) = true)

theorem identity26984 : scanCanonicalize (H12AffineFastState.compose env26984 (packedSelected [2,3,5,13] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound26984 : packedSelected [2,3,5,13] rootPS < 2^1333 := by decide +kernel

def env26985 : List Nat := [2,4,2,16,32,64,98,66,23,2,7,87,66,80,0,116,80,22,85,1,87,118,64,50,116,71,33,0,81,103,69,65,67,16,1,64]

theorem envBound26985 : H12AffineFastState.Bounded env26985 := by
  intro p hp
  have h : env26985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26984_26985 : H12AffineEnvironment.transform 2 2 env26984 = env26985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env26984 == env26985) = true)

theorem identity26985 : scanCanonicalize (H12AffineFastState.compose env26985 (packedSelected [1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound26985 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env26986 : List Nat := [2,4,2,16,23,64,85,66,23,2,7,87,66,80,0,67,80,22,85,1,87,65,64,5,67,71,22,0,81,80,69,65,67,16,1,64]

theorem envBound26986 : H12AffineFastState.Bounded env26986 := by
  intro p hp
  have h : env26986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26985_26986 : H12AffineEnvironment.transform 4 23 env26985 = env26986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env26985 == env26986) = true)

theorem identity26986 : scanCanonicalize (H12AffineFastState.compose env26986 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound26986 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26987 : List Nat := [2,2,2,16,17,64,83,66,17,2,1,81,66,80,0,67,80,16,83,1,81,65,64,3,67,65,16,0,81,80,67,65,67,16,1,64]

theorem envBound26987 : H12AffineFastState.Bounded env26987 := by
  intro p hp
  have h : env26987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26986_26987 : H12AffineEnvironment.transform 1 2 env26986 = env26987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env26986 == env26987) = true)

theorem identity26987 : scanCanonicalize (H12AffineFastState.compose env26987 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound26987 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26988 : List Nat := [2,2,2,0,1,64,67,66,1,2,1,65,66,64,0,67,64,0,67,1,65,65,64,3,67,65,0,0,65,64,67,65,67,0,1,64]

theorem envBound26988 : H12AffineFastState.Bounded env26988 := by
  intro p hp
  have h : env26988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26987_26988 : H12AffineEnvironment.transform 3 0 env26987 = env26988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env26987 == env26988) = true)

def env26989 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,72,81,4372,65536,65895,65664,4416,4373,4096,476,65910,69649,4288,69927,4414,65847,80,71746,69,65,257,65831,0,4436]

theorem envBound26989 : H12AffineFastState.Bounded env26989 := by
  intro p hp
  have h : env26989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26978_26989 : H12AffineEnvironment.transform 9 321 env26978 = env26989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env26978 == env26989) = true)

theorem identity26989 : scanCanonicalize (H12AffineFastState.compose env26989 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound26989 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env26990 : List Nat := [2,4,8,16,32,64,128,20,65,85,2048,4096,72,81,4096,65536,65651,65664,4180,4097,4096,200,65634,69649,4288,69683,4138,65571,80,71746,69,65,21,65587,0,4160]

theorem envBound26990 : H12AffineFastState.Bounded env26990 := by
  intro p hp
  have h : env26990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26989_26990 : H12AffineEnvironment.transform 7 20 env26989 = env26990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env26989 == env26990) = true)

theorem identity26990 : scanCanonicalize (H12AffineFastState.compose env26990 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 2226) := by decide +kernel

theorem selectedBound26990 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env26991 : List Nat := [2,4,8,16,32,64,128,20,65,85,2048,2226,72,81,2226,65536,65651,65664,2278,2227,2226,200,65634,67747,2162,67713,2200,65571,80,65776,69,65,21,65587,0,2290]

theorem envBound26991 : H12AffineFastState.Bounded env26991 := by
  intro p hp
  have h : env26991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26990_26991 : H12AffineEnvironment.transform 11 2226 env26990 = env26991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2226 env26990 == env26991) = true)

theorem identity26991 : scanCanonicalize (H12AffineFastState.compose env26991 (packedSelected [2,11,17,18,21] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound26991 : packedSelected [2,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env26992 : List Nat := [2,4,8,16,32,64,128,20,65,85,2048,2226,72,81,2226,114,1,242,2278,2227,2226,200,16,2257,2162,2291,2200,81,80,130,69,65,21,65,0,2290]

theorem envBound26992 : H12AffineFastState.Bounded env26992 := by
  intro p hp
  have h : env26992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26991_26992 : H12AffineEnvironment.transform 15 114 env26991 = env26992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env26991 == env26992) = true)

theorem identity26992 : scanCanonicalize (H12AffineFastState.compose env26992 (packedSelected [0,2,3,7,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 213) := by decide +kernel

theorem selectedBound26992 : packedSelected [0,2,3,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env26993 : List Nat := [2,4,8,16,32,64,128,20,65,85,213,103,72,81,103,114,1,242,51,102,103,200,16,4,167,38,77,81,80,130,69,65,21,65,0,39]

theorem envBound26993 : H12AffineFastState.Bounded env26993 := by
  intro p hp
  have h : env26993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26992_26993 : H12AffineEnvironment.transform 10 213 env26992 = env26993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 213 env26992 == env26993) = true)

theorem identity26993 : scanCanonicalize (H12AffineFastState.compose env26993 (packedSelected [0,1,2,5,7,10,11,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 83) := by decide +kernel

theorem selectedBound26993 : packedSelected [0,1,2,5,7,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env26994 : List Nat := [2,4,8,16,32,64,83,20,65,85,6,103,72,81,103,114,1,33,51,102,103,27,16,4,116,38,77,81,80,81,69,65,21,65,0,39]

theorem envBound26994 : H12AffineFastState.Bounded env26994 := by
  intro p hp
  have h : env26994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26993_26994 : H12AffineEnvironment.transform 6 83 env26993 = env26994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 83 env26993 == env26994) = true)

theorem identity26994 : scanCanonicalize (H12AffineFastState.compose env26994 (packedSelected [2,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 45) := by decide +kernel

theorem selectedBound26994 : packedSelected [2,5,10] rootPS < 2^1333 := by decide +kernel

def env26995 : List Nat := [2,4,8,16,32,45,62,20,44,56,6,10,37,60,10,31,1,33,51,11,10,27,16,4,25,38,32,60,61,60,40,44,21,44,0,39]

theorem envBound26995 : H12AffineFastState.Bounded env26995 := by
  intro p hp
  have h : env26995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26994_26995 : H12AffineEnvironment.transform 5 45 env26994 = env26995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 45 env26994 == env26995) = true)

theorem identity26995 : scanCanonicalize (H12AffineFastState.compose env26995 (packedSelected [0,2,7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound26995 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env26996 : List Nat := [2,3,8,16,32,42,57,19,43,56,1,10,34,59,10,24,1,33,51,11,10,27,16,3,25,33,32,59,58,59,40,43,18,43,0,32]

theorem envBound26996 : H12AffineFastState.Bounded env26996 := by
  intro p hp
  have h : env26996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26995_26996 : H12AffineEnvironment.transform 1 3 env26995 = env26996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env26995 == env26996) = true)

theorem identity26996 : scanCanonicalize (H12AffineFastState.compose env26996 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound26996 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26997 : List Nat := [2,3,8,16,10,0,19,19,1,18,1,10,8,17,10,24,1,11,25,11,10,27,16,3,25,11,10,17,16,17,2,1,18,1,0,10]

theorem envBound26997 : H12AffineFastState.Bounded env26997 := by
  intro p hp
  have h : env26997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26996_26997 : H12AffineEnvironment.transform 4 10 env26996 = env26997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env26996 == env26997) = true)

theorem identity26997 : scanCanonicalize (H12AffineFastState.compose env26997 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound26997 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26998 : List Nat := [2,3,8,11,10,0,8,8,1,9,1,10,8,10,10,3,1,11,2,11,10,0,11,3,2,11,10,10,11,10,2,1,9,1,0,10]

theorem envBound26998 : H12AffineFastState.Bounded env26998 := by
  intro p hp
  have h : env26998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26997_26998 : H12AffineEnvironment.transform 3 11 env26997 = env26998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env26997 == env26998) = true)

theorem identity26998 : scanCanonicalize (H12AffineFastState.compose env26998 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound26998 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26999 : List Nat := [2,3,3,0,1,0,3,3,1,2,1,1,3,1,1,3,1,0,2,0,1,0,0,3,2,0,1,1,0,1,2,1,2,1,0,1]

theorem envBound26999 : H12AffineFastState.Bounded env26999 := by
  intro p hp
  have h : env26999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26998_26999 : H12AffineEnvironment.transform 2 3 env26998 = env26999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env26998 == env26999) = true)

def env27000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65665,4416,13340,4096,476,74046,69649,13769,78894,4415,74814,1297,81227,8205,8201,257,74798,1345,5952]

theorem envBound27000 : H12AffineFastState.Bounded env27000 := by
  intro p hp
  have h : env27000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26952_27000 : H12AffineEnvironment.transform 17 65665 env26952 = env27000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env26952 == env27000) = true)

theorem identity27000 : scanCanonicalize (H12AffineFastState.compose env27000 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5385) := by decide +kernel

theorem selectedBound27000 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1296,276,65536,69991,65665,4416,277,4096,476,70711,69649,192,65831,4415,69943,1297,67650,5380,5376,257,69927,1345,5952]

theorem envBound27001 : H12AffineFastState.Bounded env27001 := by
  intro p hp
  have h : env27001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27000_27001 : H12AffineEnvironment.transform 12 5385 env27000 = env27001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env27000 == env27001) = true)

def env27002 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,5385,1296,276,65536,69991,65665,4416,277,4096,476,70711,69649,192,65831,4415,69943,1297,67650,5380,5376,257,69927,1345,5140]

theorem envBound27002 : H12AffineFastState.Bounded env27002 := by
  intro p hp
  have h : env27002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27001_27002 : H12AffineEnvironment.transform 8 340 env27001 = env27002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env27001 == env27002) = true)

def env27003 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,1289,1296,276,65536,65895,65665,320,277,0,476,66615,65553,192,65831,319,65847,1297,67650,1284,1280,257,65831,1345,1044]

theorem envBound27003 : H12AffineFastState.Bounded env27003 := by
  intro p hp
  have h : env27003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27002_27003 : H12AffineEnvironment.transform 11 0 env27002 = env27003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env27002 == env27003) = true)

theorem identity27003 : scanCanonicalize (H12AffineFastState.compose env27003 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound27003 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27004 : List Nat := [2,4,8,16,32,64,128,256,340,85,2048,0,348,325,276,65536,65895,65665,320,277,0,476,65634,65553,192,65831,319,65847,324,67650,337,341,257,65831,276,65]

theorem envBound27004 : H12AffineFastState.Bounded env27004 := by
  intro p hp
  have h : env27004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27003_27004 : H12AffineEnvironment.transform 9 85 env27003 = env27004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env27003 == env27004) = true)

theorem identity27004 : scanCanonicalize (H12AffineFastState.compose env27004 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 226) := by decide +kernel

theorem selectedBound27004 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env27005 : List Nat := [2,4,8,16,32,64,128,256,340,85,226,0,348,325,276,65536,65895,65665,320,277,0,476,65634,65553,192,65831,319,65847,324,65696,337,341,257,65831,276,65]

theorem envBound27005 : H12AffineFastState.Bounded env27005 := by
  intro p hp
  have h : env27005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27004_27005 : H12AffineEnvironment.transform 10 226 env27004 = env27005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 226 env27004 == env27005) = true)

theorem identity27005 : scanCanonicalize (H12AffineFastState.compose env27005 (packedSelected [1,2,3,12,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 144) := by decide +kernel

theorem selectedBound27005 : packedSelected [1,2,3,12,13,15] rootPS < 2^1333 := by decide +kernel

def env27006 : List Nat := [2,4,8,16,32,64,128,256,340,85,226,0,348,325,276,144,503,17,320,277,0,476,242,129,192,439,319,423,324,48,337,341,257,439,276,65]

theorem envBound27006 : H12AffineFastState.Bounded env27006 := by
  intro p hp
  have h : env27006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27005_27006 : H12AffineEnvironment.transform 15 144 env27005 = env27006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 144 env27005 == env27006) = true)

theorem identity27006 : scanCanonicalize (H12AffineFastState.compose env27006 (packedSelected [2,4,5,8,9,13,16] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound27006 : packedSelected [2,4,5,8,9,13,16] rootPS < 2^1333 := by decide +kernel

def env27007 : List Nat := [2,4,8,16,32,64,128,110,58,85,226,0,50,43,122,144,153,17,46,123,0,178,242,129,192,217,81,201,42,48,63,59,111,217,122,65]

theorem envBound27007 : H12AffineFastState.Bounded env27007 := by
  intro p hp
  have h : env27007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27006_27007 : H12AffineEnvironment.transform 7 110 env27006 = env27007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env27006 == env27007) = true)

theorem identity27007 : scanCanonicalize (H12AffineFastState.compose env27007 (packedSelected [1,2,3,4,5,8,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound27007 : packedSelected [1,2,3,4,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env27008 : List Nat := [2,4,8,16,32,49,128,31,58,36,147,0,50,43,11,144,153,17,46,10,0,178,131,129,177,168,32,184,42,48,63,59,30,168,11,48]

theorem envBound27008 : H12AffineFastState.Bounded env27008 := by
  intro p hp
  have h : env27008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27007_27008 : H12AffineEnvironment.transform 5 49 env27007 = env27008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env27007 == env27008) = true)

theorem identity27008 : scanCanonicalize (H12AffineFastState.compose env27008 (packedSelected [2,5] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound27008 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env27009 : List Nat := [2,4,8,16,12,29,128,31,22,8,147,0,30,7,11,144,153,17,2,10,0,158,131,129,157,132,12,148,6,28,19,23,30,132,11,28]

theorem envBound27009 : H12AffineFastState.Bounded env27009 := by
  intro p hp
  have h : env27009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27008_27009 : H12AffineEnvironment.transform 4 12 env27008 = env27009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env27008 == env27009) = true)

theorem identity27009 : scanCanonicalize (H12AffineFastState.compose env27009 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound27009 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env27010 : List Nat := [2,4,5,16,1,16,128,18,22,5,147,0,19,7,6,144,148,17,2,7,0,147,131,129,144,132,1,148,6,17,19,23,19,132,6,17]

theorem envBound27010 : H12AffineFastState.Bounded env27010 := by
  intro p hp
  have h : env27010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27009_27010 : H12AffineEnvironment.transform 2 5 env27009 = env27010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env27009 == env27010) = true)

theorem identity27010 : scanCanonicalize (H12AffineFastState.compose env27010 (packedSelected [0,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound27010 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env27011 : List Nat := [2,4,5,16,1,16,20,18,22,5,7,0,19,7,6,4,0,17,2,7,0,7,23,21,4,16,1,0,6,17,19,23,19,16,6,17]

theorem envBound27011 : H12AffineFastState.Bounded env27011 := by
  intro p hp
  have h : env27011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27010_27011 : H12AffineEnvironment.transform 6 20 env27010 = env27011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env27010 == env27011) = true)

theorem identity27011 : scanCanonicalize (H12AffineFastState.compose env27011 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound27011 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env27012 : List Nat := [2,4,5,0,1,0,4,2,6,5,7,0,3,7,6,4,0,1,2,7,0,7,7,5,4,0,1,0,6,1,3,7,3,0,6,1]

theorem envBound27012 : H12AffineFastState.Bounded env27012 := by
  intro p hp
  have h : env27012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27011_27012 : H12AffineEnvironment.transform 3 0 env27011 = env27012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27011 == env27012) = true)

theorem identity27012 : scanCanonicalize (H12AffineFastState.compose env27012 (packedSelected [8] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound27012 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env27013 : List Nat := [2,3,2,0,1,0,3,2,1,2,0,0,3,0,1,3,0,1,2,0,0,0,0,2,3,0,1,0,1,1,3,0,3,0,1,1]

theorem envBound27013 : H12AffineFastState.Bounded env27013 := by
  intro p hp
  have h : env27013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27012_27013 : H12AffineEnvironment.transform 1 3 env27012 = env27013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env27012 == env27013) = true)

def env27014 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,1288,1296,276,65536,65894,65665,321,277,1,476,66614,65552,192,65831,318,65846,1297,67650,1285,1281,257,65830,1345,1045]

theorem envBound27014 : H12AffineFastState.Bounded env27014 := by
  intro p hp
  have h : env27014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27002_27014 : H12AffineEnvironment.transform 11 1 env27002 = env27014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env27002 == env27014) = true)

theorem identity27014 : scanCanonicalize (H12AffineFastState.compose env27014 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound27014 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27015 : List Nat := [2,4,8,16,32,64,128,20,64,1024,2048,1,1052,1028,0,65536,65650,65665,85,1,1,200,66614,65552,192,65587,42,65570,1029,67650,1041,1045,21,65586,1109,1045]

theorem envBound27015 : H12AffineFastState.Bounded env27015 := by
  intro p hp
  have h : env27015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27014_27015 : H12AffineEnvironment.transform 7 20 env27014 = env27015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env27014 == env27015) = true)

theorem identity27015 : scanCanonicalize (H12AffineFastState.compose env27015 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 1142) := by decide +kernel

theorem selectedBound27015 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env27016 : List Nat := [2,4,8,16,32,64,128,20,64,1024,2048,1,1052,1028,0,1142,1028,1271,85,1,1,200,64,1126,192,1093,42,1108,1029,3124,1041,1045,21,1092,1109,1045]

theorem envBound27016 : H12AffineFastState.Bounded env27016 := by
  intro p hp
  have h : env27016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27015_27016 : H12AffineEnvironment.transform 15 1142 env27015 = env27016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1142 env27015 == env27016) = true)

theorem identity27016 : scanCanonicalize (H12AffineFastState.compose env27016 (packedSelected [0,2,3,5,7,8,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1128) := by decide +kernel

theorem selectedBound27016 : packedSelected [0,2,3,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env27017 : List Nat := [2,4,8,16,32,64,128,20,64,1024,1128,1,1052,1028,0,1142,1028,1271,85,1,1,200,64,1126,192,1093,42,1108,1029,92,1041,1045,21,1092,1109,1045]

theorem envBound27017 : H12AffineFastState.Bounded env27017 := by
  intro p hp
  have h : env27017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27016_27017 : H12AffineEnvironment.transform 10 1128 env27016 = env27017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1128 env27016 == env27017) = true)

theorem identity27017 : scanCanonicalize (H12AffineFastState.compose env27017 (packedSelected [1,2,3,5,15] rootPS)) = affineNative (2^(6+1) ^^^ 99) := by decide +kernel

theorem selectedBound27017 : packedSelected [1,2,3,5,15] rootPS < 2^1333 := by decide +kernel

def env27018 : List Nat := [2,4,8,16,32,64,99,20,64,1024,1128,1,1052,1028,0,1142,1028,1044,85,1,1,43,64,1126,35,1093,42,1108,1029,92,1041,1045,21,1092,1109,1045]

theorem envBound27018 : H12AffineFastState.Bounded env27018 := by
  intro p hp
  have h : env27018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27017_27018 : H12AffineEnvironment.transform 6 99 env27017 = env27018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 99 env27017 == env27018) = true)

theorem identity27018 : scanCanonicalize (H12AffineFastState.compose env27018 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound27018 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27019 : List Nat := [2,4,8,16,32,64,99,20,64,85,61,1,73,81,0,35,81,65,85,1,1,43,64,51,35,16,42,1,80,92,68,64,21,17,0,64]

theorem envBound27019 : H12AffineFastState.Bounded env27019 := by
  intro p hp
  have h : env27019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27018_27019 : H12AffineEnvironment.transform 9 85 env27018 = env27019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env27018 == env27019) = true)

theorem identity27019 : scanCanonicalize (H12AffineFastState.compose env27019 (packedSelected [1,3,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound27019 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env27020 : List Nat := [2,4,3,16,32,64,99,20,64,85,54,1,66,81,0,35,81,65,85,1,1,32,64,51,35,16,33,1,80,87,68,64,21,17,0,64]

theorem envBound27020 : H12AffineFastState.Bounded env27020 := by
  intro p hp
  have h : env27020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27019_27020 : H12AffineEnvironment.transform 2 3 env27019 = env27020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env27019 == env27020) = true)

theorem identity27020 : scanCanonicalize (H12AffineFastState.compose env27020 (packedSelected [3,8] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound27020 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env27021 : List Nat := [2,4,3,16,32,38,5,20,38,51,54,1,36,55,0,35,55,39,51,1,1,32,38,51,35,16,33,1,54,49,34,38,21,17,0,38]

theorem envBound27021 : H12AffineFastState.Bounded env27021 := by
  intro p hp
  have h : env27021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27020_27021 : H12AffineEnvironment.transform 5 38 env27020 = env27021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env27020 == env27021) = true)

theorem identity27021 : scanCanonicalize (H12AffineFastState.compose env27021 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound27021 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env27022 : List Nat := [2,4,3,6,32,38,5,2,38,37,32,1,36,33,0,35,33,39,37,1,1,32,38,37,35,6,33,1,32,39,34,38,3,7,0,38]

theorem envBound27022 : H12AffineFastState.Bounded env27022 := by
  intro p hp
  have h : env27022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27021_27022 : H12AffineEnvironment.transform 3 6 env27021 = env27022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env27021 == env27022) = true)

theorem identity27022 : scanCanonicalize (H12AffineFastState.compose env27022 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound27022 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27023 : List Nat := [2,3,3,1,32,33,2,2,33,34,32,1,35,33,0,35,33,32,34,1,1,32,33,34,35,1,33,1,32,32,34,33,3,0,0,33]

theorem envBound27023 : H12AffineFastState.Bounded env27023 := by
  intro p hp
  have h : env27023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27022_27023 : H12AffineEnvironment.transform 1 3 env27022 = env27023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env27022 == env27023) = true)

theorem identity27023 : scanCanonicalize (H12AffineFastState.compose env27023 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27023 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27024 : List Nat := [2,3,3,1,0,1,2,2,1,2,0,1,3,1,0,3,1,0,2,1,1,0,1,2,3,1,1,1,0,0,2,1,3,0,0,1]

theorem envBound27024 : H12AffineFastState.Bounded env27024 := by
  intro p hp
  have h : env27024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27023_27024 : H12AffineEnvironment.transform 4 0 env27023 = env27024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27023 == env27024) = true)

def env27025 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,5385,1296,276,65536,69991,65665,4416,277,4096,476,70711,69649,192,65831,4415,69943,1297,67650,5380,5376,257,69927,1345,5141]

theorem envBound27025 : H12AffineFastState.Bounded env27025 := by
  intro p hp
  have h : env27025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27001_27025 : H12AffineEnvironment.transform 8 341 env27001 = env27025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env27001 == env27025) = true)

def env27026 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,1289,1296,276,65536,65895,65665,320,277,0,476,66615,65553,192,65831,319,65847,1297,67650,1284,1280,257,65831,1345,1045]

theorem envBound27026 : H12AffineFastState.Bounded env27026 := by
  intro p hp
  have h : env27026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27025_27026 : H12AffineEnvironment.transform 11 0 env27025 = env27026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env27025 == env27026) = true)

theorem identity27026 : scanCanonicalize (H12AffineFastState.compose env27026 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound27026 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27027 : List Nat := [2,4,8,16,32,64,128,256,341,85,2048,0,348,325,276,65536,65895,65665,320,277,0,476,65634,65553,192,65831,319,65847,324,67650,337,341,257,65831,276,64]

theorem envBound27027 : H12AffineFastState.Bounded env27027 := by
  intro p hp
  have h : env27027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27026_27027 : H12AffineEnvironment.transform 9 85 env27026 = env27027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env27026 == env27027) = true)

theorem identity27027 : scanCanonicalize (H12AffineFastState.compose env27027 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 227) := by decide +kernel

theorem selectedBound27027 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env27028 : List Nat := [2,4,8,16,32,64,128,256,341,85,227,0,348,325,276,65536,65895,65665,320,277,0,476,65634,65553,192,65831,319,65847,324,65697,337,341,257,65831,276,64]

theorem envBound27028 : H12AffineFastState.Bounded env27028 := by
  intro p hp
  have h : env27028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27027_27028 : H12AffineEnvironment.transform 10 227 env27027 = env27028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 227 env27027 == env27028) = true)

theorem identity27028 : scanCanonicalize (H12AffineFastState.compose env27028 (packedSelected [1,2,3,12,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 145) := by decide +kernel

theorem selectedBound27028 : packedSelected [1,2,3,12,13,15] rootPS < 2^1333 := by decide +kernel

def env27029 : List Nat := [2,4,8,16,32,64,128,256,341,85,227,0,348,325,276,145,502,16,320,277,0,476,243,128,192,438,319,422,324,48,337,341,257,438,276,64]

theorem envBound27029 : H12AffineFastState.Bounded env27029 := by
  intro p hp
  have h : env27029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27028_27029 : H12AffineEnvironment.transform 15 145 env27028 = env27029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 145 env27028 == env27029) = true)

theorem identity27029 : scanCanonicalize (H12AffineFastState.compose env27029 (packedSelected [2,4,5,8,9,13,16] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound27029 : packedSelected [2,4,5,8,9,13,16] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2