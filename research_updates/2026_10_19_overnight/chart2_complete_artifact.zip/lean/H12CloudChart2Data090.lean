import H12CloudChart2Data089

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity22085 : scanCanonicalize (H12AffineFastState.compose env22085 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 428) := by decide +kernel

theorem selectedBound22085 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22086 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,129,1297,428,65536,1297,2309,1024,429,1297,1,16,65705,9,17,2049,1296,1296,2308,1285,137,256,65675,1297,137]

theorem envBound22086 : H12AffineFastState.Bounded env22086 := by
  intro p hp
  have h : env22086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22085_22086 : H12AffineEnvironment.transform 14 428 env22085 = env22086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 428 env22085 == env22086) = true)

def env22087 : List Nat := [2,4,8,16,32,16,128,256,137,272,2048,1,129,1,428,65536,1,2309,272,429,1,1,16,65705,9,17,2049,0,0,2308,21,137,256,65675,1,137]

theorem envBound22087 : H12AffineFastState.Bounded env22087 := by
  intro p hp
  have h : env22087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22086_22087 : H12AffineEnvironment.transform 9 272 env22086 = env22087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env22086 == env22087) = true)

theorem identity22087 : scanCanonicalize (H12AffineFastState.compose env22087 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound22087 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22088 : List Nat := [2,4,8,16,32,16,128,140,137,156,2048,1,129,1,32,65536,1,2185,156,33,1,1,16,65705,9,17,2049,0,0,2184,21,137,140,65675,1,137]

theorem envBound22088 : H12AffineFastState.Bounded env22088 := by
  intro p hp
  have h : env22088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22087_22088 : H12AffineEnvironment.transform 7 140 env22087 = env22088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env22087 == env22088) = true)

def env22089 : List Nat := [2,4,8,16,32,16,8,4,1,20,2048,1,9,1,32,65536,1,2049,20,33,1,1,16,65569,9,17,2049,0,0,2048,21,1,4,65539,1,1]

theorem envBound22089 : H12AffineFastState.Bounded env22089 := by
  intro p hp
  have h : env22089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22088_22089 : H12AffineEnvironment.transform 6 8 env22088 = env22089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22088 == env22089) = true)

theorem identity22089 : scanCanonicalize (H12AffineFastState.compose env22089 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound22089 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22090 : List Nat := [2,4,8,16,32,16,8,4,1,20,2048,1,9,1,32,51,1,2049,20,33,1,1,16,18,9,17,2049,0,0,2048,21,1,4,48,1,1]

theorem envBound22090 : H12AffineFastState.Bounded env22090 := by
  intro p hp
  have h : env22090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22089_22090 : H12AffineEnvironment.transform 15 51 env22089 = env22090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env22089 == env22090) = true)

theorem identity22090 : scanCanonicalize (H12AffineFastState.compose env22090 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound22090 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22091 : List Nat := [2,4,8,16,32,16,8,4,1,20,0,1,9,1,32,51,1,1,20,33,1,1,16,18,9,17,1,0,0,0,21,1,4,48,1,1]

theorem envBound22091 : H12AffineFastState.Bounded env22091 := by
  intro p hp
  have h : env22091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22090_22091 : H12AffineEnvironment.transform 10 0 env22090 = env22091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env22090 == env22091) = true)

def env22092 : List Nat := [2,4,8,16,0,16,8,4,1,20,0,1,9,1,0,19,1,1,20,1,1,1,16,18,9,17,1,0,0,0,21,1,4,16,1,1]

theorem envBound22092 : H12AffineFastState.Bounded env22092 := by
  intro p hp
  have h : env22092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22091_22092 : H12AffineEnvironment.transform 4 0 env22091 = env22092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22091 == env22092) = true)

theorem identity22092 : scanCanonicalize (H12AffineFastState.compose env22092 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22092 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22093 : List Nat := [2,4,8,1,0,1,8,4,1,5,0,1,9,1,0,2,1,1,5,1,1,1,1,3,9,0,1,0,0,0,4,1,4,1,1,1]

theorem envBound22093 : H12AffineFastState.Bounded env22093 := by
  intro p hp
  have h : env22093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22092_22093 : H12AffineEnvironment.transform 3 1 env22092 = env22093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22092 == env22093) = true)

def leafEnv22093 : List Nat := [2,4,8,1,0,1,8,4,1,5,0,1,9,1,0,2,1,1,5,1,1,1,1,3,5,9,1,0,1,0,0,0,4,1,4,1,5,3,1,1,0,1,1]

def active22093 : List Nat := [0,1,2]

def tree22093 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22093 : H12WitnessSearch.Good tree22093 := H12GlobalWitnessIndex.good

theorem leafIdentity22093 : H12AffineFastState.composeSystem env22093 rootObs = leafEnv22093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22093 rootObs == leafEnv22093) = true)

theorem terminalChecked22093 : H12PackedTerminal.terminalCheckFast leafEnv22093 active22093 tree22093 = true := by decide +kernel

def env22094 : List Nat := [2,4,8,16,1,16,8,4,1,20,0,1,9,1,1,18,1,1,20,0,1,1,16,18,9,17,1,0,0,0,21,1,4,17,1,1]

theorem envBound22094 : H12AffineFastState.Bounded env22094 := by
  intro p hp
  have h : env22094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22091_22094 : H12AffineEnvironment.transform 4 1 env22091 = env22094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22091 == env22094) = true)

def env22095 : List Nat := [2,4,8,16,32,16,9,5,0,21,2048,1,8,1,32,65536,1,2048,21,33,1,1,16,65568,9,17,2049,0,0,2049,21,0,5,65538,1,0]

theorem envBound22095 : H12AffineFastState.Bounded env22095 := by
  intro p hp
  have h : env22095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22088_22095 : H12AffineEnvironment.transform 6 9 env22088 = env22095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22088 == env22095) = true)

theorem identity22095 : scanCanonicalize (H12AffineFastState.compose env22095 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22095 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22096 : List Nat := [2,4,8,0,32,0,9,5,0,5,2048,1,8,1,32,65536,1,2048,5,33,1,1,0,65568,9,1,2049,0,0,2049,5,0,5,65538,1,0]

theorem envBound22096 : H12AffineFastState.Bounded env22096 := by
  intro p hp
  have h : env22096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22095_22096 : H12AffineEnvironment.transform 3 0 env22095 = env22096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22095 == env22096) = true)

theorem identity22096 : scanCanonicalize (H12AffineFastState.compose env22096 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound22096 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22097 : List Nat := [2,4,8,0,32,0,9,5,0,5,2048,1,8,1,32,34,1,2048,5,33,1,1,0,2,9,1,2049,0,0,2049,5,0,5,32,1,0]

theorem envBound22097 : H12AffineFastState.Bounded env22097 := by
  intro p hp
  have h : env22097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22096_22097 : H12AffineEnvironment.transform 15 34 env22096 = env22097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env22096 == env22097) = true)

theorem identity22097 : scanCanonicalize (H12AffineFastState.compose env22097 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22097 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22098 : List Nat := [2,4,8,0,0,0,9,5,0,5,2048,1,8,1,0,2,1,2048,5,1,1,1,0,2,9,1,2049,0,0,2049,5,0,5,0,1,0]

theorem envBound22098 : H12AffineFastState.Bounded env22098 := by
  intro p hp
  have h : env22098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22097_22098 : H12AffineEnvironment.transform 4 0 env22097 = env22098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22097 == env22098) = true)

def leafEnv22098 : List Nat := [2,4,8,0,0,0,9,5,0,5,2048,1,8,1,0,2,1,2048,5,1,1,1,0,2,4,9,1,1,2049,0,0,2049,5,0,5,0,5,2,1,0,0,1,1]

def active22098 : List Nat := [0,1,2,10]

def tree22098 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22098 : H12WitnessSearch.Good tree22098 := H12GlobalWitnessIndex.good

theorem leafIdentity22098 : H12AffineFastState.composeSystem env22098 rootObs = leafEnv22098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22098 rootObs == leafEnv22098) = true)

theorem terminalChecked22098 : H12PackedTerminal.terminalCheckFast leafEnv22098 active22098 tree22098 = true := by decide +kernel

def env22099 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,0,129,0,428,65536,0,2309,273,429,0,1,16,65705,9,17,2049,1,1,2308,20,137,256,65675,0,137]

theorem envBound22099 : H12AffineFastState.Bounded env22099 := by
  intro p hp
  have h : env22099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22086_22099 : H12AffineEnvironment.transform 9 273 env22086 = env22099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env22086 == env22099) = true)

theorem identity22099 : scanCanonicalize (H12AffineFastState.compose env22099 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 430) := by decide +kernel

theorem selectedBound22099 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22100 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,0,129,0,428,430,0,2309,273,429,0,1,16,263,9,17,2049,1,1,2308,20,137,256,293,0,137]

theorem envBound22100 : H12AffineFastState.Bounded env22100 := by
  intro p hp
  have h : env22100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22099_22100 : H12AffineEnvironment.transform 15 430 env22099 = env22100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 430 env22099 == env22100) = true)

def env22101 : List Nat := [2,4,8,16,32,16,128,256,137,273,136,0,129,0,428,430,0,397,273,429,0,1,16,263,9,17,137,1,1,396,20,137,256,293,0,137]

theorem envBound22101 : H12AffineFastState.Bounded env22101 := by
  intro p hp
  have h : env22101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22100_22101 : H12AffineEnvironment.transform 10 136 env22100 = env22101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env22100 == env22101) = true)

theorem identity22101 : scanCanonicalize (H12AffineFastState.compose env22101 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound22101 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22102 : List Nat := [2,4,8,16,32,16,56,256,49,273,48,0,57,0,276,278,0,309,273,277,0,1,16,263,9,17,49,1,1,308,20,49,256,293,0,49]

theorem envBound22102 : H12AffineFastState.Bounded env22102 := by
  intro p hp
  have h : env22102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22101_22102 : H12AffineEnvironment.transform 6 56 env22101 = env22102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env22101 == env22102) = true)

def env22103 : List Nat := [2,4,8,0,32,0,40,256,33,257,32,0,41,0,260,262,0,293,257,261,0,1,0,263,9,1,33,1,1,292,4,33,256,293,0,33]

theorem envBound22103 : H12AffineFastState.Bounded env22103 := by
  intro p hp
  have h : env22103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22102_22103 : H12AffineEnvironment.transform 3 0 env22102 = env22103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22102 == env22103) = true)

theorem identity22103 : scanCanonicalize (H12AffineFastState.compose env22103 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound22103 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22104 : List Nat := [2,4,8,0,32,0,40,5,33,4,32,0,41,0,1,3,0,32,4,0,0,1,0,2,9,1,33,1,1,33,4,33,5,32,0,33]

theorem envBound22104 : H12AffineFastState.Bounded env22104 := by
  intro p hp
  have h : env22104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22103_22104 : H12AffineEnvironment.transform 7 5 env22103 = env22104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env22103 == env22104) = true)

theorem identity22104 : scanCanonicalize (H12AffineFastState.compose env22104 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22104 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22105 : List Nat := [2,4,8,0,1,0,9,5,0,4,1,0,8,0,1,3,0,1,4,0,0,1,0,2,9,1,0,1,1,0,4,0,5,1,0,0]

theorem envBound22105 : H12AffineFastState.Bounded env22105 := by
  intro p hp
  have h : env22105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22104_22105 : H12AffineEnvironment.transform 4 1 env22104 = env22105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22104 == env22105) = true)

def leafEnv22105 : List Nat := [2,4,8,0,1,0,9,5,0,4,1,0,8,0,1,3,0,1,4,0,0,1,0,2,5,9,1,1,0,1,1,0,4,0,5,1,5,3,0,0,0,0,1]

def active22105 : List Nat := [0,1,2]

def tree22105 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22105 : H12WitnessSearch.Good tree22105 := H12GlobalWitnessIndex.good

theorem leafIdentity22105 : H12AffineFastState.composeSystem env22105 rootObs = leafEnv22105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22105 rootObs == leafEnv22105) = true)

theorem terminalChecked22105 : H12PackedTerminal.terminalCheckFast leafEnv22105 active22105 tree22105 = true := by decide +kernel

def env22106 : List Nat := [2,4,8,1,32,1,41,256,32,256,33,0,40,0,261,263,0,292,256,260,0,1,1,263,9,0,32,1,1,293,5,32,256,293,0,32]

theorem envBound22106 : H12AffineFastState.Bounded env22106 := by
  intro p hp
  have h : env22106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22102_22106 : H12AffineEnvironment.transform 3 1 env22102 = env22106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22102 == env22106) = true)

theorem identity22106 : scanCanonicalize (H12AffineFastState.compose env22106 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22106 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22107 : List Nat := [2,4,8,1,1,1,8,256,1,256,0,0,9,0,261,263,0,261,256,260,0,1,1,263,9,0,1,1,1,260,5,1,256,260,0,1]

theorem envBound22107 : H12AffineFastState.Bounded env22107 := by
  intro p hp
  have h : env22107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22106_22107 : H12AffineEnvironment.transform 4 1 env22106 = env22107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22106 == env22107) = true)

theorem identity22107 : scanCanonicalize (H12AffineFastState.compose env22107 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22107 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22108 : List Nat := [2,4,8,1,1,1,8,4,1,4,0,0,9,0,1,3,0,1,4,0,0,1,1,3,9,0,1,1,1,0,5,1,4,0,0,1]

theorem envBound22108 : H12AffineFastState.Bounded env22108 := by
  intro p hp
  have h : env22108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22107_22108 : H12AffineEnvironment.transform 7 4 env22107 = env22108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22107 == env22108) = true)

def leafEnv22108 : List Nat := [2,4,8,1,1,1,8,4,1,4,0,0,9,0,1,3,0,1,4,0,0,1,1,3,4,9,1,0,1,1,1,0,5,1,4,0,5,2,0,1,0,0,1]

def active22108 : List Nat := [0,1,2]

def tree22108 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22108 : H12WitnessSearch.Good tree22108 := H12GlobalWitnessIndex.good

theorem leafIdentity22108 : H12AffineFastState.composeSystem env22108 rootObs = leafEnv22108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22108 rootObs == leafEnv22108) = true)

theorem terminalChecked22108 : H12PackedTerminal.terminalCheckFast leafEnv22108 active22108 tree22108 = true := by decide +kernel

def env22109 : List Nat := [2,4,8,16,32,16,128,256,137,273,137,0,129,0,428,430,0,396,273,429,0,1,16,263,9,17,136,1,1,397,20,137,256,293,0,137]

theorem envBound22109 : H12AffineFastState.Bounded env22109 := by
  intro p hp
  have h : env22109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22100_22109 : H12AffineEnvironment.transform 10 137 env22100 = env22109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env22100 == env22109) = true)

theorem identity22109 : scanCanonicalize (H12AffineFastState.compose env22109 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 189) := by decide +kernel

theorem selectedBound22109 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22110 : List Nat := [2,4,8,16,32,16,128,189,137,172,137,0,129,0,17,19,0,49,172,16,0,1,16,186,9,17,136,1,1,48,20,137,189,152,0,137]

theorem envBound22110 : H12AffineFastState.Bounded env22110 := by
  intro p hp
  have h : env22110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22109_22110 : H12AffineEnvironment.transform 7 189 env22109 = env22110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env22109 == env22110) = true)

def env22111 : List Nat := [2,4,8,16,16,16,128,141,137,156,137,0,129,0,17,19,0,1,156,16,0,1,16,138,9,17,136,1,1,0,20,137,141,152,0,137]

theorem envBound22111 : H12AffineFastState.Bounded env22111 := by
  intro p hp
  have h : env22111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22110_22111 : H12AffineEnvironment.transform 4 16 env22110 = env22111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env22110 == env22111) = true)

def env22112 : List Nat := [2,4,8,16,17,16,128,140,137,157,137,0,129,0,17,19,0,0,157,16,0,1,16,139,9,17,136,1,1,1,20,137,140,152,0,137]

theorem envBound22112 : H12AffineFastState.Bounded env22112 := by
  intro p hp
  have h : env22112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22110_22112 : H12AffineEnvironment.transform 4 17 env22110 = env22112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env22110 == env22112) = true)

theorem identity22112 : scanCanonicalize (H12AffineFastState.compose env22112 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound22112 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22113 : List Nat := [2,4,8,16,17,16,25,21,16,4,16,0,24,0,17,19,0,0,4,16,0,1,16,18,9,17,17,1,1,1,20,16,21,1,0,16]

theorem envBound22113 : H12AffineFastState.Bounded env22113 := by
  intro p hp
  have h : env22113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22112_22113 : H12AffineEnvironment.transform 6 25 env22112 = env22113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env22112 == env22113) = true)

theorem identity22113 : scanCanonicalize (H12AffineFastState.compose env22113 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22113 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22114 : List Nat := [2,4,8,0,1,0,9,5,0,4,0,0,8,0,1,3,0,0,4,0,0,1,0,2,9,1,1,1,1,1,4,0,5,1,0,0]

theorem envBound22114 : H12AffineFastState.Bounded env22114 := by
  intro p hp
  have h : env22114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22113_22114 : H12AffineEnvironment.transform 3 0 env22113 = env22114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22113 == env22114) = true)

def leafEnv22114 : List Nat := [2,4,8,0,1,0,9,5,0,4,0,0,8,0,1,3,0,0,4,0,0,1,0,2,5,9,1,1,1,1,1,1,4,0,5,1,5,3,0,0,0,0,1]

def active22114 : List Nat := [0,1,2]

def tree22114 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22114 : H12WitnessSearch.Good tree22114 := H12GlobalWitnessIndex.good

theorem leafIdentity22114 : H12AffineFastState.composeSystem env22114 rootObs = leafEnv22114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22114 rootObs == leafEnv22114) = true)

theorem terminalChecked22114 : H12PackedTerminal.terminalCheckFast leafEnv22114 active22114 tree22114 = true := by decide +kernel

def env22115 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,129,1297,32768,65536,1296,34985,1024,32769,1296,1,16,98565,9,16,35245,1296,1296,2308,1285,137,256,98599,1296,137]

theorem envBound22115 : H12AffineFastState.Bounded env22115 := by
  intro p hp
  have h : env22115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22084_22115 : H12AffineEnvironment.transform 5 17 env22084 = env22115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22084 == env22115) = true)

theorem identity22115 : scanCanonicalize (H12AffineFastState.compose env22115 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 294) := by decide +kernel

theorem selectedBound22115 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22116 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,129,1297,32768,294,1296,34985,1024,32769,1296,1,16,32803,9,16,35245,1296,1296,2308,1285,137,256,32769,1296,137]

theorem envBound22116 : H12AffineFastState.Bounded env22116 := by
  intro p hp
  have h : env22116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22115_22116 : H12AffineEnvironment.transform 15 294 env22115 = env22116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 294 env22115 == env22116) = true)

theorem identity22116 : scanCanonicalize (H12AffineFastState.compose env22116 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22116 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env22117 : List Nat := [2,4,8,16,32,17,128,4,137,1024,2048,1044,129,1045,32768,34,1044,34985,1024,32769,1044,1,16,32803,9,16,34985,1044,1044,2048,1025,137,4,32769,1044,137]

theorem envBound22117 : H12AffineFastState.Bounded env22117 := by
  intro p hp
  have h : env22117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22116_22117 : H12AffineEnvironment.transform 7 4 env22116 = env22117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22116 == env22117) = true)

theorem identity22117 : scanCanonicalize (H12AffineFastState.compose env22117 (packedSelected [0,6] rootPS)) = affineNative (2^(14+1) ^^^ 2080) := by decide +kernel

theorem selectedBound22117 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env22118 : List Nat := [2,4,8,16,32,17,128,4,137,1024,2048,1044,129,1045,2080,34,1044,137,1024,2081,1044,1,16,2051,9,16,137,1044,1044,2048,1025,137,4,2081,1044,137]

theorem envBound22118 : H12AffineFastState.Bounded env22118 := by
  intro p hp
  have h : env22118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22117_22118 : H12AffineEnvironment.transform 14 2080 env22117 = env22118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2080 env22117 == env22118) = true)

theorem identity22118 : scanCanonicalize (H12AffineFastState.compose env22118 (packedSelected [2,4] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound22118 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env22119 : List Nat := [2,4,8,16,32,17,128,4,137,1024,137,1044,129,1045,169,34,1044,137,1024,168,1044,1,16,138,9,16,137,1044,1044,137,1025,137,4,168,1044,137]

theorem envBound22119 : H12AffineFastState.Bounded env22119 := by
  intro p hp
  have h : env22119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22118_22119 : H12AffineEnvironment.transform 10 137 env22118 = env22119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env22118 == env22119) = true)

theorem identity22119 : scanCanonicalize (H12AffineFastState.compose env22119 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound22119 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22120 : List Nat := [2,4,8,16,32,17,128,4,137,20,137,0,129,1,169,34,0,137,20,168,0,1,16,138,9,16,137,0,0,137,21,137,4,168,0,137]

theorem envBound22120 : H12AffineFastState.Bounded env22120 := by
  intro p hp
  have h : env22120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22119_22120 : H12AffineEnvironment.transform 9 20 env22119 = env22120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env22119 == env22120) = true)

def env22121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,129,1297,32768,65536,1345,262144,1024,32769,1345,649,16,98564,9,65,263053,1296,1296,1073741824,1284,513,256,98598,1345,512]

theorem envBound22121 : H12AffineFastState.Bounded env22121 := by
  intro p hp
  have h : env22121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22080_22121 : H12AffineEnvironment.transform 21 649 env22080 = env22121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 649 env22080 == env22121) = true)

theorem identity22121 : scanCanonicalize (H12AffineFastState.compose env22121 (packedSelected [1,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 330502) := by decide +kernel

theorem selectedBound22121 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env22122 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,129,1297,32768,65536,1345,262144,1024,32769,1345,649,16,98564,9,65,263053,1296,1296,330502,1284,513,256,98598,1345,512]

theorem envBound22122 : H12AffineFastState.Bounded env22122 := by
  intro p hp
  have h : env22122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22121_22122 : H12AffineEnvironment.transform 29 330502 env22121 = env22122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 330502 env22121 == env22122) = true)

theorem identity22122 : scanCanonicalize (H12AffineFastState.compose env22122 (packedSelected [3,15,17] rootPS)) = affineNative (2^(17+1) ^^^ 100647) := by decide +kernel

theorem selectedBound22122 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env22123 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,129,1297,32768,65536,1345,100647,1024,32769,1345,649,16,98564,9,65,101034,1296,1296,33313,1284,513,256,98598,1345,512]

theorem envBound22123 : H12AffineFastState.Bounded env22123 := by
  intro p hp
  have h : env22123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22122_22123 : H12AffineEnvironment.transform 17 100647 env22122 = env22123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100647 env22122 == env22123) = true)

theorem identity22123 : scanCanonicalize (H12AffineFastState.compose env22123 (packedSelected [1,8,28] rootPS)) = affineNative (2^(14+1) ^^^ 908) := by decide +kernel

theorem selectedBound22123 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env22124 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,129,1297,908,65536,1345,68267,1024,909,1345,649,16,66184,9,65,67878,1296,1296,429,1284,513,256,66218,1345,512]

theorem envBound22124 : H12AffineFastState.Bounded env22124 := by
  intro p hp
  have h : env22124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22123_22124 : H12AffineEnvironment.transform 14 908 env22123 = env22124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 908 env22123 == env22124) = true)

theorem identity22124 : scanCanonicalize (H12AffineFastState.compose env22124 (packedSelected [7] rootPS)) = affineNative (2^(10+1) ^^^ 1808) := by decide +kernel

theorem selectedBound22124 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env22125 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1808,1345,129,1297,908,65536,1345,67003,1024,909,1345,649,16,66184,9,65,67126,1296,1296,429,1284,513,256,66218,1345,512]

theorem envBound22125 : H12AffineFastState.Bounded env22125 := by
  intro p hp
  have h : env22125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22124_22125 : H12AffineEnvironment.transform 10 1808 env22124 = env22125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1808 env22124 == env22125) = true)

theorem identity22125 : scanCanonicalize (H12AffineFastState.compose env22125 (packedSelected [8,12,38] rootPS)) = affineNative (2^(8+1) ^^^ 397) := by decide +kernel

theorem selectedBound22125 : packedSelected [8,12,38] rootPS < 2^1333 := by decide +kernel

def env22126 : List Nat := [2,4,8,16,32,64,128,256,397,1024,1181,1345,129,1297,1,65536,1345,67003,1024,0,1345,260,16,65797,9,65,67003,1296,1296,429,1284,396,256,65831,1345,397]

theorem envBound22126 : H12AffineFastState.Bounded env22126 := by
  intro p hp
  have h : env22126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22125_22126 : H12AffineEnvironment.transform 8 397 env22125 = env22126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 397 env22125 == env22126) = true)

theorem identity22126 : scanCanonicalize (H12AffineFastState.compose env22126 (packedSelected [1,3,8] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound22126 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env22127 : List Nat := [2,4,8,16,32,64,128,256,397,305,428,112,129,32,1,65536,112,65674,305,0,112,260,16,65797,9,65,65674,33,33,429,53,396,256,65831,112,397]

theorem envBound22127 : H12AffineFastState.Bounded env22127 := by
  intro p hp
  have h : env22127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22126_22127 : H12AffineEnvironment.transform 9 305 env22126 = env22127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env22126 == env22127) = true)

theorem identity22127 : scanCanonicalize (H12AffineFastState.compose env22127 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound22127 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22128 : List Nat := [2,4,8,16,32,64,128,256,397,305,428,112,129,32,1,35,112,169,305,0,112,260,16,294,9,65,169,33,33,429,53,396,256,260,112,397]

theorem envBound22128 : H12AffineFastState.Bounded env22128 := by
  intro p hp
  have h : env22128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22127_22128 : H12AffineEnvironment.transform 15 35 env22127 = env22128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env22127 == env22128) = true)

theorem identity22128 : scanCanonicalize (H12AffineFastState.compose env22128 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound22128 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22129 : List Nat := [2,4,8,16,32,48,128,256,397,305,428,0,129,32,1,35,0,169,305,0,0,260,16,294,9,49,169,33,33,429,53,396,256,260,0,397]

theorem envBound22129 : H12AffineFastState.Bounded env22129 := by
  intro p hp
  have h : env22129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22128_22129 : H12AffineEnvironment.transform 5 48 env22128 = env22129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env22128 == env22129) = true)

theorem identity22129 : scanCanonicalize (H12AffineFastState.compose env22129 (packedSelected [1,2] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound22129 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env22130 : List Nat := [2,4,8,16,32,48,128,157,16,172,49,0,129,32,1,35,0,169,172,0,0,153,16,187,9,49,169,33,33,48,53,17,157,153,0,16]

theorem envBound22130 : H12AffineFastState.Bounded env22130 := by
  intro p hp
  have h : env22130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22129_22130 : H12AffineEnvironment.transform 7 157 env22129 = env22130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env22129 == env22130) = true)

theorem identity22130 : scanCanonicalize (H12AffineFastState.compose env22130 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22130 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env22131 : List Nat := [2,4,8,16,0,16,128,157,16,140,17,0,129,0,1,3,0,137,140,0,0,153,16,155,9,17,137,1,1,16,21,17,157,153,0,16]

theorem envBound22131 : H12AffineFastState.Bounded env22131 := by
  intro p hp
  have h : env22131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22130_22131 : H12AffineEnvironment.transform 4 0 env22130 = env22131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22130 == env22131) = true)

theorem identity22131 : scanCanonicalize (H12AffineFastState.compose env22131 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound22131 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22132 : List Nat := [2,4,8,16,0,16,24,5,16,20,17,0,25,0,1,3,0,17,20,0,0,1,16,3,9,17,17,1,1,16,21,17,5,1,0,16]

theorem envBound22132 : H12AffineFastState.Bounded env22132 := by
  intro p hp
  have h : env22132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22131_22132 : H12AffineEnvironment.transform 6 24 env22131 = env22132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env22131 == env22132) = true)

theorem identity22132 : scanCanonicalize (H12AffineFastState.compose env22132 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22132 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22133 : List Nat := [2,4,8,0,0,0,8,5,0,4,1,0,9,0,1,3,0,1,4,0,0,1,0,3,9,1,1,1,1,0,5,1,5,1,0,0]

theorem envBound22133 : H12AffineFastState.Bounded env22133 := by
  intro p hp
  have h : env22133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22132_22133 : H12AffineEnvironment.transform 3 0 env22132 = env22133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22132 == env22133) = true)

def env22134 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32769,4096,4194304,135184,16777216,8328,135233,21331969,4177,131153,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound22134 : H12AffineFastState.Bounded env22134 := by
  intro p hp
  have h : env22134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21975_22134 : H12AffineEnvironment.transform 26 21331969 env21975 = env22134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331969 env21975 == env22134) = true)

def env22135 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32769,4096,4194304,135185,16777216,8328,135233,134217728,4176,131152,1073741824,16876545,4294967296,257,4315938986,155551041,512]

theorem envBound22135 : H12AffineFastState.Bounded env22135 := by
  intro p hp
  have h : env22135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21974_22135 : H12AffineEnvironment.transform 18 1025 env21974 = env22135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env21974 == env22135) = true)

def env22136 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32769,4096,4194304,135185,16777216,8328,135233,21331968,4176,131152,1073741824,16876545,4294967296,257,4315938986,1345,512]

theorem envBound22136 : H12AffineFastState.Bounded env22136 := by
  intro p hp
  have h : env22136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22135_22136 : H12AffineEnvironment.transform 26 21331968 env22135 = env22136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331968 env22135 == env22136) = true)

theorem identity22136 : scanCanonicalize (H12AffineFastState.compose env22136 (packedSelected [7,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound22136 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env22137 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32769,4096,4194304,135185,98565,8328,135233,4456709,4176,131152,1073741824,1284,4294967296,257,4299260335,1345,512]

theorem envBound22137 : H12AffineFastState.Bounded env22137 := by
  intro p hp
  have h : env22137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22136_22137 : H12AffineEnvironment.transform 23 98565 env22136 = env22137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env22136 == env22137) = true)

theorem identity22137 : scanCanonicalize (H12AffineFastState.compose env22137 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound22137 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env22138 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,4096,262144,1025,32769,4096,4194304,17,98565,8328,65,4456709,4176,4176,1073741824,1284,4294967296,257,4299260335,1345,512]

theorem envBound22138 : H12AffineFastState.Bounded env22138 := by
  intro p hp
  have h : env22138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22137_22138 : H12AffineEnvironment.transform 16 4096 env22137 = env22138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env22137 == env22138) = true)

theorem identity22138 : scanCanonicalize (H12AffineFastState.compose env22138 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 4194440) := by decide +kernel

theorem selectedBound22138 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env22139 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,4096,262144,1025,32769,4096,4194304,17,98565,8328,65,4456709,4176,4176,1073741824,1284,4194440,257,98599,1345,512]

theorem envBound22139 : H12AffineFastState.Bounded env22139 := by
  intro p hp
  have h : env22139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22138_22139 : H12AffineEnvironment.transform 31 4194440 env22138 = env22139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4194440 env22138 == env22139) = true)

theorem identity22139 : scanCanonicalize (H12AffineFastState.compose env22139 (packedSelected [13,17,24,28,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 363439) := by decide +kernel

theorem selectedBound22139 : packedSelected [13,17,24,28,38,41] rootPS < 2^1333 := by decide +kernel

def env22140 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,4096,262144,1025,32769,4096,363439,17,98565,8328,65,101034,4176,4176,1073741824,1284,363303,257,98599,1345,512]

theorem envBound22140 : H12AffineFastState.Bounded env22140 := by
  intro p hp
  have h : env22140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22139_22140 : H12AffineEnvironment.transform 21 363439 env22139 = env22140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 363439 env22139 == env22140) = true)

def env22141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1344,262144,1025,32769,1344,363439,17,98565,8328,65,101034,1296,1296,1073741824,1284,363303,257,98599,1345,512]

theorem envBound22141 : H12AffineFastState.Bounded env22141 := by
  intro p hp
  have h : env22141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22140_22141 : H12AffineEnvironment.transform 11 1344 env22140 = env22141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env22140 == env22141) = true)

theorem identity22141 : scanCanonicalize (H12AffineFastState.compose env22141 (packedSelected [1,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound22141 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env22142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,268,1296,32768,65536,1344,262144,1025,32769,1344,363439,17,98565,388,65,101034,1296,1296,1073741824,1284,363303,257,98599,1345,512]

theorem envBound22142 : H12AffineFastState.Bounded env22142 := by
  intro p hp
  have h : env22142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22141_22142 : H12AffineEnvironment.transform 12 268 env22141 = env22142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env22141 == env22142) = true)

theorem identity22142 : scanCanonicalize (H12AffineFastState.compose env22142 (packedSelected [3,15,17] rootPS)) = affineNative (2^(29+1) ^^^ 68494) := by decide +kernel

theorem selectedBound22142 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env22143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,268,1296,32768,65536,1344,262144,1025,32769,1344,363439,17,98565,388,65,101034,1296,1296,68494,1284,363303,257,98599,1345,512]

theorem envBound22143 : H12AffineFastState.Bounded env22143 := by
  intro p hp
  have h : env22143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22142_22143 : H12AffineEnvironment.transform 29 68494 env22142 = env22143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 68494 env22142 == env22143) = true)

theorem identity22143 : scanCanonicalize (H12AffineFastState.compose env22143 (packedSelected [5,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 35244) := by decide +kernel

theorem selectedBound22143 : packedSelected [5,12,15] rootPS < 2^1333 := by decide +kernel

def env22144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,268,1296,32768,65536,1344,35244,1025,32769,1344,66051,17,98565,388,65,101034,1296,1296,68494,1284,66187,257,98599,1345,512]

theorem envBound22144 : H12AffineFastState.Bounded env22144 := by
  intro p hp
  have h : env22144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22143_22144 : H12AffineEnvironment.transform 17 35244 env22143 = env22144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35244 env22143 == env22144) = true)

theorem identity22144 : scanCanonicalize (H12AffineFastState.compose env22144 (packedSelected [18,23] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22144 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env22145 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1344,268,1296,32768,65536,1344,35109,1025,32769,1344,66051,17,98565,269,65,100899,1296,1296,68359,1284,66050,257,98599,1345,512]

theorem envBound22145 : H12AffineFastState.Bounded env22145 := by
  intro p hp
  have h : env22145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22144_22145 : H12AffineEnvironment.transform 6 9 env22144 = env22145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22144 == env22145) = true)

theorem identity22145 : scanCanonicalize (H12AffineFastState.compose env22145 (packedSelected [5,8] rootPS)) = affineNative (2^(15+1) ^^^ 35159) := by decide +kernel

theorem selectedBound22145 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env22146 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1344,268,1296,32768,35159,1344,35109,1025,32769,1344,35668,17,2130,269,65,884,1296,1296,33360,1284,35669,257,2160,1345,512]

theorem envBound22146 : H12AffineFastState.Bounded env22146 := by
  intro p hp
  have h : env22146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22145_22146 : H12AffineEnvironment.transform 15 35159 env22145 = env22146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35159 env22145 == env22146) = true)

theorem identity22146 : scanCanonicalize (H12AffineFastState.compose env22146 (packedSelected [0,2,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 581) := by decide +kernel

theorem selectedBound22146 : packedSelected [0,2,5,6] rootPS < 2^1333 := by decide +kernel

def env22147 : List Nat := [2,4,8,16,32,64,9,256,512,581,2048,773,268,853,32768,35159,773,35109,580,32769,773,35668,17,2130,269,65,884,853,853,33360,833,35669,257,2160,772,512]

theorem envBound22147 : H12AffineFastState.Bounded env22147 := by
  intro p hp
  have h : env22147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22146_22147 : H12AffineEnvironment.transform 9 581 env22146 = env22147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 581 env22146 == env22147) = true)

theorem identity22147 : scanCanonicalize (H12AffineFastState.compose env22147 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 804) := by decide +kernel

theorem selectedBound22147 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env22148 : List Nat := [2,4,8,16,32,64,9,256,512,581,804,773,268,853,32768,33395,773,33281,580,32769,773,32880,17,886,269,65,884,853,853,33360,833,32881,257,852,772,512]

theorem envBound22148 : H12AffineFastState.Bounded env22148 := by
  intro p hp
  have h : env22148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22147_22148 : H12AffineEnvironment.transform 10 804 env22147 = env22148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 804 env22147 == env22148) = true)

theorem identity22148 : scanCanonicalize (H12AffineFastState.compose env22148 (packedSelected [0,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound22148 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env22149 : List Nat := [2,4,8,16,32,64,9,256,292,353,0,33,268,113,32768,33111,33,33061,352,32769,33,32880,17,82,269,65,80,113,113,33140,101,32881,257,112,32,292]

theorem envBound22149 : H12AffineFastState.Bounded env22149 := by
  intro p hp
  have h : env22149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22148_22149 : H12AffineEnvironment.transform 8 292 env22148 = env22149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env22148 == env22149) = true)

theorem identity22149 : scanCanonicalize (H12AffineFastState.compose env22149 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22149 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22150 : List Nat := [2,4,8,16,0,64,9,256,260,321,0,1,268,81,32768,33111,1,33029,320,32769,1,32848,17,82,269,65,80,81,81,33108,69,32849,257,80,0,260]

theorem envBound22150 : H12AffineFastState.Bounded env22150 := by
  intro p hp
  have h : env22150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22149_22150 : H12AffineEnvironment.transform 4 0 env22149 = env22150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22149 == env22150) = true)

def env22151 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1345,262144,1025,32769,1345,363439,17,98565,8328,65,101034,1297,1297,1073741824,1284,363303,257,98599,1345,512]

theorem envBound22151 : H12AffineFastState.Bounded env22151 := by
  intro p hp
  have h : env22151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22140_22151 : H12AffineEnvironment.transform 11 1345 env22140 = env22151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env22140 == env22151) = true)

theorem identity22151 : scanCanonicalize (H12AffineFastState.compose env22151 (packedSelected [1,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 295853) := by decide +kernel

theorem selectedBound22151 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env22152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1345,262144,1025,32769,1345,363439,17,98565,8328,65,101034,1297,1297,295853,1284,363303,257,98599,1345,512]

theorem envBound22152 : H12AffineFastState.Bounded env22152 := by
  intro p hp
  have h : env22152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22151_22152 : H12AffineEnvironment.transform 29 295853 env22151 = env22152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 295853 env22151 == env22152) = true)

theorem identity22152 : scanCanonicalize (H12AffineFastState.compose env22152 (packedSelected [3,15,17] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound22152 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env22153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1345,43048,1025,32769,1345,74631,17,98565,8328,65,101034,1297,1297,11141,1284,74511,257,98599,1345,512]

theorem envBound22153 : H12AffineFastState.Bounded env22153 := by
  intro p hp
  have h : env22153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22152_22153 : H12AffineEnvironment.transform 17 43048 env22152 = env22153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env22152 == env22153) = true)

theorem identity22153 : scanCanonicalize (H12AffineFastState.compose env22153 (packedSelected [8,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound22153 : packedSelected [8,12,15] rootPS < 2^1333 := by decide +kernel

def env22154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,1,65536,1345,10281,1025,0,1345,74631,17,65796,8328,65,68267,1297,1297,11141,1284,74511,257,65830,1345,512]

theorem envBound22154 : H12AffineFastState.Bounded env22154 := by
  intro p hp
  have h : env22154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22153_22154 : H12AffineEnvironment.transform 14 1 env22153 = env22154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env22153 == env22154) = true)

theorem identity22154 : scanCanonicalize (H12AffineFastState.compose env22154 (packedSelected [3,5,24] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound22154 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env22155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,1,399,1345,10281,1025,0,1345,8712,17,139,8328,65,2852,1297,1297,11141,1284,8832,257,169,1345,512]

theorem envBound22155 : H12AffineFastState.Bounded env22155 := by
  intro p hp
  have h : env22155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22154_22155 : H12AffineEnvironment.transform 15 399 env22154 = env22155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env22154 == env22155) = true)

def env22156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32769,4096,4194304,135185,16777216,8328,135233,21331969,4176,131152,1073741824,16876545,4294967296,257,4315938986,1344,512]

theorem envBound22156 : H12AffineFastState.Bounded env22156 := by
  intro p hp
  have h : env22156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22135_22156 : H12AffineEnvironment.transform 26 21331969 env22135 = env22156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331969 env22135 == env22156) = true)

theorem identity22156 : scanCanonicalize (H12AffineFastState.compose env22156 (packedSelected [7,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 230469) := by decide +kernel

theorem selectedBound22156 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env22157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32769,4096,4194304,135185,230469,8328,135233,4588612,4176,131152,1073741824,131140,4294967296,257,4299392239,1344,512]

theorem envBound22157 : H12AffineFastState.Bounded env22157 := by
  intro p hp
  have h : env22157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22156_22157 : H12AffineEnvironment.transform 23 230469 env22156 = env22157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230469 env22156 == env22157) = true)

def env22158 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,131072,262144,1025,32769,4096,4194304,135185,230421,8328,135185,4588564,4096,131072,1073741824,131092,4294967296,257,4299392191,1296,512]

theorem envBound22158 : H12AffineFastState.Bounded env22158 := by
  intro p hp
  have h : env22158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22157_22158 : H12AffineEnvironment.transform 5 16 env22157 = env22158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22157 == env22158) = true)

theorem identity22158 : scanCanonicalize (H12AffineFastState.compose env22158 (packedSelected [3,5,8,13,15,21,28,38] rootPS)) = affineNative (2^(16+1) ^^^ 1296) := by decide +kernel

theorem selectedBound22158 : packedSelected [3,5,8,13,15,21,28,38] rootPS < 2^1333 := by decide +kernel

def env22159 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,262144,1025,32769,4096,4194304,5377,98565,8328,5377,4456708,4096,1296,1073741824,1284,4294967296,257,4299260335,1296,512]

theorem envBound22159 : H12AffineFastState.Bounded env22159 := by
  intro p hp
  have h : env22159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22158_22159 : H12AffineEnvironment.transform 16 1296 env22158 = env22159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1296 env22158 == env22159) = true)

theorem identity22159 : scanCanonicalize (H12AffineFastState.compose env22159 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(29+1) ^^^ 4196612) := by decide +kernel

theorem selectedBound22159 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env22160 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,262144,1025,32769,4096,4194304,5377,98565,8328,5377,4456708,4096,1296,4196612,1284,4294967296,257,4299260335,1296,512]

theorem envBound22160 : H12AffineFastState.Bounded env22160 := by
  intro p hp
  have h : env22160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22159_22160 : H12AffineEnvironment.transform 29 4196612 env22159 = env22160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4196612 env22159 == env22160) = true)

theorem identity22160 : scanCanonicalize (H12AffineFastState.compose env22160 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound22160 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env22161 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,43049,1025,32769,4096,4194304,5377,98565,8328,5377,4237613,4096,1296,4196612,1284,4294967296,257,4299260335,1296,512]

theorem envBound22161 : H12AffineFastState.Bounded env22161 := by
  intro p hp
  have h : env22161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22160_22161 : H12AffineEnvironment.transform 17 43049 env22160 = env22161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env22160 == env22161) = true)

def env22162 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,43049,1025,32769,1296,4194304,17,98565,8328,17,4237613,1296,1296,4196612,1284,4294967296,257,4299260335,1296,512]

theorem envBound22162 : H12AffineFastState.Bounded env22162 := by
  intro p hp
  have h : env22162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22161_22162 : H12AffineEnvironment.transform 11 1296 env22161 = env22162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env22161 == env22162) = true)

theorem identity22162 : scanCanonicalize (H12AffineFastState.compose env22162 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 908) := by decide +kernel

theorem selectedBound22162 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env22163 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,43049,1025,32769,1296,908,17,98565,8328,17,43681,1296,1296,2696,1284,4294967296,257,4295066147,1296,512]

theorem envBound22163 : H12AffineFastState.Bounded env22163 := by
  intro p hp
  have h : env22163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22162_22163 : H12AffineEnvironment.transform 21 908 env22162 = env22163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 908 env22162 == env22163) = true)

theorem identity22163 : scanCanonicalize (H12AffineFastState.compose env22163 (packedSelected [12] rootPS)) = affineNative (2^(14+1) ^^^ 8864) := by decide +kernel

theorem selectedBound22163 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env22164 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,8864,65536,1296,2697,1025,8865,1296,908,17,74661,8328,17,2049,1296,1296,2696,1284,4294967296,257,4295041155,1296,512]

theorem envBound22164 : H12AffineFastState.Bounded env22164 := by
  intro p hp
  have h : env22164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22163_22164 : H12AffineEnvironment.transform 14 8864 env22163 = env22164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8864 env22163 == env22164) = true)

def env22165 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,8192,0,8864,65536,0,2697,273,8865,0,908,17,74661,8328,17,2049,0,0,2696,20,4294967296,257,4295041155,0,512]

theorem envBound22165 : H12AffineFastState.Bounded env22165 := by
  intro p hp
  have h : env22165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22164_22165 : H12AffineEnvironment.transform 9 272 env22164 = env22165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env22164 == env22165) = true)

theorem identity22165 : scanCanonicalize (H12AffineFastState.compose env22165 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 73770) := by decide +kernel

theorem selectedBound22165 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22166 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,8192,0,8864,65536,0,2697,273,8865,0,908,17,74661,8328,17,2049,0,0,2696,20,73770,257,169,0,512]

theorem envBound22166 : H12AffineFastState.Bounded env22166 := by
  intro p hp
  have h : env22166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22165_22166 : H12AffineEnvironment.transform 31 73770 env22165 = env22166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 73770 env22165 == env22166) = true)

def env22167 : List Nat := [2,4,8,16,32,16,128,256,168,272,2048,0,8192,0,8200,65536,0,2081,273,8201,0,292,17,73997,8328,17,2049,0,0,2080,20,73770,257,169,0,168]

theorem envBound22167 : H12AffineFastState.Bounded env22167 := by
  intro p hp
  have h : env22167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22166_22167 : H12AffineEnvironment.transform 8 168 env22166 = env22167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 168 env22166 == env22167) = true)

def env22168 : List Nat := [2,4,8,16,32,16,40,256,0,272,2048,0,8192,0,8200,65536,0,2081,273,8201,0,292,17,73997,8224,17,2049,0,0,2080,20,73770,257,1,0,0]

theorem envBound22168 : H12AffineFastState.Bounded env22168 := by
  intro p hp
  have h : env22168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22167_22168 : H12AffineEnvironment.transform 6 40 env22167 = env22168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env22167 == env22168) = true)

theorem identity22168 : scanCanonicalize (H12AffineFastState.compose env22168 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound22168 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22169 : List Nat := [2,4,8,16,32,16,40,256,0,272,2048,0,8192,0,8200,8202,0,2081,273,8201,0,292,17,263,8224,17,2049,0,0,2080,20,32,257,1,0,0]

theorem envBound22169 : H12AffineFastState.Bounded env22169 := by
  intro p hp
  have h : env22169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22168_22169 : H12AffineEnvironment.transform 15 8202 env22168 = env22169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env22168 == env22169) = true)

def env22170 : List Nat := [2,4,8,16,0,16,8,256,0,272,2048,0,8192,0,8200,8202,0,2049,273,8201,0,260,17,263,8192,17,2049,0,0,2048,20,0,257,1,0,0]

theorem envBound22170 : H12AffineFastState.Bounded env22170 := by
  intro p hp
  have h : env22170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22169_22170 : H12AffineEnvironment.transform 4 0 env22169 = env22170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22169 == env22170) = true)

theorem identity22170 : scanCanonicalize (H12AffineFastState.compose env22170 (packedSelected [4] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound22170 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22171 : List Nat := [2,4,8,16,0,16,8,256,0,272,2048,0,2056,0,2048,2050,0,2049,273,2049,0,260,17,263,2056,17,2049,0,0,2048,20,0,257,1,0,0]

theorem envBound22171 : H12AffineFastState.Bounded env22171 := by
  intro p hp
  have h : env22171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22170_22171 : H12AffineEnvironment.transform 12 2056 env22170 = env22171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env22170 == env22171) = true)

def env22172 : List Nat := [2,4,8,16,0,16,8,256,0,272,0,0,8,0,0,2,0,1,273,1,0,260,17,263,8,17,1,0,0,0,20,0,257,1,0,0]

theorem envBound22172 : H12AffineFastState.Bounded env22172 := by
  intro p hp
  have h : env22172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22171_22172 : H12AffineEnvironment.transform 10 0 env22171 = env22172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env22171 == env22172) = true)

def leafEnv22172 : List Nat := [2,4,8,16,0,16,8,256,0,272,0,0,8,0,0,2,0,1,273,1,0,260,17,263,21,8,1,17,1,0,0,0,20,0,257,1,5,263,0,0,0,0,1]

def active22172 : List Nat := [0,1,2,3,7]

def tree22172 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22172 : H12WitnessSearch.Good tree22172 := H12GlobalWitnessIndex.good

theorem leafIdentity22172 : H12AffineFastState.composeSystem env22172 rootObs = leafEnv22172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22172 rootObs == leafEnv22172) = true)

theorem terminalChecked22172 : H12PackedTerminal.terminalCheckFast leafEnv22172 active22172 tree22172 = true := by decide +kernel

def env22173 : List Nat := [2,4,8,16,0,16,8,256,0,272,1,0,9,0,1,3,0,0,273,0,0,260,17,263,9,17,0,0,0,1,20,0,257,1,0,0]

theorem envBound22173 : H12AffineFastState.Bounded env22173 := by
  intro p hp
  have h : env22173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22171_22173 : H12AffineEnvironment.transform 10 1 env22171 = env22173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env22171 == env22173) = true)

theorem identity22173 : scanCanonicalize (H12AffineFastState.compose env22173 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22173 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22174 : List Nat := [2,4,8,16,0,16,8,4,0,20,1,0,9,0,1,3,0,0,21,0,0,0,17,3,9,17,0,0,0,1,20,0,5,1,0,0]

theorem envBound22174 : H12AffineFastState.Bounded env22174 := by
  intro p hp
  have h : env22174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22173_22174 : H12AffineEnvironment.transform 7 4 env22173 = env22174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22173 == env22174) = true)

def leafEnv22174 : List Nat := [2,4,8,16,0,16,8,4,0,20,1,0,9,0,1,3,0,0,21,0,0,0,17,3,21,9,1,17,0,0,0,1,20,0,5,1,5,2,0,0,0,0,1]

def active22174 : List Nat := [0,1,2,3]

def tree22174 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22174 : H12WitnessSearch.Good tree22174 := H12GlobalWitnessIndex.good

theorem leafIdentity22174 : H12AffineFastState.composeSystem env22174 rootObs = leafEnv22174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22174 rootObs == leafEnv22174) = true)

theorem terminalChecked22174 : H12PackedTerminal.terminalCheckFast leafEnv22174 active22174 tree22174 = true := by decide +kernel

def env22175 : List Nat := [2,4,8,16,1,16,9,256,0,272,2048,0,8192,0,8200,8202,0,2048,273,8201,0,261,17,263,8193,17,2049,0,0,2049,20,1,257,1,0,0]

theorem envBound22175 : H12AffineFastState.Bounded env22175 := by
  intro p hp
  have h : env22175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22169_22175 : H12AffineEnvironment.transform 4 1 env22169 = env22175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22169 == env22175) = true)

theorem identity22175 : scanCanonicalize (H12AffineFastState.compose env22175 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound22175 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22176 : List Nat := [2,4,8,16,1,16,9,5,0,21,2048,0,8192,0,8200,8202,0,2048,20,8201,0,0,17,2,8193,17,2049,0,0,2049,20,1,4,1,0,0]

theorem envBound22176 : H12AffineFastState.Bounded env22176 := by
  intro p hp
  have h : env22176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22175_22176 : H12AffineEnvironment.transform 7 5 env22175 = env22176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env22175 == env22176) = true)

def leafEnv22176 : List Nat := [2,4,8,16,1,16,9,5,0,21,2048,0,8192,0,8200,8202,0,2048,20,8201,0,0,17,2,21,8193,1,17,2049,0,0,2049,20,1,4,1,5,8202,0,0,0,0,1]

def active22176 : List Nat := [0,1,2,3,10,12]

def tree22176 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22176 : H12WitnessSearch.Good tree22176 := H12GlobalWitnessIndex.good

theorem leafIdentity22176 : H12AffineFastState.composeSystem env22176 rootObs = leafEnv22176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22176 rootObs == leafEnv22176) = true)

theorem terminalChecked22176 : H12PackedTerminal.terminalCheckFast leafEnv22176 active22176 tree22176 = true := by decide +kernel

def env22177 : List Nat := [2,4,8,16,32,16,41,256,1,272,2048,0,8192,0,8200,65536,0,2081,273,8201,0,292,17,73997,8225,17,2049,0,0,2080,20,73770,257,0,0,1]

theorem envBound22177 : H12AffineFastState.Bounded env22177 := by
  intro p hp
  have h : env22177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22167_22177 : H12AffineEnvironment.transform 6 41 env22167 = env22177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env22167 == env22177) = true)

theorem identity22177 : scanCanonicalize (H12AffineFastState.compose env22177 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 8462) := by decide +kernel

theorem selectedBound22177 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22178 : List Nat := [2,4,8,16,32,16,41,256,1,272,2048,0,8192,0,8200,8462,0,2081,273,8201,0,292,17,3,8225,17,2049,0,0,2080,20,292,257,0,0,1]

theorem envBound22178 : H12AffineFastState.Bounded env22178 := by
  intro p hp
  have h : env22178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22177_22178 : H12AffineEnvironment.transform 15 8462 env22177 = env22178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8462 env22177 == env22178) = true)

def env22179 : List Nat := [2,4,8,16,0,16,9,256,1,272,2048,0,8192,0,8200,8462,0,2049,273,8201,0,260,17,3,8193,17,2049,0,0,2048,20,260,257,0,0,1]

theorem envBound22179 : H12AffineFastState.Bounded env22179 := by
  intro p hp
  have h : env22179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22178_22179 : H12AffineEnvironment.transform 4 0 env22178 = env22179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22178 == env22179) = true)

theorem identity22179 : scanCanonicalize (H12AffineFastState.compose env22179 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound22179 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22180 : List Nat := [2,4,8,16,0,16,9,256,1,272,0,0,8192,0,8200,8462,0,1,273,8201,0,260,17,3,8193,17,1,0,0,0,20,260,257,0,0,1]

theorem envBound22180 : H12AffineFastState.Bounded env22180 := by
  intro p hp
  have h : env22180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22179_22180 : H12AffineEnvironment.transform 10 0 env22179 = env22180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env22179 == env22180) = true)

theorem identity22180 : scanCanonicalize (H12AffineFastState.compose env22180 (packedSelected [4] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound22180 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22181 : List Nat := [2,4,8,16,0,16,9,256,1,272,0,0,8,0,0,262,0,1,273,1,0,260,17,3,9,17,1,0,0,0,20,260,257,0,0,1]

theorem envBound22181 : H12AffineFastState.Bounded env22181 := by
  intro p hp
  have h : env22181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22180_22181 : H12AffineEnvironment.transform 12 8 env22180 = env22181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env22180 == env22181) = true)

def leafEnv22181 : List Nat := [2,4,8,16,0,16,9,256,1,272,0,0,8,0,0,262,0,1,273,1,0,260,17,3,21,9,1,17,1,0,0,0,20,260,257,0,5,263,0,1,0,0,1]

def active22181 : List Nat := [0,1,2,3,7]

def tree22181 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22181 : H12WitnessSearch.Good tree22181 := H12GlobalWitnessIndex.good

theorem leafIdentity22181 : H12AffineFastState.composeSystem env22181 rootObs = leafEnv22181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22181 rootObs == leafEnv22181) = true)

theorem terminalChecked22181 : H12PackedTerminal.terminalCheckFast leafEnv22181 active22181 tree22181 = true := by decide +kernel

def env22182 : List Nat := [2,4,8,16,1,16,8,256,1,272,2048,0,8192,0,8200,8462,0,2048,273,8201,0,261,17,3,8192,17,2049,0,0,2049,20,261,257,0,0,1]

theorem envBound22182 : H12AffineFastState.Bounded env22182 := by
  intro p hp
  have h : env22182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22178_22182 : H12AffineEnvironment.transform 4 1 env22178 = env22182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22178 == env22182) = true)

theorem identity22182 : scanCanonicalize (H12AffineFastState.compose env22182 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22182 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22183 : List Nat := [2,4,8,16,1,16,8,4,1,20,2048,0,8192,0,8200,8202,0,2048,21,8201,0,1,17,3,8192,17,2049,0,0,2049,20,1,5,0,0,1]

theorem envBound22183 : H12AffineFastState.Bounded env22183 := by
  intro p hp
  have h : env22183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22182_22183 : H12AffineEnvironment.transform 7 4 env22182 = env22183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22182 == env22183) = true)

def env22184 : List Nat := [2,4,8,16,32,16,128,256,169,272,2048,0,8192,0,8201,65536,0,2080,273,8200,0,293,17,73996,8328,17,2049,0,0,2081,20,73770,257,169,0,169]

theorem envBound22184 : H12AffineFastState.Bounded env22184 := by
  intro p hp
  have h : env22184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22166_22184 : H12AffineEnvironment.transform 8 169 env22166 = env22184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env22166 == env22184) = true)

def env22185 : List Nat := [2,4,8,16,32,16,40,256,1,272,2048,0,8192,0,8201,65536,0,2080,273,8200,0,293,17,73996,8224,17,2049,0,0,2081,20,73770,257,1,0,1]

theorem envBound22185 : H12AffineFastState.Bounded env22185 := by
  intro p hp
  have h : env22185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22184_22185 : H12AffineEnvironment.transform 6 40 env22184 = env22185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env22184 == env22185) = true)

theorem identity22185 : scanCanonicalize (H12AffineFastState.compose env22185 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22185 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22186 : List Nat := [2,4,8,16,1,16,9,256,1,272,2048,0,8192,0,8201,65536,0,2049,273,8200,0,260,17,73996,8193,17,2049,0,0,2048,20,73739,257,1,0,1]

theorem envBound22186 : H12AffineFastState.Bounded env22186 := by
  intro p hp
  have h : env22186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22185_22186 : H12AffineEnvironment.transform 4 1 env22185 = env22186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22185 == env22186) = true)

def env22187 : List Nat := [2,4,8,16,1,16,9,256,1,272,2048,0,8,0,1,65536,0,2049,273,0,0,260,17,65796,9,17,2049,0,0,2048,20,65539,257,1,0,1]

theorem envBound22187 : H12AffineFastState.Bounded env22187 := by
  intro p hp
  have h : env22187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22186_22187 : H12AffineEnvironment.transform 12 8 env22186 = env22187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env22186 == env22187) = true)

theorem identity22187 : scanCanonicalize (H12AffineFastState.compose env22187 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound22187 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22188 : List Nat := [2,4,8,16,1,16,9,256,1,272,1,0,8,0,1,65536,0,0,273,0,0,260,17,65796,9,17,0,0,0,1,20,65539,257,1,0,1]

theorem envBound22188 : H12AffineFastState.Bounded env22188 := by
  intro p hp
  have h : env22188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22187_22188 : H12AffineEnvironment.transform 10 1 env22187 = env22188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env22187 == env22188) = true)

def env22189 : List Nat := [2,4,8,16,1,16,9,4,1,20,1,0,8,0,1,65536,0,0,21,0,0,0,17,65536,9,17,0,0,0,1,20,65539,5,1,0,1]

theorem envBound22189 : H12AffineFastState.Bounded env22189 := by
  intro p hp
  have h : env22189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22188_22189 : H12AffineEnvironment.transform 7 4 env22188 = env22189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22188 == env22189) = true)

def env22190 : List Nat := [2,4,8,16,1,16,9,5,1,21,1,0,8,0,1,65536,0,0,20,0,0,1,17,65537,9,17,0,0,0,1,20,65539,4,1,0,1]

theorem envBound22190 : H12AffineFastState.Bounded env22190 := by
  intro p hp
  have h : env22190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22188_22190 : H12AffineEnvironment.transform 7 5 env22188 = env22190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env22188 == env22190) = true)

theorem identity22190 : scanCanonicalize (H12AffineFastState.compose env22190 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound22190 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22191 : List Nat := [2,4,8,16,1,16,9,5,1,21,1,0,8,0,1,3,0,0,20,0,0,1,17,2,9,17,0,0,0,1,20,0,4,1,0,1]

theorem envBound22191 : H12AffineFastState.Bounded env22191 := by
  intro p hp
  have h : env22191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22190_22191 : H12AffineEnvironment.transform 15 3 env22190 = env22191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env22190 == env22191) = true)

def leafEnv22191 : List Nat := [2,4,8,16,1,16,9,5,1,21,1,0,8,0,1,3,0,0,20,0,0,1,17,2,21,9,1,17,0,0,0,1,20,0,4,1,5,3,0,1,0,0,1]

def active22191 : List Nat := [0,1,2,3]

def tree22191 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22191 : H12WitnessSearch.Good tree22191 := H12GlobalWitnessIndex.good

theorem leafIdentity22191 : H12AffineFastState.composeSystem env22191 rootObs = leafEnv22191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22191 rootObs == leafEnv22191) = true)

theorem terminalChecked22191 : H12PackedTerminal.terminalCheckFast leafEnv22191 active22191 tree22191 = true := by decide +kernel

def env22192 : List Nat := [2,4,8,16,1,16,9,256,1,272,2048,0,9,0,0,65536,0,2049,273,1,0,260,17,65797,8,17,2049,0,0,2048,20,65538,257,1,0,1]

theorem envBound22192 : H12AffineFastState.Bounded env22192 := by
  intro p hp
  have h : env22192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22186_22192 : H12AffineEnvironment.transform 12 9 env22186 = env22192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env22186 == env22192) = true)

theorem identity22192 : scanCanonicalize (H12AffineFastState.compose env22192 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 2311) := by decide +kernel

theorem selectedBound22192 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22193 : List Nat := [2,4,8,16,1,16,9,256,1,272,2048,0,9,0,0,2311,0,2049,273,1,0,260,17,2050,8,17,2049,0,0,2048,20,2309,257,1,0,1]

theorem envBound22193 : H12AffineFastState.Bounded env22193 := by
  intro p hp
  have h : env22193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22192_22193 : H12AffineEnvironment.transform 15 2311 env22192 = env22193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2311 env22192 == env22193) = true)

def env22194 : List Nat := [2,4,8,16,1,16,9,256,1,272,0,0,9,0,0,263,0,1,273,1,0,260,17,2,8,17,1,0,0,0,20,261,257,1,0,1]

theorem envBound22194 : H12AffineFastState.Bounded env22194 := by
  intro p hp
  have h : env22194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22193_22194 : H12AffineEnvironment.transform 10 0 env22193 = env22194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env22193 == env22194) = true)

theorem identity22194 : scanCanonicalize (H12AffineFastState.compose env22194 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound22194 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22195 : List Nat := [2,4,8,16,1,16,9,5,1,21,0,0,9,0,0,2,0,1,20,1,0,1,17,2,8,17,1,0,0,0,20,0,4,1,0,1]

theorem envBound22195 : H12AffineFastState.Bounded env22195 := by
  intro p hp
  have h : env22195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22194_22195 : H12AffineEnvironment.transform 7 5 env22194 = env22195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env22194 == env22195) = true)

def leafEnv22195 : List Nat := [2,4,8,16,1,16,9,5,1,21,0,0,9,0,0,2,0,1,20,1,0,1,17,2,21,8,1,17,1,0,0,0,20,0,4,1,5,2,0,1,0,0,1]

def active22195 : List Nat := [0,1,2,3]

def tree22195 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22195 : H12WitnessSearch.Good tree22195 := H12GlobalWitnessIndex.good

theorem leafIdentity22195 : H12AffineFastState.composeSystem env22195 rootObs = leafEnv22195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22195 rootObs == leafEnv22195) = true)

theorem terminalChecked22195 : H12PackedTerminal.terminalCheckFast leafEnv22195 active22195 tree22195 = true := by decide +kernel

def env22196 : List Nat := [2,4,8,16,1,16,9,256,1,272,1,0,9,0,0,262,0,0,273,1,0,260,17,3,8,17,0,0,0,1,20,260,257,1,0,1]

theorem envBound22196 : H12AffineFastState.Bounded env22196 := by
  intro p hp
  have h : env22196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22193_22196 : H12AffineEnvironment.transform 10 1 env22193 = env22196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env22193 == env22196) = true)

def leafEnv22196 : List Nat := [2,4,8,16,1,16,9,256,1,272,1,0,9,0,0,262,0,0,273,1,0,260,17,3,21,8,1,17,0,0,0,1,20,260,257,1,5,263,0,1,0,0,1]

def active22196 : List Nat := [0,1,2,3,7]

def tree22196 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22196 : H12WitnessSearch.Good tree22196 := H12GlobalWitnessIndex.good

theorem leafIdentity22196 : H12AffineFastState.composeSystem env22196 rootObs = leafEnv22196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22196 rootObs == leafEnv22196) = true)

theorem terminalChecked22196 : H12PackedTerminal.terminalCheckFast leafEnv22196 active22196 tree22196 = true := by decide +kernel

def env22197 : List Nat := [2,4,8,16,32,16,41,256,0,272,2048,0,8192,0,8201,65536,0,2080,273,8200,0,293,17,73996,8225,17,2049,0,0,2081,20,73770,257,0,0,0]

theorem envBound22197 : H12AffineFastState.Bounded env22197 := by
  intro p hp
  have h : env22197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22184_22197 : H12AffineEnvironment.transform 6 41 env22184 = env22197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env22184 == env22197) = true)

theorem identity22197 : scanCanonicalize (H12AffineFastState.compose env22197 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound22197 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22198 : List Nat := [2,4,8,16,32,16,41,37,0,53,2048,0,8192,0,8201,65536,0,2080,52,8200,0,0,17,73769,8225,17,2049,0,0,2081,20,73770,36,0,0,0]

theorem envBound22198 : H12AffineFastState.Bounded env22198 := by
  intro p hp
  have h : env22198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22197_22198 : H12AffineEnvironment.transform 7 37 env22197 = env22198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env22197 == env22198) = true)

def env22199 : List Nat := [2,4,8,16,0,16,9,5,0,21,2048,0,8192,0,8201,65536,0,2048,20,8200,0,0,17,73737,8193,17,2049,0,0,2049,20,73738,4,0,0,0]

theorem envBound22199 : H12AffineFastState.Bounded env22199 := by
  intro p hp
  have h : env22199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22198_22199 : H12AffineEnvironment.transform 4 0 env22198 = env22199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22198 == env22199) = true)

theorem identity22199 : scanCanonicalize (H12AffineFastState.compose env22199 (packedSelected [0,6] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound22199 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env22200 : List Nat := [2,4,8,16,0,16,9,5,0,21,2048,0,8192,0,8201,8203,0,2048,20,8200,0,0,17,2,8193,17,2049,0,0,2049,20,1,4,0,0,0]

theorem envBound22200 : H12AffineFastState.Bounded env22200 := by
  intro p hp
  have h : env22200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22199_22200 : H12AffineEnvironment.transform 15 8203 env22199 = env22200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env22199 == env22200) = true)

def env22201 : List Nat := [2,4,8,16,1,16,8,4,0,20,2048,0,8192,0,8201,65536,0,2049,21,8200,0,0,17,73736,8192,17,2049,0,0,2048,20,73739,5,0,0,0]

theorem envBound22201 : H12AffineFastState.Bounded env22201 := by
  intro p hp
  have h : env22201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22198_22201 : H12AffineEnvironment.transform 4 1 env22198 = env22201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22198 == env22201) = true)

theorem identity22201 : scanCanonicalize (H12AffineFastState.compose env22201 (packedSelected [4] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound22201 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22202 : List Nat := [2,4,8,16,1,16,8,4,0,20,2048,0,2056,0,2049,65536,0,2049,21,2048,0,0,17,67584,2056,17,2049,0,0,2048,20,67587,5,0,0,0]

theorem envBound22202 : H12AffineFastState.Bounded env22202 := by
  intro p hp
  have h : env22202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22201_22202 : H12AffineEnvironment.transform 12 2056 env22201 = env22202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env22201 == env22202) = true)

def env22203 : List Nat := [2,4,8,16,1,16,8,4,0,20,0,0,8,0,1,65536,0,1,21,0,0,0,17,65536,8,17,1,0,0,0,20,65539,5,0,0,0]

theorem envBound22203 : H12AffineFastState.Bounded env22203 := by
  intro p hp
  have h : env22203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22202_22203 : H12AffineEnvironment.transform 10 0 env22202 = env22203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env22202 == env22203) = true)

def env22204 : List Nat := [2,4,8,16,1,16,8,4,0,20,1,0,9,0,0,65536,0,0,21,1,0,0,17,65537,9,17,0,0,0,1,20,65538,5,0,0,0]

theorem envBound22204 : H12AffineFastState.Bounded env22204 := by
  intro p hp
  have h : env22204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22202_22204 : H12AffineEnvironment.transform 10 1 env22202 = env22204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env22202 == env22204) = true)

theorem identity22204 : scanCanonicalize (H12AffineFastState.compose env22204 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound22204 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22205 : List Nat := [2,4,8,16,1,16,8,4,0,20,1,0,9,0,0,3,0,0,21,1,0,0,17,2,9,17,0,0,0,1,20,1,5,0,0,0]

theorem envBound22205 : H12AffineFastState.Bounded env22205 := by
  intro p hp
  have h : env22205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22204_22205 : H12AffineEnvironment.transform 15 3 env22204 = env22205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env22204 == env22205) = true)

def leafEnv22205 : List Nat := [2,4,8,16,1,16,8,4,0,20,1,0,9,0,0,3,0,0,21,1,0,0,17,2,21,9,1,17,0,0,0,1,20,1,5,0,5,3,0,0,0,0,1]

def active22205 : List Nat := [0,1,2,3]

def tree22205 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22205 : H12WitnessSearch.Good tree22205 := H12GlobalWitnessIndex.good

theorem leafIdentity22205 : H12AffineFastState.composeSystem env22205 rootObs = leafEnv22205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22205 rootObs == leafEnv22205) = true)

theorem terminalChecked22205 : H12PackedTerminal.terminalCheckFast leafEnv22205 active22205 tree22205 = true := by decide +kernel

def env22206 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,1,8864,65536,1,2697,272,8865,1,908,17,74661,8328,17,2049,1,1,2696,21,4294967296,257,4295041155,1,512]

theorem envBound22206 : H12AffineFastState.Bounded env22206 := by
  intro p hp
  have h : env22206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22164_22206 : H12AffineEnvironment.transform 9 273 env22164 = env22206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env22164 == env22206) = true)

theorem identity22206 : scanCanonicalize (H12AffineFastState.compose env22206 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 772) := by decide +kernel

theorem selectedBound22206 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22207 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,1,8864,65536,1,2697,272,8865,1,908,17,74661,8328,17,2049,1,1,2696,21,772,257,74631,1,512]

theorem envBound22207 : H12AffineFastState.Bounded env22207 := by
  intro p hp
  have h : env22207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22206_22207 : H12AffineEnvironment.transform 31 772 env22206 = env22207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 772 env22206 == env22207) = true)

def env22208 : List Nat := [2,4,8,16,32,16,128,4,512,21,2048,1,8192,1,8864,65536,1,2697,20,8865,1,648,17,74401,8328,17,2049,1,1,2696,21,512,5,74371,1,512]

theorem envBound22208 : H12AffineFastState.Bounded env22208 := by
  intro p hp
  have h : env22208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22207_22208 : H12AffineEnvironment.transform 7 4 env22207 = env22208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22207 == env22208) = true)

def env22209 : List Nat := [2,4,8,16,32,16,128,4,0,21,2048,1,8192,1,8352,65536,1,2185,20,8353,1,136,17,73889,8328,17,2049,1,1,2184,21,0,5,73859,1,0]

theorem envBound22209 : H12AffineFastState.Bounded env22209 := by
  intro p hp
  have h : env22209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22208_22209 : H12AffineEnvironment.transform 8 0 env22208 = env22209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env22208 == env22209) = true)

theorem identity22209 : scanCanonicalize (H12AffineFastState.compose env22209 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22209 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22210 : List Nat := [2,4,8,16,32,16,8,4,0,21,2048,1,8192,1,8232,65536,1,2049,20,8233,1,0,17,73769,8192,17,2049,1,1,2048,21,0,5,73739,1,0]

theorem envBound22210 : H12AffineFastState.Bounded env22210 := by
  intro p hp
  have h : env22210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22209_22210 : H12AffineEnvironment.transform 6 8 env22209 = env22210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22209 == env22210) = true)

theorem identity22210 : scanCanonicalize (H12AffineFastState.compose env22210 (packedSelected [4] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound22210 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22211 : List Nat := [2,4,8,16,32,16,8,4,0,21,2048,1,2056,1,2080,65536,1,2049,20,2081,1,0,17,67617,2056,17,2049,1,1,2048,21,0,5,67587,1,0]

theorem envBound22211 : H12AffineFastState.Bounded env22211 := by
  intro p hp
  have h : env22211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22210_22211 : H12AffineEnvironment.transform 12 2056 env22210 = env22211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env22210 == env22211) = true)

def env22212 : List Nat := [2,4,8,16,32,16,8,4,0,21,32,1,40,1,0,65536,1,33,20,1,1,0,17,65537,40,17,33,1,1,32,21,0,5,65571,1,0]

theorem envBound22212 : H12AffineFastState.Bounded env22212 := by
  intro p hp
  have h : env22212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22211_22212 : H12AffineEnvironment.transform 10 32 env22211 = env22212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env22211 == env22212) = true)

theorem identity22212 : scanCanonicalize (H12AffineFastState.compose env22212 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22212 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22213 : List Nat := [2,4,8,16,0,16,8,4,0,21,0,1,8,1,0,65536,1,1,20,1,1,0,17,65537,8,17,1,1,1,0,21,0,5,65539,1,0]

theorem envBound22213 : H12AffineFastState.Bounded env22213 := by
  intro p hp
  have h : env22213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22212_22213 : H12AffineEnvironment.transform 4 0 env22212 = env22213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22212 == env22213) = true)

def leafEnv22213 : List Nat := [2,4,8,16,0,16,8,4,0,21,0,1,8,1,0,65536,1,1,20,1,1,0,17,65537,20,8,1,17,1,1,1,0,21,0,5,65539,5,3,1,0,0,1,1]

def active22213 : List Nat := [0,1,2,3,15]

def tree22213 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22213 : H12WitnessSearch.Good tree22213 := H12GlobalWitnessIndex.good

theorem leafIdentity22213 : H12AffineFastState.composeSystem env22213 rootObs = leafEnv22213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22213 rootObs == leafEnv22213) = true)

theorem terminalChecked22213 : H12PackedTerminal.terminalCheckFast leafEnv22213 active22213 tree22213 = true := by decide +kernel

def env22214 : List Nat := [2,4,8,16,32,16,8,4,0,21,33,1,41,1,1,65536,1,32,20,0,1,0,17,65536,41,17,32,1,1,33,21,0,5,65570,1,0]

theorem envBound22214 : H12AffineFastState.Bounded env22214 := by
  intro p hp
  have h : env22214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22211_22214 : H12AffineEnvironment.transform 10 33 env22211 = env22214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env22211 == env22214) = true)

theorem identity22214 : scanCanonicalize (H12AffineFastState.compose env22214 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound22214 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22215 : List Nat := [2,4,8,16,32,16,8,4,0,21,33,1,41,1,1,35,1,32,20,0,1,0,17,35,41,17,32,1,1,33,21,0,5,1,1,0]

theorem envBound22215 : H12AffineFastState.Bounded env22215 := by
  intro p hp
  have h : env22215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22214_22215 : H12AffineEnvironment.transform 15 35 env22214 = env22215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env22214 == env22215) = true)

def leafEnv22215 : List Nat := [2,4,8,16,32,16,8,4,0,21,33,1,41,1,1,35,1,32,20,0,1,0,17,35,20,41,1,17,32,1,1,33,21,0,5,1,5,2,1,0,0,1,1]

def active22215 : List Nat := [0,1,2,3,4]

def tree22215 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22215 : H12WitnessSearch.Good tree22215 := H12GlobalWitnessIndex.good

theorem leafIdentity22215 : H12AffineFastState.composeSystem env22215 rootObs = leafEnv22215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22215 rootObs == leafEnv22215) = true)

theorem terminalChecked22215 : H12PackedTerminal.terminalCheckFast leafEnv22215 active22215 tree22215 = true := by decide +kernel

def env22216 : List Nat := [2,4,8,16,32,16,128,4,1,21,2048,1,8192,1,8353,65536,1,2184,20,8352,1,137,17,73888,8328,17,2049,1,1,2185,21,1,5,73858,1,1]

theorem envBound22216 : H12AffineFastState.Bounded env22216 := by
  intro p hp
  have h : env22216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22208_22216 : H12AffineEnvironment.transform 8 1 env22208 = env22216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env22208 == env22216) = true)

theorem identity22216 : scanCanonicalize (H12AffineFastState.compose env22216 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22216 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22217 : List Nat := [2,4,8,16,1,16,128,4,1,21,2048,1,8192,1,8320,65536,1,2184,20,8321,1,137,17,73857,8328,17,2049,1,1,2185,21,1,5,73858,1,1]

theorem envBound22217 : H12AffineFastState.Bounded env22217 := by
  intro p hp
  have h : env22217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22216_22217 : H12AffineEnvironment.transform 4 1 env22216 = env22217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22216 == env22217) = true)

def env22218 : List Nat := [2,4,8,16,1,16,8,4,1,21,2048,1,8192,1,8200,65536,1,2048,20,8201,1,1,17,73737,8192,17,2049,1,1,2049,21,1,5,73738,1,1]

theorem envBound22218 : H12AffineFastState.Bounded env22218 := by
  intro p hp
  have h : env22218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22217_22218 : H12AffineEnvironment.transform 6 8 env22217 = env22218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22217 == env22218) = true)

theorem identity22218 : scanCanonicalize (H12AffineFastState.compose env22218 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound22218 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22219 : List Nat := [2,4,8,16,1,16,8,4,1,21,2048,1,8192,1,8200,8203,1,2048,20,8201,1,1,17,2,8192,17,2049,1,1,2049,21,1,5,1,1,1]

theorem envBound22219 : H12AffineFastState.Bounded env22219 := by
  intro p hp
  have h : env22219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22218_22219 : H12AffineEnvironment.transform 15 8203 env22218 = env22219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env22218 == env22219) = true)

theorem identity22219 : scanCanonicalize (H12AffineFastState.compose env22219 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound22219 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22220 : List Nat := [2,4,8,16,1,16,8,4,1,21,2048,1,8,1,0,3,1,2048,20,1,1,1,17,2,8,17,2049,1,1,2049,21,1,5,1,1,1]

theorem envBound22220 : H12AffineFastState.Bounded env22220 := by
  intro p hp
  have h : env22220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22219_22220 : H12AffineEnvironment.transform 12 8 env22219 = env22220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env22219 == env22220) = true)

def env22221 : List Nat := [2,4,8,16,1,16,9,4,1,21,2048,1,8192,1,8201,65536,1,2049,20,8200,1,0,17,73736,8193,17,2049,1,1,2048,21,1,5,73739,1,1]

theorem envBound22221 : H12AffineFastState.Bounded env22221 := by
  intro p hp
  have h : env22221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22217_22221 : H12AffineEnvironment.transform 6 9 env22217 = env22221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22217 == env22221) = true)

theorem identity22221 : scanCanonicalize (H12AffineFastState.compose env22221 (packedSelected [4] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound22221 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22222 : List Nat := [2,4,8,16,1,16,9,4,1,21,2048,1,2056,1,2049,65536,1,2049,20,2048,1,0,17,67584,2057,17,2049,1,1,2048,21,1,5,67587,1,1]

theorem envBound22222 : H12AffineFastState.Bounded env22222 := by
  intro p hp
  have h : env22222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22221_22222 : H12AffineEnvironment.transform 12 2056 env22221 = env22222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env22221 == env22222) = true)

def env22223 : List Nat := [2,4,8,16,1,16,9,4,1,21,0,1,8,1,1,65536,1,1,20,0,1,0,17,65536,9,17,1,1,1,0,21,1,5,65539,1,1]

theorem envBound22223 : H12AffineFastState.Bounded env22223 := by
  intro p hp
  have h : env22223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22222_22223 : H12AffineEnvironment.transform 10 0 env22222 = env22223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env22222 == env22223) = true)

theorem identity22223 : scanCanonicalize (H12AffineFastState.compose env22223 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound22223 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22224 : List Nat := [2,4,8,16,1,16,9,4,1,21,0,1,8,1,1,3,1,1,20,0,1,0,17,3,9,17,1,1,1,0,21,1,5,0,1,1]

theorem envBound22224 : H12AffineFastState.Bounded env22224 := by
  intro p hp
  have h : env22224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22223_22224 : H12AffineEnvironment.transform 15 3 env22223 = env22224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env22223 == env22224) = true)

def leafEnv22224 : List Nat := [2,4,8,16,1,16,9,4,1,21,0,1,8,1,1,3,1,1,20,0,1,0,17,3,20,9,1,17,1,1,1,0,21,1,5,0,5,2,1,1,0,1,1]

def active22224 : List Nat := [0,1,2,3]

def tree22224 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22224 : H12WitnessSearch.Good tree22224 := H12GlobalWitnessIndex.good

theorem leafIdentity22224 : H12AffineFastState.composeSystem env22224 rootObs = leafEnv22224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22224 rootObs == leafEnv22224) = true)

theorem terminalChecked22224 : H12PackedTerminal.terminalCheckFast leafEnv22224 active22224 tree22224 = true := by decide +kernel

def env22225 : List Nat := [2,4,8,16,1,16,9,4,1,21,1,1,9,1,0,65536,1,0,20,1,1,0,17,65537,8,17,0,1,1,1,21,1,5,65538,1,1]

theorem envBound22225 : H12AffineFastState.Bounded env22225 := by
  intro p hp
  have h : env22225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22222_22225 : H12AffineEnvironment.transform 10 1 env22222 = env22225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env22222 == env22225) = true)

def env22226 : List Nat := [2,4,8,16,32,16,128,5,512,20,2048,1,8192,1,8864,65536,1,2697,21,8865,1,649,17,74400,8328,17,2049,1,1,2696,21,513,4,74370,1,512]

theorem envBound22226 : H12AffineFastState.Bounded env22226 := by
  intro p hp
  have h : env22226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22207_22226 : H12AffineEnvironment.transform 7 5 env22207 = env22226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env22207 == env22226) = true)

def env22227 : List Nat := [2,4,8,16,32,16,128,5,0,20,2048,1,8192,1,8352,65536,1,2185,21,8353,1,137,17,73888,8328,17,2049,1,1,2184,21,1,4,73858,1,0]

theorem envBound22227 : H12AffineFastState.Bounded env22227 := by
  intro p hp
  have h : env22227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22226_22227 : H12AffineEnvironment.transform 8 0 env22226 = env22227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env22226 == env22227) = true)

theorem identity22227 : scanCanonicalize (H12AffineFastState.compose env22227 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 8354) := by decide +kernel

theorem selectedBound22227 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22228 : List Nat := [2,4,8,16,32,16,128,5,0,20,2048,1,8192,1,8352,8354,1,2185,21,8353,1,137,17,2,8328,17,2049,1,1,2184,21,1,4,32,1,0]

theorem envBound22228 : H12AffineFastState.Bounded env22228 := by
  intro p hp
  have h : env22228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22227_22228 : H12AffineEnvironment.transform 15 8354 env22227 = env22228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8354 env22227 == env22228) = true)

def env22229 : List Nat := [2,4,8,16,32,16,128,5,0,20,32,1,8192,1,8352,8354,1,169,21,8353,1,137,17,2,8328,17,33,1,1,168,21,1,4,32,1,0]

theorem envBound22229 : H12AffineFastState.Bounded env22229 := by
  intro p hp
  have h : env22229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22228_22229 : H12AffineEnvironment.transform 10 32 env22228 = env22229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env22228 == env22229) = true)

theorem identity22229 : scanCanonicalize (H12AffineFastState.compose env22229 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22229 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22230 : List Nat := [2,4,8,16,1,16,128,5,0,20,1,1,8192,1,8321,8323,1,136,21,8320,1,137,17,2,8328,17,0,1,1,137,21,1,4,1,1,0]

theorem envBound22230 : H12AffineFastState.Bounded env22230 := by
  intro p hp
  have h : env22230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22229_22230 : H12AffineEnvironment.transform 4 1 env22229 = env22230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22229 == env22230) = true)

def env22231 : List Nat := [2,4,8,16,1,16,128,5,0,20,1,1,128,1,1,3,1,136,21,0,1,137,17,2,8,17,0,1,1,137,21,1,4,1,1,0]

theorem envBound22231 : H12AffineFastState.Bounded env22231 := by
  intro p hp
  have h : env22231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22230_22231 : H12AffineEnvironment.transform 12 128 env22230 = env22231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env22230 == env22231) = true)

theorem identity22231 : scanCanonicalize (H12AffineFastState.compose env22231 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22231 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22232 : List Nat := [2,4,8,16,1,16,9,5,0,20,1,1,9,1,1,3,1,1,21,0,1,0,17,2,8,17,0,1,1,0,21,1,4,1,1,0]

theorem envBound22232 : H12AffineFastState.Bounded env22232 := by
  intro p hp
  have h : env22232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22231_22232 : H12AffineEnvironment.transform 6 9 env22231 = env22232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22231 == env22232) = true)

def leafEnv22232 : List Nat := [2,4,8,16,1,16,9,5,0,20,1,1,9,1,1,3,1,1,21,0,1,0,17,2,20,8,1,17,0,1,1,0,21,1,4,1,5,3,1,0,0,1,1]

def active22232 : List Nat := [0,1,2,3]

def tree22232 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22232 : H12WitnessSearch.Good tree22232 := H12GlobalWitnessIndex.good

theorem leafIdentity22232 : H12AffineFastState.composeSystem env22232 rootObs = leafEnv22232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22232 rootObs == leafEnv22232) = true)

theorem terminalChecked22232 : H12PackedTerminal.terminalCheckFast leafEnv22232 active22232 tree22232 = true := by decide +kernel

def env22233 : List Nat := [2,4,8,16,1,16,128,5,0,20,1,1,129,1,0,2,1,136,21,1,1,137,17,2,9,17,0,1,1,137,21,1,4,1,1,0]

theorem envBound22233 : H12AffineFastState.Bounded env22233 := by
  intro p hp
  have h : env22233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22230_22233 : H12AffineEnvironment.transform 12 129 env22230 = env22233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env22230 == env22233) = true)

def leafEnv22233 : List Nat := [2,4,8,16,1,16,128,5,0,20,1,1,129,1,0,2,1,136,21,1,1,137,17,2,20,9,1,17,0,1,1,137,21,1,4,1,5,2,1,0,0,1,1]

def active22233 : List Nat := [0,1,2,3,6]

def tree22233 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22233 : H12WitnessSearch.Good tree22233 := H12GlobalWitnessIndex.good

theorem leafIdentity22233 : H12AffineFastState.composeSystem env22233 rootObs = leafEnv22233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22233 rootObs == leafEnv22233) = true)

theorem terminalChecked22233 : H12PackedTerminal.terminalCheckFast leafEnv22233 active22233 tree22233 = true := by decide +kernel

def env22234 : List Nat := [2,4,8,16,32,16,128,5,0,20,33,1,8192,1,8352,8354,1,168,21,8353,1,137,17,2,8328,17,32,1,1,169,21,1,4,32,1,0]

theorem envBound22234 : H12AffineFastState.Bounded env22234 := by
  intro p hp
  have h : env22234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22228_22234 : H12AffineEnvironment.transform 10 33 env22228 = env22234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env22228 == env22234) = true)

theorem identity22234 : scanCanonicalize (H12AffineFastState.compose env22234 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound22234 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22235 : List Nat := [2,4,8,16,32,16,40,5,0,20,33,1,8192,1,8200,8202,1,0,21,8201,1,33,17,2,8224,17,32,1,1,1,21,1,4,32,1,0]

theorem envBound22235 : H12AffineFastState.Bounded env22235 := by
  intro p hp
  have h : env22235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22234_22235 : H12AffineEnvironment.transform 6 40 env22234 = env22235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env22234 == env22235) = true)

def env22236 : List Nat := [2,4,8,16,0,16,8,5,0,20,1,1,8192,1,8200,8202,1,0,21,8201,1,1,17,2,8192,17,0,1,1,1,21,1,4,0,1,0]

theorem envBound22236 : H12AffineFastState.Bounded env22236 := by
  intro p hp
  have h : env22236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22235_22236 : H12AffineEnvironment.transform 4 0 env22235 = env22236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22235 == env22236) = true)

theorem identity22236 : scanCanonicalize (H12AffineFastState.compose env22236 (packedSelected [4] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound22236 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22237 : List Nat := [2,4,8,16,0,16,8,5,0,20,1,1,9,1,1,3,1,0,21,0,1,1,17,2,9,17,0,1,1,1,21,1,4,0,1,0]

theorem envBound22237 : H12AffineFastState.Bounded env22237 := by
  intro p hp
  have h : env22237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22236_22237 : H12AffineEnvironment.transform 12 9 env22236 = env22237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env22236 == env22237) = true)

def leafEnv22237 : List Nat := [2,4,8,16,0,16,8,5,0,20,1,1,9,1,1,3,1,0,21,0,1,1,17,2,20,9,1,17,0,1,1,1,21,1,4,0,5,3,1,0,0,1,1]

def active22237 : List Nat := [0,1,2,3]

def tree22237 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22237 : H12WitnessSearch.Good tree22237 := H12GlobalWitnessIndex.good

theorem leafIdentity22237 : H12AffineFastState.composeSystem env22237 rootObs = leafEnv22237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22237 rootObs == leafEnv22237) = true)

theorem terminalChecked22237 : H12PackedTerminal.terminalCheckFast leafEnv22237 active22237 tree22237 = true := by decide +kernel

def env22238 : List Nat := [2,4,8,16,1,16,9,5,0,20,0,1,8192,1,8200,8202,1,0,21,8201,1,0,17,2,8193,17,1,1,1,1,21,1,4,1,1,0]

theorem envBound22238 : H12AffineFastState.Bounded env22238 := by
  intro p hp
  have h : env22238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22235_22238 : H12AffineEnvironment.transform 4 1 env22235 = env22238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22235 == env22238) = true)

def leafEnv22238 : List Nat := [2,4,8,16,1,16,9,5,0,20,0,1,8192,1,8200,8202,1,0,21,8201,1,0,17,2,20,8193,1,17,1,1,1,1,21,1,4,1,5,8202,1,0,0,1,1]

def active22238 : List Nat := [0,1,2,3,12]

def tree22238 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22238 : H12WitnessSearch.Good tree22238 := H12GlobalWitnessIndex.good

theorem leafIdentity22238 : H12AffineFastState.composeSystem env22238 rootObs = leafEnv22238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22238 rootObs == leafEnv22238) = true)

theorem terminalChecked22238 : H12PackedTerminal.terminalCheckFast leafEnv22238 active22238 tree22238 = true := by decide +kernel

def env22239 : List Nat := [2,4,8,16,32,16,128,5,1,20,2048,1,8192,1,8353,65536,1,2184,21,8352,1,136,17,73889,8328,17,2049,1,1,2185,21,0,4,73859,1,1]

theorem envBound22239 : H12AffineFastState.Bounded env22239 := by
  intro p hp
  have h : env22239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22226_22239 : H12AffineEnvironment.transform 8 1 env22226 = env22239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env22226 == env22239) = true)

theorem identity22239 : scanCanonicalize (H12AffineFastState.compose env22239 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound22239 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22240 : List Nat := [2,4,8,16,32,16,128,5,1,20,2048,1,8192,1,8353,8203,1,2184,21,8352,1,136,17,170,8328,17,2049,1,1,2185,21,0,4,136,1,1]

theorem envBound22240 : H12AffineFastState.Bounded env22240 := by
  intro p hp
  have h : env22240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22239_22240 : H12AffineEnvironment.transform 15 8203 env22239 = env22240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env22239 == env22240) = true)

def env22241 : List Nat := [2,4,8,16,32,16,128,5,1,20,2048,1,2208,1,2049,2219,1,2184,21,2048,1,136,17,170,2088,17,2049,1,1,2185,21,0,4,136,1,1]

theorem envBound22241 : H12AffineFastState.Bounded env22241 := by
  intro p hp
  have h : env22241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22240_22241 : H12AffineEnvironment.transform 12 2208 env22240 = env22241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2208 env22240 == env22241) = true)

def env22242 : List Nat := [2,4,8,16,32,16,128,5,1,20,2048,1,2209,1,2048,2218,1,2184,21,2049,1,136,17,170,2089,17,2049,1,1,2185,21,0,4,136,1,1]

theorem envBound22242 : H12AffineFastState.Bounded env22242 := by
  intro p hp
  have h : env22242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22240_22242 : H12AffineEnvironment.transform 12 2209 env22240 = env22242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2209 env22240 == env22242) = true)

theorem identity22242 : scanCanonicalize (H12AffineFastState.compose env22242 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22242 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22243 : List Nat := [2,4,8,16,32,16,9,5,1,20,2048,1,2088,1,2048,2083,1,2049,21,2049,1,1,17,35,2089,17,2049,1,1,2048,21,0,4,1,1,1]

theorem envBound22243 : H12AffineFastState.Bounded env22243 := by
  intro p hp
  have h : env22243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22242_22243 : H12AffineEnvironment.transform 6 9 env22242 = env22243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22242 == env22243) = true)

def env22244 : List Nat := [2,4,8,16,32,16,9,5,1,20,0,1,40,1,0,35,1,1,21,1,1,1,17,35,41,17,1,1,1,0,21,0,4,1,1,1]

theorem envBound22244 : H12AffineFastState.Bounded env22244 := by
  intro p hp
  have h : env22244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22243_22244 : H12AffineEnvironment.transform 10 0 env22243 = env22244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env22243 == env22244) = true)

theorem identity22244 : scanCanonicalize (H12AffineFastState.compose env22244 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22244 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22245 : List Nat := [2,4,8,16,1,16,9,5,1,20,0,1,9,1,0,2,1,1,21,1,1,1,17,2,8,17,1,1,1,0,21,0,4,1,1,1]

theorem envBound22245 : H12AffineFastState.Bounded env22245 := by
  intro p hp
  have h : env22245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22244_22245 : H12AffineEnvironment.transform 4 1 env22244 = env22245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22244 == env22245) = true)

def leafEnv22245 : List Nat := [2,4,8,16,1,16,9,5,1,20,0,1,9,1,0,2,1,1,21,1,1,1,17,2,20,8,1,17,1,1,1,0,21,0,4,1,5,2,1,1,0,1,1]

def active22245 : List Nat := [0,1,2,3]

def tree22245 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22245 : H12WitnessSearch.Good tree22245 := H12GlobalWitnessIndex.good

theorem leafIdentity22245 : H12AffineFastState.composeSystem env22245 rootObs = leafEnv22245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22245 rootObs == leafEnv22245) = true)

theorem terminalChecked22245 : H12PackedTerminal.terminalCheckFast leafEnv22245 active22245 tree22245 = true := by decide +kernel

def env22246 : List Nat := [2,4,8,16,32,16,9,5,1,20,1,1,41,1,1,34,1,0,21,0,1,1,17,35,40,17,0,1,1,1,21,0,4,1,1,1]

theorem envBound22246 : H12AffineFastState.Bounded env22246 := by
  intro p hp
  have h : env22246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22243_22246 : H12AffineEnvironment.transform 10 1 env22243 = env22246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env22243 == env22246) = true)

def leafEnv22246 : List Nat := [2,4,8,16,32,16,9,5,1,20,1,1,41,1,1,34,1,0,21,0,1,1,17,35,20,40,1,17,0,1,1,1,21,0,4,1,5,3,1,1,0,1,1]

def active22246 : List Nat := [0,1,2,3,4]

def tree22246 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22246 : H12WitnessSearch.Good tree22246 := H12GlobalWitnessIndex.good

theorem leafIdentity22246 : H12AffineFastState.composeSystem env22246 rootObs = leafEnv22246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22246 rootObs == leafEnv22246) = true)

theorem terminalChecked22246 : H12PackedTerminal.terminalCheckFast leafEnv22246 active22246 tree22246 = true := by decide +kernel

def env22247 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,65536,1296,43049,1025,32769,1297,4194304,16,98565,8328,16,4237613,1297,1296,4196612,1284,4294967296,257,4299260335,1296,512]

theorem envBound22247 : H12AffineFastState.Bounded env22247 := by
  intro p hp
  have h : env22247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22161_22247 : H12AffineEnvironment.transform 11 1297 env22161 = env22247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env22161 == env22247) = true)

theorem identity22247 : scanCanonicalize (H12AffineFastState.compose env22247 (packedSelected [1,3] rootPS)) = affineNative (2^(21+1) ^^^ 260) := by decide +kernel

theorem selectedBound22247 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22248 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,65536,1296,43049,1025,32769,1297,260,16,98565,8328,16,43049,1297,1296,2048,1284,4294967296,257,4295065771,1296,512]

theorem envBound22248 : H12AffineFastState.Bounded env22248 := by
  intro p hp
  have h : env22248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22247_22248 : H12AffineEnvironment.transform 21 260 env22247 = env22248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 260 env22247 == env22248) = true)

theorem identity22248 : scanCanonicalize (H12AffineFastState.compose env22248 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound22248 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env22249 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,33166,1296,43049,1025,32769,1297,260,16,139,8328,16,43049,1297,1296,2048,1284,4294967296,257,4294967589,1296,512]

theorem envBound22249 : H12AffineFastState.Bounded env22249 := by
  intro p hp
  have h : env22249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22248_22249 : H12AffineEnvironment.transform 15 33166 env22248 = env22249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env22248 == env22249) = true)

theorem identity22249 : scanCanonicalize (H12AffineFastState.compose env22249 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 10540) := by decide +kernel

theorem selectedBound22249 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22250 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,33166,1296,43049,1025,32769,1297,260,16,139,8328,16,43049,1297,1296,2048,1284,10540,257,10249,1296,512]

theorem envBound22250 : H12AffineFastState.Bounded env22250 := by
  intro p hp
  have h : env22250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22249_22250 : H12AffineEnvironment.transform 31 10540 env22249 = env22250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 10540 env22249 == env22250) = true)

theorem identity22250 : scanCanonicalize (H12AffineFastState.compose env22250 (packedSelected [12] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound22250 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env22251 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2317,1297,32768,33166,1296,33060,1025,32769,1297,260,16,139,2437,16,33060,1297,1296,2048,1284,33,257,260,1296,512]

theorem envBound22251 : H12AffineFastState.Bounded env22251 := by
  intro p hp
  have h : env22251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22250_22251 : H12AffineEnvironment.transform 12 2317 env22250 = env22251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env22250 == env22251) = true)

theorem identity22251 : scanCanonicalize (H12AffineFastState.compose env22251 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound22251 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22252 : List Nat := [2,4,8,16,32,16,128,256,260,1024,2048,1297,2317,1297,32768,33166,1296,33060,1025,32769,1297,260,16,139,2437,16,33060,1297,1296,2048,1284,33,257,260,1296,260]

theorem envBound22252 : H12AffineFastState.Bounded env22252 := by
  intro p hp
  have h : env22252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22251_22252 : H12AffineEnvironment.transform 8 260 env22251 = env22252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env22251 == env22252) = true)

theorem identity22252 : scanCanonicalize (H12AffineFastState.compose env22252 (packedSelected [0,4,6] rootPS)) = affineNative (2^(14+1) ^^^ 2340) := by decide +kernel

theorem selectedBound22252 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env22253 : List Nat := [2,4,8,16,32,16,128,256,260,1024,2048,1297,2317,1297,2340,2218,1296,2048,1025,2341,1297,260,16,139,2437,16,2048,1297,1296,2048,1284,33,257,260,1296,260]

theorem envBound22253 : H12AffineFastState.Bounded env22253 := by
  intro p hp
  have h : env22253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22252_22253 : H12AffineEnvironment.transform 14 2340 env22252 = env22253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2340 env22252 == env22253) = true)

def env22254 : List Nat := [2,4,8,16,0,16,128,256,260,1024,2048,1297,2317,1297,2308,2186,1296,2048,1025,2309,1297,260,16,139,2437,16,2048,1297,1296,2048,1284,1,257,260,1296,260]

theorem envBound22254 : H12AffineFastState.Bounded env22254 := by
  intro p hp
  have h : env22254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22253_22254 : H12AffineEnvironment.transform 4 0 env22253 = env22254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22253 == env22254) = true)

theorem identity22254 : scanCanonicalize (H12AffineFastState.compose env22254 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22254 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22255 : List Nat := [2,4,8,16,0,16,128,4,0,1024,2048,1045,2057,1045,2048,2186,1044,2048,1025,2049,1045,0,16,139,2177,16,2048,1045,1044,2048,1024,1,5,0,1044,0]

theorem envBound22255 : H12AffineFastState.Bounded env22255 := by
  intro p hp
  have h : env22255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22254_22255 : H12AffineEnvironment.transform 7 4 env22254 = env22255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22254 == env22255) = true)

theorem identity22255 : scanCanonicalize (H12AffineFastState.compose env22255 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22255 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22256 : List Nat := [2,4,8,16,0,16,8,4,0,1024,2048,1045,2057,1045,2048,2050,1044,2048,1025,2049,1045,0,16,3,2057,16,2048,1045,1044,2048,1024,1,5,0,1044,0]

theorem envBound22256 : H12AffineFastState.Bounded env22256 := by
  intro p hp
  have h : env22256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22255_22256 : H12AffineEnvironment.transform 6 8 env22255 = env22256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22255 == env22256) = true)

def leafEnv22256 : List Nat := [2,4,8,16,0,16,8,4,0,1024,2048,1045,2057,1045,2048,2050,1044,2048,1025,2049,1045,0,16,3,1025,2057,1,16,2048,1045,1044,2048,1024,1,5,0,5,2051,1044,0,0,1044,1]

def active22256 : List Nat := [0,1,2,3,9,10]

def tree22256 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22256 : H12WitnessSearch.Good tree22256 := H12GlobalWitnessIndex.good

theorem leafIdentity22256 : H12AffineFastState.composeSystem env22256 rootObs = leafEnv22256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22256 rootObs == leafEnv22256) = true)

theorem terminalChecked22256 : H12PackedTerminal.terminalCheckFast leafEnv22256 active22256 tree22256 = true := by decide +kernel

def env22257 : List Nat := [2,4,8,16,1,16,128,256,260,1024,2048,1297,2317,1297,2309,2187,1296,2048,1025,2308,1297,260,16,139,2437,16,2048,1297,1296,2048,1284,0,257,260,1296,260]

theorem envBound22257 : H12AffineFastState.Bounded env22257 := by
  intro p hp
  have h : env22257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22253_22257 : H12AffineEnvironment.transform 4 1 env22253 = env22257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22253 == env22257) = true)

theorem identity22257 : scanCanonicalize (H12AffineFastState.compose env22257 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound22257 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22258 : List Nat := [2,4,8,16,1,16,128,140,136,1024,2048,1181,2177,1181,2185,2187,1180,2048,1025,2184,1181,136,16,139,2057,16,2048,1181,1180,2048,1160,0,141,136,1180,136]

theorem envBound22258 : H12AffineFastState.Bounded env22258 := by
  intro p hp
  have h : env22258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22257_22258 : H12AffineEnvironment.transform 7 140 env22257 = env22258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env22257 == env22258) = true)

def leafEnv22258 : List Nat := [2,4,8,16,1,16,128,140,136,1024,2048,1181,2177,1181,2185,2187,1180,2048,1025,2184,1181,136,16,139,1161,2057,1,16,2048,1181,1180,2048,1160,0,141,136,5,2050,1180,136,0,1180,1]

def active22258 : List Nat := [0,1,2,3,6,9,10]

def tree22258 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22258 : H12WitnessSearch.Good tree22258 := H12GlobalWitnessIndex.good

theorem leafIdentity22258 : H12AffineFastState.composeSystem env22258 rootObs = leafEnv22258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22258 rootObs == leafEnv22258) = true)

theorem terminalChecked22258 : H12PackedTerminal.terminalCheckFast leafEnv22258 active22258 tree22258 = true := by decide +kernel

def env22259 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,1025,32769,4096,4194304,135185,230420,8328,135184,4588565,4097,131073,1073741824,131093,4294967296,257,4299392190,1297,512]

theorem envBound22259 : H12AffineFastState.Bounded env22259 := by
  intro p hp
  have h : env22259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22157_22259 : H12AffineEnvironment.transform 5 17 env22157 = env22259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22157 == env22259) = true)

theorem identity22259 : scanCanonicalize (H12AffineFastState.compose env22259 (packedSelected [3,5,8,13,15,21,28,38] rootPS)) = affineNative (2^(29+1) ^^^ 4427163) := by decide +kernel

theorem selectedBound22259 : packedSelected [3,5,8,13,15,21,28,38] rootPS < 2^1333 := by decide +kernel

def env22260 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,1025,32769,4096,4194304,135185,230420,8328,135184,4588565,4097,131073,4427163,131093,4294967296,257,4299392190,1297,512]

theorem envBound22260 : H12AffineFastState.Bounded env22260 := by
  intro p hp
  have h : env22260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22259_22260 : H12AffineEnvironment.transform 29 4427163 env22259 = env22260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4427163 env22259 == env22260) = true)

theorem identity22260 : scanCanonicalize (H12AffineFastState.compose env22260 (packedSelected [1,3,13,17,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 1297) := by decide +kernel

theorem selectedBound22260 : packedSelected [1,3,13,17,24,28] rootPS < 2^1333 := by decide +kernel

def env22261 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,262144,1025,32769,4096,4194304,5376,98565,8328,5377,4456708,4097,1296,4294794,1284,4294967296,257,4299260335,1297,512]

theorem envBound22261 : H12AffineFastState.Bounded env22261 := by
  intro p hp
  have h : env22261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22260_22261 : H12AffineEnvironment.transform 16 1297 env22260 = env22261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1297 env22260 == env22261) = true)

theorem identity22261 : scanCanonicalize (H12AffineFastState.compose env22261 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound22261 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env22262 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,33166,1297,262144,1025,32769,4096,4194304,5376,139,8328,5377,4456708,4097,1296,4196612,1284,4294967296,257,4299161633,1297,512]

theorem envBound22262 : H12AffineFastState.Bounded env22262 := by
  intro p hp
  have h : env22262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22261_22262 : H12AffineEnvironment.transform 15 33166 env22261 = env22262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env22261 == env22262) = true)

theorem identity22262 : scanCanonicalize (H12AffineFastState.compose env22262 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound22262 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env22263 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,33166,1297,43049,1025,32769,4096,4194304,5376,139,8328,5377,4237613,4097,1296,4196612,1284,4294967296,257,4299161633,1297,512]

theorem envBound22263 : H12AffineFastState.Bounded env22263 := by
  intro p hp
  have h : env22263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22262_22263 : H12AffineEnvironment.transform 17 43049 env22262 = env22263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env22262 == env22263) = true)

def env22264 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,33166,1297,43049,1025,32769,1296,4194304,16,139,8328,17,4237613,1297,1296,4196612,1284,4294967296,257,4299161633,1297,512]

theorem envBound22264 : H12AffineFastState.Bounded env22264 := by
  intro p hp
  have h : env22264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22263_22264 : H12AffineEnvironment.transform 11 1296 env22263 = env22264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env22263 == env22264) = true)

theorem identity22264 : scanCanonicalize (H12AffineFastState.compose env22264 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 41089) := by decide +kernel

theorem selectedBound22264 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22265 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,33166,1297,43049,1025,32769,1296,4194304,16,139,8328,17,4237613,1297,1296,4196612,1284,41089,257,4235424,1297,512]

theorem envBound22265 : H12AffineFastState.Bounded env22265 := by
  intro p hp
  have h : env22265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22264_22265 : H12AffineEnvironment.transform 31 41089 env22264 = env22265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 41089 env22264 == env22265) = true)

theorem identity22265 : scanCanonicalize (H12AffineFastState.compose env22265 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 260) := by decide +kernel

theorem selectedBound22265 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env22266 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,33166,1297,43049,1025,32769,1296,260,16,139,8328,17,43049,1297,1296,2048,1284,41089,257,41380,1297,512]

theorem envBound22266 : H12AffineFastState.Bounded env22266 := by
  intro p hp
  have h : env22266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22265_22266 : H12AffineEnvironment.transform 21 260 env22265 = env22266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 260 env22265 == env22266) = true)

theorem identity22266 : scanCanonicalize (H12AffineFastState.compose env22266 (packedSelected [12] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound22266 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env22267 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,8232,8614,1297,2049,1025,8233,1296,260,16,139,8328,17,2049,1297,1296,2048,1284,169,257,396,1297,512]

theorem envBound22267 : H12AffineFastState.Bounded env22267 := by
  intro p hp
  have h : env22267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22266_22267 : H12AffineEnvironment.transform 14 8232 env22266 = env22267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env22266 == env22267) = true)

theorem identity22267 : scanCanonicalize (H12AffineFastState.compose env22267 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound22267 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22268 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1296,8192,1297,8232,8614,1297,2049,1025,8233,1296,260,16,139,8328,17,2049,1297,1296,2048,1284,169,257,396,1297,136]

theorem envBound22268 : H12AffineFastState.Bounded env22268 := by
  intro p hp
  have h : env22268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22267_22268 : H12AffineEnvironment.transform 8 136 env22267 = env22268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env22267 == env22268) = true)

theorem identity22268 : scanCanonicalize (H12AffineFastState.compose env22268 (packedSelected [0,2] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound22268 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env22269 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1296,2316,1297,2340,2218,1297,2049,1025,2341,1296,260,16,139,2436,17,2049,1297,1296,2048,1284,169,257,396,1297,136]

theorem envBound22269 : H12AffineFastState.Bounded env22269 := by
  intro p hp
  have h : env22269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22268_22269 : H12AffineEnvironment.transform 12 2316 env22268 = env22269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env22268 == env22269) = true)

def env22270 : List Nat := [2,4,8,16,32,17,8,256,0,1024,2048,1296,2316,1297,2340,2082,1297,2049,1025,2341,1296,260,16,3,2316,17,2049,1297,1296,2048,1284,33,257,260,1297,0]

theorem envBound22270 : H12AffineFastState.Bounded env22270 := by
  intro p hp
  have h : env22270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22269_22270 : H12AffineEnvironment.transform 6 8 env22269 = env22270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22269 == env22270) = true)

theorem identity22270 : scanCanonicalize (H12AffineFastState.compose env22270 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22270 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22271 : List Nat := [2,4,8,16,32,17,8,4,0,1024,2048,1044,2056,1045,2080,2082,1045,2049,1025,2081,1044,0,16,3,2056,17,2049,1045,1044,2048,1024,33,5,0,1045,0]

theorem envBound22271 : H12AffineFastState.Bounded env22271 := by
  intro p hp
  have h : env22271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22270_22271 : H12AffineEnvironment.transform 7 4 env22270 = env22271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22270 == env22271) = true)

def leafEnv22271 : List Nat := [2,4,8,16,32,17,8,4,0,1024,2048,1044,2056,1045,2080,2082,1045,2049,1025,2081,1044,0,16,3,1025,2056,1,17,2049,1045,1044,2048,1024,33,5,0,5,2083,1045,0,0,1044,1]

def active22271 : List Nat := [0,1,2,3,4,9,10]

def tree22271 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22271 : H12WitnessSearch.Good tree22271 := H12GlobalWitnessIndex.good

theorem leafIdentity22271 : H12AffineFastState.composeSystem env22271 rootObs = leafEnv22271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22271 rootObs == leafEnv22271) = true)

theorem terminalChecked22271 : H12PackedTerminal.terminalCheckFast leafEnv22271 active22271 tree22271 = true := by decide +kernel

def env22272 : List Nat := [2,4,8,16,32,17,9,256,1,1024,2048,1296,2316,1297,2340,2083,1297,2049,1025,2341,1296,260,16,2,2317,17,2049,1297,1296,2048,1284,32,257,261,1297,1]

theorem envBound22272 : H12AffineFastState.Bounded env22272 := by
  intro p hp
  have h : env22272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22269_22272 : H12AffineEnvironment.transform 6 9 env22269 = env22272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22269 == env22272) = true)

theorem identity22272 : scanCanonicalize (H12AffineFastState.compose env22272 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22272 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22273 : List Nat := [2,4,8,16,1,17,9,256,1,1024,2048,1296,2316,1297,2309,2050,1297,2049,1025,2308,1296,260,16,2,2317,17,2049,1297,1296,2048,1284,1,257,261,1297,1]

theorem envBound22273 : H12AffineFastState.Bounded env22273 := by
  intro p hp
  have h : env22273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22272_22273 : H12AffineEnvironment.transform 4 1 env22272 = env22273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22272 == env22273) = true)

def leafEnv22273 : List Nat := [2,4,8,16,1,17,9,256,1,1024,2048,1296,2316,1297,2309,2050,1297,2049,1025,2308,1296,260,16,2,1285,2317,1,17,2049,1297,1296,2048,1284,1,257,261,5,2050,1297,1,0,1296,1]

def active22273 : List Nat := [0,1,2,3,7,9,10]

def tree22273 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22273 : H12WitnessSearch.Good tree22273 := H12GlobalWitnessIndex.good

theorem leafIdentity22273 : H12AffineFastState.composeSystem env22273 rootObs = leafEnv22273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22273 rootObs == leafEnv22273) = true)

theorem terminalChecked22273 : H12PackedTerminal.terminalCheckFast leafEnv22273 active22273 tree22273 = true := by decide +kernel

def env22274 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,33166,1297,43049,1025,32769,1297,4194304,17,139,8328,16,4237613,1296,1296,4196612,1284,4294967296,257,4299161633,1297,512]

theorem envBound22274 : H12AffineFastState.Bounded env22274 := by
  intro p hp
  have h : env22274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22263_22274 : H12AffineEnvironment.transform 11 1297 env22263 = env22274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env22263 == env22274) = true)

theorem identity22274 : scanCanonicalize (H12AffineFastState.compose env22274 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 4230061) := by decide +kernel

theorem selectedBound22274 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22275 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,33166,1297,43049,1025,32769,1297,4194304,17,139,8328,16,4237613,1296,1296,4196612,1284,4230061,257,35724,1297,512]

theorem envBound22275 : H12AffineFastState.Bounded env22275 := by
  intro p hp
  have h : env22275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22274_22275 : H12AffineEnvironment.transform 31 4230061 env22274 = env22275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4230061 env22274 == env22275) = true)

theorem identity22275 : scanCanonicalize (H12AffineFastState.compose env22275 (packedSelected [3] rootPS)) = affineNative (2^(21+1) ^^^ 260) := by decide +kernel

theorem selectedBound22275 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22276 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,33166,1297,43049,1025,32769,1297,260,17,139,8328,16,43049,1296,1296,2048,1284,35497,257,35724,1297,512]

theorem envBound22276 : H12AffineFastState.Bounded env22276 := by
  intro p hp
  have h : env22276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22275_22276 : H12AffineEnvironment.transform 21 260 env22275 = env22276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 260 env22275 == env22276) = true)

theorem identity22276 : scanCanonicalize (H12AffineFastState.compose env22276 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound22276 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env22277 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,8192,1296,32768,33166,1297,43049,1025,32769,1297,260,17,139,8328,16,43049,1296,1296,2048,1284,34849,257,35076,1297,136]

theorem envBound22277 : H12AffineFastState.Bounded env22277 := by
  intro p hp
  have h : env22277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22276_22277 : H12AffineEnvironment.transform 8 136 env22276 = env22277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env22276 == env22277) = true)

theorem identity22277 : scanCanonicalize (H12AffineFastState.compose env22277 (packedSelected [0,6] rootPS)) = affineNative (2^(14+1) ^^^ 2340) := by decide +kernel

theorem selectedBound22277 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env22278 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,8192,1296,2340,2218,1297,8461,1025,2341,1297,260,17,139,8328,16,8461,1296,1296,2048,1284,261,257,32,1297,136]

theorem envBound22278 : H12AffineFastState.Bounded env22278 := by
  intro p hp
  have h : env22278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22277_22278 : H12AffineEnvironment.transform 14 2340 env22277 = env22278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2340 env22277 == env22278) = true)

theorem identity22278 : scanCanonicalize (H12AffineFastState.compose env22278 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound22278 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22279 : List Nat := [2,4,8,16,32,17,41,256,33,1024,2048,1297,8192,1296,2340,2051,1297,8461,1025,2341,1297,260,17,34,8225,16,8461,1296,1296,2048,1284,261,257,32,1297,33]

theorem envBound22279 : H12AffineFastState.Bounded env22279 := by
  intro p hp
  have h : env22279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22278_22279 : H12AffineEnvironment.transform 6 41 env22278 = env22279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env22278 == env22279) = true)

theorem identity22279 : scanCanonicalize (H12AffineFastState.compose env22279 (packedSelected [4] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound22279 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22280 : List Nat := [2,4,8,16,32,17,41,256,33,1024,2048,1297,2317,1296,2340,2051,1297,2048,1025,2341,1297,260,17,34,2348,16,2048,1296,1296,2048,1284,261,257,32,1297,33]

theorem envBound22280 : H12AffineFastState.Bounded env22280 := by
  intro p hp
  have h : env22280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22279_22280 : H12AffineEnvironment.transform 12 2317 env22279 = env22280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env22279 == env22280) = true)

def env22281 : List Nat := [2,4,8,16,0,17,9,256,1,1024,2048,1297,2317,1296,2308,2051,1297,2048,1025,2309,1297,260,17,2,2316,16,2048,1296,1296,2048,1284,261,257,0,1297,1]

theorem envBound22281 : H12AffineFastState.Bounded env22281 := by
  intro p hp
  have h : env22281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22280_22281 : H12AffineEnvironment.transform 4 0 env22280 = env22281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22280 == env22281) = true)

theorem identity22281 : scanCanonicalize (H12AffineFastState.compose env22281 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22281 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22282 : List Nat := [2,4,8,16,0,17,9,4,1,1024,2048,1045,2057,1044,2048,2051,1045,2048,1025,2049,1045,0,17,2,2056,16,2048,1044,1044,2048,1024,1,5,0,1045,1]

theorem envBound22282 : H12AffineFastState.Bounded env22282 := by
  intro p hp
  have h : env22282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22281_22282 : H12AffineEnvironment.transform 7 4 env22281 = env22282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22281 == env22282) = true)

def leafEnv22282 : List Nat := [2,4,8,16,0,17,9,4,1,1024,2048,1045,2057,1044,2048,2051,1045,2048,1025,2049,1045,0,17,2,1025,2056,1,16,2048,1044,1044,2048,1024,1,5,0,5,2051,1045,1,0,1044,1]

def active22282 : List Nat := [0,1,2,3,9,10]

def tree22282 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22282 : H12WitnessSearch.Good tree22282 := H12GlobalWitnessIndex.good

theorem leafIdentity22282 : H12AffineFastState.composeSystem env22282 rootObs = leafEnv22282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22282 rootObs == leafEnv22282) = true)

theorem terminalChecked22282 : H12PackedTerminal.terminalCheckFast leafEnv22282 active22282 tree22282 = true := by decide +kernel

def env22283 : List Nat := [2,4,8,16,1,17,8,256,0,1024,2048,1297,2317,1296,2309,2051,1297,2048,1025,2308,1297,260,17,3,2317,16,2048,1296,1296,2048,1284,261,257,1,1297,0]

theorem envBound22283 : H12AffineFastState.Bounded env22283 := by
  intro p hp
  have h : env22283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22280_22283 : H12AffineEnvironment.transform 4 1 env22280 = env22283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22280 == env22283) = true)

def leafEnv22283 : List Nat := [2,4,8,16,1,17,8,256,0,1024,2048,1297,2317,1296,2309,2051,1297,2048,1025,2308,1297,260,17,3,1285,2317,1,16,2048,1296,1296,2048,1284,261,257,1,5,2050,1297,0,0,1296,1]

def active22283 : List Nat := [0,1,2,3,7,9,10]

def tree22283 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22283 : H12WitnessSearch.Good tree22283 := H12GlobalWitnessIndex.good

theorem leafIdentity22283 : H12AffineFastState.composeSystem env22283 rootObs = leafEnv22283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22283 rootObs == leafEnv22283) = true)

theorem terminalChecked22283 : H12PackedTerminal.terminalCheckFast leafEnv22283 active22283 tree22283 = true := by decide +kernel

def env22284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,524288,32769,4096,4194304,660496,16777216,8328,135233,134217728,529489,656464,1073741824,17399809,4294967296,525569,4315938986,155551040,512]

theorem envBound22284 : H12AffineFastState.Bounded env22284 := by
  intro p hp
  have h : env22284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21973_22284 : H12AffineEnvironment.transform 13 4177 env21973 = env22284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env21973 == env22284) = true)

theorem identity22284 : scanCanonicalize (H12AffineFastState.compose env22284 (packedSelected [4,9,16] rootPS)) = affineNative (2^(23+1) ^^^ 623877) := by decide +kernel

theorem selectedBound22284 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env22285 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,524288,32769,4096,4194304,660496,623877,8328,135233,134217728,529489,656464,1073741824,1284,4294967296,525569,4299785647,139198533,512]

theorem envBound22285 : H12AffineFastState.Bounded env22285 := by
  intro p hp
  have h : env22285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22284_22285 : H12AffineEnvironment.transform 23 623877 env22284 = env22285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 623877 env22284 == env22285) = true)

theorem identity22285 : scanCanonicalize (H12AffineFastState.compose env22285 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(29+1) ^^^ 135105934) := by decide +kernel

theorem selectedBound22285 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env22286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,524288,32769,4096,4194304,660496,623877,8328,135233,134217728,529489,656464,135105934,1284,4294967296,525569,4299785647,139198533,512]

theorem envBound22286 : H12AffineFastState.Bounded env22286 := by
  intro p hp
  have h : env22286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22285_22286 : H12AffineEnvironment.transform 29 135105934 env22285 = env22286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 135105934 env22285 == env22286) = true)

theorem identity22286 : scanCanonicalize (H12AffineFastState.compose env22286 (packedSelected [3,5,10] rootPS)) = affineNative (2^(26+1) ^^^ 4498049) := by decide +kernel

theorem selectedBound22286 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22287 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,524288,32769,4096,4194304,660496,623877,8328,135233,4498049,529489,656464,4796175,1284,4294967296,525569,4299785647,565956,512]

theorem envBound22287 : H12AffineFastState.Bounded env22287 := by
  intro p hp
  have h : env22287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22286_22287 : H12AffineEnvironment.transform 26 4498049 env22286 = env22287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4498049 env22286 == env22287) = true)

theorem identity22287 : scanCanonicalize (H12AffineFastState.compose env22287 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 42884) := by decide +kernel

theorem selectedBound22287 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env22288 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,42884,32769,4096,4194304,177044,74369,8328,135233,4498049,46037,173012,4294795,1284,4294967296,41605,4299235883,1344,512]

theorem envBound22288 : H12AffineFastState.Bounded env22288 := by
  intro p hp
  have h : env22288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22287_22288 : H12AffineEnvironment.transform 18 42884 env22287 = env22288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 42884 env22287 == env22288) = true)

theorem identity22288 : scanCanonicalize (H12AffineFastState.compose env22288 (packedSelected [13,21] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound22288 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env22289 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,32768,65536,131072,262144,42253,32769,4096,4194304,176413,73736,8328,135233,4497416,45404,172381,4294795,1284,4294967296,40972,4299235490,1344,137]

theorem envBound22289 : H12AffineFastState.Bounded env22289 := by
  intro p hp
  have h : env22289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22288_22289 : H12AffineEnvironment.transform 8 137 env22288 = env22289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env22288 == env22289) = true)

theorem identity22289 : scanCanonicalize (H12AffineFastState.compose env22289 (packedSelected [0,6,27] rootPS)) = affineNative (2^(31+1) ^^^ 98339) := by decide +kernel

theorem selectedBound22289 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env22290 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,32768,65536,131072,262144,42253,32769,4096,4194304,176413,73736,8328,135233,4497416,45404,172381,4294795,1284,98339,40972,4235393,1344,137]

theorem envBound22290 : H12AffineFastState.Bounded env22290 := by
  intro p hp
  have h : env22290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22289_22290 : H12AffineEnvironment.transform 31 98339 env22289 = env22290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 98339 env22289 == env22290) = true)

def env22291 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,32768,65536,1344,262144,42253,32769,4096,4194304,46173,73736,8328,5377,4497416,45404,42013,4294795,1284,98339,40972,4235393,1344,137]

theorem envBound22291 : H12AffineFastState.Bounded env22291 := by
  intro p hp
  have h : env22291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22290_22291 : H12AffineEnvironment.transform 16 1344 env22290 = env22291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env22290 == env22291) = true)

theorem identity22291 : scanCanonicalize (H12AffineFastState.compose env22291 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound22291 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22292 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,8461,65536,1344,262144,1024,8460,4096,4194304,5456,73736,8328,5377,4456709,4177,1296,4270470,1284,74030,257,4194700,1344,137]

theorem envBound22292 : H12AffineFastState.Bounded env22292 := by
  intro p hp
  have h : env22292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22291_22292 : H12AffineEnvironment.transform 14 8461 env22291 = env22292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env22291 == env22292) = true)

theorem identity22292 : scanCanonicalize (H12AffineFastState.compose env22292 (packedSelected [1,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 264224) := by decide +kernel

theorem selectedBound22292 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env22293 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,8461,65536,1344,262144,1024,8460,4096,264224,5456,73736,8328,5377,2341,4177,1296,336294,1284,74030,257,264620,1344,137]

theorem envBound22293 : H12AffineFastState.Bounded env22293 := by
  intro p hp
  have h : env22293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22292_22293 : H12AffineEnvironment.transform 21 264224 env22292 = env22293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 264224 env22292 == env22293) = true)

theorem identity22293 : scanCanonicalize (H12AffineFastState.compose env22293 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound22293 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env22294 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,8461,8323,1344,262144,1024,8460,4096,264224,5456,139,8328,5377,2341,4177,1296,262437,1284,429,257,264620,1344,137]

theorem envBound22294 : H12AffineFastState.Bounded env22294 := by
  intro p hp
  have h : env22294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22293_22294 : H12AffineEnvironment.transform 15 8323 env22293 = env22294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env22293 == env22294) = true)

theorem identity22294 : scanCanonicalize (H12AffineFastState.compose env22294 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound22294 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env22295 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,8461,8323,1344,2341,1024,8460,4096,261,5456,139,8328,5377,2341,4177,1296,2048,1284,429,257,137,1344,137]

theorem envBound22295 : H12AffineFastState.Bounded env22295 := by
  intro p hp
  have h : env22295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22294_22295 : H12AffineEnvironment.transform 17 2341 env22294 = env22295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env22294 == env22295) = true)

theorem identity22295 : scanCanonicalize (H12AffineFastState.compose env22295 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound22295 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22296 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,2088,4177,2341,2219,1344,2341,1024,2340,4096,261,5456,139,2208,5377,2341,4177,1296,2048,1284,429,257,137,1344,137]

theorem envBound22296 : H12AffineFastState.Bounded env22296 := by
  intro p hp
  have h : env22296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22295_22296 : H12AffineEnvironment.transform 12 2088 env22295 = env22296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env22295 == env22296) = true)

theorem identity22296 : scanCanonicalize (H12AffineFastState.compose env22296 (packedSelected [2,4] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound22296 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env22297 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,2088,1345,2341,2219,1344,2341,1024,2340,1296,261,64,139,2208,17,2341,1345,1296,2048,1284,429,257,137,1344,137]

theorem envBound22297 : H12AffineFastState.Bounded env22297 := by
  intro p hp
  have h : env22297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22296_22297 : H12AffineEnvironment.transform 11 1296 env22296 = env22297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env22296 == env22297) = true)

theorem identity22297 : scanCanonicalize (H12AffineFastState.compose env22297 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 166) := by decide +kernel

theorem selectedBound22297 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22298 : List Nat := [2,4,8,16,32,64,128,166,137,1024,2048,1206,2088,1255,2179,2219,1254,2179,1024,2178,1206,163,64,139,2208,17,2179,1255,1206,2048,1186,11,167,137,1254,137]

theorem envBound22298 : H12AffineFastState.Bounded env22298 := by
  intro p hp
  have h : env22298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22297_22298 : H12AffineEnvironment.transform 7 166 env22297 = env22298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 166 env22297 == env22298) = true)

def env22299 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,32768,65536,1345,262144,42253,32769,4096,4194304,46172,73736,8328,5376,4497416,45404,42012,4294795,1284,98339,40972,4235393,1344,137]

theorem envBound22299 : H12AffineFastState.Bounded env22299 := by
  intro p hp
  have h : env22299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22290_22299 : H12AffineEnvironment.transform 16 1345 env22290 = env22299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env22290 == env22299) = true)

def env22300 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914001,134217728,8519745,676864,1073741824,25412673,4294967296,8536385,4315938986,164610305,512]

theorem envBound22300 : H12AffineFastState.Bounded env22300 := by
  intro p hp
  have h : env22300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21971_22300 : H12AffineEnvironment.transform 20 4097 env21971 = env22300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env21971 == env22300) = true)

theorem identity22300 : scanCanonicalize (H12AffineFastState.compose env22300 (packedSelected [14] rootPS)) = affineNative (2^(26+1) ^^^ 29855760) := by decide +kernel

theorem selectedBound22300 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env22301 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914001,29855760,8519745,676864,1073741824,25412673,4294967296,8536385,4315938986,545041,512]

theorem envBound22301 : H12AffineFastState.Bounded env22301 := by
  intro p hp
  have h : env22301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22300_22301 : H12AffineEnvironment.transform 26 29855760 env22300 = env22301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 29855760 env22300 == env22301) = true)

def env22302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,147520,16777216,8328,672785,21352528,16385,676864,1073741824,16876545,4294967296,257,4315938986,545041,512]

theorem envBound22302 : H12AffineFastState.Bounded env22302 := by
  intro p hp
  have h : env22302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22301_22302 : H12AffineEnvironment.transform 22 147520 env22301 = env22302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env22301 == env22302) = true)

def env22303 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,4194304,17664,16777216,8328,541009,21352528,16385,545088,1073741824,16876545,4294967296,257,4315938986,545041,512]

theorem envBound22303 : H12AffineFastState.Bounded env22303 := by
  intro p hp
  have h : env22303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22302_22303 : H12AffineEnvironment.transform 16 1344 env22302 = env22303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env22302 == env22303) = true)

theorem identity22303 : scanCanonicalize (H12AffineFastState.compose env22303 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound22303 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env22304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,4194304,17664,98565,8328,541009,4477269,16385,545088,1073741824,1284,4294967296,257,4299260335,545041,512]

theorem envBound22304 : H12AffineFastState.Bounded env22304 := by
  intro p hp
  have h : env22304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22303_22304 : H12AffineEnvironment.transform 23 98565 env22303 = env22304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env22303 == env22304) = true)

def env22305 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,21504,32769,4097,4194304,17664,98565,8328,5457,4477269,16385,1344,1073741824,1284,4294967296,257,4299260335,1297,512]

theorem envBound22305 : H12AffineFastState.Bounded env22305 := by
  intro p hp
  have h : env22305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22304_22305 : H12AffineEnvironment.transform 18 21504 env22304 = env22305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21504 env22304 == env22305) = true)

def env22306 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,1296,262144,21504,32769,4097,4194304,17664,98565,8328,5377,4477189,16385,1296,1073741824,1284,4294967296,257,4299260335,1297,512]

theorem envBound22306 : H12AffineFastState.Bounded env22306 := by
  intro p hp
  have h : env22306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22305_22306 : H12AffineEnvironment.transform 5 16 env22305 = env22306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22305 == env22306) = true)

def env22307 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,16384,32768,65536,1296,262144,16656,32769,1297,4194304,17664,98565,8328,17,4473877,16385,1296,1073741824,1284,4294967296,257,4299260335,1297,512]

theorem envBound22307 : H12AffineFastState.Bounded env22307 := by
  intro p hp
  have h : env22307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22306_22307 : H12AffineEnvironment.transform 11 1296 env22306 = env22307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env22306 == env22307) = true)

theorem identity22307 : scanCanonicalize (H12AffineFastState.compose env22307 (packedSelected [3,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 1945) := by decide +kernel

theorem selectedBound22307 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env22308 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1945,32768,65536,1296,262144,1673,32769,1297,4194304,665,98565,8328,17,4457356,1944,1296,1073741824,1284,4294967296,257,4299260335,1297,512]

theorem envBound22308 : H12AffineFastState.Bounded env22308 := by
  intro p hp
  have h : env22308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22307_22308 : H12AffineEnvironment.transform 13 1945 env22307 = env22308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1945 env22307 == env22308) = true)

def env22309 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1296,8192,1297,32768,65536,1296,262144,1025,32769,1297,4194304,17,98565,8328,17,4456708,1296,1296,1073741824,1284,4294967296,257,4299260335,1297,136]

theorem envBound22309 : H12AffineFastState.Bounded env22309 := by
  intro p hp
  have h : env22309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22308_22309 : H12AffineEnvironment.transform 8 136 env22308 = env22309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env22308 == env22309) = true)

def env22310 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,0,8192,1,32768,65536,0,262144,273,32769,1,4194304,17,98565,8328,17,4456708,0,0,1073741824,20,4294967296,257,4299260335,1,136]

theorem envBound22310 : H12AffineFastState.Bounded env22310 := by
  intro p hp
  have h : env22310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22309_22310 : H12AffineEnvironment.transform 9 272 env22309 = env22310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env22309 == env22310) = true)

theorem identity22310 : scanCanonicalize (H12AffineFastState.compose env22310 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 362499) := by decide +kernel

theorem selectedBound22310 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22311 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,0,8192,1,32768,65536,0,262144,273,32769,1,4194304,17,98565,8328,17,4456708,0,0,1073741824,20,362499,257,4458924,1,136]

theorem envBound22311 : H12AffineFastState.Bounded env22311 := by
  intro p hp
  have h : env22311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22310_22311 : H12AffineEnvironment.transform 31 362499 env22310 = env22311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 362499 env22310 == env22311) = true)

theorem identity22311 : scanCanonicalize (H12AffineFastState.compose env22311 (packedSelected [3] rootPS)) = affineNative (2^(29+1) ^^^ 4196612) := by decide +kernel

theorem selectedBound22311 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22312 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,0,8192,1,32768,65536,0,262144,273,32769,1,4194304,17,98565,8328,17,4456708,0,0,4196612,20,362499,257,4458924,1,136]

theorem envBound22312 : H12AffineFastState.Bounded env22312 := by
  intro p hp
  have h : env22312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22311_22312 : H12AffineEnvironment.transform 29 4196612 env22311 = env22312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4196612 env22311 == env22312) = true)

theorem identity22312 : scanCanonicalize (H12AffineFastState.compose env22312 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound22312 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env22313 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,0,8192,1,32768,65536,0,43049,273,32769,1,4194304,17,98565,8328,17,4237613,0,0,4196612,20,73770,257,4235653,1,136]

theorem envBound22313 : H12AffineFastState.Bounded env22313 := by
  intro p hp
  have h : env22313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22312_22313 : H12AffineEnvironment.transform 17 43049 env22312 = env22313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env22312 == env22313) = true)

def env22314 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,0,8192,1,32768,65536,0,43049,273,32769,1,10248,17,98565,8328,17,33061,0,0,8460,20,73770,257,35213,1,136]

theorem envBound22314 : H12AffineFastState.Bounded env22314 := by
  intro p hp
  have h : env22314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22313_22314 : H12AffineEnvironment.transform 21 10248 env22313 = env22314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env22313 == env22314) = true)

def env22315 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,0,8192,1,8232,65536,0,2049,273,8233,1,10248,17,74029,8328,17,8461,0,0,8460,20,73770,257,10661,1,136]

theorem envBound22315 : H12AffineFastState.Bounded env22315 := by
  intro p hp
  have h : env22315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22314_22315 : H12AffineEnvironment.transform 14 8232 env22314 = env22315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env22314 == env22315) = true)

theorem identity22315 : scanCanonicalize (H12AffineFastState.compose env22315 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound22315 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22316 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,0,2316,1,2340,65536,0,2049,273,2341,1,260,17,67617,2436,17,2049,0,0,2048,20,67878,257,169,1,136]

theorem envBound22316 : H12AffineFastState.Bounded env22316 := by
  intro p hp
  have h : env22316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22315_22316 : H12AffineEnvironment.transform 12 2316 env22315 = env22316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env22315 == env22316) = true)

def env22317 : List Nat := [2,4,8,16,32,16,128,36,136,52,2048,0,2088,1,2048,65536,0,2049,53,2049,1,32,17,67617,2208,17,2049,0,0,2048,20,67586,37,169,1,136]

theorem envBound22317 : H12AffineFastState.Bounded env22317 := by
  intro p hp
  have h : env22317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22316_22317 : H12AffineEnvironment.transform 7 36 env22316 = env22317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env22316 == env22317) = true)

theorem identity22317 : scanCanonicalize (H12AffineFastState.compose env22317 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 2051) := by decide +kernel

theorem selectedBound22317 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22318 : List Nat := [2,4,8,16,32,16,128,36,136,52,2048,0,2088,1,2048,2051,0,2049,53,2049,1,32,17,34,2208,17,2049,0,0,2048,20,1,37,169,1,136]

theorem envBound22318 : H12AffineFastState.Bounded env22318 := by
  intro p hp
  have h : env22318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22317_22318 : H12AffineEnvironment.transform 15 2051 env22317 = env22318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2051 env22317 == env22318) = true)

def env22319 : List Nat := [2,4,8,16,32,16,128,36,136,52,0,0,40,1,0,3,0,1,53,1,1,32,17,34,160,17,1,0,0,0,20,1,37,169,1,136]

theorem envBound22319 : H12AffineFastState.Bounded env22319 := by
  intro p hp
  have h : env22319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22318_22319 : H12AffineEnvironment.transform 10 0 env22318 = env22319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env22318 == env22319) = true)

def env22320 : List Nat := [2,4,8,16,0,16,128,4,136,20,0,0,8,1,0,3,0,1,21,1,1,0,17,2,128,17,1,0,0,0,20,1,5,137,1,136]

theorem envBound22320 : H12AffineFastState.Bounded env22320 := by
  intro p hp
  have h : env22320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22319_22320 : H12AffineEnvironment.transform 4 0 env22319 = env22320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22319 == env22320) = true)

def env22321 : List Nat := [2,4,8,16,1,16,128,5,136,21,0,0,9,1,0,3,0,1,20,1,1,1,17,3,129,17,1,0,0,0,20,1,4,136,1,136]

theorem envBound22321 : H12AffineFastState.Bounded env22321 := by
  intro p hp
  have h : env22321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22319_22321 : H12AffineEnvironment.transform 4 1 env22319 = env22321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22319 == env22321) = true)

theorem identity22321 : scanCanonicalize (H12AffineFastState.compose env22321 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22321 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22322 : List Nat := [2,4,8,16,1,16,9,5,1,21,0,0,9,1,0,3,0,1,20,1,1,1,17,3,8,17,1,0,0,0,20,1,4,1,1,1]

theorem envBound22322 : H12AffineFastState.Bounded env22322 := by
  intro p hp
  have h : env22322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22321_22322 : H12AffineEnvironment.transform 6 9 env22321 = env22322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22321 == env22322) = true)

def leafEnv22322 : List Nat := [2,4,8,16,1,16,9,5,1,21,0,0,9,1,0,3,0,1,20,1,1,1,17,3,21,8,1,17,1,0,0,0,20,1,4,1,5,2,1,1,0,1,1]

def active22322 : List Nat := [0,1,2,3]

def tree22322 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22322 : H12WitnessSearch.Good tree22322 := H12GlobalWitnessIndex.good

theorem leafIdentity22322 : H12AffineFastState.composeSystem env22322 rootObs = leafEnv22322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22322 rootObs == leafEnv22322) = true)

theorem terminalChecked22322 : H12PackedTerminal.terminalCheckFast leafEnv22322 active22322 tree22322 = true := by decide +kernel

def env22323 : List Nat := [2,4,8,16,32,16,128,36,136,52,1,0,41,1,1,2,0,0,53,0,1,32,17,34,161,17,0,0,0,1,20,1,37,169,1,136]

theorem envBound22323 : H12AffineFastState.Bounded env22323 := by
  intro p hp
  have h : env22323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22318_22323 : H12AffineEnvironment.transform 10 1 env22318 = env22323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env22318 == env22323) = true)

theorem identity22323 : scanCanonicalize (H12AffineFastState.compose env22323 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound22323 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22324 : List Nat := [2,4,8,16,32,16,41,36,33,52,1,0,41,1,1,2,0,0,53,0,1,32,17,34,8,17,0,0,0,1,20,1,37,0,1,33]

theorem envBound22324 : H12AffineFastState.Bounded env22324 := by
  intro p hp
  have h : env22324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22323_22324 : H12AffineEnvironment.transform 6 41 env22323 = env22324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env22323 == env22324) = true)

def env22325 : List Nat := [2,4,8,16,32,16,128,37,136,53,2048,0,2089,1,2049,65536,0,2049,52,2048,1,33,17,67617,2209,17,2049,0,0,2048,20,67587,36,169,1,136]

theorem envBound22325 : H12AffineFastState.Bounded env22325 := by
  intro p hp
  have h : env22325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22316_22325 : H12AffineEnvironment.transform 7 37 env22316 = env22325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env22316 == env22325) = true)

theorem identity22325 : scanCanonicalize (H12AffineFastState.compose env22325 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22325 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22326 : List Nat := [2,4,8,16,0,16,128,5,136,21,2048,0,2057,1,2049,65536,0,2049,20,2048,1,1,17,67585,2177,17,2049,0,0,2048,20,67587,4,137,1,136]

theorem envBound22326 : H12AffineFastState.Bounded env22326 := by
  intro p hp
  have h : env22326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22325_22326 : H12AffineEnvironment.transform 4 0 env22325 = env22326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22325 == env22326) = true)

theorem identity22326 : scanCanonicalize (H12AffineFastState.compose env22326 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 2187) := by decide +kernel

theorem selectedBound22326 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22327 : List Nat := [2,4,8,16,0,16,128,5,136,21,2048,0,2057,1,2049,2187,0,2049,20,2048,1,1,17,138,2177,17,2049,0,0,2048,20,136,4,137,1,136]

theorem envBound22327 : H12AffineFastState.Bounded env22327 := by
  intro p hp
  have h : env22327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22326_22327 : H12AffineEnvironment.transform 15 2187 env22326 = env22327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2187 env22326 == env22327) = true)

theorem identity22327 : scanCanonicalize (H12AffineFastState.compose env22327 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound22327 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22328 : List Nat := [2,4,8,16,0,16,128,5,136,21,1,0,8,1,0,138,0,0,20,1,1,1,17,138,128,17,0,0,0,1,20,136,4,137,1,136]

theorem envBound22328 : H12AffineFastState.Bounded env22328 := by
  intro p hp
  have h : env22328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22327_22328 : H12AffineEnvironment.transform 10 1 env22327 = env22328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env22327 == env22328) = true)

def leafEnv22328 : List Nat := [2,4,8,16,0,16,128,5,136,21,1,0,8,1,0,138,0,0,20,1,1,1,17,138,21,128,1,17,0,0,0,1,20,136,4,137,5,2,1,136,0,1,1]

def active22328 : List Nat := [0,1,2,3,6]

def tree22328 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22328 : H12WitnessSearch.Good tree22328 := H12GlobalWitnessIndex.good

theorem leafIdentity22328 : H12AffineFastState.composeSystem env22328 rootObs = leafEnv22328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22328 rootObs == leafEnv22328) = true)

end H12CloudChart2