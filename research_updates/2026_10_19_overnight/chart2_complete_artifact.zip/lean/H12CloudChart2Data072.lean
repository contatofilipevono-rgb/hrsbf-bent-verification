import H12CloudChart2Data071

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound17661 : H12AffineFastState.Bounded env17661 := by
  intro p hp
  have h : env17661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17660_17661 : H12AffineEnvironment.transform 8 1 env17660 = env17661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env17660 == env17661) = true)

theorem identity17661 : scanCanonicalize (H12AffineFastState.compose env17661 (packedSelected [1,4] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound17661 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env17662 : List Nat := [2,4,8,16,32,1,8,4,1,4,32,0,56,16,1,3,0,48,4,0,1,49,16,2,56,1,1,16,16,49,5,49,4,32,0,1]

theorem envBound17662 : H12AffineFastState.Bounded env17662 := by
  intro p hp
  have h : env17662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17661_17662 : H12AffineEnvironment.transform 5 1 env17661 = env17662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env17661 == env17662) = true)

theorem identity17662 : scanCanonicalize (H12AffineFastState.compose env17662 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound17662 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env17663 : List Nat := [2,4,8,16,17,1,8,4,1,4,17,0,9,16,1,3,0,1,4,0,1,0,16,2,9,1,1,16,16,0,5,0,4,17,0,1]

theorem envBound17663 : H12AffineFastState.Bounded env17663 := by
  intro p hp
  have h : env17663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17662_17663 : H12AffineEnvironment.transform 4 17 env17662 = env17663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env17662 == env17663) = true)

theorem identity17663 : scanCanonicalize (H12AffineFastState.compose env17663 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17663 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17664 : List Nat := [2,4,8,1,0,1,8,4,1,4,0,0,9,1,1,3,0,1,4,0,1,0,1,2,9,1,1,1,1,0,5,0,4,0,0,1]

theorem envBound17664 : H12AffineFastState.Bounded env17664 := by
  intro p hp
  have h : env17664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17663_17664 : H12AffineEnvironment.transform 3 1 env17663 = env17664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17663 == env17664) = true)

def env17665 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,1092,8192,1045,0,65536,1092,8833,1024,1,1093,8321,16,65536,8328,64,513,1045,1045,1073741824,1025,8201,5,65570,1093,512]

theorem envBound17665 : H12AffineFastState.Bounded env17665 := by
  intro p hp
  have h : env17665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17653_17665 : H12AffineEnvironment.transform 7 5 env17653 = env17665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17653 == env17665) = true)

theorem identity17665 : scanCanonicalize (H12AffineFastState.compose env17665 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound17665 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env17666 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,1092,8192,1045,0,34,1092,8833,1024,1,1093,8321,16,34,8328,64,513,1045,1045,1073741824,1025,8201,5,0,1093,512]

theorem envBound17666 : H12AffineFastState.Bounded env17666 := by
  intro p hp
  have h : env17666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17665_17666 : H12AffineEnvironment.transform 15 34 env17665 = env17666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env17665 == env17666) = true)

theorem identity17666 : scanCanonicalize (H12AffineFastState.compose env17666 (packedSelected [1,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 2081) := by decide +kernel

theorem selectedBound17666 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env17667 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,1092,8192,1045,0,34,1092,8833,1024,1,1093,8321,16,34,8328,64,513,1045,1045,2081,1025,8201,5,0,1093,512]

theorem envBound17667 : H12AffineFastState.Bounded env17667 := by
  intro p hp
  have h : env17667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17666_17667 : H12AffineEnvironment.transform 29 2081 env17666 = env17667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2081 env17666 == env17667) = true)

theorem identity17667 : scanCanonicalize (H12AffineFastState.compose env17667 (packedSelected [3,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound17667 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env17668 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,1092,8,1045,0,34,1092,649,1024,1,1093,137,16,34,128,64,513,1045,1045,2081,1025,1,5,0,1093,512]

theorem envBound17668 : H12AffineFastState.Bounded env17668 := by
  intro p hp
  have h : env17668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17667_17668 : H12AffineEnvironment.transform 12 8 env17667 = env17668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env17667 == env17668) = true)

theorem identity17668 : scanCanonicalize (H12AffineFastState.compose env17668 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound17668 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17669 : List Nat := [2,4,8,16,32,64,128,5,169,1024,2048,1092,8,1045,0,34,1092,32,1024,1,1093,137,16,34,128,64,168,1045,1045,2081,1025,1,5,0,1093,169]

theorem envBound17669 : H12AffineFastState.Bounded env17669 := by
  intro p hp
  have h : env17669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17668_17669 : H12AffineEnvironment.transform 8 169 env17668 = env17669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env17668 == env17669) = true)

theorem identity17669 : scanCanonicalize (H12AffineFastState.compose env17669 (packedSelected [0,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound17669 : packedSelected [0,4,7] rootPS < 2^1333 := by decide +kernel

def env17670 : List Nat := [2,4,8,16,32,1,128,5,169,1024,2048,1029,8,1045,0,34,1029,32,1024,1,1028,137,16,34,128,1,168,1045,1045,2081,1025,1,5,0,1028,169]

theorem envBound17670 : H12AffineFastState.Bounded env17670 := by
  intro p hp
  have h : env17670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17669_17670 : H12AffineEnvironment.transform 5 1 env17669 = env17670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env17669 == env17670) = true)

theorem identity17670 : scanCanonicalize (H12AffineFastState.compose env17670 (packedSelected [4,11] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound17670 : packedSelected [4,11] rootPS < 2^1333 := by decide +kernel

def env17671 : List Nat := [2,4,8,16,32,1,41,5,0,1024,2048,1029,8,1045,0,34,1029,32,1024,1,1028,32,16,34,41,1,1,1045,1045,2081,1025,1,5,0,1028,0]

theorem envBound17671 : H12AffineFastState.Bounded env17671 := by
  intro p hp
  have h : env17671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17670_17671 : H12AffineEnvironment.transform 6 41 env17670 = env17671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env17670 == env17671) = true)

theorem identity17671 : scanCanonicalize (H12AffineFastState.compose env17671 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound17671 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17672 : List Nat := [2,4,8,16,17,1,24,5,0,1024,2048,1029,8,1045,0,19,1029,17,1024,1,1028,17,16,19,24,1,1,1045,1045,2064,1025,1,5,0,1028,0]

theorem envBound17672 : H12AffineFastState.Bounded env17672 := by
  intro p hp
  have h : env17672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17671_17672 : H12AffineEnvironment.transform 4 17 env17671 = env17672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env17671 == env17672) = true)

theorem identity17672 : scanCanonicalize (H12AffineFastState.compose env17672 (packedSelected [0,1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17672 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env17673 : List Nat := [2,4,8,1,0,1,9,5,0,1024,2048,1029,8,1028,0,2,1029,0,1024,1,1028,0,1,2,9,1,1,1028,1028,2049,1025,1,5,0,1028,0]

theorem envBound17673 : H12AffineFastState.Bounded env17673 := by
  intro p hp
  have h : env17673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17672_17673 : H12AffineEnvironment.transform 3 1 env17672 = env17673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17672 == env17673) = true)

def env17674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,17665,16777216,8328,541009,4609044,148800,676864,1073741824,17006913,4294967296,132160,4315938986,17420309,512]

theorem envBound17674 : H12AffineFastState.Bounded env17674 := by
  intro p hp
  have h : env17674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17501_17674 : H12AffineEnvironment.transform 22 17665 env17501 = env17674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17665 env17501 == env17674) = true)

def env17675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,4194304,17665,16777216,8328,541009,4477268,16384,545088,1073741824,16876545,4294967296,256,4315938986,17420309,512]

theorem envBound17675 : H12AffineFastState.Bounded env17675 := by
  intro p hp
  have h : env17675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17674_17675 : H12AffineEnvironment.transform 16 1344 env17674 = env17675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env17674 == env17675) = true)

theorem identity17675 : scanCanonicalize (H12AffineFastState.compose env17675 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 98564) := by decide +kernel

theorem selectedBound17675 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env17676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,4194304,17665,98564,8328,541009,4477268,16384,545088,1073741824,1285,4294967296,256,4299260334,545041,512]

theorem envBound17676 : H12AffineFastState.Bounded env17676 := by
  intro p hp
  have h : env17676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17675_17676 : H12AffineEnvironment.transform 23 98564 env17675 = env17676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98564 env17675 == env17676) = true)

def env17677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,21504,32769,4097,4194304,17665,98564,8328,5457,4477268,16384,1344,1073741824,1285,4294967296,256,4299260334,1297,512]

theorem envBound17677 : H12AffineFastState.Bounded env17677 := by
  intro p hp
  have h : env17677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17676_17677 : H12AffineEnvironment.transform 18 21504 env17676 = env17677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21504 env17676 == env17677) = true)

def env17678 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,1296,262144,21504,32769,4097,4194304,17665,98564,8328,5377,4477188,16384,1296,1073741824,1285,4294967296,256,4299260334,1297,512]

theorem envBound17678 : H12AffineFastState.Bounded env17678 := by
  intro p hp
  have h : env17678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17677_17678 : H12AffineEnvironment.transform 5 16 env17677 = env17678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17677 == env17678) = true)

theorem identity17678 : scanCanonicalize (H12AffineFastState.compose env17678 (packedSelected [3,8,12,15,17,19,21] rootPS)) = affineNative (2^(31+1) ^^^ 4235936) := by decide +kernel

theorem selectedBound17678 : packedSelected [3,8,12,15,17,19,21] rootPS < 2^1333 := by decide +kernel

def env17679 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,1296,262144,21504,32769,4097,4194304,17665,98564,8328,5377,4477188,16384,1296,1073741824,1285,4235936,256,74510,1297,512]

theorem envBound17679 : H12AffineFastState.Bounded env17679 := by
  intro p hp
  have h : env17679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17678_17679 : H12AffineEnvironment.transform 31 4235936 env17678 = env17679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4235936 env17678 == env17679) = true)

theorem identity17679 : scanCanonicalize (H12AffineFastState.compose env17679 (packedSelected [9,22] rootPS)) = affineNative (2^(13+1) ^^^ 4096) := by decide +kernel

theorem selectedBound17679 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env17680 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,262144,1024,32769,4097,4194304,5377,98564,8328,5377,4456708,4096,1296,1073741824,1285,4235936,256,74510,1297,512]

theorem envBound17680 : H12AffineFastState.Bounded env17680 := by
  intro p hp
  have h : env17680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17679_17680 : H12AffineEnvironment.transform 13 4096 env17679 = env17680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env17679 == env17680) = true)

theorem identity17680 : scanCanonicalize (H12AffineFastState.compose env17680 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(29+1) ^^^ 4227617) := by decide +kernel

theorem selectedBound17680 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env17681 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,262144,1024,32769,4097,4194304,5377,98564,8328,5377,4456708,4096,1296,4227617,1285,4235936,256,74510,1297,512]

theorem envBound17681 : H12AffineFastState.Bounded env17681 := by
  intro p hp
  have h : env17681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17680_17681 : H12AffineEnvironment.transform 29 4227617 env17680 = env17681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4227617 env17680 == env17681) = true)

theorem identity17681 : scanCanonicalize (H12AffineFastState.compose env17681 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(21+1) ^^^ 34848) := by decide +kernel

theorem selectedBound17681 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env17682 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,262144,1024,32769,4097,34848,5377,98564,8328,5377,297252,4096,1296,2561,1285,10880,256,74510,1297,512]

theorem envBound17682 : H12AffineFastState.Bounded env17682 := by
  intro p hp
  have h : env17682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17681_17682 : H12AffineEnvironment.transform 21 34848 env17681 = env17682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 34848 env17681 == env17682) = true)

theorem identity17682 : scanCanonicalize (H12AffineFastState.compose env17682 (packedSelected [1,3,5,12,13,24] rootPS)) = affineNative (2^(17+1) ^^^ 2476) := by decide +kernel

theorem selectedBound17682 : packedSelected [1,3,5,12,13,24] rootPS < 2^1333 := by decide +kernel

def env17683 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,2476,1024,32769,4097,34848,5377,98564,8328,5377,32904,4096,1296,2561,1285,10880,256,74510,1297,512]

theorem envBound17683 : H12AffineFastState.Bounded env17683 := by
  intro p hp
  have h : env17683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17682_17683 : H12AffineEnvironment.transform 17 2476 env17682 = env17683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2476 env17682 == env17683) = true)

theorem identity17683 : scanCanonicalize (H12AffineFastState.compose env17683 (packedSelected [8,12,13,28] rootPS)) = affineNative (2^(12+1) ^^^ 2721) := by decide +kernel

theorem selectedBound17683 : packedSelected [8,12,13,28] rootPS < 2^1333 := by decide +kernel

def env17684 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,2721,4096,32768,65536,1296,2476,1024,32769,4097,34848,5377,98564,2601,5377,32904,4096,1296,2561,1285,33,256,68015,1297,512]

theorem envBound17684 : H12AffineFastState.Bounded env17684 := by
  intro p hp
  have h : env17684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17683_17684 : H12AffineEnvironment.transform 12 2721 env17683 = env17684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2721 env17683 == env17684) = true)

theorem identity17684 : scanCanonicalize (H12AffineFastState.compose env17684 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 2852) := by decide +kernel

theorem selectedBound17684 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env17685 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,2721,4096,2852,65536,1296,2476,1024,2853,4097,772,5377,68128,2601,5377,2988,4096,1296,2561,1285,33,256,68015,1297,512]

theorem envBound17685 : H12AffineFastState.Bounded env17685 := by
  intro p hp
  have h : env17685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17684_17685 : H12AffineEnvironment.transform 14 2852 env17684 = env17685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2852 env17684 == env17685) = true)

theorem identity17685 : scanCanonicalize (H12AffineFastState.compose env17685 (packedSelected [5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1724) := by decide +kernel

theorem selectedBound17685 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env17686 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1724,2721,1724,2852,65536,1296,2476,1024,2853,1725,772,957,68128,2601,957,2988,1724,1296,2561,1285,33,256,68015,1297,512]

theorem envBound17686 : H12AffineFastState.Bounded env17686 := by
  intro p hp
  have h : env17686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17685_17686 : H12AffineEnvironment.transform 11 1724 env17685 = env17686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1724 env17685 == env17686) = true)

theorem identity17686 : scanCanonicalize (H12AffineFastState.compose env17686 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(8+1) ^^^ 428) := by decide +kernel

theorem selectedBound17686 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env17687 : List Nat := [2,4,8,16,32,16,128,256,428,1024,2048,1296,2317,1296,2184,65536,1296,2476,1024,2185,1297,168,17,67980,2437,17,2048,1296,1296,2477,1285,33,256,68015,1297,428]

theorem envBound17687 : H12AffineFastState.Bounded env17687 := by
  intro p hp
  have h : env17687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17686_17687 : H12AffineEnvironment.transform 8 428 env17686 = env17687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env17686 == env17687) = true)

theorem identity17687 : scanCanonicalize (H12AffineFastState.compose env17687 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound17687 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17688 : List Nat := [2,4,8,16,32,16,128,256,428,1024,1213,1296,1456,1296,1077,65536,1296,1297,1024,1076,1297,168,17,66865,1336,17,1213,1296,1296,1296,1285,33,256,66834,1297,428]

theorem envBound17688 : H12AffineFastState.Bounded env17688 := by
  intro p hp
  have h : env17688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17687_17688 : H12AffineEnvironment.transform 10 1213 env17687 = env17688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env17687 == env17688) = true)

theorem identity17688 : scanCanonicalize (H12AffineFastState.compose env17688 (packedSelected [0,1,4] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound17688 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env17689 : List Nat := [2,4,8,16,32,16,128,256,428,30,163,270,430,270,43,65536,270,271,30,42,271,168,17,65839,294,17,163,270,270,270,283,33,256,65804,271,428]

theorem envBound17689 : H12AffineFastState.Bounded env17689 := by
  intro p hp
  have h : env17689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17688_17689 : H12AffineEnvironment.transform 9 30 env17688 = env17689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env17688 == env17689) = true)

theorem identity17689 : scanCanonicalize (H12AffineFastState.compose env17689 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 8) := by decide +kernel

theorem selectedBound17689 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17690 : List Nat := [2,4,8,16,32,16,128,256,428,30,163,270,430,270,43,8,270,271,30,42,271,168,17,295,294,17,163,270,270,270,283,33,256,260,271,428]

theorem envBound17690 : H12AffineFastState.Bounded env17690 := by
  intro p hp
  have h : env17690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17689_17690 : H12AffineEnvironment.transform 15 8 env17689 = env17690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8 env17689 == env17690) = true)

theorem identity17690 : scanCanonicalize (H12AffineFastState.compose env17690 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 188) := by decide +kernel

theorem selectedBound17690 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env17691 : List Nat := [2,4,8,16,32,16,128,188,16,30,163,178,18,178,43,8,178,179,30,42,179,168,17,155,154,17,163,178,178,178,167,33,188,184,179,16]

theorem envBound17691 : H12AffineFastState.Bounded env17691 := by
  intro p hp
  have h : env17691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17690_17691 : H12AffineEnvironment.transform 7 188 env17690 = env17691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env17690 == env17691) = true)

theorem identity17691 : scanCanonicalize (H12AffineFastState.compose env17691 (packedSelected [0,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17691 : packedSelected [0,10] rootPS < 2^1333 := by decide +kernel

def env17692 : List Nat := [2,4,8,1,32,1,128,173,1,15,163,163,3,163,43,8,163,162,15,42,162,168,0,138,139,0,163,163,163,163,167,33,173,169,162,1]

theorem envBound17692 : H12AffineFastState.Bounded env17692 := by
  intro p hp
  have h : env17692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17691_17692 : H12AffineEnvironment.transform 3 1 env17691 = env17692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17691 == env17692) = true)

theorem identity17692 : scanCanonicalize (H12AffineFastState.compose env17692 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound17692 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17693 : List Nat := [2,4,8,1,32,1,35,14,1,15,0,0,3,0,43,8,0,1,15,42,1,11,0,41,40,0,0,0,0,0,4,33,14,10,1,1]

theorem envBound17693 : H12AffineFastState.Bounded env17693 := by
  intro p hp
  have h : env17693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17692_17693 : H12AffineEnvironment.transform 6 35 env17692 = env17693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env17692 == env17693) = true)

theorem identity17693 : scanCanonicalize (H12AffineFastState.compose env17693 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound17693 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17694 : List Nat := [2,4,3,1,32,1,35,5,1,4,0,0,3,0,32,3,0,1,4,33,1,0,0,34,35,0,0,0,0,0,4,33,5,1,1,1]

theorem envBound17694 : H12AffineFastState.Bounded env17694 := by
  intro p hp
  have h : env17694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17693_17694 : H12AffineEnvironment.transform 2 3 env17693 = env17694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env17693 == env17694) = true)

def env17695 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,1297,262144,21504,32769,4097,4194304,17665,98564,8328,5376,4477189,16384,1297,1073741824,1285,4294967296,256,4299260334,1297,512]

theorem envBound17695 : H12AffineFastState.Bounded env17695 := by
  intro p hp
  have h : env17695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17677_17695 : H12AffineEnvironment.transform 5 17 env17677 = env17695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17677 == env17695) = true)

theorem identity17695 : scanCanonicalize (H12AffineFastState.compose env17695 (packedSelected [3,8,12,15,17,19,21] rootPS)) = affineNative (2^(29+1) ^^^ 4497708) := by decide +kernel

theorem selectedBound17695 : packedSelected [3,8,12,15,17,19,21] rootPS < 2^1333 := by decide +kernel

def env17696 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,1297,262144,21504,32769,4097,4194304,17665,98564,8328,5376,4477189,16384,1297,4497708,1285,4294967296,256,4299260334,1297,512]

theorem envBound17696 : H12AffineFastState.Bounded env17696 := by
  intro p hp
  have h : env17696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17695_17696 : H12AffineEnvironment.transform 29 4497708 env17695 = env17696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4497708 env17695 == env17696) = true)

theorem identity17696 : scanCanonicalize (H12AffineFastState.compose env17696 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 63529) := by decide +kernel

theorem selectedBound17696 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env17697 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,1297,63529,21504,32769,4097,4194304,17665,98564,8328,5376,4237612,16384,1297,4217093,1285,4294967296,256,4299260334,1297,512]

theorem envBound17697 : H12AffineFastState.Bounded env17697 := by
  intro p hp
  have h : env17697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17696_17697 : H12AffineEnvironment.transform 17 63529 env17696 = env17697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 63529 env17696 == env17697) = true)

def env17698 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,1297,63529,21504,32769,4097,10248,17665,98564,8328,5376,33060,16384,1297,28941,1285,4294967296,256,4295076262,1297,512]

theorem envBound17698 : H12AffineFastState.Bounded env17698 := by
  intro p hp
  have h : env17698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17697_17698 : H12AffineEnvironment.transform 21 10248 env17697 = env17698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env17697 == env17698) = true)

theorem identity17698 : scanCanonicalize (H12AffineFastState.compose env17698 (packedSelected [11] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound17698 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env17699 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,32768,65536,1297,48440,4369,32769,4097,10248,16,98564,8328,5376,33060,1297,1297,13340,1285,4294967296,256,4295076262,1297,512]

theorem envBound17699 : H12AffineFastState.Bounded env17699 := by
  intro p hp
  have h : env17699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17698_17699 : H12AffineEnvironment.transform 13 1297 env17698 = env17699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env17698 == env17699) = true)

theorem identity17699 : scanCanonicalize (H12AffineFastState.compose env17699 (packedSelected [1,3,5] rootPS)) = affineNative (2^(14+1) ^^^ 8865) := by decide +kernel

theorem selectedBound17699 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env17700 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,8865,65536,1297,8089,4369,8864,4097,10248,16,74661,8328,5376,9093,1297,1297,13340,1285,4294967296,256,4295035655,1297,512]

theorem envBound17700 : H12AffineFastState.Bounded env17700 := by
  intro p hp
  have h : env17700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17699_17700 : H12AffineEnvironment.transform 14 8865 env17699 = env17700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8865 env17699 == env17700) = true)

theorem identity17700 : scanCanonicalize (H12AffineFastState.compose env17700 (packedSelected [8,12] rootPS)) = affineNative (2^(12+1) ^^^ 2948) := by decide +kernel

theorem selectedBound17700 : packedSelected [8,12] rootPS < 2^1333 := by decide +kernel

def env17701 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,2948,1297,2341,65536,1297,8089,4369,2340,4097,908,16,67617,2828,5376,2049,1297,1297,8088,1285,4294967296,256,4295035655,1297,512]

theorem envBound17701 : H12AffineFastState.Bounded env17701 := by
  intro p hp
  have h : env17701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17700_17701 : H12AffineEnvironment.transform 12 2948 env17700 = env17701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2948 env17700 == env17701) = true)

theorem identity17701 : scanCanonicalize (H12AffineFastState.compose env17701 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound17701 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17702 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2948,1297,2341,65536,1297,2696,1024,2340,1296,908,16,67617,2828,17,2049,1297,1297,2697,1285,4294967296,256,4295035655,1297,512]

theorem envBound17702 : H12AffineFastState.Bounded env17702 := by
  intro p hp
  have h : env17702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17701_17702 : H12AffineEnvironment.transform 11 1297 env17701 = env17702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env17701 == env17702) = true)

def env17703 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,2948,1,2341,65536,1,2696,272,2340,0,908,16,67617,2828,17,2049,1,1,2697,21,4294967296,256,4295035655,1,512]

theorem envBound17703 : H12AffineFastState.Bounded env17703 := by
  intro p hp
  have h : env17703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17702_17703 : H12AffineEnvironment.transform 9 272 env17702 = env17703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env17702 == env17703) = true)

theorem identity17703 : scanCanonicalize (H12AffineFastState.compose env17703 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 68526) := by decide +kernel

theorem selectedBound17703 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17704 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,2948,1,2341,65536,1,2696,272,2340,0,908,16,67617,2828,17,2049,1,1,2697,21,68526,256,169,1,512]

theorem envBound17704 : H12AffineFastState.Bounded env17704 := by
  intro p hp
  have h : env17704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17703_17704 : H12AffineEnvironment.transform 31 68526 env17703 = env17704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 68526 env17703 == env17704) = true)

def env17705 : List Nat := [2,4,8,16,32,17,128,36,512,52,2048,1,2720,1,2049,65536,1,2696,52,2048,0,680,16,67617,2600,17,2049,1,1,2697,21,68234,36,169,1,512]

theorem envBound17705 : H12AffineFastState.Bounded env17705 := by
  intro p hp
  have h : env17705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17704_17705 : H12AffineEnvironment.transform 7 36 env17704 = env17705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17704 == env17705) = true)

theorem identity17705 : scanCanonicalize (H12AffineFastState.compose env17705 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 2050) := by decide +kernel

theorem selectedBound17705 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17706 : List Nat := [2,4,8,16,32,17,128,36,512,52,2048,1,2720,1,2049,2050,1,2696,52,2048,0,680,16,35,2600,17,2049,1,1,2697,21,648,36,169,1,512]

theorem envBound17706 : H12AffineFastState.Bounded env17706 := by
  intro p hp
  have h : env17706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17705_17706 : H12AffineEnvironment.transform 15 2050 env17705 = env17706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2050 env17705 == env17706) = true)

def env17707 : List Nat := [2,4,8,16,32,17,128,36,512,52,0,1,672,1,1,2,1,648,52,0,0,680,16,35,552,17,1,1,1,649,21,648,36,169,1,512]

theorem envBound17707 : H12AffineFastState.Bounded env17707 := by
  intro p hp
  have h : env17707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17706_17707 : H12AffineEnvironment.transform 10 0 env17706 = env17707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env17706 == env17707) = true)

theorem identity17707 : scanCanonicalize (H12AffineFastState.compose env17707 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound17707 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17708 : List Nat := [2,4,8,16,32,17,40,36,512,52,0,1,520,1,1,2,1,544,52,0,0,512,16,35,552,17,1,1,1,545,21,544,36,1,1,512]

theorem envBound17708 : H12AffineFastState.Bounded env17708 := by
  intro p hp
  have h : env17708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17707_17708 : H12AffineEnvironment.transform 6 40 env17707 = env17708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env17707 == env17708) = true)

def env17709 : List Nat := [2,4,8,16,32,17,40,36,0,52,0,1,8,1,1,2,1,32,52,0,0,0,16,35,40,17,1,1,1,33,21,32,36,1,1,0]

theorem envBound17709 : H12AffineFastState.Bounded env17709 := by
  intro p hp
  have h : env17709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17708_17709 : H12AffineEnvironment.transform 8 0 env17708 = env17709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env17708 == env17709) = true)

theorem identity17709 : scanCanonicalize (H12AffineFastState.compose env17709 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17709 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17710 : List Nat := [2,4,8,16,0,17,8,4,0,20,0,1,8,1,1,2,1,0,20,0,0,0,16,3,8,17,1,1,1,1,21,0,4,1,1,0]

theorem envBound17710 : H12AffineFastState.Bounded env17710 := by
  intro p hp
  have h : env17710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17709_17710 : H12AffineEnvironment.transform 4 0 env17709 = env17710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17709 == env17710) = true)

def leafEnv17710 : List Nat := [2,4,8,16,0,17,8,4,0,20,0,1,8,1,1,2,1,0,20,0,0,0,16,3,21,8,1,17,1,1,1,1,21,0,4,1,4,3,1,0,0,0,1]

def active17710 : List Nat := [0,1,2,3]

def tree17710 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17710 : H12WitnessSearch.Good tree17710 := H12GlobalWitnessIndex.good

theorem leafIdentity17710 : H12AffineFastState.composeSystem env17710 rootObs = leafEnv17710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17710 rootObs == leafEnv17710) = true)

theorem terminalChecked17710 : H12PackedTerminal.terminalCheckFast leafEnv17710 active17710 tree17710 = true := by decide +kernel

def env17711 : List Nat := [2,4,8,16,32,17,40,36,1,52,0,1,9,1,1,2,1,33,52,0,0,1,16,35,41,17,1,1,1,32,21,33,36,1,1,1]

theorem envBound17711 : H12AffineFastState.Bounded env17711 := by
  intro p hp
  have h : env17711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17708_17711 : H12AffineEnvironment.transform 8 1 env17708 = env17711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env17708 == env17711) = true)

def leafEnv17711 : List Nat := [2,4,8,16,32,17,40,36,1,52,0,1,9,1,1,2,1,33,52,0,0,1,16,35,21,41,1,17,1,1,1,32,21,33,36,1,4,35,1,1,0,0,1]

def active17711 : List Nat := [0,1,2,3,4]

def tree17711 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17711 : H12WitnessSearch.Good tree17711 := H12GlobalWitnessIndex.good

theorem leafIdentity17711 : H12AffineFastState.composeSystem env17711 rootObs = leafEnv17711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17711 rootObs == leafEnv17711) = true)

theorem terminalChecked17711 : H12PackedTerminal.terminalCheckFast leafEnv17711 active17711 tree17711 = true := by decide +kernel

def env17712 : List Nat := [2,4,8,16,32,17,128,36,512,52,1,1,673,1,0,3,1,649,52,1,0,680,16,35,553,17,0,1,1,648,21,648,36,169,1,512]

theorem envBound17712 : H12AffineFastState.Bounded env17712 := by
  intro p hp
  have h : env17712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17706_17712 : H12AffineEnvironment.transform 10 1 env17706 = env17712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env17706 == env17712) = true)

def env17713 : List Nat := [2,4,8,16,32,17,128,36,0,52,1,1,161,1,0,3,1,137,52,1,0,168,16,35,41,17,0,1,1,136,21,136,36,169,1,0]

theorem envBound17713 : H12AffineFastState.Bounded env17713 := by
  intro p hp
  have h : env17713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17712_17713 : H12AffineEnvironment.transform 8 0 env17712 = env17713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env17712 == env17713) = true)

theorem identity17713 : scanCanonicalize (H12AffineFastState.compose env17713 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound17713 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17714 : List Nat := [2,4,8,16,32,17,8,36,0,52,1,1,41,1,0,3,1,1,52,1,0,32,16,35,41,17,0,1,1,0,21,0,36,33,1,0]

theorem envBound17714 : H12AffineFastState.Bounded env17714 := by
  intro p hp
  have h : env17714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17713_17714 : H12AffineEnvironment.transform 6 8 env17713 = env17714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17713 == env17714) = true)

def leafEnv17714 : List Nat := [2,4,8,16,32,17,8,36,0,52,1,1,41,1,0,3,1,1,52,1,0,32,16,35,21,41,1,17,0,1,1,0,21,0,36,33,4,34,1,0,0,0,1]

def active17714 : List Nat := [0,1,2,3,4]

def tree17714 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17714 : H12WitnessSearch.Good tree17714 := H12GlobalWitnessIndex.good

theorem leafIdentity17714 : H12AffineFastState.composeSystem env17714 rootObs = leafEnv17714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17714 rootObs == leafEnv17714) = true)

theorem terminalChecked17714 : H12PackedTerminal.terminalCheckFast leafEnv17714 active17714 tree17714 = true := by decide +kernel

def env17715 : List Nat := [2,4,8,16,32,17,128,36,1,52,1,1,160,1,0,3,1,136,52,1,0,169,16,35,40,17,0,1,1,137,21,137,36,169,1,1]

theorem envBound17715 : H12AffineFastState.Bounded env17715 := by
  intro p hp
  have h : env17715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17712_17715 : H12AffineEnvironment.transform 8 1 env17712 = env17715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env17712 == env17715) = true)

theorem identity17715 : scanCanonicalize (H12AffineFastState.compose env17715 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound17715 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17716 : List Nat := [2,4,8,16,32,17,40,36,1,52,1,1,8,1,0,3,1,32,52,1,0,1,16,35,40,17,0,1,1,33,21,33,36,1,1,1]

theorem envBound17716 : H12AffineFastState.Bounded env17716 := by
  intro p hp
  have h : env17716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17715_17716 : H12AffineEnvironment.transform 6 40 env17715 = env17716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env17715 == env17716) = true)

def leafEnv17716 : List Nat := [2,4,8,16,32,17,40,36,1,52,1,1,8,1,0,3,1,32,52,1,0,1,16,35,21,40,1,17,0,1,1,33,21,33,36,1,4,34,1,1,0,0,1]

def active17716 : List Nat := [0,1,2,3,4]

def tree17716 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17716 : H12WitnessSearch.Good tree17716 := H12GlobalWitnessIndex.good

theorem leafIdentity17716 : H12AffineFastState.composeSystem env17716 rootObs = leafEnv17716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17716 rootObs == leafEnv17716) = true)

theorem terminalChecked17716 : H12PackedTerminal.terminalCheckFast leafEnv17716 active17716 tree17716 = true := by decide +kernel

def env17717 : List Nat := [2,4,8,16,32,17,128,37,512,53,2048,1,2721,1,2048,65536,1,2696,53,2049,0,681,16,67617,2601,17,2049,1,1,2697,21,68235,37,169,1,512]

theorem envBound17717 : H12AffineFastState.Bounded env17717 := by
  intro p hp
  have h : env17717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17704_17717 : H12AffineEnvironment.transform 7 37 env17704 = env17717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env17704 == env17717) = true)

theorem identity17717 : scanCanonicalize (H12AffineFastState.compose env17717 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 168) := by decide +kernel

theorem selectedBound17717 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17718 : List Nat := [2,4,8,16,32,17,128,37,168,53,2048,1,2057,1,2048,65536,1,2080,53,2049,0,1,16,67617,2177,17,2049,1,1,2081,21,67619,37,169,1,168]

theorem envBound17718 : H12AffineFastState.Bounded env17718 := by
  intro p hp
  have h : env17718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17717_17718 : H12AffineEnvironment.transform 8 168 env17717 = env17718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 168 env17717 == env17718) = true)

def env17719 : List Nat := [2,4,8,16,32,17,128,37,168,53,0,1,9,1,0,65536,1,32,53,1,0,1,16,65569,129,17,1,1,1,33,21,65571,37,169,1,168]

theorem envBound17719 : H12AffineFastState.Bounded env17719 := by
  intro p hp
  have h : env17719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17718_17719 : H12AffineEnvironment.transform 10 0 env17718 = env17719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env17718 == env17719) = true)

theorem identity17719 : scanCanonicalize (H12AffineFastState.compose env17719 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound17719 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17720 : List Nat := [2,4,8,16,32,17,128,37,168,53,0,1,9,1,0,171,1,32,53,1,0,1,16,138,129,17,1,1,1,33,21,136,37,169,1,168]

theorem envBound17720 : H12AffineFastState.Bounded env17720 := by
  intro p hp
  have h : env17720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17719_17720 : H12AffineEnvironment.transform 15 171 env17719 = env17720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env17719 == env17720) = true)

theorem identity17720 : scanCanonicalize (H12AffineFastState.compose env17720 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17720 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17721 : List Nat := [2,4,8,16,0,17,128,5,136,21,0,1,9,1,0,139,1,0,21,1,0,1,16,138,129,17,1,1,1,1,21,136,5,137,1,136]

theorem envBound17721 : H12AffineFastState.Bounded env17721 := by
  intro p hp
  have h : env17721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17720_17721 : H12AffineEnvironment.transform 4 0 env17720 = env17721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17720 == env17721) = true)

def leafEnv17721 : List Nat := [2,4,8,16,0,17,128,5,136,21,0,1,9,1,0,139,1,0,21,1,0,1,16,138,21,129,1,17,1,1,1,1,21,136,5,137,4,3,1,136,0,0,1]

def active17721 : List Nat := [0,1,2,3,6]

def tree17721 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17721 : H12WitnessSearch.Good tree17721 := H12GlobalWitnessIndex.good

theorem leafIdentity17721 : H12AffineFastState.composeSystem env17721 rootObs = leafEnv17721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17721 rootObs == leafEnv17721) = true)

theorem terminalChecked17721 : H12PackedTerminal.terminalCheckFast leafEnv17721 active17721 tree17721 = true := by decide +kernel

def env17722 : List Nat := [2,4,8,16,32,17,128,37,168,53,1,1,8,1,1,65536,1,33,53,0,0,1,16,65568,128,17,0,1,1,32,21,65570,37,169,1,168]

theorem envBound17722 : H12AffineFastState.Bounded env17722 := by
  intro p hp
  have h : env17722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17718_17722 : H12AffineEnvironment.transform 10 1 env17718 = env17722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env17718 == env17722) = true)

def env17723 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,2948,0,2341,65536,0,2696,273,2340,1,908,16,67617,2828,17,2049,0,0,2697,20,4294967296,256,4295035655,0,512]

theorem envBound17723 : H12AffineFastState.Bounded env17723 := by
  intro p hp
  have h : env17723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17702_17723 : H12AffineEnvironment.transform 9 273 env17702 = env17723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env17702 == env17723) = true)

theorem identity17723 : scanCanonicalize (H12AffineFastState.compose env17723 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 772) := by decide +kernel

theorem selectedBound17723 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17724 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,2948,0,2341,65536,0,2696,273,2340,1,908,16,67617,2828,17,2049,0,0,2697,20,772,256,67587,0,512]

theorem envBound17724 : H12AffineFastState.Bounded env17724 := by
  intro p hp
  have h : env17724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17723_17724 : H12AffineEnvironment.transform 31 772 env17723 = env17724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 772 env17723 == env17724) = true)

def env17725 : List Nat := [2,4,8,16,32,17,128,256,0,273,2048,0,2436,0,2341,65536,0,2184,273,2340,1,396,16,67617,2316,17,2049,0,0,2185,20,260,256,67587,0,0]

theorem envBound17725 : H12AffineFastState.Bounded env17725 := by
  intro p hp
  have h : env17725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17724_17725 : H12AffineEnvironment.transform 8 0 env17724 = env17725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env17724 == env17725) = true)

theorem identity17725 : scanCanonicalize (H12AffineFastState.compose env17725 (packedSelected [0,2,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound17725 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env17726 : List Nat := [2,4,8,16,32,17,40,256,0,273,2048,0,2348,0,2341,65536,0,2080,273,2340,1,292,16,67617,2316,17,2049,0,0,2081,20,260,256,67587,0,0]

theorem envBound17726 : H12AffineFastState.Bounded env17726 := by
  intro p hp
  have h : env17726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17725_17726 : H12AffineEnvironment.transform 6 40 env17725 = env17726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env17725 == env17726) = true)

def env17727 : List Nat := [2,4,8,16,32,17,40,256,0,273,292,0,8,0,1,65536,0,260,273,0,1,292,16,65797,40,17,293,0,0,261,20,260,256,65831,0,0]

theorem envBound17727 : H12AffineFastState.Bounded env17727 := by
  intro p hp
  have h : env17727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17726_17727 : H12AffineEnvironment.transform 10 292 env17726 = env17727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env17726 == env17727) = true)

theorem identity17727 : scanCanonicalize (H12AffineFastState.compose env17727 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound17727 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17728 : List Nat := [2,4,8,16,32,17,40,256,0,273,292,0,8,0,1,2,0,260,273,0,1,292,16,263,40,17,293,0,0,261,20,260,256,293,0,0]

theorem envBound17728 : H12AffineFastState.Bounded env17728 := by
  intro p hp
  have h : env17728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17727_17728 : H12AffineEnvironment.transform 15 2 env17727 = env17728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env17727 == env17728) = true)

theorem identity17728 : scanCanonicalize (H12AffineFastState.compose env17728 (packedSelected [2,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17728 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env17729 : List Nat := [2,4,8,16,0,17,8,256,0,273,260,0,8,0,1,2,0,260,273,0,1,260,16,263,8,17,261,0,0,261,20,260,256,261,0,0]

theorem envBound17729 : H12AffineFastState.Bounded env17729 := by
  intro p hp
  have h : env17729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17728_17729 : H12AffineEnvironment.transform 4 0 env17728 = env17729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17728 == env17729) = true)

def leafEnv17729 : List Nat := [2,4,8,16,0,17,8,256,0,273,260,0,8,0,1,2,0,260,273,0,1,260,16,263,20,8,1,17,261,0,0,261,20,260,256,261,4,263,0,0,0,1,1]

def active17729 : List Nat := [0,1,2,3,7]

def tree17729 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17729 : H12WitnessSearch.Good tree17729 := H12GlobalWitnessIndex.good

theorem leafIdentity17729 : H12AffineFastState.composeSystem env17729 rootObs = leafEnv17729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17729 rootObs == leafEnv17729) = true)

theorem terminalChecked17729 : H12PackedTerminal.terminalCheckFast leafEnv17729 active17729 tree17729 = true := by decide +kernel

def env17730 : List Nat := [2,4,8,16,32,17,40,256,0,273,293,0,9,0,0,65536,0,261,273,1,1,292,16,65796,41,17,292,0,0,260,20,260,256,65830,0,0]

theorem envBound17730 : H12AffineFastState.Bounded env17730 := by
  intro p hp
  have h : env17730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17726_17730 : H12AffineEnvironment.transform 10 293 env17726 = env17730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env17726 == env17730) = true)

theorem identity17730 : scanCanonicalize (H12AffineFastState.compose env17730 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17730 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17731 : List Nat := [2,4,8,16,32,17,40,36,0,53,1,0,9,0,0,65536,0,33,53,1,1,0,16,65568,41,17,0,0,0,32,20,32,36,65538,0,0]

theorem envBound17731 : H12AffineFastState.Bounded env17731 := by
  intro p hp
  have h : env17731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17730_17731 : H12AffineEnvironment.transform 7 36 env17730 = env17731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17730 == env17731) = true)

theorem identity17731 : scanCanonicalize (H12AffineFastState.compose env17731 (packedSelected [2,4] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound17731 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env17732 : List Nat := [2,4,8,16,32,17,40,36,0,53,1,0,9,0,0,35,0,33,53,1,1,0,16,3,41,17,0,0,0,32,20,32,36,33,0,0]

theorem envBound17732 : H12AffineFastState.Bounded env17732 := by
  intro p hp
  have h : env17732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17731_17732 : H12AffineEnvironment.transform 15 35 env17731 = env17732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env17731 == env17732) = true)

theorem identity17732 : scanCanonicalize (H12AffineFastState.compose env17732 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17732 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17733 : List Nat := [2,4,8,16,0,17,8,4,0,21,1,0,9,0,0,3,0,1,21,1,1,0,16,3,9,17,0,0,0,0,20,0,4,1,0,0]

theorem envBound17733 : H12AffineFastState.Bounded env17733 := by
  intro p hp
  have h : env17733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17732_17733 : H12AffineEnvironment.transform 4 0 env17732 = env17733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17732 == env17733) = true)

def leafEnv17733 : List Nat := [2,4,8,16,0,17,8,4,0,21,1,0,9,0,0,3,0,1,21,1,1,0,16,3,20,9,1,17,0,0,0,0,20,0,4,1,4,2,0,0,0,1,1]

def active17733 : List Nat := [0,1,2,3]

def tree17733 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17733 : H12WitnessSearch.Good tree17733 := H12GlobalWitnessIndex.good

theorem leafIdentity17733 : H12AffineFastState.composeSystem env17733 rootObs = leafEnv17733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17733 rootObs == leafEnv17733) = true)

theorem terminalChecked17733 : H12PackedTerminal.terminalCheckFast leafEnv17733 active17733 tree17733 = true := by decide +kernel

def env17734 : List Nat := [2,4,8,16,32,17,128,256,1,273,2048,0,2437,0,2341,65536,0,2185,273,2340,1,397,16,67617,2317,17,2049,0,0,2184,20,261,256,67587,0,1]

theorem envBound17734 : H12AffineFastState.Bounded env17734 := by
  intro p hp
  have h : env17734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17724_17734 : H12AffineEnvironment.transform 8 1 env17724 = env17734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env17724 == env17734) = true)

theorem identity17734 : scanCanonicalize (H12AffineFastState.compose env17734 (packedSelected [0,2,6] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound17734 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env17735 : List Nat := [2,4,8,16,32,17,128,140,1,157,2048,0,2057,0,2217,65536,0,2185,157,2216,1,1,16,67617,2177,17,2049,0,0,2184,20,137,140,67587,0,1]

theorem envBound17735 : H12AffineFastState.Bounded env17735 := by
  intro p hp
  have h : env17735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17734_17735 : H12AffineEnvironment.transform 7 140 env17734 = env17735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env17734 == env17735) = true)

def env17736 : List Nat := [2,4,8,16,32,17,128,140,1,157,168,0,161,0,1,65536,0,33,157,0,1,1,16,65673,41,17,169,0,0,32,20,137,140,65707,0,1]

theorem envBound17736 : H12AffineFastState.Bounded env17736 := by
  intro p hp
  have h : env17736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17735_17736 : H12AffineEnvironment.transform 10 168 env17735 = env17736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env17735 == env17736) = true)

theorem identity17736 : scanCanonicalize (H12AffineFastState.compose env17736 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound17736 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17737 : List Nat := [2,4,8,16,32,17,128,140,1,157,168,0,161,0,1,170,0,33,157,0,1,1,16,35,41,17,169,0,0,32,20,137,140,1,0,1]

theorem envBound17737 : H12AffineFastState.Bounded env17737 := by
  intro p hp
  have h : env17737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17736_17737 : H12AffineEnvironment.transform 15 170 env17736 = env17737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env17736 == env17737) = true)

def env17738 : List Nat := [2,4,8,16,0,17,128,140,1,157,136,0,129,0,1,138,0,1,157,0,1,1,16,3,9,17,137,0,0,0,20,137,140,1,0,1]

theorem envBound17738 : H12AffineFastState.Bounded env17738 := by
  intro p hp
  have h : env17738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17737_17738 : H12AffineEnvironment.transform 4 0 env17737 = env17738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17737 == env17738) = true)

def leafEnv17738 : List Nat := [2,4,8,16,0,17,128,140,1,157,136,0,129,0,1,138,0,1,157,0,1,1,16,3,20,9,1,17,137,0,0,0,20,137,140,1,4,139,0,1,0,1,1]

def active17738 : List Nat := [0,1,2,3,6]

def tree17738 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17738 : H12WitnessSearch.Good tree17738 := H12GlobalWitnessIndex.good

theorem leafIdentity17738 : H12AffineFastState.composeSystem env17738 rootObs = leafEnv17738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17738 rootObs == leafEnv17738) = true)

theorem terminalChecked17738 : H12PackedTerminal.terminalCheckFast leafEnv17738 active17738 tree17738 = true := by decide +kernel

def env17739 : List Nat := [2,4,8,16,1,17,128,140,1,157,137,0,128,0,1,139,0,0,157,0,1,1,16,2,8,17,136,0,0,1,20,137,140,1,0,1]

theorem envBound17739 : H12AffineFastState.Bounded env17739 := by
  intro p hp
  have h : env17739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17737_17739 : H12AffineEnvironment.transform 4 1 env17737 = env17739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17737 == env17739) = true)

theorem identity17739 : scanCanonicalize (H12AffineFastState.compose env17739 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17739 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17740 : List Nat := [2,4,8,16,1,17,9,5,1,20,0,0,9,0,1,2,0,0,20,0,1,1,16,2,8,17,1,0,0,1,20,0,5,1,0,1]

theorem envBound17740 : H12AffineFastState.Bounded env17740 := by
  intro p hp
  have h : env17740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17739_17740 : H12AffineEnvironment.transform 6 9 env17739 = env17740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17739 == env17740) = true)

def leafEnv17740 : List Nat := [2,4,8,16,1,17,9,5,1,20,0,0,9,0,1,2,0,0,20,0,1,1,16,2,20,8,1,17,1,0,0,1,20,0,5,1,4,2,0,1,0,1,1]

def active17740 : List Nat := [0,1,2,3]

def tree17740 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17740 : H12WitnessSearch.Good tree17740 := H12GlobalWitnessIndex.good

theorem leafIdentity17740 : H12AffineFastState.composeSystem env17740 rootObs = leafEnv17740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17740 rootObs == leafEnv17740) = true)

theorem terminalChecked17740 : H12PackedTerminal.terminalCheckFast leafEnv17740 active17740 tree17740 = true := by decide +kernel

def env17741 : List Nat := [2,4,8,16,32,17,128,140,1,157,169,0,160,0,0,65536,0,32,157,1,1,1,16,65672,40,17,168,0,0,33,20,137,140,65706,0,1]

theorem envBound17741 : H12AffineFastState.Bounded env17741 := by
  intro p hp
  have h : env17741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17735_17741 : H12AffineEnvironment.transform 10 169 env17735 = env17741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 169 env17735 == env17741) = true)

theorem identity17741 : scanCanonicalize (H12AffineFastState.compose env17741 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound17741 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17742 : List Nat := [2,4,8,16,32,17,40,36,1,53,1,0,8,0,0,65536,0,32,53,1,1,1,16,65568,40,17,0,0,0,33,20,33,36,65538,0,1]

theorem envBound17742 : H12AffineFastState.Bounded env17742 := by
  intro p hp
  have h : env17742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17741_17742 : H12AffineEnvironment.transform 6 40 env17741 = env17742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env17741 == env17742) = true)

def env17743 : List Nat := [2,4,8,16,0,17,8,4,1,21,1,0,8,0,0,65536,0,0,21,1,1,1,16,65536,8,17,0,0,0,1,20,1,4,65538,0,1]

theorem envBound17743 : H12AffineFastState.Bounded env17743 := by
  intro p hp
  have h : env17743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17742_17743 : H12AffineEnvironment.transform 4 0 env17742 = env17743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17742 == env17743) = true)

theorem identity17743 : scanCanonicalize (H12AffineFastState.compose env17743 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound17743 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17744 : List Nat := [2,4,8,16,0,17,8,4,1,21,1,0,8,0,0,3,0,0,21,1,1,1,16,3,8,17,0,0,0,1,20,1,4,1,0,1]

theorem envBound17744 : H12AffineFastState.Bounded env17744 := by
  intro p hp
  have h : env17744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17743_17744 : H12AffineEnvironment.transform 15 3 env17743 = env17744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env17743 == env17744) = true)

def leafEnv17744 : List Nat := [2,4,8,16,0,17,8,4,1,21,1,0,8,0,0,3,0,0,21,1,1,1,16,3,20,8,1,17,0,0,0,1,20,1,4,1,4,2,0,1,0,1,1]

def active17744 : List Nat := [0,1,2,3]

def tree17744 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17744 : H12WitnessSearch.Good tree17744 := H12GlobalWitnessIndex.good

theorem leafIdentity17744 : H12AffineFastState.composeSystem env17744 rootObs = leafEnv17744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17744 rootObs == leafEnv17744) = true)

theorem terminalChecked17744 : H12PackedTerminal.terminalCheckFast leafEnv17744 active17744 tree17744 = true := by decide +kernel

def env17745 : List Nat := [2,4,8,16,1,17,9,5,1,20,1,0,8,0,0,65536,0,1,20,1,1,1,16,65537,9,17,0,0,0,0,20,0,5,65538,0,1]

theorem envBound17745 : H12AffineFastState.Bounded env17745 := by
  intro p hp
  have h : env17745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17742_17745 : H12AffineEnvironment.transform 4 1 env17742 = env17745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17742 == env17745) = true)

def leafEnv17745 : List Nat := [2,4,8,16,1,17,9,5,1,20,1,0,8,0,0,65536,0,1,20,1,1,1,16,65537,20,9,1,17,0,0,0,0,20,0,5,65538,4,3,0,1,0,1,1]

def active17745 : List Nat := [0,1,2,3,15]

def tree17745 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17745 : H12WitnessSearch.Good tree17745 := H12GlobalWitnessIndex.good

theorem leafIdentity17745 : H12AffineFastState.composeSystem env17745 rootObs = leafEnv17745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17745 rootObs == leafEnv17745) = true)

theorem terminalChecked17745 : H12PackedTerminal.terminalCheckFast leafEnv17745 active17745 tree17745 = true := by decide +kernel

def env17746 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,1297,63529,21504,32769,4097,10249,17665,98564,8328,5376,33061,16384,1297,28940,1285,4294967296,256,4295076263,1297,512]

theorem envBound17746 : H12AffineFastState.Bounded env17746 := by
  intro p hp
  have h : env17746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17697_17746 : H12AffineEnvironment.transform 21 10249 env17697 = env17746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env17697 == env17746) = true)

theorem identity17746 : scanCanonicalize (H12AffineFastState.compose env17746 (packedSelected [11] rootPS)) = affineNative (2^(14+1) ^^^ 19509) := by decide +kernel

theorem selectedBound17746 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env17747 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,19509,65536,1297,13340,21504,19508,4097,10249,17665,85297,8328,5376,19728,16384,1297,28940,1285,4294967296,256,4295058834,1297,512]

theorem envBound17747 : H12AffineFastState.Bounded env17747 := by
  intro p hp
  have h : env17747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17746_17747 : H12AffineEnvironment.transform 14 19509 env17746 = env17747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 19509 env17746 == env17747) = true)

def env17748 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1296,2341,65536,1297,13340,4368,2340,4097,10249,17,67617,8328,5376,2048,1296,1297,13340,1285,4294967296,256,4295041154,1297,512]

theorem envBound17748 : H12AffineFastState.Bounded env17748 := by
  intro p hp
  have h : env17748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17747_17748 : H12AffineEnvironment.transform 13 1296 env17747 = env17748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env17747 == env17748) = true)

theorem identity17748 : scanCanonicalize (H12AffineFastState.compose env17748 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 13495) := by decide +kernel

theorem selectedBound17748 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env17749 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1296,2341,13495,1297,13340,4368,2340,4097,10249,17,15510,8328,5376,2048,1296,1297,13340,1285,4294967296,256,4294972469,1297,512]

theorem envBound17749 : H12AffineFastState.Bounded env17749 := by
  intro p hp
  have h : env17749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17748_17749 : H12AffineEnvironment.transform 15 13495 env17748 = env17749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13495 env17748 == env17749) = true)

theorem identity17749 : scanCanonicalize (H12AffineFastState.compose env17749 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound17749 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17750 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,2317,1296,2341,7610,1297,7441,4368,2340,4097,260,17,5531,2437,5376,2048,1296,1297,7441,1285,4294967296,256,4294972469,1297,512]

theorem envBound17750 : H12AffineFastState.Bounded env17750 := by
  intro p hp
  have h : env17750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17749_17750 : H12AffineEnvironment.transform 12 2317 env17749 = env17750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env17749 == env17750) = true)

theorem identity17750 : scanCanonicalize (H12AffineFastState.compose env17750 (packedSelected [0,1,2,3,4,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound17750 : packedSelected [0,1,2,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env17751 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,2317,1296,2341,2218,1297,2049,1024,2340,1297,260,17,139,2437,16,2048,1296,1297,2049,1285,4294967296,256,4294967589,1297,512]

theorem envBound17751 : H12AffineFastState.Bounded env17751 := by
  intro p hp
  have h : env17751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17750_17751 : H12AffineEnvironment.transform 11 1296 env17750 = env17751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env17750 == env17751) = true)

theorem identity17751 : scanCanonicalize (H12AffineFastState.compose env17751 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 32) := by decide +kernel

theorem selectedBound17751 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17752 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,2317,1296,2341,2218,1297,2049,1024,2340,1297,260,17,139,2437,16,2048,1296,1297,2049,1285,32,256,261,1297,512]

theorem envBound17752 : H12AffineFastState.Bounded env17752 := by
  intro p hp
  have h : env17752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17751_17752 : H12AffineEnvironment.transform 31 32 env17751 = env17752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 32 env17751 == env17752) = true)

theorem identity17752 : scanCanonicalize (H12AffineFastState.compose env17752 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound17752 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17753 : List Nat := [2,4,8,16,32,17,128,256,260,1024,2048,1296,2317,1296,2341,2218,1297,2049,1024,2340,1297,260,17,139,2437,16,2048,1296,1297,2049,1285,32,256,261,1297,260]

theorem envBound17753 : H12AffineFastState.Bounded env17753 := by
  intro p hp
  have h : env17753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17752_17753 : H12AffineEnvironment.transform 8 260 env17752 = env17753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env17752 == env17753) = true)

def env17754 : List Nat := [2,4,8,16,0,17,128,256,260,1024,2048,1296,2317,1296,2309,2186,1297,2049,1024,2308,1297,260,17,139,2437,16,2048,1296,1297,2049,1285,0,256,261,1297,260]

theorem envBound17754 : H12AffineFastState.Bounded env17754 := by
  intro p hp
  have h : env17754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17753_17754 : H12AffineEnvironment.transform 4 0 env17753 = env17754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17753 == env17754) = true)

theorem identity17754 : scanCanonicalize (H12AffineFastState.compose env17754 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound17754 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17755 : List Nat := [2,4,8,16,0,17,128,140,136,1024,2048,1180,2177,1180,2185,2186,1181,2049,1024,2184,1181,136,17,139,2057,16,2048,1180,1181,2049,1161,0,140,137,1181,136]

theorem envBound17755 : H12AffineFastState.Bounded env17755 := by
  intro p hp
  have h : env17755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17754_17755 : H12AffineEnvironment.transform 7 140 env17754 = env17755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env17754 == env17755) = true)

def leafEnv17755 : List Nat := [2,4,8,16,0,17,128,140,136,1024,2048,1180,2177,1180,2185,2186,1181,2049,1024,2184,1181,136,17,139,1161,2057,1,16,2048,1180,1181,2049,1161,0,140,137,4,2051,1181,136,0,1180,1]

def active17755 : List Nat := [0,1,2,3,6,9,10]

def tree17755 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17755 : H12WitnessSearch.Good tree17755 := H12GlobalWitnessIndex.good

theorem leafIdentity17755 : H12AffineFastState.composeSystem env17755 rootObs = leafEnv17755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17755 rootObs == leafEnv17755) = true)

theorem terminalChecked17755 : H12PackedTerminal.terminalCheckFast leafEnv17755 active17755 tree17755 = true := by decide +kernel

def env17756 : List Nat := [2,4,8,16,1,17,128,256,260,1024,2048,1296,2317,1296,2308,2187,1297,2049,1024,2309,1297,260,17,139,2437,16,2048,1296,1297,2049,1285,1,256,261,1297,260]

theorem envBound17756 : H12AffineFastState.Bounded env17756 := by
  intro p hp
  have h : env17756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17753_17756 : H12AffineEnvironment.transform 4 1 env17753 = env17756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17753 == env17756) = true)

theorem identity17756 : scanCanonicalize (H12AffineFastState.compose env17756 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17756 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17757 : List Nat := [2,4,8,16,1,17,128,5,1,1024,2048,1045,2056,1045,2049,2187,1044,2049,1024,2048,1044,1,17,139,2176,16,2048,1045,1044,2049,1024,1,5,0,1044,1]

theorem envBound17757 : H12AffineFastState.Bounded env17757 := by
  intro p hp
  have h : env17757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17756_17757 : H12AffineEnvironment.transform 7 5 env17756 = env17757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17756 == env17757) = true)

theorem identity17757 : scanCanonicalize (H12AffineFastState.compose env17757 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17757 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17758 : List Nat := [2,4,8,16,1,17,9,5,1,1024,2048,1045,2056,1045,2049,2050,1044,2049,1024,2048,1044,1,17,2,2057,16,2048,1045,1044,2049,1024,1,5,0,1044,1]

theorem envBound17758 : H12AffineFastState.Bounded env17758 := by
  intro p hp
  have h : env17758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17757_17758 : H12AffineEnvironment.transform 6 9 env17757 = env17758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17757 == env17758) = true)

def leafEnv17758 : List Nat := [2,4,8,16,1,17,9,5,1,1024,2048,1045,2056,1045,2049,2050,1044,2049,1024,2048,1044,1,17,2,1024,2057,1,16,2048,1045,1044,2049,1024,1,5,0,4,2050,1044,1,0,1045,1]

def active17758 : List Nat := [0,1,2,3,9,10]

def tree17758 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17758 : H12WitnessSearch.Good tree17758 := H12GlobalWitnessIndex.good

theorem leafIdentity17758 : H12AffineFastState.composeSystem env17758 rootObs = leafEnv17758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17758 rootObs == leafEnv17758) = true)

theorem terminalChecked17758 : H12PackedTerminal.terminalCheckFast leafEnv17758 active17758 tree17758 = true := by decide +kernel

def env17759 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,2340,65536,1297,13340,4369,2341,4097,10249,16,67616,8328,5376,2049,1297,1297,13341,1285,4294967296,256,4295041155,1297,512]

theorem envBound17759 : H12AffineFastState.Bounded env17759 := by
  intro p hp
  have h : env17759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17747_17759 : H12AffineEnvironment.transform 13 1297 env17747 = env17759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env17747 == env17759) = true)

theorem identity17759 : scanCanonicalize (H12AffineFastState.compose env17759 (packedSelected [1,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 2948) := by decide +kernel

theorem selectedBound17759 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env17760 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,2948,1297,2340,65536,1297,8088,4369,2341,4097,909,16,67616,2828,5376,2049,1297,1297,8089,1285,4294967296,256,4295035655,1297,512]

theorem envBound17760 : H12AffineFastState.Bounded env17760 := by
  intro p hp
  have h : env17760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17759_17760 : H12AffineEnvironment.transform 12 2948 env17759 = env17760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2948 env17759 == env17760) = true)

theorem identity17760 : scanCanonicalize (H12AffineFastState.compose env17760 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound17760 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17761 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2948,1297,2340,65536,1297,2697,1024,2341,1296,909,16,67616,2828,17,2049,1297,1297,2696,1285,4294967296,256,4295035655,1297,512]

theorem envBound17761 : H12AffineFastState.Bounded env17761 := by
  intro p hp
  have h : env17761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17760_17761 : H12AffineEnvironment.transform 11 1297 env17760 = env17761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env17760 == env17761) = true)

def env17762 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,2948,1,2340,65536,1,2697,272,2341,0,909,16,67616,2828,17,2049,1,1,2696,21,4294967296,256,4295035655,1,512]

theorem envBound17762 : H12AffineFastState.Bounded env17762 := by
  intro p hp
  have h : env17762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17761_17762 : H12AffineEnvironment.transform 9 272 env17761 = env17762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env17761 == env17762) = true)

theorem identity17762 : scanCanonicalize (H12AffineFastState.compose env17762 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 68526) := by decide +kernel

theorem selectedBound17762 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17763 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,2948,1,2340,65536,1,2697,272,2341,0,909,16,67616,2828,17,2049,1,1,2696,21,68526,256,169,1,512]

theorem envBound17763 : H12AffineFastState.Bounded env17763 := by
  intro p hp
  have h : env17763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17762_17763 : H12AffineEnvironment.transform 31 68526 env17762 = env17763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 68526 env17762 == env17763) = true)

def env17764 : List Nat := [2,4,8,16,32,17,128,36,512,52,2048,1,2720,1,2048,65536,1,2697,52,2049,0,681,16,67616,2600,17,2049,1,1,2696,21,68234,36,169,1,512]

theorem envBound17764 : H12AffineFastState.Bounded env17764 := by
  intro p hp
  have h : env17764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17763_17764 : H12AffineEnvironment.transform 7 36 env17763 = env17764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17763 == env17764) = true)

theorem identity17764 : scanCanonicalize (H12AffineFastState.compose env17764 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17764 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17765 : List Nat := [2,4,8,16,0,17,128,4,512,20,2048,1,2688,1,2048,65536,1,2697,20,2049,0,649,16,67584,2568,17,2049,1,1,2696,21,68234,4,137,1,512]

theorem envBound17765 : H12AffineFastState.Bounded env17765 := by
  intro p hp
  have h : env17765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17764_17765 : H12AffineEnvironment.transform 4 0 env17764 = env17765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17764 == env17765) = true)

def env17766 : List Nat := [2,4,8,16,0,17,128,4,512,20,0,1,640,1,0,65536,1,649,20,1,0,649,16,65536,520,17,1,1,1,648,21,66186,4,137,1,512]

theorem envBound17766 : H12AffineFastState.Bounded env17766 := by
  intro p hp
  have h : env17766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17765_17766 : H12AffineEnvironment.transform 10 0 env17765 = env17766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env17765 == env17766) = true)

theorem identity17766 : scanCanonicalize (H12AffineFastState.compose env17766 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound17766 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17767 : List Nat := [2,4,8,16,0,17,128,4,512,20,0,1,640,1,0,138,1,649,20,1,0,649,16,138,520,17,1,1,1,648,21,512,4,137,1,512]

theorem envBound17767 : H12AffineFastState.Bounded env17767 := by
  intro p hp
  have h : env17767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17766_17767 : H12AffineEnvironment.transform 15 138 env17766 = env17767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env17766 == env17767) = true)

theorem identity17767 : scanCanonicalize (H12AffineFastState.compose env17767 (packedSelected [2,6] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound17767 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17768 : List Nat := [2,4,8,16,0,17,128,4,136,20,0,1,8,1,0,138,1,1,20,1,0,1,16,138,128,17,1,1,1,0,21,136,4,137,1,136]

theorem envBound17768 : H12AffineFastState.Bounded env17768 := by
  intro p hp
  have h : env17768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17767_17768 : H12AffineEnvironment.transform 8 136 env17767 = env17768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env17767 == env17768) = true)

def leafEnv17768 : List Nat := [2,4,8,16,0,17,128,4,136,20,0,1,8,1,0,138,1,1,20,1,0,1,16,138,21,128,1,17,1,1,1,0,21,136,4,137,4,2,1,136,0,0,1]

def active17768 : List Nat := [0,1,2,3,6]

def tree17768 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17768 : H12WitnessSearch.Good tree17768 := H12GlobalWitnessIndex.good

theorem leafIdentity17768 : H12AffineFastState.composeSystem env17768 rootObs = leafEnv17768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17768 rootObs == leafEnv17768) = true)

theorem terminalChecked17768 : H12PackedTerminal.terminalCheckFast leafEnv17768 active17768 tree17768 = true := by decide +kernel

def env17769 : List Nat := [2,4,8,16,0,17,128,4,512,20,1,1,641,1,1,65536,1,648,20,0,0,649,16,65537,521,17,0,1,1,649,21,66187,4,137,1,512]

theorem envBound17769 : H12AffineFastState.Bounded env17769 := by
  intro p hp
  have h : env17769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17765_17769 : H12AffineEnvironment.transform 10 1 env17765 = env17769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env17765 == env17769) = true)

def env17770 : List Nat := [2,4,8,16,32,17,128,37,512,53,2048,1,2721,1,2049,65536,1,2697,53,2048,0,680,16,67616,2601,17,2049,1,1,2696,21,68235,37,169,1,512]

theorem envBound17770 : H12AffineFastState.Bounded env17770 := by
  intro p hp
  have h : env17770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17763_17770 : H12AffineEnvironment.transform 7 37 env17763 = env17770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env17763 == env17770) = true)

theorem identity17770 : scanCanonicalize (H12AffineFastState.compose env17770 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 2698) := by decide +kernel

theorem selectedBound17770 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17771 : List Nat := [2,4,8,16,32,17,128,37,512,53,2048,1,2721,1,2049,2698,1,2697,53,2048,0,680,16,682,2601,17,2049,1,1,2696,21,1,37,169,1,512]

theorem envBound17771 : H12AffineFastState.Bounded env17771 := by
  intro p hp
  have h : env17771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17770_17771 : H12AffineEnvironment.transform 15 2698 env17770 = env17771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2698 env17770 == env17771) = true)

def env17772 : List Nat := [2,4,8,16,32,17,128,37,512,53,0,1,673,1,1,650,1,649,53,0,0,680,16,682,553,17,1,1,1,648,21,1,37,169,1,512]

theorem envBound17772 : H12AffineFastState.Bounded env17772 := by
  intro p hp
  have h : env17772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17771_17772 : H12AffineEnvironment.transform 10 0 env17771 = env17772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env17771 == env17772) = true)

theorem identity17772 : scanCanonicalize (H12AffineFastState.compose env17772 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound17772 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17773 : List Nat := [2,4,8,16,32,17,128,37,33,53,0,1,128,1,1,171,1,168,53,0,0,137,16,139,8,17,1,1,1,169,21,1,37,169,1,33]

theorem envBound17773 : H12AffineFastState.Bounded env17773 := by
  intro p hp
  have h : env17773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17772_17773 : H12AffineEnvironment.transform 8 33 env17772 = env17773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env17772 == env17773) = true)

def env17774 : List Nat := [2,4,8,16,0,17,128,5,1,21,0,1,128,1,1,139,1,136,21,0,0,137,16,139,8,17,1,1,1,137,21,1,5,137,1,1]

theorem envBound17774 : H12AffineFastState.Bounded env17774 := by
  intro p hp
  have h : env17774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17773_17774 : H12AffineEnvironment.transform 4 0 env17773 = env17774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17773 == env17774) = true)

def env17775 : List Nat := [2,4,8,16,1,17,128,4,0,20,0,1,128,1,1,138,1,137,20,0,0,137,16,139,8,17,1,1,1,136,21,1,4,136,1,0]

theorem envBound17775 : H12AffineFastState.Bounded env17775 := by
  intro p hp
  have h : env17775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17773_17775 : H12AffineEnvironment.transform 4 1 env17773 = env17775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17773 == env17775) = true)

theorem identity17775 : scanCanonicalize (H12AffineFastState.compose env17775 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17775 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17776 : List Nat := [2,4,8,16,1,17,9,4,0,20,0,1,9,1,1,3,1,0,20,0,0,0,16,2,8,17,1,1,1,1,21,1,4,1,1,0]

theorem envBound17776 : H12AffineFastState.Bounded env17776 := by
  intro p hp
  have h : env17776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17775_17776 : H12AffineEnvironment.transform 6 9 env17775 = env17776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17775 == env17776) = true)

def leafEnv17776 : List Nat := [2,4,8,16,1,17,9,4,0,20,0,1,9,1,1,3,1,0,20,0,0,0,16,2,21,8,1,17,1,1,1,1,21,1,4,1,4,3,1,0,0,0,1]

def active17776 : List Nat := [0,1,2,3]

def tree17776 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17776 : H12WitnessSearch.Good tree17776 := H12GlobalWitnessIndex.good

theorem leafIdentity17776 : H12AffineFastState.composeSystem env17776 rootObs = leafEnv17776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17776 rootObs == leafEnv17776) = true)

theorem terminalChecked17776 : H12PackedTerminal.terminalCheckFast leafEnv17776 active17776 tree17776 = true := by decide +kernel

def env17777 : List Nat := [2,4,8,16,32,17,128,37,512,53,1,1,672,1,0,651,1,648,53,1,0,680,16,682,552,17,0,1,1,649,21,1,37,169,1,512]

theorem envBound17777 : H12AffineFastState.Bounded env17777 := by
  intro p hp
  have h : env17777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17771_17777 : H12AffineEnvironment.transform 10 1 env17771 = env17777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env17771 == env17777) = true)

def env17778 : List Nat := [2,4,8,16,0,17,128,5,512,21,1,1,640,1,0,651,1,648,21,1,0,648,16,650,520,17,0,1,1,649,21,1,5,137,1,512]

theorem envBound17778 : H12AffineFastState.Bounded env17778 := by
  intro p hp
  have h : env17778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17777_17778 : H12AffineEnvironment.transform 4 0 env17777 = env17778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17777 == env17778) = true)

def env17779 : List Nat := [2,4,8,16,1,17,128,4,512,20,1,1,641,1,0,651,1,648,20,1,0,649,16,651,521,17,0,1,1,649,21,1,4,136,1,512]

theorem envBound17779 : H12AffineFastState.Bounded env17779 := by
  intro p hp
  have h : env17779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17777_17779 : H12AffineEnvironment.transform 4 1 env17777 = env17779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17777 == env17779) = true)

theorem identity17779 : scanCanonicalize (H12AffineFastState.compose env17779 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17779 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17780 : List Nat := [2,4,8,16,1,17,9,4,512,20,1,1,520,1,0,514,1,513,20,1,0,512,16,514,521,17,0,1,1,512,21,1,4,1,1,512]

theorem envBound17780 : H12AffineFastState.Bounded env17780 := by
  intro p hp
  have h : env17780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17779_17780 : H12AffineEnvironment.transform 6 9 env17779 = env17780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17779 == env17780) = true)

def leafEnv17780 : List Nat := [2,4,8,16,1,17,9,4,512,20,1,1,520,1,0,514,1,513,20,1,0,512,16,514,21,521,1,17,0,1,1,512,21,1,4,1,4,2,1,512,0,0,1]

def active17780 : List Nat := [0,1,2,3,8]

def tree17780 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17780 : H12WitnessSearch.Good tree17780 := H12GlobalWitnessIndex.good

theorem leafIdentity17780 : H12AffineFastState.composeSystem env17780 rootObs = leafEnv17780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17780 rootObs == leafEnv17780) = true)

theorem terminalChecked17780 : H12PackedTerminal.terminalCheckFast leafEnv17780 active17780 tree17780 = true := by decide +kernel

def env17781 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,2948,0,2340,65536,0,2697,273,2341,1,909,16,67616,2828,17,2049,0,0,2696,20,4294967296,256,4295035655,0,512]

theorem envBound17781 : H12AffineFastState.Bounded env17781 := by
  intro p hp
  have h : env17781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17761_17781 : H12AffineEnvironment.transform 9 273 env17761 = env17781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env17761 == env17781) = true)

theorem identity17781 : scanCanonicalize (H12AffineFastState.compose env17781 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 773) := by decide +kernel

theorem selectedBound17781 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17782 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,2948,0,2340,65536,0,2697,273,2341,1,909,16,67616,2828,17,2049,0,0,2696,20,773,256,67586,0,512]

theorem envBound17782 : H12AffineFastState.Bounded env17782 := by
  intro p hp
  have h : env17782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17781_17782 : H12AffineEnvironment.transform 31 773 env17781 = env17782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 773 env17781 == env17782) = true)

def env17783 : List Nat := [2,4,8,16,32,17,128,256,0,273,2048,0,2436,0,2340,65536,0,2185,273,2341,1,397,16,67616,2316,17,2049,0,0,2184,20,261,256,67586,0,0]

theorem envBound17783 : H12AffineFastState.Bounded env17783 := by
  intro p hp
  have h : env17783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17782_17783 : H12AffineEnvironment.transform 8 0 env17782 = env17783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env17782 == env17783) = true)

theorem identity17783 : scanCanonicalize (H12AffineFastState.compose env17783 (packedSelected [0,2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17783 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env17784 : List Nat := [2,4,8,16,32,17,128,4,0,21,2048,0,2176,0,2080,65536,0,2185,21,2081,1,137,16,67616,2056,17,2049,0,0,2184,20,1,4,67586,0,0]

theorem envBound17784 : H12AffineFastState.Bounded env17784 := by
  intro p hp
  have h : env17784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17783_17784 : H12AffineEnvironment.transform 7 4 env17783 = env17784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17783 == env17784) = true)

theorem identity17784 : scanCanonicalize (H12AffineFastState.compose env17784 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 2082) := by decide +kernel

theorem selectedBound17784 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17785 : List Nat := [2,4,8,16,32,17,128,4,0,21,2048,0,2176,0,2080,2082,0,2185,21,2081,1,137,16,2,2056,17,2049,0,0,2184,20,1,4,32,0,0]

theorem envBound17785 : H12AffineFastState.Bounded env17785 := by
  intro p hp
  have h : env17785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17784_17785 : H12AffineEnvironment.transform 15 2082 env17784 = env17785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2082 env17784 == env17785) = true)

def env17786 : List Nat := [2,4,8,16,32,17,128,4,0,21,32,0,160,0,0,2,0,169,21,1,1,137,16,2,40,17,33,0,0,168,20,1,4,32,0,0]

theorem envBound17786 : H12AffineFastState.Bounded env17786 := by
  intro p hp
  have h : env17786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17785_17786 : H12AffineEnvironment.transform 10 32 env17785 = env17786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env17785 == env17786) = true)

theorem identity17786 : scanCanonicalize (H12AffineFastState.compose env17786 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17786 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17787 : List Nat := [2,4,8,16,1,17,128,4,0,21,1,0,129,0,0,2,0,136,21,1,1,137,16,2,9,17,0,0,0,137,20,1,4,1,0,0]

theorem envBound17787 : H12AffineFastState.Bounded env17787 := by
  intro p hp
  have h : env17787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17786_17787 : H12AffineEnvironment.transform 4 1 env17786 = env17787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17786 == env17787) = true)

def leafEnv17787 : List Nat := [2,4,8,16,1,17,128,4,0,21,1,0,129,0,0,2,0,136,21,1,1,137,16,2,20,9,1,17,0,0,0,137,20,1,4,1,4,2,0,0,0,1,1]

def active17787 : List Nat := [0,1,2,3,6]

def tree17787 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17787 : H12WitnessSearch.Good tree17787 := H12GlobalWitnessIndex.good

theorem leafIdentity17787 : H12AffineFastState.composeSystem env17787 rootObs = leafEnv17787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17787 rootObs == leafEnv17787) = true)

theorem terminalChecked17787 : H12PackedTerminal.terminalCheckFast leafEnv17787 active17787 tree17787 = true := by decide +kernel

def env17788 : List Nat := [2,4,8,16,32,17,128,4,0,21,33,0,161,0,1,3,0,168,21,0,1,137,16,2,41,17,32,0,0,169,20,1,4,32,0,0]

theorem envBound17788 : H12AffineFastState.Bounded env17788 := by
  intro p hp
  have h : env17788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17785_17788 : H12AffineEnvironment.transform 10 33 env17785 = env17788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env17785 == env17788) = true)

theorem identity17788 : scanCanonicalize (H12AffineFastState.compose env17788 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound17788 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17789 : List Nat := [2,4,8,16,32,17,40,4,0,21,33,0,9,0,1,3,0,0,21,0,1,33,16,2,41,17,32,0,0,1,20,1,4,32,0,0]

theorem envBound17789 : H12AffineFastState.Bounded env17789 := by
  intro p hp
  have h : env17789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17788_17789 : H12AffineEnvironment.transform 6 40 env17788 = env17789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env17788 == env17789) = true)

def leafEnv17789 : List Nat := [2,4,8,16,32,17,40,4,0,21,33,0,9,0,1,3,0,0,21,0,1,33,16,2,20,41,1,17,32,0,0,1,20,1,4,32,4,3,0,0,0,1,1]

def active17789 : List Nat := [0,1,2,3,4]

def tree17789 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17789 : H12WitnessSearch.Good tree17789 := H12GlobalWitnessIndex.good

theorem leafIdentity17789 : H12AffineFastState.composeSystem env17789 rootObs = leafEnv17789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17789 rootObs == leafEnv17789) = true)

theorem terminalChecked17789 : H12PackedTerminal.terminalCheckFast leafEnv17789 active17789 tree17789 = true := by decide +kernel

def env17790 : List Nat := [2,4,8,16,32,17,128,256,1,273,2048,0,2437,0,2340,65536,0,2184,273,2341,1,396,16,67616,2317,17,2049,0,0,2185,20,260,256,67586,0,1]

theorem envBound17790 : H12AffineFastState.Bounded env17790 := by
  intro p hp
  have h : env17790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17782_17790 : H12AffineEnvironment.transform 8 1 env17782 = env17790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env17782 == env17790) = true)

theorem identity17790 : scanCanonicalize (H12AffineFastState.compose env17790 (packedSelected [0,2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17790 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env17791 : List Nat := [2,4,8,16,0,17,128,256,1,273,2048,0,2437,0,2308,65536,0,2184,273,2309,1,396,16,67584,2317,17,2049,0,0,2185,20,260,256,67586,0,1]

theorem envBound17791 : H12AffineFastState.Bounded env17791 := by
  intro p hp
  have h : env17791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17790_17791 : H12AffineEnvironment.transform 4 0 env17790 = env17791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17790 == env17791) = true)

def env17792 : List Nat := [2,4,8,16,0,17,128,256,1,273,260,0,129,0,0,65536,0,396,273,1,1,396,16,65796,9,17,261,0,0,397,20,260,256,65798,0,1]

theorem envBound17792 : H12AffineFastState.Bounded env17792 := by
  intro p hp
  have h : env17792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17791_17792 : H12AffineEnvironment.transform 10 260 env17791 = env17792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env17791 == env17792) = true)

theorem identity17792 : scanCanonicalize (H12AffineFastState.compose env17792 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17792 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17793 : List Nat := [2,4,8,16,0,17,128,5,1,20,1,0,129,0,0,65536,0,137,20,1,1,137,16,65537,9,17,0,0,0,136,20,1,5,65539,0,1]

theorem envBound17793 : H12AffineFastState.Bounded env17793 := by
  intro p hp
  have h : env17793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17792_17793 : H12AffineEnvironment.transform 7 5 env17792 = env17793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17792 == env17793) = true)

def env17794 : List Nat := [2,4,8,16,0,17,128,256,1,273,261,0,128,0,1,65536,0,397,273,0,1,396,16,65797,8,17,260,0,0,396,20,260,256,65799,0,1]

theorem envBound17794 : H12AffineFastState.Bounded env17794 := by
  intro p hp
  have h : env17794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17791_17794 : H12AffineEnvironment.transform 10 261 env17791 = env17794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env17791 == env17794) = true)

theorem identity17794 : scanCanonicalize (H12AffineFastState.compose env17794 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound17794 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17795 : List Nat := [2,4,8,16,0,17,128,256,1,273,261,0,128,0,1,139,0,397,273,0,1,396,16,398,8,17,260,0,0,396,20,260,256,396,0,1]

theorem envBound17795 : H12AffineFastState.Bounded env17795 := by
  intro p hp
  have h : env17795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17794_17795 : H12AffineEnvironment.transform 15 139 env17794 = env17795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env17794 == env17795) = true)

theorem identity17795 : scanCanonicalize (H12AffineFastState.compose env17795 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17795 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17796 : List Nat := [2,4,8,16,0,17,128,4,1,21,1,0,128,0,1,139,0,137,21,0,1,136,16,138,8,17,0,0,0,136,20,0,4,136,0,1]

theorem envBound17796 : H12AffineFastState.Bounded env17796 := by
  intro p hp
  have h : env17796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17795_17796 : H12AffineEnvironment.transform 7 4 env17795 = env17796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17795 == env17796) = true)

theorem identity17796 : scanCanonicalize (H12AffineFastState.compose env17796 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17796 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17797 : List Nat := [2,4,8,16,0,17,9,4,1,21,1,0,9,0,1,2,0,0,21,0,1,1,16,3,8,17,0,0,0,1,20,0,4,1,0,1]

theorem envBound17797 : H12AffineFastState.Bounded env17797 := by
  intro p hp
  have h : env17797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17796_17797 : H12AffineEnvironment.transform 6 9 env17796 = env17797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17796 == env17797) = true)

def leafEnv17797 : List Nat := [2,4,8,16,0,17,9,4,1,21,1,0,9,0,1,2,0,0,21,0,1,1,16,3,20,8,1,17,0,0,0,1,20,0,4,1,4,3,0,1,0,1,1]

def active17797 : List Nat := [0,1,2,3]

def tree17797 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17797 : H12WitnessSearch.Good tree17797 := H12GlobalWitnessIndex.good

theorem leafIdentity17797 : H12AffineFastState.composeSystem env17797 rootObs = leafEnv17797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17797 rootObs == leafEnv17797) = true)

theorem terminalChecked17797 : H12PackedTerminal.terminalCheckFast leafEnv17797 active17797 tree17797 = true := by decide +kernel

def env17798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,21505,32769,4097,4194304,17665,98564,8328,5456,4477268,16384,1345,1073741824,1285,4294967296,256,4299260334,1296,512]

theorem envBound17798 : H12AffineFastState.Bounded env17798 := by
  intro p hp
  have h : env17798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17676_17798 : H12AffineEnvironment.transform 18 21505 env17676 = env17798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21505 env17676 == env17798) = true)

theorem identity17798 : scanCanonicalize (H12AffineFastState.compose env17798 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17798 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env17799 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,1296,262144,21505,32769,4097,4194304,17665,98564,8328,5376,4477188,16384,1297,1073741824,1285,4294967296,256,4299260334,1296,512]

theorem envBound17799 : H12AffineFastState.Bounded env17799 := by
  intro p hp
  have h : env17799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17798_17799 : H12AffineEnvironment.transform 5 16 env17798 = env17799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17798 == env17799) = true)

theorem identity17799 : scanCanonicalize (H12AffineFastState.compose env17799 (packedSelected [3,8,12,15,17,19,21] rootPS)) = affineNative (2^(29+1) ^^^ 4497708) := by decide +kernel

theorem selectedBound17799 : packedSelected [3,8,12,15,17,19,21] rootPS < 2^1333 := by decide +kernel

def env17800 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,1296,262144,21505,32769,4097,4194304,17665,98564,8328,5376,4477188,16384,1297,4497708,1285,4294967296,256,4299260334,1296,512]

theorem envBound17800 : H12AffineFastState.Bounded env17800 := by
  intro p hp
  have h : env17800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17799_17800 : H12AffineEnvironment.transform 29 4497708 env17799 = env17800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4497708 env17799 == env17800) = true)

theorem identity17800 : scanCanonicalize (H12AffineFastState.compose env17800 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 63528) := by decide +kernel

theorem selectedBound17800 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env17801 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,1296,63528,21505,32769,4097,4194304,17665,98564,8328,5376,4237612,16384,1297,4217092,1285,4294967296,256,4299260334,1296,512]

theorem envBound17801 : H12AffineFastState.Bounded env17801 := by
  intro p hp
  have h : env17801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17800_17801 : H12AffineEnvironment.transform 17 63528 env17800 = env17801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 63528 env17800 == env17801) = true)

def env17802 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,1296,63528,21505,32769,4097,10248,17665,98564,8328,5376,33060,16384,1297,28940,1285,4294967296,256,4295076262,1296,512]

theorem envBound17802 : H12AffineFastState.Bounded env17802 := by
  intro p hp
  have h : env17802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17801_17802 : H12AffineEnvironment.transform 21 10248 env17801 = env17802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env17801 == env17802) = true)

theorem identity17802 : scanCanonicalize (H12AffineFastState.compose env17802 (packedSelected [11] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound17802 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env17803 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1296,32768,65536,1296,48440,4369,32769,4097,10248,17,98564,8328,5376,33060,1296,1297,13340,1285,4294967296,256,4295076262,1296,512]

theorem envBound17803 : H12AffineFastState.Bounded env17803 := by
  intro p hp
  have h : env17803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17802_17803 : H12AffineEnvironment.transform 13 1296 env17802 = env17803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env17802 == env17803) = true)

theorem identity17803 : scanCanonicalize (H12AffineFastState.compose env17803 (packedSelected [1,3,5] rootPS)) = affineNative (2^(14+1) ^^^ 13624) := by decide +kernel

theorem selectedBound17803 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env17804 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1296,13624,65536,1296,2048,4369,13625,4097,10248,17,78908,8328,5376,13340,1296,1297,13340,1285,4294967296,256,4295040158,1296,512]

theorem envBound17804 : H12AffineFastState.Bounded env17804 := by
  intro p hp
  have h : env17804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17803_17804 : H12AffineEnvironment.transform 14 13624 env17803 = env17804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13624 env17803 == env17804) = true)

theorem identity17804 : scanCanonicalize (H12AffineFastState.compose env17804 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound17804 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17805 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,8233,65536,1296,2048,1024,8232,1296,10248,17,74029,8328,17,8461,1296,1297,8461,1285,4294967296,256,4295035279,1296,512]

theorem envBound17805 : H12AffineFastState.Bounded env17805 := by
  intro p hp
  have h : env17805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17804_17805 : H12AffineEnvironment.transform 11 1297 env17804 = env17805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env17804 == env17805) = true)

theorem identity17805 : scanCanonicalize (H12AffineFastState.compose env17805 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 2218) := by decide +kernel

theorem selectedBound17805 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17806 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,8233,2218,1296,2048,1024,8232,1296,10248,17,10631,8328,17,8461,1296,1297,8461,1285,4294967296,256,4294967589,1296,512]

theorem envBound17806 : H12AffineFastState.Bounded env17806 := by
  intro p hp
  have h : env17806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17805_17806 : H12AffineEnvironment.transform 15 2218 env17805 = env17806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2218 env17805 == env17806) = true)

theorem identity17806 : scanCanonicalize (H12AffineFastState.compose env17806 (packedSelected [1,10] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound17806 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env17807 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2316,1296,2341,2218,1296,2048,1024,2340,1296,260,17,139,2436,17,2049,1296,1297,2049,1285,4294967296,256,4294967589,1296,512]

theorem envBound17807 : H12AffineFastState.Bounded env17807 := by
  intro p hp
  have h : env17807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17806_17807 : H12AffineEnvironment.transform 12 2316 env17806 = env17807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env17806 == env17807) = true)

theorem identity17807 : scanCanonicalize (H12AffineFastState.compose env17807 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 169) := by decide +kernel

theorem selectedBound17807 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17808 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2316,1296,2341,2218,1296,2048,1024,2340,1296,260,17,139,2436,17,2049,1296,1297,2049,1285,169,256,396,1296,512]

theorem envBound17808 : H12AffineFastState.Bounded env17808 := by
  intro p hp
  have h : env17808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17807_17808 : H12AffineEnvironment.transform 31 169 env17807 = env17808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 169 env17807 == env17808) = true)

theorem identity17808 : scanCanonicalize (H12AffineFastState.compose env17808 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound17808 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17809 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1297,2316,1296,2341,2218,1296,2048,1024,2340,1296,260,17,139,2436,17,2049,1296,1297,2049,1285,169,256,396,1296,136]

theorem envBound17809 : H12AffineFastState.Bounded env17809 := by
  intro p hp
  have h : env17809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17808_17809 : H12AffineEnvironment.transform 8 136 env17808 = env17809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env17808 == env17809) = true)

def env17810 : List Nat := [2,4,8,16,32,16,8,256,0,1024,2048,1297,2316,1296,2341,2082,1296,2048,1024,2340,1296,260,17,3,2316,17,2049,1296,1297,2049,1285,33,256,260,1296,0]

theorem envBound17810 : H12AffineFastState.Bounded env17810 := by
  intro p hp
  have h : env17810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17809_17810 : H12AffineEnvironment.transform 6 8 env17809 = env17810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17809 == env17810) = true)

theorem identity17810 : scanCanonicalize (H12AffineFastState.compose env17810 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17810 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17811 : List Nat := [2,4,8,16,0,16,8,256,0,1024,2048,1297,2316,1296,2309,2050,1296,2048,1024,2308,1296,260,17,3,2316,17,2049,1296,1297,2049,1285,1,256,260,1296,0]

theorem envBound17811 : H12AffineFastState.Bounded env17811 := by
  intro p hp
  have h : env17811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17810_17811 : H12AffineEnvironment.transform 4 0 env17810 = env17811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17810 == env17811) = true)

def leafEnv17811 : List Nat := [2,4,8,16,0,16,8,256,0,1024,2048,1297,2316,1296,2309,2050,1296,2048,1024,2308,1296,260,17,3,1285,2316,1,17,2049,1296,1297,2049,1285,1,256,260,4,2051,1296,0,0,1296,1]

def active17811 : List Nat := [0,1,2,3,7,9,10]

def tree17811 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17811 : H12WitnessSearch.Good tree17811 := H12GlobalWitnessIndex.good

theorem leafIdentity17811 : H12AffineFastState.composeSystem env17811 rootObs = leafEnv17811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17811 rootObs == leafEnv17811) = true)

theorem terminalChecked17811 : H12PackedTerminal.terminalCheckFast leafEnv17811 active17811 tree17811 = true := by decide +kernel

def env17812 : List Nat := [2,4,8,16,32,16,9,256,1,1024,2048,1297,2316,1296,2341,2083,1296,2048,1024,2340,1296,260,17,2,2317,17,2049,1296,1297,2049,1285,32,256,261,1296,1]

theorem envBound17812 : H12AffineFastState.Bounded env17812 := by
  intro p hp
  have h : env17812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17809_17812 : H12AffineEnvironment.transform 6 9 env17809 = env17812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17809 == env17812) = true)

theorem identity17812 : scanCanonicalize (H12AffineFastState.compose env17812 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17812 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17813 : List Nat := [2,4,8,16,32,16,9,5,1,1024,2048,1044,2057,1045,2080,2083,1045,2048,1024,2081,1045,1,17,2,2056,17,2049,1045,1044,2049,1024,32,5,0,1045,1]

theorem envBound17813 : H12AffineFastState.Bounded env17813 := by
  intro p hp
  have h : env17813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17812_17813 : H12AffineEnvironment.transform 7 5 env17812 = env17813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17812 == env17813) = true)

def leafEnv17813 : List Nat := [2,4,8,16,32,16,9,5,1,1024,2048,1044,2057,1045,2080,2083,1045,2048,1024,2081,1045,1,17,2,1024,2056,1,17,2049,1045,1044,2049,1024,32,5,0,4,2083,1045,1,0,1045,1]

def active17813 : List Nat := [0,1,2,3,4,9,10]

def tree17813 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17813 : H12WitnessSearch.Good tree17813 := H12GlobalWitnessIndex.good

theorem leafIdentity17813 : H12AffineFastState.composeSystem env17813 rootObs = leafEnv17813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17813 rootObs == leafEnv17813) = true)

theorem terminalChecked17813 : H12PackedTerminal.terminalCheckFast leafEnv17813 active17813 tree17813 = true := by decide +kernel

def env17814 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,1296,63528,21505,32769,4097,10249,17665,98564,8328,5376,33061,16384,1297,28941,1285,4294967296,256,4295076263,1296,512]

theorem envBound17814 : H12AffineFastState.Bounded env17814 := by
  intro p hp
  have h : env17814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17801_17814 : H12AffineEnvironment.transform 21 10249 env17801 = env17814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env17801 == env17814) = true)

theorem identity17814 : scanCanonicalize (H12AffineFastState.compose env17814 (packedSelected [11] rootPS)) = affineNative (2^(14+1) ^^^ 19508) := by decide +kernel

theorem selectedBound17814 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env17815 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,19508,65536,1296,13340,21505,19509,4097,10249,17665,85296,8328,5376,19729,16384,1297,28941,1285,4294967296,256,4295058835,1296,512]

theorem envBound17815 : H12AffineFastState.Bounded env17815 := by
  intro p hp
  have h : env17815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17814_17815 : H12AffineEnvironment.transform 14 19508 env17814 = env17815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 19508 env17814 == env17815) = true)

def env17816 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1296,2340,65536,1296,13340,4369,2341,4097,10249,17,67616,8328,5376,2049,1296,1297,13341,1285,4294967296,256,4295041155,1296,512]

theorem envBound17816 : H12AffineFastState.Bounded env17816 := by
  intro p hp
  have h : env17816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17815_17816 : H12AffineEnvironment.transform 13 1296 env17815 = env17816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env17815 == env17816) = true)

theorem identity17816 : scanCanonicalize (H12AffineFastState.compose env17816 (packedSelected [1,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 7197) := by decide +kernel

theorem selectedBound17816 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env17817 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,7197,1296,2340,65536,1296,2049,4369,2341,4097,5140,17,67616,7317,5376,2049,1296,1297,2048,1285,4294967296,256,4295040158,1296,512]

theorem envBound17817 : H12AffineFastState.Bounded env17817 := by
  intro p hp
  have h : env17817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17816_17817 : H12AffineEnvironment.transform 12 7197 env17816 = env17817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7197 env17816 == env17817) = true)

theorem identity17817 : scanCanonicalize (H12AffineFastState.compose env17817 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound17817 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17818 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2316,1296,2340,65536,1296,2049,1024,2341,1296,261,17,67616,2436,17,2049,1296,1297,2048,1285,4294967296,256,4295035279,1296,512]

theorem envBound17818 : H12AffineFastState.Bounded env17818 := by
  intro p hp
  have h : env17818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17817_17818 : H12AffineEnvironment.transform 11 1297 env17817 = env17818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env17817 == env17818) = true)

theorem identity17818 : scanCanonicalize (H12AffineFastState.compose env17818 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 2219) := by decide +kernel

theorem selectedBound17818 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17819 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2316,1296,2340,2219,1296,2049,1024,2341,1296,261,17,139,2436,17,2049,1296,1297,2048,1285,4294967296,256,4294967588,1296,512]

theorem envBound17819 : H12AffineFastState.Bounded env17819 := by
  intro p hp
  have h : env17819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17818_17819 : H12AffineEnvironment.transform 15 2219 env17818 = env17819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2219 env17818 == env17819) = true)

theorem identity17819 : scanCanonicalize (H12AffineFastState.compose env17819 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 169) := by decide +kernel

theorem selectedBound17819 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17820 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2316,1296,2340,2219,1296,2049,1024,2341,1296,261,17,139,2436,17,2049,1296,1297,2048,1285,169,256,397,1296,512]

theorem envBound17820 : H12AffineFastState.Bounded env17820 := by
  intro p hp
  have h : env17820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17819_17820 : H12AffineEnvironment.transform 31 169 env17819 = env17820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 169 env17819 == env17820) = true)

theorem identity17820 : scanCanonicalize (H12AffineFastState.compose env17820 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound17820 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17821 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1297,2316,1296,2340,2219,1296,2049,1024,2341,1296,261,17,139,2436,17,2049,1296,1297,2048,1285,169,256,397,1296,136]

theorem envBound17821 : H12AffineFastState.Bounded env17821 := by
  intro p hp
  have h : env17821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17820_17821 : H12AffineEnvironment.transform 8 136 env17820 = env17821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env17820 == env17821) = true)

def env17822 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1297,2341,65536,1296,13340,4368,2340,4097,10249,16,67617,8328,5376,2048,1297,1297,13340,1285,4294967296,256,4295041154,1296,512]

theorem envBound17822 : H12AffineFastState.Bounded env17822 := by
  intro p hp
  have h : env17822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17815_17822 : H12AffineEnvironment.transform 13 1297 env17815 = env17822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env17815 == env17822) = true)

theorem identity17822 : scanCanonicalize (H12AffineFastState.compose env17822 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 9007) := by decide +kernel

theorem selectedBound17822 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env17823 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1297,2341,9007,1296,13340,4368,2340,4097,10249,16,11022,8328,5376,2048,1297,1297,13340,1285,4294967296,256,4294968237,1296,512]

theorem envBound17823 : H12AffineFastState.Bounded env17823 := by
  intro p hp
  have h : env17823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17822_17823 : H12AffineEnvironment.transform 15 9007 env17822 = env17823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9007 env17822 == env17823) = true)

theorem identity17823 : scanCanonicalize (H12AffineFastState.compose env17823 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound17823 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17824 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,2317,1297,2341,2594,1296,7441,4368,2340,4097,260,16,515,2437,5376,2048,1297,1297,7441,1285,4294967296,256,4294968237,1296,512]

theorem envBound17824 : H12AffineFastState.Bounded env17824 := by
  intro p hp
  have h : env17824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17823_17824 : H12AffineEnvironment.transform 12 2317 env17823 = env17824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env17823 == env17824) = true)

theorem identity17824 : scanCanonicalize (H12AffineFastState.compose env17824 (packedSelected [1,3,8] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound17824 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env17825 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2317,1297,2341,2594,1296,2049,1024,2340,1297,260,16,515,2437,16,2048,1297,1297,2049,1285,4294967296,256,4294968237,1296,512]

theorem envBound17825 : H12AffineFastState.Bounded env17825 := by
  intro p hp
  have h : env17825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17824_17825 : H12AffineEnvironment.transform 11 1296 env17824 = env17825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env17824 == env17825) = true)

theorem identity17825 : scanCanonicalize (H12AffineFastState.compose env17825 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound17825 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17826 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1296,2317,1297,2341,2218,1296,2049,1024,2340,1297,260,16,139,2437,16,2048,1297,1297,2049,1285,4294967296,256,4294967589,1296,136]

theorem envBound17826 : H12AffineFastState.Bounded env17826 := by
  intro p hp
  have h : env17826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17825_17826 : H12AffineEnvironment.transform 8 136 env17825 = env17826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env17825 == env17826) = true)

theorem identity17826 : scanCanonicalize (H12AffineFastState.compose env17826 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 260) := by decide +kernel

theorem selectedBound17826 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17827 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1296,2317,1297,2341,2218,1296,2049,1024,2340,1297,260,16,139,2437,16,2048,1297,1297,2049,1285,260,256,33,1296,136]

theorem envBound17827 : H12AffineFastState.Bounded env17827 := by
  intro p hp
  have h : env17827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17826_17827 : H12AffineEnvironment.transform 31 260 env17826 = env17827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 260 env17826 == env17827) = true)

theorem identity17827 : scanCanonicalize (H12AffineFastState.compose env17827 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound17827 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17828 : List Nat := [2,4,8,16,32,16,41,256,33,1024,2048,1296,2317,1297,2341,2051,1296,2049,1024,2340,1297,260,16,34,2348,16,2048,1297,1297,2049,1285,260,256,33,1296,33]

theorem envBound17828 : H12AffineFastState.Bounded env17828 := by
  intro p hp
  have h : env17828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17827_17828 : H12AffineEnvironment.transform 6 41 env17827 = env17828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env17827 == env17828) = true)

def env17829 : List Nat := [2,4,8,16,0,16,9,256,1,1024,2048,1296,2317,1297,2309,2051,1296,2049,1024,2308,1297,260,16,2,2316,16,2048,1297,1297,2049,1285,260,256,1,1296,1]

theorem envBound17829 : H12AffineFastState.Bounded env17829 := by
  intro p hp
  have h : env17829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17828_17829 : H12AffineEnvironment.transform 4 0 env17828 = env17829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17828 == env17829) = true)

def leafEnv17829 : List Nat := [2,4,8,16,0,16,9,256,1,1024,2048,1296,2317,1297,2309,2051,1296,2049,1024,2308,1297,260,16,2,1285,2316,1,16,2048,1297,1297,2049,1285,260,256,1,4,2051,1296,1,0,1296,1]

def active17829 : List Nat := [0,1,2,3,7,9,10]

def tree17829 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17829 : H12WitnessSearch.Good tree17829 := H12GlobalWitnessIndex.good

theorem leafIdentity17829 : H12AffineFastState.composeSystem env17829 rootObs = leafEnv17829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17829 rootObs == leafEnv17829) = true)

theorem terminalChecked17829 : H12PackedTerminal.terminalCheckFast leafEnv17829 active17829 tree17829 = true := by decide +kernel

def env17830 : List Nat := [2,4,8,16,1,16,8,256,0,1024,2048,1296,2317,1297,2308,2051,1296,2049,1024,2309,1297,260,16,3,2317,16,2048,1297,1297,2049,1285,260,256,0,1296,0]

theorem envBound17830 : H12AffineFastState.Bounded env17830 := by
  intro p hp
  have h : env17830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17828_17830 : H12AffineEnvironment.transform 4 1 env17828 = env17830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17828 == env17830) = true)

theorem identity17830 : scanCanonicalize (H12AffineFastState.compose env17830 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17830 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17831 : List Nat := [2,4,8,16,1,16,8,5,0,1024,2048,1045,2056,1044,2049,2051,1045,2049,1024,2048,1044,1,16,3,2056,16,2048,1044,1044,2049,1024,1,5,0,1045,0]

theorem envBound17831 : H12AffineFastState.Bounded env17831 := by
  intro p hp
  have h : env17831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17830_17831 : H12AffineEnvironment.transform 7 5 env17830 = env17831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17830 == env17831) = true)

def leafEnv17831 : List Nat := [2,4,8,16,1,16,8,5,0,1024,2048,1045,2056,1044,2049,2051,1045,2049,1024,2048,1044,1,16,3,1024,2056,1,16,2048,1044,1044,2049,1024,1,5,0,4,2050,1045,0,0,1045,1]

def active17831 : List Nat := [0,1,2,3,9,10]

def tree17831 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17831 : H12WitnessSearch.Good tree17831 := H12GlobalWitnessIndex.good

theorem leafIdentity17831 : H12AffineFastState.composeSystem env17831 rootObs = leafEnv17831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17831 rootObs == leafEnv17831) = true)

theorem terminalChecked17831 : H12PackedTerminal.terminalCheckFast leafEnv17831 active17831 tree17831 = true := by decide +kernel

def env17832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,4194304,17665,16777216,8328,541009,4477269,16385,545089,1073741824,16876544,4294967296,257,4315938986,17420309,512]

theorem envBound17832 : H12AffineFastState.Bounded env17832 := by
  intro p hp
  have h : env17832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17674_17832 : H12AffineEnvironment.transform 16 1345 env17674 = env17832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env17674 == env17832) = true)

theorem identity17832 : scanCanonicalize (H12AffineFastState.compose env17832 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 644436) := by decide +kernel

theorem selectedBound17832 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env17833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,4194304,17665,644436,8328,541009,4477269,16385,545089,1073741824,545108,4294967296,257,4299806206,1345,512]

theorem envBound17833 : H12AffineFastState.Bounded env17833 := by
  intro p hp
  have h : env17833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17832_17833 : H12AffineEnvironment.transform 23 644436 env17832 = env17833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 644436 env17832 == env17833) = true)

theorem identity17833 : scanCanonicalize (H12AffineFastState.compose env17833 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound17833 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env17834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1025,32769,4097,4194304,17665,119125,8328,17744,4477269,16385,21824,1073741824,21845,4294967296,257,4299280895,1345,512]

theorem envBound17834 : H12AffineFastState.Bounded env17834 := by
  intro p hp
  have h : env17834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17833_17834 : H12AffineEnvironment.transform 18 1025 env17833 = env17834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env17833 == env17834) = true)

def env17835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,1345,262144,1025,32769,4097,4194304,5377,98645,8328,5456,4456789,4097,1344,1073741824,1365,4294967296,257,4299260415,1345,512]

theorem envBound17835 : H12AffineFastState.Bounded env17835 := by
  intro p hp
  have h : env17835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17834_17835 : H12AffineEnvironment.transform 13 4096 env17834 = env17835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env17834 == env17835) = true)

theorem identity17835 : scanCanonicalize (H12AffineFastState.compose env17835 (packedSelected [12,13,15,17,38,41] rootPS)) = affineNative (2^(31+1) ^^^ 1077979297) := by decide +kernel

theorem selectedBound17835 : packedSelected [12,13,15,17,38,41] rootPS < 2^1333 := by decide +kernel

def env17836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,1345,262144,1025,32769,4097,4194304,5377,98645,8328,5456,4456789,4097,1344,1073741824,1365,1077979297,257,1073817950,1345,512]

theorem envBound17836 : H12AffineFastState.Bounded env17836 := by
  intro p hp
  have h : env17836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17835_17836 : H12AffineEnvironment.transform 31 1077979297 env17835 = env17836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1077979297 env17835 == env17836) = true)

def env17837 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1297,262144,1025,32769,4097,4194304,5377,98565,8328,5376,4456709,4097,1296,1073741824,1285,1077979297,257,1073817870,1297,512]

theorem envBound17837 : H12AffineFastState.Bounded env17837 := by
  intro p hp
  have h : env17837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17836_17837 : H12AffineEnvironment.transform 5 16 env17836 = env17837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17836 == env17837) = true)

theorem identity17837 : scanCanonicalize (H12AffineFastState.compose env17837 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(29+1) ^^^ 303144) := by decide +kernel

theorem selectedBound17837 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env17838 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1297,262144,1025,32769,4097,4194304,5377,98565,8328,5376,4456709,4097,1296,303144,1285,4458633,257,362790,1297,512]

theorem envBound17838 : H12AffineFastState.Bounded env17838 := by
  intro p hp
  have h : env17838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17837_17838 : H12AffineEnvironment.transform 29 303144 env17837 = env17838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 303144 env17837 == env17838) = true)

theorem identity17838 : scanCanonicalize (H12AffineFastState.compose env17838 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(21+1) ^^^ 305964) := by decide +kernel

theorem selectedBound17838 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env17839 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1297,262144,1025,32769,4097,305964,5377,98565,8328,5376,43561,4097,1296,303144,1285,41893,257,362790,1297,512]

theorem envBound17839 : H12AffineFastState.Bounded env17839 := by
  intro p hp
  have h : env17839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17838_17839 : H12AffineEnvironment.transform 21 305964 env17838 = env17839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 305964 env17838 == env17839) = true)

theorem identity17839 : scanCanonicalize (H12AffineFastState.compose env17839 (packedSelected [1,3,5,12,13,24] rootPS)) = affineNative (2^(17+1) ^^^ 32904) := by decide +kernel

theorem selectedBound17839 : packedSelected [1,3,5,12,13,24] rootPS < 2^1333 := by decide +kernel

def env17840 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1297,32904,1025,32769,4097,11172,5377,98565,8328,5376,43561,4097,1296,8352,1285,41893,257,68014,1297,512]

theorem envBound17840 : H12AffineFastState.Bounded env17840 := by
  intro p hp
  have h : env17840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17839_17840 : H12AffineEnvironment.transform 17 32904 env17839 = env17840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32904 env17839 == env17840) = true)

theorem identity17840 : scanCanonicalize (H12AffineFastState.compose env17840 (packedSelected [8,12,13,28] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound17840 : packedSelected [8,12,13,28] rootPS < 2^1333 := by decide +kernel

def env17841 : List Nat := [2,4,8,16,32,16,128,256,1,1024,2048,4096,8192,4096,32768,65536,1297,32904,1025,32769,4097,10661,5377,98565,8328,5376,43048,4097,1296,8352,1285,41380,257,68014,1297,1]

theorem envBound17841 : H12AffineFastState.Bounded env17841 := by
  intro p hp
  have h : env17841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17840_17841 : H12AffineEnvironment.transform 8 1 env17840 = env17841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env17840 == env17841) = true)

theorem identity17841 : scanCanonicalize (H12AffineFastState.compose env17841 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2209) := by decide +kernel

theorem selectedBound17841 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17842 : List Nat := [2,4,8,16,32,16,128,256,1,1024,2048,4096,2209,4096,32768,65536,1297,32904,1025,32769,4097,260,5377,98565,2089,5376,32905,4097,1296,2049,1285,35077,257,68014,1297,1]

theorem envBound17842 : H12AffineFastState.Bounded env17842 := by
  intro p hp
  have h : env17842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17841_17842 : H12AffineEnvironment.transform 12 2209 env17841 = env17842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2209 env17841 == env17842) = true)

theorem identity17842 : scanCanonicalize (H12AffineFastState.compose env17842 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 7577) := by decide +kernel

theorem selectedBound17842 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17843 : List Nat := [2,4,8,16,32,16,128,256,1,1024,2048,4096,2209,4096,7577,65536,1297,7441,1025,7576,4097,260,5377,72860,2089,5376,7440,4097,1296,2049,1285,5276,257,68014,1297,1]

theorem envBound17843 : H12AffineFastState.Bounded env17843 := by
  intro p hp
  have h : env17843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17842_17843 : H12AffineEnvironment.transform 14 7577 env17842 = env17843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7577 env17842 == env17843) = true)

def env17844 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,262144,1025,32769,4097,4194304,5377,98564,8328,5377,4456708,4097,1297,1073741824,1284,1077979297,257,1073817871,1296,512]

theorem envBound17844 : H12AffineFastState.Bounded env17844 := by
  intro p hp
  have h : env17844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17836_17844 : H12AffineEnvironment.transform 5 17 env17836 = env17844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17836 == env17844) = true)

theorem identity17844 : scanCanonicalize (H12AffineFastState.compose env17844 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(29+1) ^^^ 4497708) := by decide +kernel

theorem selectedBound17844 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env17845 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,262144,1025,32769,4097,4194304,5377,98564,8328,5377,4456708,4097,1297,4497708,1284,264589,257,4556835,1296,512]

theorem envBound17845 : H12AffineFastState.Bounded env17845 := by
  intro p hp
  have h : env17845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17844_17845 : H12AffineEnvironment.transform 29 4497708 env17844 = env17845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4497708 env17844 == env17845) = true)

theorem identity17845 : scanCanonicalize (H12AffineFastState.compose env17845 (packedSelected [5,8,10,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 43681) := by decide +kernel

theorem selectedBound17845 : packedSelected [5,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env17846 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,43681,1025,32769,4097,4194304,5377,98564,8328,5377,4238245,4097,1297,4197261,1284,41772,257,4268674,1296,512]

theorem envBound17846 : H12AffineFastState.Bounded env17846 := by
  intro p hp
  have h : env17846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17845_17846 : H12AffineEnvironment.transform 17 43681 env17845 = env17846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43681 env17845 == env17846) = true)

theorem identity17846 : scanCanonicalize (H12AffineFastState.compose env17846 (packedSelected [1,10] rootPS)) = affineNative (2^(21+1) ^^^ 35756) := by decide +kernel

theorem selectedBound17846 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env17847 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,43681,1025,32769,4097,35756,5377,98564,8328,5377,8201,4097,1297,32801,1284,41772,257,108846,1296,512]

theorem envBound17847 : H12AffineFastState.Bounded env17847 := by
  intro p hp
  have h : env17847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17846_17847 : H12AffineEnvironment.transform 21 35756 env17846 = env17847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 35756 env17846 == env17847) = true)

theorem identity17847 : scanCanonicalize (H12AffineFastState.compose env17847 (packedSelected [1,12,17] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound17847 : packedSelected [1,12,17] rootPS < 2^1333 := by decide +kernel

def env17848 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8192,4096,32768,65536,1296,43048,1025,32769,4097,35109,5377,98564,8328,5377,8201,4097,1297,32801,1284,41381,257,108846,1296,137]

theorem envBound17848 : H12AffineFastState.Bounded env17848 := by
  intro p hp
  have h : env17848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17847_17848 : H12AffineEnvironment.transform 8 137 env17847 = env17848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env17847 == env17848) = true)

def env17849 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,8192,1296,32768,65536,1296,43048,1025,32769,1297,35109,17,98564,8328,17,8201,1297,1297,32801,1284,41381,257,108846,1296,137]

theorem envBound17849 : H12AffineFastState.Bounded env17849 := by
  intro p hp
  have h : env17849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17848_17849 : H12AffineEnvironment.transform 11 1296 env17848 = env17849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env17848 == env17849) = true)

theorem identity17849 : scanCanonicalize (H12AffineFastState.compose env17849 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound17849 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17850 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,2056,1296,32768,65536,1296,32800,1025,32769,1297,35109,17,98564,2176,17,2049,1297,1297,32801,1284,35245,257,98598,1296,137]

theorem envBound17850 : H12AffineFastState.Bounded env17850 := by
  intro p hp
  have h : env17850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17849_17850 : H12AffineEnvironment.transform 12 2056 env17849 = env17850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env17849 == env17850) = true)

def env17851 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,0,2056,0,32768,65536,0,32800,273,32769,1,35109,17,98564,2176,17,2049,1,1,32801,20,35245,257,98598,0,137]

theorem envBound17851 : H12AffineFastState.Bounded env17851 := by
  intro p hp
  have h : env17851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17850_17851 : H12AffineEnvironment.transform 9 272 env17850 = env17851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env17850 == env17851) = true)

theorem identity17851 : scanCanonicalize (H12AffineFastState.compose env17851 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound17851 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17852 : List Nat := [2,4,8,16,32,17,128,256,137,272,260,0,268,0,32768,65536,0,32800,273,32769,1,32801,17,98564,388,17,261,1,1,32801,20,32937,257,98598,0,137]

theorem envBound17852 : H12AffineFastState.Bounded env17852 := by
  intro p hp
  have h : env17852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17851_17852 : H12AffineEnvironment.transform 10 260 env17851 = env17852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env17851 == env17852) = true)

def env17853 : List Nat := [2,4,8,16,32,17,128,256,137,272,260,0,268,0,0,65536,0,32,273,1,1,33,17,65796,388,17,261,1,1,33,20,169,257,65830,0,137]

theorem envBound17853 : H12AffineFastState.Bounded env17853 := by
  intro p hp
  have h : env17853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17852_17853 : H12AffineEnvironment.transform 14 0 env17852 = env17853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env17852 == env17853) = true)

theorem identity17853 : scanCanonicalize (H12AffineFastState.compose env17853 (packedSelected [0,4] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound17853 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17854 : List Nat := [2,4,8,16,32,17,128,256,137,272,260,0,268,0,0,399,0,32,273,1,1,33,17,139,388,17,261,1,1,33,20,169,257,169,0,137]

theorem envBound17854 : H12AffineFastState.Bounded env17854 := by
  intro p hp
  have h : env17854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17853_17854 : H12AffineEnvironment.transform 15 399 env17853 = env17854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env17853 == env17854) = true)

theorem identity17854 : scanCanonicalize (H12AffineFastState.compose env17854 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound17854 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17855 : List Nat := [2,4,8,16,32,17,128,21,137,5,17,0,25,0,0,154,0,32,4,1,1,33,17,139,145,17,16,1,1,33,20,169,20,169,0,137]

theorem envBound17855 : H12AffineFastState.Bounded env17855 := by
  intro p hp
  have h : env17855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17854_17855 : H12AffineEnvironment.transform 7 21 env17854 = env17855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env17854 == env17855) = true)

def env17856 : List Nat := [2,4,8,16,0,17,128,21,137,5,17,0,25,0,0,154,0,0,4,1,1,1,17,139,145,17,16,1,1,1,20,137,20,137,0,137]

theorem envBound17856 : H12AffineFastState.Bounded env17856 := by
  intro p hp
  have h : env17856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17855_17856 : H12AffineEnvironment.transform 4 0 env17855 = env17856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17855 == env17856) = true)

theorem identity17856 : scanCanonicalize (H12AffineFastState.compose env17856 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17856 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17857 : List Nat := [2,4,8,1,0,0,128,4,137,5,0,0,8,0,0,139,0,0,4,1,1,1,0,139,128,0,1,1,1,1,5,137,5,137,0,137]

theorem envBound17857 : H12AffineFastState.Bounded env17857 := by
  intro p hp
  have h : env17857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17856_17857 : H12AffineEnvironment.transform 3 1 env17856 = env17857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17856 == env17857) = true)

def leafEnv17857 : List Nat := [2,4,8,1,0,0,128,4,137,5,0,0,8,0,0,139,0,0,4,1,1,1,0,139,5,128,1,0,1,1,1,1,5,137,5,137,4,2,0,137,0,1,1]

def active17857 : List Nat := [0,1,2,6]

def tree17857 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17857 : H12WitnessSearch.Good tree17857 := H12GlobalWitnessIndex.good

theorem leafIdentity17857 : H12AffineFastState.composeSystem env17857 rootObs = leafEnv17857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17857 rootObs == leafEnv17857) = true)

theorem terminalChecked17857 : H12PackedTerminal.terminalCheckFast leafEnv17857 active17857 tree17857 = true := by decide +kernel

def env17858 : List Nat := [2,4,8,16,1,17,128,21,137,5,17,0,25,0,0,154,0,1,4,1,1,0,17,139,145,17,16,1,1,0,20,136,20,136,0,137]

theorem envBound17858 : H12AffineFastState.Bounded env17858 := by
  intro p hp
  have h : env17858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17855_17858 : H12AffineEnvironment.transform 4 1 env17855 = env17858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17855 == env17858) = true)

def leafEnv17858 : List Nat := [2,4,8,16,1,17,128,21,137,5,17,0,25,0,0,154,0,1,4,1,1,0,17,139,20,145,1,17,16,1,1,0,20,136,20,136,4,19,0,137,0,1,1]

def active17858 : List Nat := [0,1,2,3,6]

def tree17858 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17858 : H12WitnessSearch.Good tree17858 := H12GlobalWitnessIndex.good

theorem leafIdentity17858 : H12AffineFastState.composeSystem env17858 rootObs = leafEnv17858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17858 rootObs == leafEnv17858) = true)

theorem terminalChecked17858 : H12PackedTerminal.terminalCheckFast leafEnv17858 active17858 tree17858 = true := by decide +kernel

def env17859 : List Nat := [2,4,8,16,32,17,128,256,137,272,260,0,268,0,1,65536,0,33,273,0,1,32,17,65797,388,17,261,1,1,32,20,168,257,65831,0,137]

theorem envBound17859 : H12AffineFastState.Bounded env17859 := by
  intro p hp
  have h : env17859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17852_17859 : H12AffineEnvironment.transform 14 1 env17852 = env17859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env17852 == env17859) = true)

def env17860 : List Nat := [2,4,8,16,32,17,128,256,137,273,2048,1,2056,1,32768,65536,1,32800,272,32769,0,35109,17,98564,2176,17,2049,0,0,32801,21,35245,257,98598,1,137]

theorem envBound17860 : H12AffineFastState.Bounded env17860 := by
  intro p hp
  have h : env17860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17850_17860 : H12AffineEnvironment.transform 9 273 env17850 = env17860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env17850 == env17860) = true)

theorem identity17860 : scanCanonicalize (H12AffineFastState.compose env17860 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 34955) := by decide +kernel

theorem selectedBound17860 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17861 : List Nat := [2,4,8,16,32,17,128,256,137,273,2048,1,2056,1,32768,34955,1,32800,272,32769,0,35109,17,2447,2176,17,2049,0,0,32801,21,35245,257,2477,1,137]

theorem envBound17861 : H12AffineFastState.Bounded env17861 := by
  intro p hp
  have h : env17861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17860_17861 : H12AffineEnvironment.transform 15 34955 env17860 = env17861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34955 env17860 == env17861) = true)

def env17862 : List Nat := [2,4,8,16,32,17,128,256,137,273,2048,1,2056,1,136,2051,1,168,272,137,0,2477,17,2447,2176,17,2049,0,0,169,21,2341,257,2477,1,137]

theorem envBound17862 : H12AffineFastState.Bounded env17862 := by
  intro p hp
  have h : env17862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17861_17862 : H12AffineEnvironment.transform 14 136 env17861 = env17862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env17861 == env17862) = true)

def env17863 : List Nat := [2,4,8,16,0,17,128,256,137,273,2048,1,2056,1,136,2051,1,136,272,137,0,2445,17,2447,2176,17,2049,0,0,137,21,2309,257,2445,1,137]

theorem envBound17863 : H12AffineFastState.Bounded env17863 := by
  intro p hp
  have h : env17863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17862_17863 : H12AffineEnvironment.transform 4 0 env17862 = env17863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17862 == env17863) = true)

theorem identity17863 : scanCanonicalize (H12AffineFastState.compose env17863 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 276) := by decide +kernel

theorem selectedBound17863 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17864 : List Nat := [2,4,8,16,0,17,128,256,137,273,276,1,284,1,136,279,1,136,272,137,0,153,17,155,404,17,277,0,0,137,21,17,257,153,1,137]

theorem envBound17864 : H12AffineFastState.Bounded env17864 := by
  intro p hp
  have h : env17864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17863_17864 : H12AffineEnvironment.transform 10 276 env17863 = env17864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 276 env17863 == env17864) = true)

def env17865 : List Nat := [2,4,8,16,0,17,8,256,1,273,276,1,284,1,0,279,1,0,272,1,0,17,17,19,284,17,277,0,0,1,21,17,257,17,1,1]

theorem envBound17865 : H12AffineFastState.Bounded env17865 := by
  intro p hp
  have h : env17865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17864_17865 : H12AffineEnvironment.transform 6 8 env17864 = env17865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17864 == env17865) = true)

theorem identity17865 : scanCanonicalize (H12AffineFastState.compose env17865 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound17865 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17866 : List Nat := [2,4,8,16,0,17,8,21,1,4,1,1,9,1,0,2,1,0,5,1,0,17,17,19,9,17,0,0,0,1,21,17,20,17,1,1]

theorem envBound17866 : H12AffineFastState.Bounded env17866 := by
  intro p hp
  have h : env17866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17865_17866 : H12AffineEnvironment.transform 7 21 env17865 = env17866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env17865 == env17866) = true)

def env17867 : List Nat := [2,4,8,16,0,17,9,256,0,273,276,1,284,1,1,279,1,1,272,0,0,16,17,18,285,17,277,0,0,0,21,17,257,16,1,0]

theorem envBound17867 : H12AffineFastState.Bounded env17867 := by
  intro p hp
  have h : env17867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17864_17867 : H12AffineEnvironment.transform 6 9 env17864 = env17867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17864 == env17867) = true)

theorem identity17867 : scanCanonicalize (H12AffineFastState.compose env17867 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound17867 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17868 : List Nat := [2,4,8,0,0,1,9,256,0,257,260,1,268,1,1,263,1,1,256,0,0,0,1,2,269,1,261,0,0,0,5,1,257,0,1,0]

theorem envBound17868 : H12AffineFastState.Bounded env17868 := by
  intro p hp
  have h : env17868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17867_17868 : H12AffineEnvironment.transform 3 0 env17867 = env17868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17867 == env17868) = true)

def leafEnv17868 : List Nat := [2,4,8,0,0,1,9,256,0,257,260,1,268,1,1,263,1,1,256,0,0,0,1,2,5,269,1,1,261,0,0,0,5,1,257,0,4,263,1,0,0,0,1]

def active17868 : List Nat := [0,1,2,7]

def tree17868 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17868 : H12WitnessSearch.Good tree17868 := H12GlobalWitnessIndex.good

theorem leafIdentity17868 : H12AffineFastState.composeSystem env17868 rootObs = leafEnv17868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17868 rootObs == leafEnv17868) = true)

theorem terminalChecked17868 : H12PackedTerminal.terminalCheckFast leafEnv17868 active17868 tree17868 = true := by decide +kernel

def env17869 : List Nat := [2,4,8,16,1,17,128,256,137,273,2048,1,2056,1,136,2051,1,137,272,137,0,2444,17,2447,2176,17,2049,0,0,136,21,2308,257,2444,1,137]

theorem envBound17869 : H12AffineFastState.Bounded env17869 := by
  intro p hp
  have h : env17869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17862_17869 : H12AffineEnvironment.transform 4 1 env17862 = env17869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17862 == env17869) = true)

theorem identity17869 : scanCanonicalize (H12AffineFastState.compose env17869 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 156) := by decide +kernel

theorem selectedBound17869 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17870 : List Nat := [2,4,8,16,1,17,128,156,137,141,2048,1,2056,1,136,2051,1,137,140,137,0,2064,17,2067,2176,17,2049,0,0,136,21,2200,157,2064,1,137]

theorem envBound17870 : H12AffineFastState.Bounded env17870 := by
  intro p hp
  have h : env17870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17869_17870 : H12AffineEnvironment.transform 7 156 env17869 = env17870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 156 env17869 == env17870) = true)

def env17871 : List Nat := [2,4,8,16,1,17,128,156,137,141,0,1,8,1,136,3,1,137,140,137,0,16,17,19,128,17,1,0,0,136,21,152,157,16,1,137]

theorem envBound17871 : H12AffineFastState.Bounded env17871 := by
  intro p hp
  have h : env17871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17870_17871 : H12AffineEnvironment.transform 10 0 env17870 = env17871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env17870 == env17871) = true)

theorem identity17871 : scanCanonicalize (H12AffineFastState.compose env17871 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17871 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17872 : List Nat := [2,4,8,1,1,0,128,141,137,141,0,1,8,1,136,3,1,137,140,137,0,1,0,2,128,0,1,0,0,136,4,137,140,1,1,137]

theorem envBound17872 : H12AffineFastState.Bounded env17872 := by
  intro p hp
  have h : env17872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17871_17872 : H12AffineEnvironment.transform 3 1 env17871 = env17872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17871 == env17872) = true)

theorem identity17872 : scanCanonicalize (H12AffineFastState.compose env17872 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17872 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17873 : List Nat := [2,4,8,1,1,0,9,4,0,4,0,1,8,1,1,3,1,0,5,0,0,1,0,2,9,0,1,0,0,1,4,0,5,1,1,0]

theorem envBound17873 : H12AffineFastState.Bounded env17873 := by
  intro p hp
  have h : env17873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17872_17873 : H12AffineEnvironment.transform 6 9 env17872 = env17873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17872 == env17873) = true)

def leafEnv17873 : List Nat := [2,4,8,1,1,0,9,4,0,4,0,1,8,1,1,3,1,0,5,0,0,1,0,2,4,9,1,0,1,0,0,1,4,0,5,1,4,3,1,0,0,0,1]

def active17873 : List Nat := [0,1,2]

def tree17873 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17873 : H12WitnessSearch.Good tree17873 := H12GlobalWitnessIndex.good

theorem leafIdentity17873 : H12AffineFastState.composeSystem env17873 rootObs = leafEnv17873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17873 rootObs == leafEnv17873) = true)

theorem terminalChecked17873 : H12PackedTerminal.terminalCheckFast leafEnv17873 active17873 tree17873 = true := by decide +kernel

def env17874 : List Nat := [2,4,8,16,1,17,128,156,137,141,1,1,9,1,136,2,1,137,140,137,0,17,17,18,129,17,0,0,0,136,21,153,157,17,1,137]

theorem envBound17874 : H12AffineFastState.Bounded env17874 := by
  intro p hp
  have h : env17874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17870_17874 : H12AffineEnvironment.transform 10 1 env17870 = env17874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env17870 == env17874) = true)

theorem identity17874 : scanCanonicalize (H12AffineFastState.compose env17874 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound17874 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17875 : List Nat := [2,4,8,16,1,17,24,4,17,21,1,1,9,1,16,2,1,17,20,17,0,17,17,18,25,17,0,0,0,16,21,1,5,17,1,17]

theorem envBound17875 : H12AffineFastState.Bounded env17875 := by
  intro p hp
  have h : env17875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17874_17875 : H12AffineEnvironment.transform 6 24 env17874 = env17875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env17874 == env17875) = true)

def env17876 : List Nat := [2,4,8,16,32,17,128,256,137,273,2048,1,2056,1,137,2050,1,169,272,136,0,2476,17,2447,2176,17,2049,0,0,168,21,2340,257,2477,1,137]

theorem envBound17876 : H12AffineFastState.Bounded env17876 := by
  intro p hp
  have h : env17876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17861_17876 : H12AffineEnvironment.transform 14 137 env17861 = env17876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env17861 == env17876) = true)

def env17877 : List Nat := [2,4,8,16,0,17,128,256,137,273,2048,1,2056,1,137,2050,1,137,272,136,0,2444,17,2447,2176,17,2049,0,0,136,21,2308,257,2445,1,137]

theorem envBound17877 : H12AffineFastState.Bounded env17877 := by
  intro p hp
  have h : env17877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17876_17877 : H12AffineEnvironment.transform 4 0 env17876 = env17877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17876 == env17877) = true)

theorem identity17877 : scanCanonicalize (H12AffineFastState.compose env17877 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound17877 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17878 : List Nat := [2,4,8,16,0,17,25,256,16,273,2048,1,2056,1,16,2050,1,16,272,17,0,2325,17,2326,2073,17,2049,0,0,17,21,2308,257,2324,1,16]

theorem envBound17878 : H12AffineFastState.Bounded env17878 := by
  intro p hp
  have h : env17878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17877_17878 : H12AffineEnvironment.transform 6 25 env17877 = env17878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env17877 == env17878) = true)

def env17879 : List Nat := [2,4,8,16,0,17,25,256,16,273,0,1,8,1,16,2,1,16,272,17,0,277,17,278,25,17,1,0,0,17,21,260,257,276,1,16]

theorem envBound17879 : H12AffineFastState.Bounded env17879 := by
  intro p hp
  have h : env17879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17878_17879 : H12AffineEnvironment.transform 10 0 env17878 = env17879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env17878 == env17879) = true)

theorem identity17879 : scanCanonicalize (H12AffineFastState.compose env17879 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17879 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17880 : List Nat := [2,4,8,1,0,0,8,256,1,256,0,1,8,1,1,2,1,1,257,0,0,260,0,263,8,0,1,0,0,0,4,260,257,261,1,1]

theorem envBound17880 : H12AffineFastState.Bounded env17880 := by
  intro p hp
  have h : env17880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17879_17880 : H12AffineEnvironment.transform 3 1 env17879 = env17880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17879 == env17880) = true)

theorem identity17880 : scanCanonicalize (H12AffineFastState.compose env17880 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17880 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17881 : List Nat := [2,4,8,1,0,0,8,4,1,4,0,1,8,1,1,2,1,1,5,0,0,0,0,3,8,0,1,0,0,0,4,0,5,1,1,1]

theorem envBound17881 : H12AffineFastState.Bounded env17881 := by
  intro p hp
  have h : env17881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17880_17881 : H12AffineEnvironment.transform 7 4 env17880 = env17881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17880 == env17881) = true)

def leafEnv17881 : List Nat := [2,4,8,1,0,0,8,4,1,4,0,1,8,1,1,2,1,1,5,0,0,0,0,3,4,8,1,0,1,0,0,0,4,0,5,1,4,3,1,1,0,0,1]

def active17881 : List Nat := [0,1,2]

def tree17881 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17881 : H12WitnessSearch.Good tree17881 := H12GlobalWitnessIndex.good

theorem leafIdentity17881 : H12AffineFastState.composeSystem env17881 rootObs = leafEnv17881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17881 rootObs == leafEnv17881) = true)

theorem terminalChecked17881 : H12PackedTerminal.terminalCheckFast leafEnv17881 active17881 tree17881 = true := by decide +kernel

def env17882 : List Nat := [2,4,8,16,0,17,25,256,16,273,1,1,9,1,16,3,1,16,272,17,0,276,17,279,24,17,0,0,0,17,21,261,257,277,1,16]

theorem envBound17882 : H12AffineFastState.Bounded env17882 := by
  intro p hp
  have h : env17882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17878_17882 : H12AffineEnvironment.transform 10 1 env17878 = env17882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env17878 == env17882) = true)

def env17883 : List Nat := [2,4,8,0,0,1,9,256,0,257,1,1,9,1,0,3,1,0,256,1,0,260,1,263,8,1,0,0,0,1,5,261,257,261,1,0]

theorem envBound17883 : H12AffineFastState.Bounded env17883 := by
  intro p hp
  have h : env17883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17882_17883 : H12AffineEnvironment.transform 3 0 env17882 = env17883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17882 == env17883) = true)

def env17884 : List Nat := [2,4,8,1,0,0,8,256,1,256,1,1,9,1,1,3,1,1,257,0,0,261,0,262,9,0,0,0,0,0,4,261,257,260,1,1]

theorem envBound17884 : H12AffineFastState.Bounded env17884 := by
  intro p hp
  have h : env17884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17882_17884 : H12AffineEnvironment.transform 3 1 env17882 = env17884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17882 == env17884) = true)

theorem identity17884 : scanCanonicalize (H12AffineFastState.compose env17884 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17884 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17885 : List Nat := [2,4,8,1,0,0,8,5,1,5,1,1,9,1,1,3,1,1,4,0,0,0,0,3,9,0,0,0,0,0,4,0,4,1,1,1]

theorem envBound17885 : H12AffineFastState.Bounded env17885 := by
  intro p hp
  have h : env17885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17884_17885 : H12AffineEnvironment.transform 7 5 env17884 = env17885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17884 == env17885) = true)

def leafEnv17885 : List Nat := [2,4,8,1,0,0,8,5,1,5,1,1,9,1,1,3,1,1,4,0,0,0,0,3,4,9,1,0,0,0,0,0,4,0,4,1,4,2,1,1,0,0,1]

def active17885 : List Nat := [0,1,2]

def tree17885 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17885 : H12WitnessSearch.Good tree17885 := H12GlobalWitnessIndex.good

theorem leafIdentity17885 : H12AffineFastState.composeSystem env17885 rootObs = leafEnv17885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17885 rootObs == leafEnv17885) = true)

theorem terminalChecked17885 : H12PackedTerminal.terminalCheckFast leafEnv17885 active17885 tree17885 = true := by decide +kernel

def env17886 : List Nat := [2,4,8,16,1,17,128,256,137,273,2048,1,2056,1,137,2050,1,136,272,136,0,2445,17,2447,2176,17,2049,0,0,137,21,2309,257,2444,1,137]

theorem envBound17886 : H12AffineFastState.Bounded env17886 := by
  intro p hp
  have h : env17886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17876_17886 : H12AffineEnvironment.transform 4 1 env17876 = env17886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17876 == env17886) = true)

theorem identity17886 : scanCanonicalize (H12AffineFastState.compose env17886 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound17886 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17887 : List Nat := [2,4,8,16,1,17,128,256,137,273,16,1,24,1,137,18,1,136,272,136,0,413,17,415,144,17,17,0,0,137,21,277,257,412,1,137]

theorem envBound17887 : H12AffineFastState.Bounded env17887 := by
  intro p hp
  have h : env17887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17886_17887 : H12AffineEnvironment.transform 10 16 env17886 = env17887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env17886 == env17887) = true)

def env17888 : List Nat := [2,4,8,0,1,1,128,256,137,257,0,1,8,1,137,2,1,136,256,136,0,397,1,399,128,1,1,0,0,137,5,261,257,396,1,137]

theorem envBound17888 : H12AffineFastState.Bounded env17888 := by
  intro p hp
  have h : env17888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17887_17888 : H12AffineEnvironment.transform 3 0 env17887 = env17888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17887 == env17888) = true)

theorem identity17888 : scanCanonicalize (H12AffineFastState.compose env17888 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound17888 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17889 : List Nat := [2,4,8,0,1,1,128,140,137,141,0,1,8,1,137,2,1,136,140,136,0,1,1,3,128,1,1,0,0,137,5,137,141,0,1,137]

theorem envBound17889 : H12AffineFastState.Bounded env17889 := by
  intro p hp
  have h : env17889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17888_17889 : H12AffineEnvironment.transform 7 140 env17888 = env17889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env17888 == env17889) = true)

theorem identity17889 : scanCanonicalize (H12AffineFastState.compose env17889 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound17889 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17890 : List Nat := [2,4,8,0,1,1,8,4,1,5,0,1,8,1,1,2,1,0,4,0,0,1,1,3,8,1,1,0,0,1,5,1,5,0,1,1]

theorem envBound17890 : H12AffineFastState.Bounded env17890 := by
  intro p hp
  have h : env17890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17889_17890 : H12AffineEnvironment.transform 6 8 env17889 = env17890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17889 == env17890) = true)

def leafEnv17890 : List Nat := [2,4,8,0,1,1,8,4,1,5,0,1,8,1,1,2,1,0,4,0,0,1,1,3,5,8,1,1,1,0,0,1,5,1,5,0,4,3,1,1,0,0,1]

def active17890 : List Nat := [0,1,2]

def tree17890 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17890 : H12WitnessSearch.Good tree17890 := H12GlobalWitnessIndex.good

theorem leafIdentity17890 : H12AffineFastState.composeSystem env17890 rootObs = leafEnv17890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17890 rootObs == leafEnv17890) = true)

theorem terminalChecked17890 : H12PackedTerminal.terminalCheckFast leafEnv17890 active17890 tree17890 = true := by decide +kernel

def env17891 : List Nat := [2,4,8,1,1,0,128,256,137,256,1,1,9,1,137,3,1,136,257,136,0,396,0,398,129,0,0,0,0,137,4,260,257,397,1,137]

theorem envBound17891 : H12AffineFastState.Bounded env17891 := by
  intro p hp
  have h : env17891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17887_17891 : H12AffineEnvironment.transform 3 1 env17887 = env17891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17887 == env17891) = true)

theorem identity17891 : scanCanonicalize (H12AffineFastState.compose env17891 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17891 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17892 : List Nat := [2,4,8,1,1,0,128,4,137,4,1,1,9,1,137,3,1,136,5,136,0,136,0,138,129,0,0,0,0,137,4,0,5,137,1,137]

theorem envBound17892 : H12AffineFastState.Bounded env17892 := by
  intro p hp
  have h : env17892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17891_17892 : H12AffineEnvironment.transform 7 4 env17891 = env17892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17891 == env17892) = true)

def env17893 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1297,8192,1297,32768,65536,1296,43048,1025,32769,1296,35109,16,98564,8328,16,8201,1296,1297,32801,1284,41381,257,108846,1296,137]

theorem envBound17893 : H12AffineFastState.Bounded env17893 := by
  intro p hp
  have h : env17893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17848_17893 : H12AffineEnvironment.transform 11 1297 env17848 = env17893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env17848 == env17893) = true)

theorem identity17893 : scanCanonicalize (H12AffineFastState.compose env17893 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound17893 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17894 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1297,8192,1297,8233,65536,1296,2049,1025,8232,1296,10508,16,74029,8328,16,8201,1296,1297,8200,1284,396,257,67847,1296,137]

theorem envBound17894 : H12AffineFastState.Bounded env17894 := by
  intro p hp
  have h : env17894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17893_17894 : H12AffineEnvironment.transform 14 8233 env17893 = env17894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env17893 == env17894) = true)

theorem identity17894 : scanCanonicalize (H12AffineFastState.compose env17894 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 2478) := by decide +kernel

theorem selectedBound17894 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17895 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1297,8192,1297,8233,2478,1296,2049,1025,8232,1296,10508,16,10371,8328,16,8201,1296,1297,8200,1284,396,257,169,1296,137]

theorem envBound17895 : H12AffineFastState.Bounded env17895 := by
  intro p hp
  have h : env17895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17894_17895 : H12AffineEnvironment.transform 15 2478 env17894 = env17895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2478 env17894 == env17895) = true)

theorem identity17895 : scanCanonicalize (H12AffineFastState.compose env17895 (packedSelected [0,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17895 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env17896 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,1044,8192,1044,8233,2219,1045,2049,1025,8232,1045,10249,16,10371,8328,16,8201,1045,1044,8200,1025,137,4,169,1045,137]

theorem envBound17896 : H12AffineFastState.Bounded env17896 := by
  intro p hp
  have h : env17896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17895_17896 : H12AffineEnvironment.transform 7 5 env17895 = env17896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17895 == env17896) = true)

theorem identity17896 : scanCanonicalize (H12AffineFastState.compose env17896 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 2057) := by decide +kernel

theorem selectedBound17896 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env17897 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,1044,2057,1044,2080,2219,1045,2049,1025,2081,1045,0,16,138,2177,16,2048,1045,1044,2049,1025,137,4,169,1045,137]

theorem envBound17897 : H12AffineFastState.Bounded env17897 := by
  intro p hp
  have h : env17897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17896_17897 : H12AffineEnvironment.transform 12 2057 env17896 = env17897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env17896 == env17897) = true)

theorem identity17897 : scanCanonicalize (H12AffineFastState.compose env17897 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound17897 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17898 : List Nat := [2,4,8,16,32,17,128,5,137,1024,1212,1044,1205,1044,1180,1047,1045,1213,1025,1181,1045,0,16,138,1085,16,1212,1045,1044,1213,1025,137,4,169,1045,137]

theorem envBound17898 : H12AffineFastState.Bounded env17898 := by
  intro p hp
  have h : env17898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17897_17898 : H12AffineEnvironment.transform 10 1212 env17897 = env17898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env17897 == env17898) = true)

def env17899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,1345,262144,1025,32769,4097,4194304,5376,98644,8328,5457,4456788,4096,1345,1073741824,1364,4294967296,257,4299260414,1345,512]

theorem envBound17899 : H12AffineFastState.Bounded env17899 := by
  intro p hp
  have h : env17899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17834_17899 : H12AffineEnvironment.transform 13 4097 env17834 = env17899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env17834 == env17899) = true)

theorem identity17899 : scanCanonicalize (H12AffineFastState.compose env17899 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17899 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env17900 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,262144,1025,32769,4097,4194304,5376,98564,8328,5377,4456708,4096,1297,1073741824,1284,4294967296,257,4299260334,1297,512]

theorem envBound17900 : H12AffineFastState.Bounded env17900 := by
  intro p hp
  have h : env17900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17899_17900 : H12AffineEnvironment.transform 5 16 env17899 = env17900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17899 == env17900) = true)

theorem identity17900 : scanCanonicalize (H12AffineFastState.compose env17900 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(31+1) ^^^ 1078296838) := by decide +kernel

theorem selectedBound17900 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env17901 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,262144,1025,32769,4097,4194304,5376,98564,8328,5377,4456708,4096,1297,1073741824,1284,1078296838,257,1074004136,1297,512]

end H12CloudChart2