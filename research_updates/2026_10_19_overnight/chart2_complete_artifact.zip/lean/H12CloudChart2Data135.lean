import H12CloudChart2Data134

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env33498 : List Nat := [2,4,8,16,32,17,128,256,413,5,2048,2194,25,277,2194,2224,276,2097,4,2195,2195,397,17,50,145,17,43,276,2194,2341,20,2455,257,2179,277,412]

theorem envBound33498 : H12AffineFastState.Bounded env33498 := by
  intro p hp
  have h : env33498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33497_33498 : H12AffineEnvironment.transform 11 2194 env33497 = env33498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2194 env33497 == env33498) = true)

theorem identity33498 : scanCanonicalize (H12AffineFastState.compose env33498 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound33498 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env33499 : List Nat := [2,4,8,16,32,17,128,256,413,5,147,1,25,277,1,35,276,162,4,0,0,397,17,50,145,17,43,276,1,438,20,260,257,16,277,412]

theorem envBound33499 : H12AffineFastState.Bounded env33499 := by
  intro p hp
  have h : env33499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33498_33499 : H12AffineEnvironment.transform 10 147 env33498 = env33499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env33498 == env33499) = true)

theorem identity33499 : scanCanonicalize (H12AffineFastState.compose env33499 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound33499 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33500 : List Nat := [2,4,8,16,11,17,128,256,413,5,147,1,25,277,1,8,276,137,4,0,0,397,17,25,145,17,0,276,1,413,20,260,257,16,277,412]

theorem envBound33500 : H12AffineFastState.Bounded env33500 := by
  intro p hp
  have h : env33500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33499_33500 : H12AffineEnvironment.transform 4 11 env33499 = env33500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env33499 == env33500) = true)

theorem identity33500 : scanCanonicalize (H12AffineFastState.compose env33500 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 13) := by decide +kernel

theorem selectedBound33500 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env33501 : List Nat := [2,4,8,16,11,17,128,13,144,5,147,1,25,24,1,8,25,137,4,0,0,128,17,25,145,17,0,25,1,144,20,9,12,16,24,145]

theorem envBound33501 : H12AffineFastState.Bounded env33501 := by
  intro p hp
  have h : env33501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33500_33501 : H12AffineEnvironment.transform 7 13 env33500 = env33501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 13 env33500 == env33501) = true)

theorem identity33501 : scanCanonicalize (H12AffineFastState.compose env33501 (packedSelected [5,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33501 : packedSelected [5,7] rootPS < 2^1333 := by decide +kernel

def env33502 : List Nat := [2,4,8,16,11,17,8,13,24,5,27,1,25,24,1,8,25,1,4,0,0,8,17,25,25,17,0,25,1,24,20,9,12,16,24,25]

theorem envBound33502 : H12AffineFastState.Bounded env33502 := by
  intro p hp
  have h : env33502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33501_33502 : H12AffineEnvironment.transform 6 8 env33501 = env33502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33501 == env33502) = true)

theorem identity33502 : scanCanonicalize (H12AffineFastState.compose env33502 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound33502 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env33503 : List Nat := [2,4,8,2,11,3,8,13,10,5,9,1,11,10,1,8,11,1,4,0,0,8,3,11,11,3,0,11,1,10,6,9,12,2,10,11]

theorem envBound33503 : H12AffineFastState.Bounded env33503 := by
  intro p hp
  have h : env33503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33502_33503 : H12AffineEnvironment.transform 3 2 env33502 = env33503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env33502 == env33503) = true)

theorem identity33503 : scanCanonicalize (H12AffineFastState.compose env33503 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound33503 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33504 : List Nat := [2,4,4,2,7,3,4,1,6,5,5,1,7,6,1,4,7,1,4,0,0,4,3,7,7,3,0,7,1,6,6,5,0,2,6,7]

theorem envBound33504 : H12AffineFastState.Bounded env33504 := by
  intro p hp
  have h : env33504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33503_33504 : H12AffineEnvironment.transform 2 4 env33503 = env33504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env33503 == env33504) = true)

theorem identity33504 : scanCanonicalize (H12AffineFastState.compose env33504 (packedSelected [2,5] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound33504 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env33505 : List Nat := [2,0,0,2,3,3,0,1,2,1,1,1,3,2,1,0,3,1,0,0,0,0,3,3,3,3,0,3,1,2,2,1,0,2,2,3]

theorem envBound33505 : H12AffineFastState.Bounded env33505 := by
  intro p hp
  have h : env33505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33504_33505 : H12AffineEnvironment.transform 1 0 env33504 = env33505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env33504 == env33505) = true)

theorem identity33505 : scanCanonicalize (H12AffineFastState.compose env33505 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound33505 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33506 : List Nat := [0,0,0,0,1,1,0,1,0,1,1,1,1,0,1,0,1,1,0,0,0,0,1,1,1,1,0,1,1,0,0,1,0,0,0,1]

theorem envBound33506 : H12AffineFastState.Bounded env33506 := by
  intro p hp
  have h : env33506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33505_33506 : H12AffineEnvironment.transform 0 0 env33505 = env33506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env33505 == env33506) = true)

def env33507 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77935,32769,4097,46529,17,266384,70886,78894,77840,1297,74814,81227,365713,308666,257,74798,1345,79471]

theorem envBound33507 : H12AffineFastState.Bounded env33507 := by
  intro p hp
  have h : env33507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33461_33507 : H12AffineEnvironment.transform 13 1297 env33461 = env33507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env33461 == env33507) = true)

theorem identity33507 : scanCanonicalize (H12AffineFastState.compose env33507 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound33507 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env33508 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32882,1345,262144,45085,32769,4097,46529,17,266384,38036,46172,45154,1297,42060,48441,267491,308666,257,42076,1345,46621]

theorem envBound33508 : H12AffineFastState.Bounded env33508 := by
  intro p hp
  have h : env33508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33507_33508 : H12AffineEnvironment.transform 15 32882 env33507 = env33508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env33507 == env33508) = true)

def env33509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1345,262144,42333,32769,1345,41089,17,263632,33236,41244,42274,1297,42060,43129,262563,303354,257,42076,1345,41821]

theorem envBound33509 : H12AffineFastState.Bounded env33509 := by
  intro p hp
  have h : env33509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33508_33509 : H12AffineEnvironment.transform 11 1344 env33508 = env33509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env33508 == env33509) = true)

theorem identity33509 : scanCanonicalize (H12AffineFastState.compose env33509 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound33509 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33510 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,81,32768,32882,1,262144,40989,32769,1,41089,17,262288,33236,41244,41058,81,41228,43129,262563,303354,257,41244,1,41821]

theorem envBound33510 : H12AffineFastState.Bounded env33510 := by
  intro p hp
  have h : env33510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33509_33510 : H12AffineEnvironment.transform 9 320 env33509 = env33510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env33509 == env33510) = true)

theorem identity33510 : scanCanonicalize (H12AffineFastState.compose env33510 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound33510 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env33511 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,81,8541,8495,1,262144,320,8540,1,476,17,262288,8329,65,319,81,81,2340,262563,262567,257,65,1,512]

theorem envBound33511 : H12AffineFastState.Bounded env33511 := by
  intro p hp
  have h : env33511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33510_33511 : H12AffineEnvironment.transform 14 8541 env33510 = env33511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env33510 == env33511) = true)

theorem identity33511 : scanCanonicalize (H12AffineFastState.compose env33511 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound33511 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33512 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,0,8192,81,8264,8250,1,262144,85,8265,1,201,17,262288,8329,65,42,81,81,2097,262326,262322,20,65,1,512]

theorem envBound33512 : H12AffineFastState.Bounded env33512 := by
  intro p hp
  have h : env33512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33511_33512 : H12AffineEnvironment.transform 7 21 env33511 = env33512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env33511 == env33512) = true)

theorem identity33512 : scanCanonicalize (H12AffineFastState.compose env33512 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 8754) := by decide +kernel

theorem selectedBound33512 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33513 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,0,8192,81,8264,8250,1,8754,85,8265,1,201,17,8866,8329,65,42,81,81,2097,8836,8832,20,65,1,512]

theorem envBound33513 : H12AffineFastState.Bounded env33513 := by
  intro p hp
  have h : env33513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33512_33513 : H12AffineEnvironment.transform 17 8754 env33512 = env33513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8754 env33512 == env33513) = true)

theorem identity33513 : scanCanonicalize (H12AffineFastState.compose env33513 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33513 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env33514 : List Nat := [2,4,8,16,32,16,128,21,512,5,2048,0,8192,1,8216,8250,1,8754,5,8217,1,153,17,8866,8329,17,42,1,1,2097,8836,8832,20,17,1,512]

theorem envBound33514 : H12AffineFastState.Bounded env33514 := by
  intro p hp
  have h : env33514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33513_33514 : H12AffineEnvironment.transform 5 16 env33513 = env33514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33513 == env33514) = true)

theorem identity33514 : scanCanonicalize (H12AffineFastState.compose env33514 (packedSelected [1,3,13] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound33514 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env33515 : List Nat := [2,4,8,16,32,16,128,21,512,5,42,0,8192,1,8216,8250,1,8754,5,8217,1,153,17,8866,8329,17,42,1,1,27,8836,8832,20,17,1,512]

theorem envBound33515 : H12AffineFastState.Bounded env33515 := by
  intro p hp
  have h : env33515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33514_33515 : H12AffineEnvironment.transform 10 42 env33514 = env33515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env33514 == env33515) = true)

theorem identity33515 : scanCanonicalize (H12AffineFastState.compose env33515 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound33515 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env33516 : List Nat := [2,4,8,16,32,16,57,21,512,5,42,0,8192,1,8216,8250,1,8754,5,8217,1,32,17,8731,8240,17,42,1,1,27,8765,8761,20,17,1,512]

theorem envBound33516 : H12AffineFastState.Bounded env33516 := by
  intro p hp
  have h : env33516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33515_33516 : H12AffineEnvironment.transform 6 57 env33515 = env33516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env33515 == env33516) = true)

theorem identity33516 : scanCanonicalize (H12AffineFastState.compose env33516 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound33516 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env33517 : List Nat := [2,4,8,11,32,11,34,14,512,5,42,0,8192,1,8195,8225,1,8745,5,8194,1,32,10,8704,8235,10,42,1,1,0,8742,8738,15,10,1,512]

theorem envBound33517 : H12AffineFastState.Bounded env33517 := by
  intro p hp
  have h : env33517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33516_33517 : H12AffineEnvironment.transform 3 11 env33516 = env33517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env33516 == env33517) = true)

theorem identity33517 : scanCanonicalize (H12AffineFastState.compose env33517 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound33517 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env33518 : List Nat := [2,4,8,11,32,11,34,14,0,5,42,0,8192,1,8195,8225,1,8233,5,8194,1,32,10,8192,8235,10,42,1,1,0,8230,8226,15,10,1,0]

theorem envBound33518 : H12AffineFastState.Bounded env33518 := by
  intro p hp
  have h : env33518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33517_33518 : H12AffineEnvironment.transform 8 0 env33517 = env33518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env33517 == env33518) = true)

theorem identity33518 : scanCanonicalize (H12AffineFastState.compose env33518 (packedSelected [0,1,2] rootPS)) = affineNative (2^(12+1) ^^^ 3) := by decide +kernel

theorem selectedBound33518 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env33519 : List Nat := [2,4,8,11,32,11,34,14,0,5,42,0,3,1,0,34,1,42,5,1,1,32,10,3,40,10,42,1,1,0,37,33,15,10,1,0]

theorem envBound33519 : H12AffineFastState.Bounded env33519 := by
  intro p hp
  have h : env33519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33518_33519 : H12AffineEnvironment.transform 12 3 env33518 = env33519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3 env33518 == env33519) = true)

def env33520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1345,262144,42332,32769,1344,41088,17,263633,33237,41245,42275,1297,42060,43128,262562,303355,257,42076,1345,41820]

theorem envBound33520 : H12AffineFastState.Bounded env33520 := by
  intro p hp
  have h : env33520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33508_33520 : H12AffineEnvironment.transform 11 1345 env33508 = env33520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env33508 == env33520) = true)

theorem identity33520 : scanCanonicalize (H12AffineFastState.compose env33520 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 34226) := by decide +kernel

theorem selectedBound33520 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1345,34226,42332,32769,1344,41088,17,32867,33237,41245,42275,1297,42060,43128,33808,9545,257,42076,1345,41820]

theorem envBound33521 : H12AffineFastState.Bounded env33521 := by
  intro p hp
  have h : env33521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33520_33521 : H12AffineEnvironment.transform 17 34226 env33520 = env33521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34226 env33520 == env33521) = true)

theorem identity33521 : scanCanonicalize (H12AffineFastState.compose env33521 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 3614) := by decide +kernel

theorem selectedBound33521 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env33522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,3614,3692,1345,2988,11074,3615,1344,11934,17,3709,4043,12035,11069,1297,10834,9830,2574,9545,257,10818,1345,11586]

theorem envBound33522 : H12AffineFastState.Bounded env33522 := by
  intro p hp
  have h : env33522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33521_33522 : H12AffineEnvironment.transform 14 3614 env33521 = env33522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3614 env33521 == env33522) = true)

def env33523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95614,32769,4097,61648,16,284033,86519,94526,77841,1296,74814,96346,381312,308667,257,90430,1345,95102]

theorem envBound33523 : H12AffineFastState.Bounded env33523 := by
  intro p hp
  have h : env33523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33460_33523 : H12AffineEnvironment.transform 16 16465 env33460 = env33523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env33460 == env33523) = true)

def env33524 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77934,32769,4097,46528,16,266385,70887,78894,77841,1296,74814,81226,365712,308667,257,74798,1345,79470]

theorem envBound33524 : H12AffineFastState.Bounded env33524 := by
  intro p hp
  have h : env33524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33523_33524 : H12AffineEnvironment.transform 13 1296 env33523 = env33524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env33523 == env33524) = true)

theorem identity33524 : scanCanonicalize (H12AffineFastState.compose env33524 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound33524 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env33525 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32883,1345,262144,45085,32769,4097,46528,16,266385,38036,46173,45154,1296,42061,48441,267491,308667,257,42077,1345,46621]

theorem envBound33525 : H12AffineFastState.Bounded env33525 := by
  intro p hp
  have h : env33525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33524_33525 : H12AffineEnvironment.transform 15 32883 env33524 = env33525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env33524 == env33525) = true)

def env33526 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1345,262144,42333,32769,1345,41088,16,263633,33236,41245,42274,1296,42061,43129,262563,303355,257,42077,1345,41821]

theorem envBound33526 : H12AffineFastState.Bounded env33526 := by
  intro p hp
  have h : env33526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33525_33526 : H12AffineEnvironment.transform 11 1344 env33525 = env33526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env33525 == env33526) = true)

theorem identity33526 : scanCanonicalize (H12AffineFastState.compose env33526 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 277) := by decide +kernel

theorem selectedBound33526 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33527 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,277,358,1345,262144,9288,276,1345,8597,16,263633,193,8200,9271,1296,9560,10604,262563,270830,257,9544,1345,8776]

theorem envBound33527 : H12AffineFastState.Bounded env33527 := by
  intro p hp
  have h : env33527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33526_33527 : H12AffineEnvironment.transform 14 277 env33526 = env33527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 277 env33526 == env33527) = true)

theorem identity33527 : scanCanonicalize (H12AffineFastState.compose env33527 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 2988) := by decide +kernel

theorem selectedBound33527 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env33528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,277,358,1345,2988,9288,276,1345,8597,16,3709,193,8200,9271,1296,9560,10604,2575,10818,257,9544,1345,8776]

theorem envBound33528 : H12AffineFastState.Bounded env33528 := by
  intro p hp
  have h : env33528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33527_33528 : H12AffineEnvironment.transform 17 2988 env33527 = env33528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2988 env33527 == env33528) = true)

def env33529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1345,262144,42332,32769,1344,41089,16,263632,33237,41244,42275,1296,42061,43128,262562,303354,257,42077,1345,41820]

theorem envBound33529 : H12AffineFastState.Bounded env33529 := by
  intro p hp
  have h : env33529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33525_33529 : H12AffineEnvironment.transform 11 1345 env33525 = env33529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env33525 == env33529) = true)

theorem identity33529 : scanCanonicalize (H12AffineFastState.compose env33529 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 486) := by decide +kernel

theorem selectedBound33529 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1345,486,42332,32769,1344,41089,16,1078,33237,41244,42275,1296,42061,43128,68,41244,257,42077,1345,41820]

theorem envBound33530 : H12AffineFastState.Bounded env33530 := by
  intro p hp
  have h : env33530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33529_33530 : H12AffineEnvironment.transform 17 486 env33529 = env33530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 486 env33529 == env33530) = true)

theorem identity33530 : scanCanonicalize (H12AffineFastState.compose env33530 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound33530 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env33531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,8540,8495,1345,486,1024,8541,1344,477,16,1078,8329,64,1151,1296,1297,2340,68,64,257,1281,1345,512]

theorem envBound33531 : H12AffineFastState.Bounded env33531 := by
  intro p hp
  have h : env33531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33530_33531 : H12AffineEnvironment.transform 14 8540 env33530 = env33531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env33530 == env33531) = true)

theorem identity33531 : scanCanonicalize (H12AffineFastState.compose env33531 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound33531 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33532 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,276,8192,325,8540,8495,276,486,85,8541,277,477,16,99,8329,64,42,325,324,2340,68,64,257,340,276,512]

theorem envBound33532 : H12AffineFastState.Bounded env33532 := by
  intro p hp
  have h : env33532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33531_33532 : H12AffineEnvironment.transform 9 85 env33531 = env33532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env33531 == env33532) = true)

theorem identity33532 : scanCanonicalize (H12AffineFastState.compose env33532 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 704) := by decide +kernel

theorem selectedBound33532 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33533 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,276,704,325,924,1007,276,486,85,925,277,477,16,99,585,64,42,325,324,2340,68,64,257,340,276,512]

theorem envBound33533 : H12AffineFastState.Bounded env33533 := by
  intro p hp
  have h : env33533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33532_33533 : H12AffineEnvironment.transform 12 704 env33532 = env33533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 704 env33532 == env33533) = true)

theorem identity33533 : scanCanonicalize (H12AffineFastState.compose env33533 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33533 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env33534 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,276,656,277,924,959,276,438,5,925,277,397,16,51,537,16,42,277,276,2340,20,16,257,260,276,512]

theorem envBound33534 : H12AffineFastState.Bounded env33534 := by
  intro p hp
  have h : env33534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33533_33534 : H12AffineEnvironment.transform 5 16 env33533 = env33534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33533 == env33534) = true)

theorem identity33534 : scanCanonicalize (H12AffineFastState.compose env33534 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 271) := by decide +kernel

theorem selectedBound33534 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env33535 : List Nat := [2,4,8,16,32,16,128,256,512,5,271,276,656,277,924,959,276,438,5,925,277,397,16,51,537,16,42,277,276,43,20,16,257,260,276,512]

theorem envBound33535 : H12AffineFastState.Bounded env33535 := by
  intro p hp
  have h : env33535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33534_33535 : H12AffineEnvironment.transform 10 271 env33534 = env33535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 271 env33534 == env33535) = true)

def env33536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77935,32769,4097,46529,16,266384,70886,78895,77841,1296,74814,81227,365713,308667,257,74799,1345,79471]

theorem envBound33536 : H12AffineFastState.Bounded env33536 := by
  intro p hp
  have h : env33536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33523_33536 : H12AffineEnvironment.transform 13 1297 env33523 = env33536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env33523 == env33536) = true)

theorem identity33536 : scanCanonicalize (H12AffineFastState.compose env33536 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound33536 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env33537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,262144,77935,13341,4097,477,16,266384,70886,78895,77841,1296,74814,81227,336013,262567,257,74799,1345,79471]

theorem envBound33537 : H12AffineFastState.Bounded env33537 := by
  intro p hp
  have h : env33537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33536_33537 : H12AffineEnvironment.transform 14 13340 env33536 = env33537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env33536 == env33537) = true)

def env33538 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,65664,77935,13341,4097,477,16,69648,70886,78895,77841,1296,74814,81227,8205,65831,257,74799,1345,79471]

theorem envBound33538 : H12AffineFastState.Bounded env33538 := by
  intro p hp
  have h : env33538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33537_33538 : H12AffineEnvironment.transform 17 65664 env33537 = env33538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env33537 == env33538) = true)

theorem identity33538 : scanCanonicalize (H12AffineFastState.compose env33538 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound33538 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33539 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,12636,65536,0,65664,77935,12637,4097,477,16,69648,70054,78191,77841,80,74110,79883,8205,65831,257,74095,1,78639]

theorem envBound33539 : H12AffineFastState.Bounded env33539 := by
  intro p hp
  have h : env33539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33538_33539 : H12AffineEnvironment.transform 9 320 env33538 = env33539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env33538 == env33539) = true)

def env33540 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,8192,1,12556,65536,0,65664,77887,12557,4097,397,16,69648,70054,78143,77841,0,74030,79883,8205,65831,257,74047,1,78639]

theorem envBound33540 : H12AffineFastState.Bounded env33540 := by
  intro p hp
  have h : env33540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33539_33540 : H12AffineEnvironment.transform 5 16 env33539 = env33540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33539 == env33540) = true)

theorem identity33540 : scanCanonicalize (H12AffineFastState.compose env33540 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 12346) := by decide +kernel

theorem selectedBound33540 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33541 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,8192,1,12556,12346,0,12474,5,12557,4097,397,16,8234,8604,261,43,0,4372,2097,8205,12573,257,4357,1,789]

theorem envBound33541 : H12AffineFastState.Bounded env33541 := by
  intro p hp
  have h : env33541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33540_33541 : H12AffineEnvironment.transform 15 12346 env33540 = env33541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12346 env33540 == env33541) = true)

theorem identity33541 : scanCanonicalize (H12AffineFastState.compose env33541 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound33541 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env33542 : List Nat := [2,4,8,16,32,16,128,21,512,5,2048,4096,8192,1,12313,12346,0,12474,5,12312,4097,152,16,8234,8329,16,43,0,4097,2097,8205,12296,20,4112,1,512]

theorem envBound33542 : H12AffineFastState.Bounded env33542 := by
  intro p hp
  have h : env33542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33541_33542 : H12AffineEnvironment.transform 7 21 env33541 = env33542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env33541 == env33542) = true)

theorem identity33542 : scanCanonicalize (H12AffineFastState.compose env33542 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound33542 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env33543 : List Nat := [2,4,8,16,32,16,128,21,512,5,42,4096,8192,1,12313,12346,0,12474,5,12312,4097,152,16,8234,8329,16,43,0,4097,27,8205,12296,20,4112,1,512]

theorem envBound33543 : H12AffineFastState.Bounded env33543 := by
  intro p hp
  have h : env33543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33542_33543 : H12AffineEnvironment.transform 10 42 env33542 = env33543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env33542 == env33543) = true)

theorem identity33543 : scanCanonicalize (H12AffineFastState.compose env33543 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound33543 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env33544 : List Nat := [2,4,8,16,32,16,128,21,512,5,42,4096,25,1,4096,4131,0,4259,5,4097,4097,152,16,51,144,16,43,0,4097,27,20,4113,20,4112,1,512]

theorem envBound33544 : H12AffineFastState.Bounded env33544 := by
  intro p hp
  have h : env33544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33543_33544 : H12AffineEnvironment.transform 12 25 env33543 = env33544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env33543 == env33544) = true)

theorem identity33544 : scanCanonicalize (H12AffineFastState.compose env33544 (packedSelected [1,2,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound33544 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env33545 : List Nat := [2,4,8,11,32,11,128,14,512,5,42,4096,2,1,4096,4131,0,4259,5,4097,4097,131,11,40,139,11,43,0,4097,0,15,4106,15,4107,1,512]

theorem envBound33545 : H12AffineFastState.Bounded env33545 := by
  intro p hp
  have h : env33545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33544_33545 : H12AffineEnvironment.transform 3 11 env33544 = env33545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env33544 == env33545) = true)

theorem identity33545 : scanCanonicalize (H12AffineFastState.compose env33545 (packedSelected [1,2] rootPS)) = affineNative (2^(11+1) ^^^ 143) := by decide +kernel

theorem selectedBound33545 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env33546 : List Nat := [2,4,8,11,32,11,128,14,512,5,42,143,2,1,143,172,0,44,5,142,142,131,11,40,139,11,43,0,142,0,15,133,15,132,1,512]

theorem envBound33546 : H12AffineFastState.Bounded env33546 := by
  intro p hp
  have h : env33546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33545_33546 : H12AffineEnvironment.transform 11 143 env33545 = env33546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 143 env33545 == env33546) = true)

def env33547 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,8192,0,12557,65536,0,65664,77886,12556,4097,396,16,69648,70054,78142,77841,1,74031,79883,8205,65831,257,74046,1,78639]

theorem envBound33547 : H12AffineFastState.Bounded env33547 := by
  intro p hp
  have h : env33547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33539_33547 : H12AffineEnvironment.transform 5 17 env33539 = env33547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33539 == env33547) = true)

theorem identity33547 : scanCanonicalize (H12AffineFastState.compose env33547 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound33547 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33548 : List Nat := [2,4,8,16,32,17,128,21,512,4,2048,4096,8192,0,12312,65536,0,65664,77886,12313,4097,153,16,69648,69811,77867,77841,1,73786,79883,8205,65586,20,73771,1,78394]

theorem envBound33548 : H12AffineFastState.Bounded env33548 := by
  intro p hp
  have h : env33548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33547_33548 : H12AffineEnvironment.transform 7 21 env33547 = env33548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env33547 == env33548) = true)

theorem identity33548 : scanCanonicalize (H12AffineFastState.compose env33548 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 12347) := by decide +kernel

theorem selectedBound33548 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env33549 : List Nat := [2,4,8,16,32,17,128,21,512,4,2048,4096,8192,0,12312,12347,0,12475,5,12313,4097,153,16,8235,8328,16,42,1,4097,2096,8205,12297,20,4112,1,513]

theorem envBound33549 : H12AffineFastState.Bounded env33549 := by
  intro p hp
  have h : env33549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33548_33549 : H12AffineEnvironment.transform 15 12347 env33548 = env33549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12347 env33548 == env33549) = true)

theorem identity33549 : scanCanonicalize (H12AffineFastState.compose env33549 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 544) := by decide +kernel

theorem selectedBound33549 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env33550 : List Nat := [2,4,8,16,32,17,128,21,512,4,2048,544,8192,0,8760,8731,0,8859,5,8761,545,153,16,8235,8328,16,42,1,545,2096,8205,8745,20,560,1,513]

theorem envBound33550 : H12AffineFastState.Bounded env33550 := by
  intro p hp
  have h : env33550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33549_33550 : H12AffineEnvironment.transform 11 544 env33549 = env33550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env33549 == env33550) = true)

theorem identity33550 : scanCanonicalize (H12AffineFastState.compose env33550 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound33550 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33551 : List Nat := [2,4,8,16,32,17,128,21,512,4,2048,544,24,0,544,515,0,643,5,545,545,153,16,51,144,16,42,1,545,2096,21,561,20,560,1,513]

theorem envBound33551 : H12AffineFastState.Bounded env33551 := by
  intro p hp
  have h : env33551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33550_33551 : H12AffineEnvironment.transform 12 24 env33550 = env33551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env33550 == env33551) = true)

theorem identity33551 : scanCanonicalize (H12AffineFastState.compose env33551 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound33551 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33552 : List Nat := [2,4,8,16,32,17,128,21,49,4,2048,17,24,0,17,50,0,178,5,16,16,153,16,51,144,16,42,1,16,2096,21,0,20,1,1,48]

theorem envBound33552 : H12AffineFastState.Bounded env33552 := by
  intro p hp
  have h : env33552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33551_33552 : H12AffineEnvironment.transform 8 49 env33551 = env33552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env33551 == env33552) = true)

theorem identity33552 : scanCanonicalize (H12AffineFastState.compose env33552 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 54) := by decide +kernel

theorem selectedBound33552 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env33553 : List Nat := [2,4,8,16,32,17,128,21,49,4,54,17,24,0,17,50,0,178,5,16,16,153,16,51,144,16,42,1,16,6,21,0,20,1,1,48]

theorem envBound33553 : H12AffineFastState.Bounded env33553 := by
  intro p hp
  have h : env33553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33552_33553 : H12AffineEnvironment.transform 10 54 env33552 = env33553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 54 env33552 == env33553) = true)

theorem identity33553 : scanCanonicalize (H12AffineFastState.compose env33553 (packedSelected [0,1,2,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound33553 : packedSelected [0,1,2,7,8,11] rootPS < 2^1333 := by decide +kernel

def env33554 : List Nat := [2,4,8,16,32,17,56,21,49,4,54,17,24,0,17,50,0,10,5,16,16,33,16,51,40,16,42,1,16,6,21,0,20,1,1,48]

theorem envBound33554 : H12AffineFastState.Bounded env33554 := by
  intro p hp
  have h : env33554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33553_33554 : H12AffineEnvironment.transform 6 56 env33553 = env33554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env33553 == env33554) = true)

theorem identity33554 : scanCanonicalize (H12AffineFastState.compose env33554 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound33554 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33555 : List Nat := [2,4,8,16,16,17,8,21,1,4,6,17,24,0,17,2,0,10,5,16,16,17,16,3,24,16,26,1,16,6,21,0,20,1,1,0]

theorem envBound33555 : H12AffineFastState.Bounded env33555 := by
  intro p hp
  have h : env33555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33554_33555 : H12AffineEnvironment.transform 4 16 env33554 = env33555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env33554 == env33555) = true)

theorem identity33555 : scanCanonicalize (H12AffineFastState.compose env33555 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound33555 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33556 : List Nat := [2,4,8,3,3,2,8,6,1,4,6,2,11,0,2,2,0,10,5,3,3,2,3,3,11,3,9,1,3,6,6,0,7,1,1,0]

theorem envBound33556 : H12AffineFastState.Bounded env33556 := by
  intro p hp
  have h : env33556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33555_33556 : H12AffineEnvironment.transform 3 3 env33555 = env33556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env33555 == env33556) = true)

theorem identity33556 : scanCanonicalize (H12AffineFastState.compose env33556 (packedSelected [1,7] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound33556 : packedSelected [1,7] rootPS < 2^1333 := by decide +kernel

def env33557 : List Nat := [2,4,6,3,3,2,6,6,1,4,6,2,5,0,2,2,0,4,5,3,3,2,3,3,5,3,7,1,3,6,6,0,7,1,1,0]

theorem envBound33557 : H12AffineFastState.Bounded env33557 := by
  intro p hp
  have h : env33557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33556_33557 : H12AffineEnvironment.transform 2 6 env33556 = env33557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env33556 == env33557) = true)

theorem identity33557 : scanCanonicalize (H12AffineFastState.compose env33557 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound33557 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33558 : List Nat := [2,3,1,3,3,2,1,1,1,3,1,2,2,0,2,2,0,3,2,3,3,2,3,3,2,3,0,1,3,1,1,0,0,1,1,0]

theorem envBound33558 : H12AffineFastState.Bounded env33558 := by
  intro p hp
  have h : env33558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33557_33558 : H12AffineEnvironment.transform 1 3 env33557 = env33558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env33557 == env33558) = true)

theorem identity33558 : scanCanonicalize (H12AffineFastState.compose env33558 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound33558 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33559 : List Nat := [1,0,1,0,0,1,1,1,1,0,1,1,1,0,1,1,0,0,1,0,0,1,0,0,1,0,0,1,0,1,1,0,0,1,1,0]

theorem envBound33559 : H12AffineFastState.Bounded env33559 := by
  intro p hp
  have h : env33559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33558_33559 : H12AffineEnvironment.transform 0 1 env33558 = env33559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env33558 == env33559) = true)

def env33560 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,65665,77935,13341,4097,477,16,69649,70886,78895,77841,1296,74814,81227,8204,65830,257,74799,1345,79471]

theorem envBound33560 : H12AffineFastState.Bounded env33560 := by
  intro p hp
  have h : env33560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33537_33560 : H12AffineEnvironment.transform 17 65665 env33537 = env33560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env33537 == env33560) = true)

theorem identity33560 : scanCanonicalize (H12AffineFastState.compose env33560 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound33560 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33561 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,9245,65536,1344,65665,73838,9244,0,477,16,65552,66791,74798,73744,1296,74814,77130,8204,65830,257,74799,1345,75374]

theorem envBound33561 : H12AffineFastState.Bounded env33561 := by
  intro p hp
  have h : env33561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33560_33561 : H12AffineEnvironment.transform 11 1 env33560 = env33561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env33560 == env33561) = true)

def env33562 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1,8192,1297,9245,65536,1296,65665,73790,9244,0,397,16,65552,66743,74798,73744,1296,74814,77082,8204,65830,257,74799,1297,75326]

theorem envBound33562 : H12AffineFastState.Bounded env33562 := by
  intro p hp
  have h : env33562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33561_33562 : H12AffineEnvironment.transform 5 16 env33561 = env33562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33561 == env33562) = true)

theorem identity33562 : scanCanonicalize (H12AffineFastState.compose env33562 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8251) := by decide +kernel

theorem selectedBound33562 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33563 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1,8192,1297,9245,8251,1296,8378,5,9244,0,397,16,8235,9356,1045,43,1296,1029,3361,8204,8477,257,1044,1297,1541]

theorem envBound33563 : H12AffineFastState.Bounded env33563 := by
  intro p hp
  have h : env33563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33562_33563 : H12AffineEnvironment.transform 15 8251 env33562 = env33563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8251 env33562 == env33563) = true)

theorem identity33563 : scanCanonicalize (H12AffineFastState.compose env33563 (packedSelected [2,3,10,23,24,26,32] rootPS)) = affineNative (2^(9+1) ^^^ 921) := by decide +kernel

theorem selectedBound33563 : packedSelected [2,3,10,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env33564 : List Nat := [2,4,8,16,32,16,128,256,512,921,2048,1,8192,648,9092,8251,649,8378,5,9093,0,397,16,8235,8981,908,43,649,924,2744,8204,8477,257,909,648,412]

theorem envBound33564 : H12AffineFastState.Bounded env33564 := by
  intro p hp
  have h : env33564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33563_33564 : H12AffineEnvironment.transform 9 921 env33563 = env33564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 921 env33563 == env33564) = true)

theorem identity33564 : scanCanonicalize (H12AffineFastState.compose env33564 (packedSelected [0,4,5,7,9,18,21,23,26,28] rootPS)) = affineNative (2^(12+1) ^^^ 2990) := by decide +kernel

theorem selectedBound33564 : packedSelected [0,4,5,7,9,18,21,23,26,28] rootPS < 2^1333 := by decide +kernel

def env33565 : List Nat := [2,4,8,16,32,16,128,256,512,921,2048,1,2990,648,2090,2965,649,2836,5,2091,0,397,16,2949,2235,908,43,649,924,2744,2978,2739,257,909,648,412]

theorem envBound33565 : H12AffineFastState.Bounded env33565 := by
  intro p hp
  have h : env33565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33564_33565 : H12AffineEnvironment.transform 12 2990 env33564 = env33565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2990 env33564 == env33565) = true)

theorem identity33565 : scanCanonicalize (H12AffineFastState.compose env33565 (packedSelected [5,8,10,12,15,19] rootPS)) = affineNative (2^(10+1) ^^^ 391) := by decide +kernel

theorem selectedBound33565 : packedSelected [5,8,10,12,15,19] rootPS < 2^1333 := by decide +kernel

def env33566 : List Nat := [2,4,8,16,32,16,128,256,512,921,391,1,553,648,429,530,649,659,5,428,0,397,16,514,316,908,43,649,924,831,549,820,257,909,648,412]

theorem envBound33566 : H12AffineFastState.Bounded env33566 := by
  intro p hp
  have h : env33566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33565_33566 : H12AffineEnvironment.transform 10 391 env33565 = env33566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 391 env33565 == env33566) = true)

theorem identity33566 : scanCanonicalize (H12AffineFastState.compose env33566 (packedSelected [1,3,5,7,8,9,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound33566 : packedSelected [1,3,5,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env33567 : List Nat := [2,4,8,16,32,16,128,256,0,409,391,1,41,136,429,18,137,147,5,428,0,397,16,2,316,396,43,137,412,319,37,308,257,397,136,412]

theorem envBound33567 : H12AffineFastState.Bounded env33567 := by
  intro p hp
  have h : env33567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33566_33567 : H12AffineEnvironment.transform 8 0 env33566 = env33567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env33566 == env33567) = true)

theorem identity33567 : scanCanonicalize (H12AffineFastState.compose env33567 (packedSelected [2,3,4,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound33567 : packedSelected [2,3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env33568 : List Nat := [2,4,8,16,32,16,35,256,0,314,292,1,41,43,270,18,42,48,5,271,0,302,16,2,316,303,43,42,319,319,37,308,257,302,43,319]

theorem envBound33568 : H12AffineFastState.Bounded env33568 := by
  intro p hp
  have h : env33568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33567_33568 : H12AffineEnvironment.transform 6 35 env33567 = env33568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env33567 == env33568) = true)

theorem identity33568 : scanCanonicalize (H12AffineFastState.compose env33568 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound33568 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env33569 : List Nat := [2,4,8,16,11,16,8,256,0,273,271,1,2,0,270,18,1,27,5,271,0,261,16,2,279,260,0,1,276,276,14,287,257,261,0,276]

theorem envBound33569 : H12AffineFastState.Bounded env33569 := by
  intro p hp
  have h : env33569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33568_33569 : H12AffineEnvironment.transform 4 11 env33568 = env33569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env33568 == env33569) = true)

def env33570 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1,8192,1297,9245,65536,1297,65665,73791,9244,0,396,16,65552,66742,74798,73744,1296,74814,77083,8204,65830,257,74799,1296,75327]

theorem envBound33570 : H12AffineFastState.Bounded env33570 := by
  intro p hp
  have h : env33570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33561_33570 : H12AffineEnvironment.transform 5 17 env33561 = env33570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33561 == env33570) = true)

theorem identity33570 : scanCanonicalize (H12AffineFastState.compose env33570 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound33570 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33571 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,1,8192,277,8217,65536,277,65665,73791,8216,0,396,16,65552,65714,73770,73744,276,73786,76063,8204,65830,257,73771,276,74299]

theorem envBound33571 : H12AffineFastState.Bounded env33571 := by
  intro p hp
  have h : env33571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33570_33571 : H12AffineEnvironment.transform 9 4 env33570 = env33571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env33570 == env33571) = true)

def env33572 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,147521,16777216,33554432,672785,134217728,148801,33584585,2189403,50962568,4294967296,34088328,4347445490,151462017,33563273]

theorem envBound33572 : H12AffineFastState.Bounded env33572 := by
  intro p hp
  have h : env33572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31203_33572 : H12AffineEnvironment.transform 34 151462017 env31203 = env33572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 151462017 env31203 == env33572) = true)

def env33573 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,33554432,672785,134217728,148801,33584585,96347,50962568,4294967296,34088328,4345352434,151462017,33563273]

theorem envBound33573 : H12AffineFastState.Bounded env33573 := by
  intro p hp
  have h : env33573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33572_33573 : H12AffineEnvironment.transform 20 4096 env33572 = env33573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env33572 == env33573) = true)

theorem identity33573 : scanCanonicalize (H12AffineFastState.compose env33573 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 16949354) := by decide +kernel

theorem selectedBound33573 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env33574 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,33554432,672785,134217728,148801,33584585,96347,50962568,16949354,34088328,33714328,151462017,33563273]

theorem envBound33574 : H12AffineFastState.Bounded env33574 := by
  intro p hp
  have h : env33574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33573_33574 : H12AffineEnvironment.transform 31 16949354 env33573 = env33574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 16949354 env33573 == env33574) = true)

def env33575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533640,672785,134217728,148801,545089,96347,16876544,16949354,256,676880,151462017,525825]

theorem envBound33575 : H12AffineFastState.Bounded env33575 := by
  intro p hp
  have h : env33575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33574_33575 : H12AffineEnvironment.transform 24 533640 env33574 = env33575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env33574 == env33575) = true)

def env33576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533640,672785,17245632,148801,545089,96347,16876544,16949354,256,676880,1345,525825]

theorem envBound33576 : H12AffineFastState.Bounded env33576 := by
  intro p hp
  have h : env33576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33575_33576 : H12AffineEnvironment.transform 26 17245632 env33575 = env33576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env33575 == env33576) = true)

theorem identity33576 : scanCanonicalize (H12AffineFastState.compose env33576 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717115) := by decide +kernel

theorem selectedBound33576 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env33577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,717115,533640,672785,906491,148801,545089,96347,750907,545105,256,676880,1345,525825]

theorem envBound33577 : H12AffineFastState.Bounded env33577 := by
  intro p hp
  have h : env33577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33576_33577 : H12AffineEnvironment.transform 23 717115 env33576 = env33577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717115 env33576 == env33577) = true)

def env33578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,58683,143496,20497,508155,148801,148801,96347,90427,148817,256,16400,1345,135681]

theorem envBound33578 : H12AffineFastState.Bounded env33578 := by
  intro p hp
  have h : env33578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33577_33578 : H12AffineEnvironment.transform 18 136192 env33577 = env33578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env33577 == env33578) = true)

def env33579 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,58519,143496,20497,508155,148717,148717,96347,90263,148733,172,16400,1261,135681]

theorem envBound33579 : H12AffineFastState.Bounded env33579 := by
  intro p hp
  have h : env33579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33578_33579 : H12AffineEnvironment.transform 7 172 env33578 = env33579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env33578 == env33579) = true)

def env33580 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,58519,143496,20497,508075,148669,148669,96267,90263,148653,172,16400,1213,135681]

theorem envBound33580 : H12AffineFastState.Bounded env33580 := by
  intro p hp
  have h : env33580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33579_33580 : H12AffineEnvironment.transform 5 16 env33579 = env33580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33579 == env33580) = true)

theorem identity33580 : scanCanonicalize (H12AffineFastState.compose env33580 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound33580 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env33581 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4096,61569,61617,58519,32808,20497,356363,62493,62493,96267,90263,62477,172,16400,1213,41633]

theorem envBound33581 : H12AffineFastState.Bounded env33581 := by
  intro p hp
  have h : env33581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33580_33581 : H12AffineEnvironment.transform 16 45216 env33580 = env33581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env33580 == env33581) = true)

theorem identity33581 : scanCanonicalize (H12AffineFastState.compose env33581 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound33581 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env33582 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,2184,42144,32769,4096,61569,61617,58519,32808,20497,96387,62493,62493,96267,90263,62477,172,16400,1213,41633]

theorem envBound33582 : H12AffineFastState.Bounded env33582 := by
  intro p hp
  have h : env33582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33581_33582 : H12AffineEnvironment.transform 17 2184 env33581 = env33582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env33581 == env33582) = true)

theorem identity33582 : scanCanonicalize (H12AffineFastState.compose env33582 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 24600) := by decide +kernel

theorem selectedBound33582 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env33583 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,24600,65536,20664,2184,17592,24601,4096,4249,4265,1167,24624,20497,96387,5125,5125,96267,90263,5141,172,16400,1213,17081]

theorem envBound33583 : H12AffineFastState.Bounded env33583 := by
  intro p hp
  have h : env33583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33582_33583 : H12AffineEnvironment.transform 14 24600 env33582 = env33583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24600 env33582 == env33583) = true)

theorem identity33583 : scanCanonicalize (H12AffineFastState.compose env33583 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound33583 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env33584 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,24600,13375,20664,2184,17592,24601,4096,4249,4265,1167,24624,20497,19644,5125,5125,19508,21672,5141,172,16400,1213,17081]

theorem envBound33584 : H12AffineFastState.Bounded env33584 := by
  intro p hp
  have h : env33584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33583_33584 : H12AffineEnvironment.transform 15 13375 env33583 = env33584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env33583 == env33584) = true)

theorem identity33584 : scanCanonicalize (H12AffineFastState.compose env33584 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 11940) := by decide +kernel

theorem selectedBound33584 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env33585 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,11940,3772,13375,15900,2184,10780,3773,4096,4249,4265,1167,3732,16053,8728,5125,5125,8848,14860,5141,172,11956,1213,11293]

theorem envBound33585 : H12AffineFastState.Bounded env33585 := by
  intro p hp
  have h : env33585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33584_33585 : H12AffineEnvironment.transform 13 11940 env33584 = env33585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11940 env33584 == env33585) = true)

theorem identity33585 : scanCanonicalize (H12AffineFastState.compose env33585 (packedSelected [2,7,9,10,12,13] rootPS)) = affineNative (2^(11+1) ^^^ 2745) := by decide +kernel

theorem selectedBound33585 : packedSelected [2,7,9,10,12,13] rootPS < 2^1333 := by decide +kernel

def env33586 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,2745,8192,11940,3772,11910,9381,2184,10780,3773,2745,2592,2576,1167,3732,9228,8728,3772,3772,8848,8373,3756,172,11956,1213,11293]

theorem envBound33586 : H12AffineFastState.Bounded env33586 := by
  intro p hp
  have h : env33586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33585_33586 : H12AffineEnvironment.transform 11 2745 env33585 = env33586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2745 env33585 == env33586) = true)

theorem identity33586 : scanCanonicalize (H12AffineFastState.compose env33586 (packedSelected [0,3,4,6,7,8,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 2234) := by decide +kernel

theorem selectedBound33586 : packedSelected [0,3,4,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env33587 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,2745,2234,1566,3772,1596,3103,2184,678,3773,2745,2592,2576,1167,3732,3254,2722,3772,3772,2602,2063,3756,172,1550,1213,1191]

theorem envBound33587 : H12AffineFastState.Bounded env33587 := by
  intro p hp
  have h : env33587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33586_33587 : H12AffineEnvironment.transform 12 2234 env33586 = env33587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2234 env33586 == env33587) = true)

theorem identity33587 : scanCanonicalize (H12AffineFastState.compose env33587 (packedSelected [2,6,10,12] rootPS)) = affineNative (2^(9+1) ^^^ 559) := by decide +kernel

theorem selectedBound33587 : packedSelected [2,6,10,12] rootPS < 2^1333 := by decide +kernel

def env33588 : List Nat := [2,4,8,16,32,16,128,172,512,559,2048,2745,2234,49,2195,19,2608,2184,678,2194,2745,2592,2576,672,2235,2713,2722,2195,2195,2602,2063,2179,172,33,658,648]

theorem envBound33588 : H12AffineFastState.Bounded env33588 := by
  intro p hp
  have h : env33588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33587_33588 : H12AffineEnvironment.transform 9 559 env33587 = env33588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 559 env33587 == env33588) = true)

theorem identity33588 : scanCanonicalize (H12AffineFastState.compose env33588 (packedSelected [4,6,9] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound33588 : packedSelected [4,6,9] rootPS < 2^1333 := by decide +kernel

def env33589 : List Nat := [2,4,8,16,32,16,128,172,147,188,2048,2090,2234,49,2195,19,2211,2184,53,2194,2090,2227,2179,51,2235,2058,2097,2195,2195,2233,2063,2179,172,33,1,27]

theorem envBound33589 : H12AffineFastState.Bounded env33589 := by
  intro p hp
  have h : env33589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33588_33589 : H12AffineEnvironment.transform 8 147 env33588 = env33589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env33588 == env33589) = true)

theorem identity33589 : scanCanonicalize (H12AffineFastState.compose env33589 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound33589 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env33590 : List Nat := [2,4,8,16,32,16,128,172,147,188,26,48,160,49,137,19,185,146,53,136,48,169,153,51,161,16,43,137,137,163,21,153,172,33,1,27]

theorem envBound33590 : H12AffineFastState.Bounded env33590 := by
  intro p hp
  have h : env33590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33589_33590 : H12AffineEnvironment.transform 10 26 env33589 = env33590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env33589 == env33590) = true)

theorem identity33590 : scanCanonicalize (H12AffineFastState.compose env33590 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound33590 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33591 : List Nat := [2,4,8,16,32,16,56,20,43,4,26,48,24,49,49,19,1,42,53,48,48,17,33,51,25,16,43,49,49,27,21,33,20,33,1,27]

theorem envBound33591 : H12AffineFastState.Bounded env33591 := by
  intro p hp
  have h : env33591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33590_33591 : H12AffineEnvironment.transform 6 56 env33590 = env33591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env33590 == env33591) = true)

theorem identity33591 : scanCanonicalize (H12AffineFastState.compose env33591 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound33591 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env33592 : List Nat := [2,4,8,16,13,16,21,20,6,4,26,29,24,28,28,19,1,7,24,29,29,17,12,30,25,16,6,28,28,27,21,12,20,12,1,27]

theorem envBound33592 : H12AffineFastState.Bounded env33592 := by
  intro p hp
  have h : env33592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33591_33592 : H12AffineEnvironment.transform 4 13 env33591 = env33592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env33591 == env33592) = true)

theorem identity33592 : scanCanonicalize (H12AffineFastState.compose env33592 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound33592 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33593 : List Nat := [2,4,8,12,13,12,9,8,6,4,6,1,4,0,0,15,1,7,4,1,1,13,12,2,5,12,6,0,0,7,9,12,8,12,1,7]

theorem envBound33593 : H12AffineFastState.Bounded env33593 := by
  intro p hp
  have h : env33593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33592_33593 : H12AffineEnvironment.transform 3 12 env33592 = env33593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env33592 == env33593) = true)

theorem identity33593 : scanCanonicalize (H12AffineFastState.compose env33593 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound33593 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33594 : List Nat := [2,4,0,4,5,4,1,0,6,4,6,1,4,0,0,7,1,7,4,1,1,5,4,2,5,4,6,0,0,7,1,4,0,4,1,7]

theorem envBound33594 : H12AffineFastState.Bounded env33594 := by
  intro p hp
  have h : env33594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33593_33594 : H12AffineEnvironment.transform 2 0 env33593 = env33594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env33593 == env33594) = true)

theorem identity33594 : scanCanonicalize (H12AffineFastState.compose env33594 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound33594 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33595 : List Nat := [2,2,0,2,3,2,1,0,0,2,0,1,2,0,0,1,1,1,2,1,1,3,2,2,3,2,0,0,0,1,1,2,0,2,1,1]

theorem envBound33595 : H12AffineFastState.Bounded env33595 := by
  intro p hp
  have h : env33595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33594_33595 : H12AffineEnvironment.transform 1 2 env33594 = env33595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env33594 == env33595) = true)

theorem identity33595 : scanCanonicalize (H12AffineFastState.compose env33595 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound33595 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33596 : List Nat := [0,0,0,0,1,0,1,0,0,0,0,1,0,0,0,1,1,1,0,1,1,1,0,0,1,0,0,0,0,1,1,0,0,0,1,1]

theorem envBound33596 : H12AffineFastState.Bounded env33596 := by
  intro p hp
  have h : env33596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33595_33596 : H12AffineEnvironment.transform 0 0 env33595 = env33596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env33595 == env33596) = true)

def env33597 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,58519,143496,20497,508074,148668,148668,96266,90263,148652,172,16400,1212,135681]

theorem envBound33597 : H12AffineFastState.Bounded env33597 := by
  intro p hp
  have h : env33597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33579_33597 : H12AffineEnvironment.transform 5 17 env33579 = env33597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33579 == env33597) = true)

theorem identity33597 : scanCanonicalize (H12AffineFastState.compose env33597 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound33597 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env33598 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4096,61568,147472,58519,143496,20497,120866,148668,148668,96266,90263,148652,172,16400,1212,135681]

theorem envBound33598 : H12AffineFastState.Bounded env33598 := by
  intro p hp
  have h : env33598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33597_33598 : H12AffineEnvironment.transform 17 137352 env33597 = env33598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env33597 == env33598) = true)

theorem identity33598 : scanCanonicalize (H12AffineFastState.compose env33598 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound33598 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env33599 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,62493,60565,57373,32769,4096,61568,46093,58519,50325,20497,120866,45217,45217,96266,90263,45233,172,16400,1212,58908]

theorem envBound33599 : H12AffineFastState.Bounded env33599 := by
  intro p hp
  have h : env33599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33598_33599 : H12AffineEnvironment.transform 16 62493 env33598 = env33599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env33598 == env33599) = true)

theorem identity33599 : scanCanonicalize (H12AffineFastState.compose env33599 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 12346) := by decide +kernel

theorem selectedBound33599 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33600 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,12346,62493,60565,57373,32769,4096,61568,46093,58519,50325,20497,59416,45217,45217,18480,20653,45233,172,16400,1212,58908]

theorem envBound33600 : H12AffineFastState.Bounded env33600 := by
  intro p hp
  have h : env33600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33599_33600 : H12AffineEnvironment.transform 15 12346 env33599 = env33600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12346 env33599 == env33600) = true)

theorem identity33600 : scanCanonicalize (H12AffineFastState.compose env33600 (packedSelected [0,2,3,4,5,6,7,9,10,13,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 7733) := by decide +kernel

theorem selectedBound33600 : packedSelected [0,2,3,4,5,6,7,9,10,13,18,23] rootPS < 2^1333 := by decide +kernel

def env33601 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,7733,12346,27176,29344,32296,7732,4096,28341,10808,31394,23200,20497,30253,11924,11924,18480,20653,11908,172,16400,1212,30761]

theorem envBound33601 : H12AffineFastState.Bounded env33601 := by
  intro p hp
  have h : env33601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33600_33601 : H12AffineEnvironment.transform 14 7733 env33600 = env33601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7733 env33600 == env33601) = true)

theorem identity33601 : scanCanonicalize (H12AffineFastState.compose env33601 (packedSelected [0,2,3,4,5,6,7,9,10,13,17,19,21,26] rootPS)) = affineNative (2^(13+1) ^^^ 15916) := by decide +kernel

theorem selectedBound33601 : packedSelected [0,2,3,4,5,6,7,9,10,13,17,19,21,26] rootPS < 2^1333 := by decide +kernel

def env33602 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,15916,7733,12346,5124,3212,4,7732,4096,4249,10808,1166,9356,11837,2049,11924,11924,13852,11905,11908,172,15932,1212,1541]

theorem envBound33602 : H12AffineFastState.Bounded env33602 := by
  intro p hp
  have h : env33602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33601_33602 : H12AffineEnvironment.transform 13 15916 env33601 = env33602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15916 env33601 == env33602) = true)

theorem identity33602 : scanCanonicalize (H12AffineFastState.compose env33602 (packedSelected [0,1,6,8,9,10,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound33602 : packedSelected [0,1,6,8,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env33603 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,2088,5636,7733,6162,5124,3212,4,7732,4096,4249,528,1166,3236,1557,2049,1724,1724,7732,1705,1708,172,5652,1212,1541]

theorem envBound33603 : H12AffineFastState.Bounded env33603 := by
  intro p hp
  have h : env33603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33602_33603 : H12AffineEnvironment.transform 12 2088 env33602 = env33603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env33602 == env33603) = true)

theorem identity33603 : scanCanonicalize (H12AffineFastState.compose env33603 (packedSelected [2,4,7,10,11,13] rootPS)) = affineNative (2^(11+1) ^^^ 3213) := by decide +kernel

theorem selectedBound33603 : packedSelected [2,4,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env33604 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,3213,2088,2697,696,1183,2185,3212,4,697,3213,3092,528,1166,3236,1557,2049,1724,1724,697,1705,1708,172,2713,1212,1541]

theorem envBound33604 : H12AffineFastState.Bounded env33604 := by
  intro p hp
  have h : env33604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33603_33604 : H12AffineEnvironment.transform 11 3213 env33603 = env33604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3213 env33603 == env33604) = true)

theorem identity33604 : scanCanonicalize (H12AffineFastState.compose env33604 (packedSelected [1,2,4,5,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1191) := by decide +kernel

theorem selectedBound33604 : packedSelected [1,2,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env33605 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1191,42,1167,1582,696,1183,1070,43,4,697,42,179,528,1166,3,1557,1190,1724,1724,697,1705,1708,172,1598,1212,1541]

theorem envBound33605 : H12AffineFastState.Bounded env33605 := by
  intro p hp
  have h : env33605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33604_33605 : H12AffineEnvironment.transform 10 1191 env33604 = env33605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1191 env33604 == env33605) = true)

theorem identity33605 : scanCanonicalize (H12AffineFastState.compose env33605 (packedSelected [1,3,4,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 653) := by decide +kernel

theorem selectedBound33605 : packedSelected [1,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env33606 : List Nat := [2,4,8,16,32,17,128,172,512,653,554,42,514,163,696,530,675,43,4,697,42,179,528,515,3,152,555,49,49,697,36,33,172,179,561,136]

theorem envBound33606 : H12AffineFastState.Bounded env33606 := by
  intro p hp
  have h : env33606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33605_33606 : H12AffineEnvironment.transform 9 653 env33605 = env33606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 653 env33605 == env33606) = true)

def env33607 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,58518,143496,20497,508155,148716,148716,96347,90262,148732,173,16400,1260,135681]

theorem envBound33607 : H12AffineFastState.Bounded env33607 := by
  intro p hp
  have h : env33607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33578_33607 : H12AffineEnvironment.transform 7 173 env33578 = env33607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env33578 == env33607) = true)

def env33608 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,58518,143496,20497,508075,148668,148668,96267,90262,148652,173,16400,1212,135681]

theorem envBound33608 : H12AffineFastState.Bounded env33608 := by
  intro p hp
  have h : env33608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33607_33608 : H12AffineEnvironment.transform 5 16 env33607 = env33608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33607 == env33608) = true)

theorem identity33608 : scanCanonicalize (H12AffineFastState.compose env33608 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound33608 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env33609 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102559,32769,4096,61569,115854,58518,111639,20497,279604,114723,114723,96267,90262,114739,173,16400,1212,104094]

theorem envBound33609 : H12AffineFastState.Bounded env33609 := by
  intro p hp
  have h : env33609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33608_33609 : H12AffineEnvironment.transform 16 99487 env33608 = env33609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env33608 == env33609) = true)

theorem identity33609 : scanCanonicalize (H12AffineFastState.compose env33609 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound33609 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env33610 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,8192,16384,32768,65536,98459,262144,102559,32769,4096,61569,114826,57490,110611,20497,278576,114723,114723,96267,90262,114739,173,16400,184,103066]

theorem envBound33610 : H12AffineFastState.Bounded env33610 := by
  intro p hp
  have h : env33610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33609_33610 : H12AffineEnvironment.transform 9 4 env33609 = env33610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env33609 == env33610) = true)

theorem identity33610 : scanCanonicalize (H12AffineFastState.compose env33610 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 37018) := by decide +kernel

theorem selectedBound33610 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env33611 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,8192,16384,32768,37018,4097,262144,5,32769,4096,61569,20496,57490,8329,20497,278576,20665,20665,59537,61452,20649,173,16400,184,512]

theorem envBound33611 : H12AffineFastState.Bounded env33611 := by
  intro p hp
  have h : env33611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33610_33611 : H12AffineEnvironment.transform 15 37018 env33610 = env33611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37018 env33610 == env33611) = true)

theorem identity33611 : scanCanonicalize (H12AffineFastState.compose env33611 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound33611 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33612 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,8192,185,32768,37018,4097,262144,5,32769,4096,45112,4265,41003,8329,4264,262281,4096,4096,43048,45237,4112,173,169,184,512]

theorem envBound33612 : H12AffineFastState.Bounded env33612 := by
  intro p hp
  have h : env33612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33611_33612 : H12AffineEnvironment.transform 13 185 env33611 = env33612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env33611 == env33612) = true)

theorem identity33612 : scanCanonicalize (H12AffineFastState.compose env33612 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 4745) := by decide +kernel

theorem selectedBound33612 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33613 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,8192,185,4745,531,4097,262144,5,4744,4096,8881,4265,12962,8329,4264,262281,4096,4096,15009,8764,4112,173,169,184,512]

theorem envBound33613 : H12AffineFastState.Bounded env33613 := by
  intro p hp
  have h : env33613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33612_33613 : H12AffineEnvironment.transform 14 4745 env33612 = env33613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4745 env33612 == env33613) = true)

theorem identity33613 : scanCanonicalize (H12AffineFastState.compose env33613 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 6193) := by decide +kernel

theorem selectedBound33613 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env33614 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,8192,185,4745,531,4097,6193,5,4744,4096,8881,4265,12962,8329,4264,6328,4096,4096,15009,8764,4112,173,169,184,512]

theorem envBound33614 : H12AffineFastState.Bounded env33614 := by
  intro p hp
  have h : env33614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33613_33614 : H12AffineEnvironment.transform 17 6193 env33613 = env33614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6193 env33613 == env33614) = true)

theorem identity33614 : scanCanonicalize (H12AffineFastState.compose env33614 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2099) := by decide +kernel

theorem selectedBound33614 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env33615 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,2099,185,4745,531,4097,6193,5,4744,4096,2690,4265,6801,2234,4264,6328,4096,4096,4754,2575,4112,173,169,184,512]

theorem envBound33615 : H12AffineFastState.Bounded env33615 := by
  intro p hp
  have h : env33615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33614_33615 : H12AffineEnvironment.transform 12 2099 env33614 = env33615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2099 env33614 == env33615) = true)

theorem identity33615 : scanCanonicalize (H12AffineFastState.compose env33615 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2586) := by decide +kernel

theorem selectedBound33615 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env33616 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,2586,2099,185,2195,531,2587,555,5,2194,2586,2690,2739,139,2234,2738,674,2586,2586,2184,2575,2570,173,169,184,512]

theorem envBound33616 : H12AffineFastState.Bounded env33616 := by
  intro p hp
  have h : env33616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33615_33616 : H12AffineEnvironment.transform 11 2586 env33615 = env33616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2586 env33615 == env33616) = true)

theorem identity33616 : scanCanonicalize (H12AffineFastState.compose env33616 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound33616 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33617 : List Nat := [2,4,8,16,32,16,128,173,512,4,48,554,3,185,163,531,555,555,5,162,554,690,643,139,138,642,674,554,554,184,575,570,173,169,184,512]

theorem envBound33617 : H12AffineFastState.Bounded env33617 := by
  intro p hp
  have h : env33617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33616_33617 : H12AffineEnvironment.transform 10 48 env33616 = env33617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env33616 == env33617) = true)

theorem identity33617 : scanCanonicalize (H12AffineFastState.compose env33617 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33617 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33618 : List Nat := [2,4,8,16,32,16,9,36,512,4,48,554,3,48,42,531,555,555,5,43,554,571,522,2,3,523,555,554,554,49,575,570,36,32,49,512]

theorem envBound33618 : H12AffineFastState.Bounded env33618 := by
  intro p hp
  have h : env33618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33617_33618 : H12AffineEnvironment.transform 6 9 env33617 = env33618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33617 == env33618) = true)

theorem identity33618 : scanCanonicalize (H12AffineFastState.compose env33618 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 44) := by decide +kernel

theorem selectedBound33618 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33619 : List Nat := [2,4,8,16,32,16,9,36,44,4,48,6,3,48,42,63,7,7,5,43,6,23,38,2,3,39,7,6,6,49,19,22,36,32,49,44]

theorem envBound33619 : H12AffineFastState.Bounded env33619 := by
  intro p hp
  have h : env33619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33618_33619 : H12AffineEnvironment.transform 8 44 env33618 = env33619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 44 env33618 == env33619) = true)

def env33620 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,58518,143496,20497,508074,148669,148669,96266,90262,148653,173,16400,1213,135681]

theorem envBound33620 : H12AffineFastState.Bounded env33620 := by
  intro p hp
  have h : env33620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33607_33620 : H12AffineEnvironment.transform 5 17 env33607 = env33620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33607 == env33620) = true)

theorem identity33620 : scanCanonicalize (H12AffineFastState.compose env33620 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound33620 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env33621 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136192,32769,4096,61568,147472,58518,143496,20497,60444,148669,148669,96266,90262,148653,173,16400,1213,135681]

theorem envBound33621 : H12AffineFastState.Bounded env33621 := by
  intro p hp
  have h : env33621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33620_33621 : H12AffineEnvironment.transform 17 208054 env33620 = env33621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env33620 == env33621) = true)

theorem identity33621 : scanCanonicalize (H12AffineFastState.compose env33621 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound33621 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env33622 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53282,131072,195732,136192,32769,4096,61568,147472,58518,143496,20497,60444,148669,148669,43048,45236,148653,173,16400,1213,135681]

theorem envBound33622 : H12AffineFastState.Bounded env33622 := by
  intro p hp
  have h : env33622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33621_33622 : H12AffineEnvironment.transform 15 53282 env33621 = env33622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env33621 == env33622) = true)

theorem identity33622 : scanCanonicalize (H12AffineFastState.compose env33622 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound33622 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env33623 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53282,21692,43048,16572,32769,4096,61568,5292,58518,25652,20497,60444,4097,4097,43048,45236,4113,173,16400,1213,18109]

theorem envBound33623 : H12AffineFastState.Bounded env33623 := by
  intro p hp
  have h : env33623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33622_33623 : H12AffineEnvironment.transform 16 21692 env33622 = env33623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env33622 == env33623) = true)

theorem identity33623 : scanCanonicalize (H12AffineFastState.compose env33623 (packedSelected [4,9,20] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound33623 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env33624 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,185,32768,37019,5125,43048,5,32769,4096,45113,5292,42031,9357,4264,44197,4097,4097,43048,45236,4113,173,169,1213,1540]

theorem envBound33624 : H12AffineFastState.Bounded env33624 := by
  intro p hp
  have h : env33624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33623_33624 : H12AffineEnvironment.transform 13 185 env33623 = env33624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env33623 == env33624) = true)

theorem identity33624 : scanCanonicalize (H12AffineFastState.compose env33624 (packedSelected [0,2,3,4,5,6,11,16] rootPS)) = affineNative (2^(14+1) ^^^ 5821) := by decide +kernel

theorem selectedBound33624 : packedSelected [0,2,3,4,5,6,11,16] rootPS < 2^1333 := by decide +kernel

def env33625 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,185,5821,1574,5125,16021,5,5820,4096,9860,5292,12946,9357,4264,14872,4097,4097,16021,9737,4113,173,169,1213,1540]

theorem envBound33625 : H12AffineFastState.Bounded env33625 := by
  intro p hp
  have h : env33625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33624_33625 : H12AffineEnvironment.transform 14 5821 env33624 = env33625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5821 env33624 == env33625) = true)

theorem identity33625 : scanCanonicalize (H12AffineFastState.compose env33625 (packedSelected [0,1,2,5,7,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 7823) := by decide +kernel

theorem selectedBound33625 : packedSelected [0,1,2,5,7,15,17] rootPS < 2^1333 := by decide +kernel

def env33626 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,7823,185,5821,1574,5125,26,5,5820,4096,6155,5292,3101,6658,4264,1175,4097,4097,26,6278,4113,173,169,1213,1540]

theorem envBound33626 : H12AffineFastState.Bounded env33626 := by
  intro p hp
  have h : env33626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33625_33626 : H12AffineEnvironment.transform 12 7823 env33625 = env33626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7823 env33625 == env33626) = true)

theorem identity33626 : scanCanonicalize (H12AffineFastState.compose env33626 (packedSelected [0,2,3,5,7,15] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound33626 : packedSelected [0,2,3,5,7,15] rootPS < 2^1333 := by decide +kernel

def env33627 : List Nat := [2,4,8,16,17,17,128,156,512,1024,2048,4096,7823,136,5772,1559,5125,26,5,5773,4096,6155,5277,3101,6658,4249,1175,4097,4097,26,6278,4113,156,152,1164,1540]

theorem envBound33627 : H12AffineFastState.Bounded env33627 := by
  intro p hp
  have h : env33627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33626_33627 : H12AffineEnvironment.transform 4 17 env33626 = env33627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env33626 == env33627) = true)

theorem identity33627 : scanCanonicalize (H12AffineFastState.compose env33627 (packedSelected [0,1,2,3,4,5,7,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound33627 : packedSelected [0,1,2,3,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env33628 : List Nat := [2,4,8,16,17,17,128,156,512,543,2048,4096,6288,136,4243,8,4634,26,5,4242,4096,6155,4738,2562,6658,4249,648,4097,4097,26,6278,4113,156,152,659,27]

theorem envBound33628 : H12AffineFastState.Bounded env33628 := by
  intro p hp
  have h : env33628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33627_33628 : H12AffineEnvironment.transform 9 543 env33627 = env33628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env33627 == env33628) = true)

theorem identity33628 : scanCanonicalize (H12AffineFastState.compose env33628 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound33628 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env33629 : List Nat := [2,4,8,16,17,17,128,156,1,30,2048,4096,6288,136,4243,8,4123,26,5,4242,4096,6155,4227,2051,6147,4249,137,4097,4097,26,6278,4113,156,152,146,27]

theorem envBound33629 : H12AffineFastState.Bounded env33629 := by
  intro p hp
  have h : env33629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33628_33629 : H12AffineEnvironment.transform 8 1 env33628 = env33629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env33628 == env33629) = true)

theorem identity33629 : scanCanonicalize (H12AffineFastState.compose env33629 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound33629 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env33630 : List Nat := [2,4,8,16,17,17,128,156,1,30,26,4096,4234,136,4243,8,4123,26,5,4242,4096,4113,4227,25,4121,4249,137,4097,4097,26,4252,4113,156,152,146,27]

theorem envBound33630 : H12AffineFastState.Bounded env33630 := by
  intro p hp
  have h : env33630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33629_33630 : H12AffineEnvironment.transform 10 26 env33629 = env33630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env33629 == env33630) = true)

theorem identity33630 : scanCanonicalize (H12AffineFastState.compose env33630 (packedSelected [1,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 147) := by decide +kernel

theorem selectedBound33630 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env33631 : List Nat := [2,4,8,16,17,17,128,156,1,30,26,147,25,136,0,8,136,26,5,1,147,130,16,25,138,10,137,146,146,26,15,130,156,152,146,27]

theorem envBound33631 : H12AffineFastState.Bounded env33631 := by
  intro p hp
  have h : env33631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33630_33631 : H12AffineEnvironment.transform 11 147 env33630 = env33631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 147 env33630 == env33631) = true)

theorem identity33631 : scanCanonicalize (H12AffineFastState.compose env33631 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound33631 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env33632 : List Nat := [2,4,8,16,17,17,19,15,1,30,26,0,25,27,0,8,27,26,5,1,0,17,16,25,25,10,26,1,1,26,15,17,15,11,1,27]

theorem envBound33632 : H12AffineFastState.Bounded env33632 := by
  intro p hp
  have h : env33632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33631_33632 : H12AffineEnvironment.transform 6 19 env33631 = env33632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env33631 == env33632) = true)

theorem identity33632 : scanCanonicalize (H12AffineFastState.compose env33632 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound33632 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33633 : List Nat := [2,4,5,16,17,17,19,2,1,19,23,0,20,22,0,5,22,23,5,1,0,17,16,20,20,7,23,1,1,23,2,17,2,6,1,22]

theorem envBound33633 : H12AffineFastState.Bounded env33633 := by
  intro p hp
  have h : env33633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33632_33633 : H12AffineEnvironment.transform 2 5 env33632 = env33633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env33632 == env33633) = true)

def env33634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,58682,143497,20496,508154,148801,148800,96347,90426,148816,256,16401,1345,135680]

theorem envBound33634 : H12AffineFastState.Bounded env33634 := by
  intro p hp
  have h : env33634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33577_33634 : H12AffineEnvironment.transform 18 136193 env33577 = env33634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env33577 == env33634) = true)

def env33635 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,58518,143497,20496,508154,148717,148716,96347,90262,148732,172,16401,1261,135680]

theorem envBound33635 : H12AffineFastState.Bounded env33635 := by
  intro p hp
  have h : env33635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33634_33635 : H12AffineEnvironment.transform 7 172 env33634 = env33635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env33634 == env33635) = true)

def env33636 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,58518,143497,20496,508074,148669,148668,96267,90262,148652,172,16401,1213,135680]

theorem envBound33636 : H12AffineFastState.Bounded env33636 := by
  intro p hp
  have h : env33636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33635_33636 : H12AffineEnvironment.transform 5 16 env33635 = env33636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33635 == env33636) = true)

theorem identity33636 : scanCanonicalize (H12AffineFastState.compose env33636 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound33636 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env33637 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4096,61569,147473,58518,143497,20496,120867,148669,148668,96267,90262,148652,172,16401,1213,135680]

theorem envBound33637 : H12AffineFastState.Bounded env33637 := by
  intro p hp
  have h : env33637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33636_33637 : H12AffineEnvironment.transform 17 137353 env33636 = env33637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env33636 == env33637) = true)

theorem identity33637 : scanCanonicalize (H12AffineFastState.compose env33637 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound33637 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env33638 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,62493,60564,57372,32769,4096,61569,46092,58518,50324,20496,120867,45216,45217,96267,90262,45233,172,16401,1213,58909]

theorem envBound33638 : H12AffineFastState.Bounded env33638 := by
  intro p hp
  have h : env33638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33637_33638 : H12AffineEnvironment.transform 16 62493 env33637 = env33638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env33637 == env33638) = true)

theorem identity33638 : scanCanonicalize (H12AffineFastState.compose env33638 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 12347) := by decide +kernel

theorem selectedBound33638 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33639 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,12347,62493,60564,57372,32769,4096,61569,46092,58518,50324,20496,59416,45216,45217,18480,20653,45233,172,16401,1213,58909]

theorem envBound33639 : H12AffineFastState.Bounded env33639 := by
  intro p hp
  have h : env33639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33638_33639 : H12AffineEnvironment.transform 15 12347 env33638 = env33639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12347 env33638 == env33639) = true)

theorem identity33639 : scanCanonicalize (H12AffineFastState.compose env33639 (packedSelected [0,2,3,4,5,6,7,9,10,13,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 24205) := by decide +kernel

theorem selectedBound33639 : packedSelected [0,2,3,4,5,6,7,9,10,13,18,23] rootPS < 2^1333 := by decide +kernel

def env33640 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,24205,12347,10896,12825,16017,24204,4096,11788,27265,14875,6681,20496,13973,28205,28204,18480,20653,28220,172,16401,1213,14480]

theorem envBound33640 : H12AffineFastState.Bounded env33640 := by
  intro p hp
  have h : env33640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33639_33640 : H12AffineEnvironment.transform 14 24205 env33639 = env33640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24205 env33639 == env33640) = true)

theorem identity33640 : scanCanonicalize (H12AffineFastState.compose env33640 (packedSelected [0,2,3,4,5,6,7,9,10,13,17,19,21,26] rootPS)) = affineNative (2^(12+1) ^^^ 7828) := by decide +kernel

theorem selectedBound33640 : packedSelected [0,2,3,4,5,6,7,9,10,13,17,19,21,26] rootPS < 2^1333 := by decide +kernel

def env33641 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,7828,16384,24205,3759,5124,3213,5,24204,4096,4248,21525,1167,6681,20496,2049,20665,20664,18480,20653,20648,172,16401,1213,1540]

theorem envBound33641 : H12AffineFastState.Bounded env33641 := by
  intro p hp
  have h : env33641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33640_33641 : H12AffineEnvironment.transform 12 7828 env33640 = env33641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7828 env33640 == env33641) = true)

theorem identity33641 : scanCanonicalize (H12AffineFastState.compose env33641 (packedSelected [3,5,6,10,11,12,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound33641 : packedSelected [3,5,6,10,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env33642 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,48,3748,16384,20157,3759,1076,3213,5,20156,48,168,17445,1167,2601,16416,2049,16521,16520,18480,16541,16536,172,16401,1213,1540]

theorem envBound33642 : H12AffineFastState.Bounded env33642 := by
  intro p hp
  have h : env33642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33641_33642 : H12AffineEnvironment.transform 11 48 env33641 = env33642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env33641 == env33642) = true)

theorem identity33642 : scanCanonicalize (H12AffineFastState.compose env33642 (packedSelected [0,2,3,4,6,7,8,9,12] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound33642 : packedSelected [0,2,3,4,6,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env33643 : List Nat := [2,4,8,16,32,16,128,172,26,1024,2048,48,3262,16384,19623,3253,1076,3213,5,19622,48,168,17445,1167,2099,16416,2049,16521,16520,18480,16541,16536,172,16401,1213,1054]

theorem envBound33643 : H12AffineFastState.Bounded env33643 := by
  intro p hp
  have h : env33643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33642_33643 : H12AffineEnvironment.transform 8 26 env33642 = env33643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env33642 == env33643) = true)

theorem identity33643 : scanCanonicalize (H12AffineFastState.compose env33643 (packedSelected [1,2,4,6,7,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 1070) := by decide +kernel

theorem selectedBound33643 : packedSelected [1,2,4,6,7,8,13] rootPS < 2^1333 := by decide +kernel

def env33644 : List Nat := [2,4,8,16,32,16,128,172,26,1024,1070,48,144,16384,16521,155,1076,163,5,16520,48,168,17445,1167,1053,16416,1071,16521,16520,17438,16541,16536,172,16401,1213,1054]

theorem envBound33644 : H12AffineFastState.Bounded env33644 := by
  intro p hp
  have h : env33644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33643_33644 : H12AffineEnvironment.transform 10 1070 env33643 = env33644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1070 env33643 == env33644) = true)

theorem identity33644 : scanCanonicalize (H12AffineFastState.compose env33644 (packedSelected [0,1,3,6,7,10] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound33644 : packedSelected [0,1,3,6,7,10] rootPS < 2^1333 := by decide +kernel

def env33645 : List Nat := [2,4,8,11,32,11,128,172,1,1024,1070,43,139,16384,16521,128,1071,163,5,16520,43,168,17445,1167,1030,16416,1071,16521,16520,17413,16518,16515,172,16394,1190,1029]

theorem envBound33645 : H12AffineFastState.Bounded env33645 := by
  intro p hp
  have h : env33645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33644_33645 : H12AffineEnvironment.transform 3 11 env33644 = env33645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env33644 == env33645) = true)

theorem identity33645 : scanCanonicalize (H12AffineFastState.compose env33645 (packedSelected [1,3,4,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound33645 : packedSelected [1,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env33646 : List Nat := [2,4,8,11,32,11,128,172,1,4,42,43,139,16384,16521,128,43,163,5,16520,43,168,16417,139,2,16416,43,16521,16520,16385,16518,16515,172,16394,162,1]

theorem envBound33646 : H12AffineFastState.Bounded env33646 := by
  intro p hp
  have h : env33646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33645_33646 : H12AffineEnvironment.transform 9 4 env33645 = env33646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env33645 == env33646) = true)

theorem identity33646 : scanCanonicalize (H12AffineFastState.compose env33646 (packedSelected [0,3] rootPS)) = affineNative (2^(13+1) ^^^ 162) := by decide +kernel

theorem selectedBound33646 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env33647 : List Nat := [2,4,8,11,32,11,128,172,1,4,42,43,139,162,43,128,43,163,5,42,43,168,131,139,2,130,43,43,42,163,36,33,172,168,162,1]

theorem envBound33647 : H12AffineFastState.Bounded env33647 := by
  intro p hp
  have h : env33647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33646_33647 : H12AffineEnvironment.transform 13 162 env33646 = env33647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 162 env33646 == env33647) = true)

theorem identity33647 : scanCanonicalize (H12AffineFastState.compose env33647 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33647 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env33648 : List Nat := [2,4,8,11,32,11,9,37,1,4,42,43,2,43,43,9,43,42,5,42,43,33,10,2,2,11,43,43,42,42,36,33,37,33,43,1]

theorem envBound33648 : H12AffineFastState.Bounded env33648 := by
  intro p hp
  have h : env33648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33647_33648 : H12AffineEnvironment.transform 6 9 env33647 = env33648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33647 == env33648) = true)

theorem identity33648 : scanCanonicalize (H12AffineFastState.compose env33648 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound33648 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33649 : List Nat := [2,3,8,11,32,11,9,34,1,3,42,43,2,43,43,9,43,42,2,42,43,33,10,2,2,11,43,43,42,42,35,33,34,33,43,1]

theorem envBound33649 : H12AffineFastState.Bounded env33649 := by
  intro p hp
  have h : env33649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33648_33649 : H12AffineEnvironment.transform 1 3 env33648 = env33649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env33648 == env33649) = true)

def env33650 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,58518,143497,20496,508075,148668,148669,96266,90262,148653,172,16401,1212,135680]

theorem envBound33650 : H12AffineFastState.Bounded env33650 := by
  intro p hp
  have h : env33650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33635_33650 : H12AffineEnvironment.transform 5 17 env33635 = env33650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33635 == env33650) = true)

theorem identity33650 : scanCanonicalize (H12AffineFastState.compose env33650 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound33650 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env33651 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4096,61568,61617,58518,32808,20496,356362,62493,62492,96266,90262,62476,172,16401,1212,41633]

theorem envBound33651 : H12AffineFastState.Bounded env33651 := by
  intro p hp
  have h : env33651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33650_33651 : H12AffineEnvironment.transform 16 45217 env33650 = env33651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env33650 == env33651) = true)

theorem identity33651 : scanCanonicalize (H12AffineFastState.compose env33651 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound33651 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env33652 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,2184,42144,32769,4096,61568,61617,58518,32808,20496,96386,62493,62492,96266,90262,62476,172,16401,1212,41633]

theorem envBound33652 : H12AffineFastState.Bounded env33652 := by
  intro p hp
  have h : env33652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33651_33652 : H12AffineEnvironment.transform 17 2184 env33651 = env33652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env33651 == env33652) = true)

theorem identity33652 : scanCanonicalize (H12AffineFastState.compose env33652 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 24600) := by decide +kernel

theorem selectedBound33652 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env33653 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,24600,65536,20665,2184,17592,24601,4096,4248,4265,1166,24624,20496,96386,5125,5124,96266,90262,5140,172,16401,1212,17081]

theorem envBound33653 : H12AffineFastState.Bounded env33653 := by
  intro p hp
  have h : env33653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33652_33653 : H12AffineEnvironment.transform 14 24600 env33652 = env33653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24600 env33652 == env33653) = true)

theorem identity33653 : scanCanonicalize (H12AffineFastState.compose env33653 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound33653 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env33654 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,24600,13375,20665,2184,17592,24601,4096,4248,4265,1166,24624,20496,19645,5125,5124,19509,21673,5140,172,16401,1212,17081]

theorem envBound33654 : H12AffineFastState.Bounded env33654 := by
  intro p hp
  have h : env33654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33653_33654 : H12AffineEnvironment.transform 15 13375 env33653 = env33654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env33653 == env33654) = true)

theorem identity33654 : scanCanonicalize (H12AffineFastState.compose env33654 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 10913) := by decide +kernel

theorem selectedBound33654 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env33655 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,10913,2745,13375,14872,2184,11801,2744,4096,4248,4265,1166,2705,15025,9756,5125,5124,9876,15880,5140,172,10928,1212,10264]

theorem envBound33655 : H12AffineFastState.Bounded env33655 := by
  intro p hp
  have h : env33655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33654_33655 : H12AffineEnvironment.transform 13 10913 env33654 = env33655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10913 env33654 == env33655) = true)

theorem identity33655 : scanCanonicalize (H12AffineFastState.compose env33655 (packedSelected [2,7,9,10,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 5284) := by decide +kernel

theorem selectedBound33655 : packedSelected [2,7,9,10,12,13] rootPS < 2^1333 := by decide +kernel

def env33656 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,5284,7685,2745,155,3772,2184,6845,2744,4096,4248,4265,1166,2705,3605,4792,5125,5124,4656,2732,5140,172,7700,1212,7356]

theorem envBound33656 : H12AffineFastState.Bounded env33656 := by
  intro p hp
  have h : env33656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33655_33656 : H12AffineEnvironment.transform 12 5284 env33655 = env33656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5284 env33655 == env33656) = true)

theorem identity33656 : scanCanonicalize (H12AffineFastState.compose env33656 (packedSelected [2,6,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 3636) := by decide +kernel

theorem selectedBound33656 : packedSelected [2,6,10,12] rootPS < 2^1333 := by decide +kernel

def env33657 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,3636,2704,49,2745,155,3772,2184,1161,2744,3636,3756,3741,1166,2705,3605,3212,2609,2608,3076,2732,2592,172,32,1212,648]

theorem envBound33657 : H12AffineFastState.Bounded env33657 := by
  intro p hp
  have h : env33657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33656_33657 : H12AffineEnvironment.transform 11 3636 env33656 = env33657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3636 env33656 == env33657) = true)

theorem identity33657 : scanCanonicalize (H12AffineFastState.compose env33657 (packedSelected [0,2,3,5,6,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound33657 : packedSelected [0,2,3,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env33658 : List Nat := [2,4,8,16,32,17,128,172,512,565,2048,2049,2704,49,2745,155,2185,2184,700,2744,2049,2201,2216,699,2705,2080,2745,2609,2608,2609,2732,2592,172,32,649,648]

theorem envBound33658 : H12AffineFastState.Bounded env33658 := by
  intro p hp
  have h : env33658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33657_33658 : H12AffineEnvironment.transform 9 565 env33657 = env33658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env33657 == env33658) = true)

theorem identity33658 : scanCanonicalize (H12AffineFastState.compose env33658 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 659) := by decide +kernel

theorem selectedBound33658 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env33659 : List Nat := [2,4,8,16,32,17,128,172,512,565,659,658,3,49,42,155,538,539,700,43,658,522,571,699,2,691,42,162,163,162,63,179,172,32,649,648]

theorem envBound33659 : H12AffineFastState.Bounded env33659 := by
  intro p hp
  have h : env33659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33658_33659 : H12AffineEnvironment.transform 10 659 env33658 = env33659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 659 env33658 == env33659) = true)

theorem identity33659 : scanCanonicalize (H12AffineFastState.compose env33659 (packedSelected [4,5,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound33659 : packedSelected [4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env33660 : List Nat := [2,4,8,16,32,17,128,172,163,150,48,49,3,49,42,155,185,184,31,43,49,169,152,24,2,16,42,162,163,162,63,179,172,32,42,43]

theorem envBound33660 : H12AffineFastState.Bounded env33660 := by
  intro p hp
  have h : env33660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33659_33660 : H12AffineEnvironment.transform 8 163 env33659 = env33660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env33659 == env33660) = true)

theorem identity33660 : scanCanonicalize (H12AffineFastState.compose env33660 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound33660 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env33661 : List Nat := [2,4,8,11,32,10,128,172,163,141,43,42,3,42,42,128,162,163,4,43,42,169,131,3,2,11,42,162,163,162,36,168,172,32,42,43]

theorem envBound33661 : H12AffineFastState.Bounded env33661 := by
  intro p hp
  have h : env33661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33660_33661 : H12AffineEnvironment.transform 3 11 env33660 = env33661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env33660 == env33661) = true)

theorem identity33661 : scanCanonicalize (H12AffineFastState.compose env33661 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33661 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33662 : List Nat := [2,4,8,11,32,10,9,37,42,4,43,42,3,42,42,9,43,42,4,43,42,32,10,3,2,11,42,43,42,43,36,33,37,32,42,43]

theorem envBound33662 : H12AffineFastState.Bounded env33662 := by
  intro p hp
  have h : env33662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33661_33662 : H12AffineEnvironment.transform 6 9 env33661 = env33662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33661 == env33662) = true)

theorem identity33662 : scanCanonicalize (H12AffineFastState.compose env33662 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound33662 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33663 : List Nat := [2,4,8,11,15,10,9,10,5,4,4,5,3,5,5,9,4,5,4,4,5,15,10,3,2,11,5,4,5,4,11,14,10,15,5,4]

theorem envBound33663 : H12AffineFastState.Bounded env33663 := by
  intro p hp
  have h : env33663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33662_33663 : H12AffineEnvironment.transform 4 15 env33662 = env33663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env33662 == env33663) = true)

theorem identity33663 : scanCanonicalize (H12AffineFastState.compose env33663 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound33663 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33664 : List Nat := [2,4,5,6,2,7,4,7,5,4,4,5,3,5,5,4,4,5,4,4,5,2,7,3,2,6,5,4,5,4,6,3,7,2,5,4]

theorem envBound33664 : H12AffineFastState.Bounded env33664 := by
  intro p hp
  have h : env33664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33663_33664 : H12AffineEnvironment.transform 2 5 env33663 = env33664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env33663 == env33664) = true)

theorem identity33664 : scanCanonicalize (H12AffineFastState.compose env33664 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound33664 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33665 : List Nat := [2,3,2,1,2,0,3,0,2,3,3,2,3,2,2,3,3,2,3,3,2,2,0,3,2,1,2,3,2,3,1,3,0,2,2,3]

theorem envBound33665 : H12AffineFastState.Bounded env33665 := by
  intro p hp
  have h : env33665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33664_33665 : H12AffineEnvironment.transform 1 3 env33664 = env33665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env33664 == env33665) = true)

theorem identity33665 : scanCanonicalize (H12AffineFastState.compose env33665 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound33665 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env33666 : List Nat := [1,0,1,1,1,0,0,0,1,0,0,1,0,1,1,0,0,1,0,0,1,1,0,0,1,1,1,0,1,0,1,0,0,1,1,0]

theorem envBound33666 : H12AffineFastState.Bounded env33666 := by
  intro p hp
  have h : env33666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33665_33666 : H12AffineEnvironment.transform 0 1 env33665 = env33666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env33665 == env33666) = true)

def env33667 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,58519,143497,20496,508154,148716,148717,96347,90263,148733,173,16401,1260,135680]

theorem envBound33667 : H12AffineFastState.Bounded env33667 := by
  intro p hp
  have h : env33667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33634_33667 : H12AffineEnvironment.transform 7 173 env33634 = env33667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env33634 == env33667) = true)

def env33668 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,58519,143497,20496,508074,148668,148669,96267,90263,148653,173,16401,1212,135680]

theorem envBound33668 : H12AffineFastState.Bounded env33668 := by
  intro p hp
  have h : env33668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33667_33668 : H12AffineEnvironment.transform 5 16 env33667 = env33668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33667 == env33668) = true)

theorem identity33668 : scanCanonicalize (H12AffineFastState.compose env33668 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound33668 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env33669 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136193,32769,4096,61569,147473,58519,143497,20496,60445,148668,148669,96267,90263,148653,173,16401,1212,135680]

theorem envBound33669 : H12AffineFastState.Bounded env33669 := by
  intro p hp
  have h : env33669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33668_33669 : H12AffineEnvironment.transform 17 208055 env33668 = env33669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env33668 == env33669) = true)

theorem identity33669 : scanCanonicalize (H12AffineFastState.compose env33669 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound33669 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env33670 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53283,131072,195732,136193,32769,4096,61569,147473,58519,143497,20496,60445,148668,148669,43048,45236,148653,173,16401,1212,135680]

theorem envBound33670 : H12AffineFastState.Bounded env33670 := by
  intro p hp
  have h : env33670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33669_33670 : H12AffineEnvironment.transform 15 53283 env33669 = env33670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env33669 == env33670) = true)

theorem identity33670 : scanCanonicalize (H12AffineFastState.compose env33670 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound33670 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env33671 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53283,21692,43048,16573,32769,4096,61569,5293,58519,25653,20496,60445,4096,4097,43048,45236,4113,173,16401,1212,18108]

theorem envBound33671 : H12AffineFastState.Bounded env33671 := by
  intro p hp
  have h : env33671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33670_33671 : H12AffineEnvironment.transform 16 21692 env33670 = env33671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env33670 == env33671) = true)

theorem identity33671 : scanCanonicalize (H12AffineFastState.compose env33671 (packedSelected [4,9,20] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound33671 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env33672 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,185,32768,37018,5125,43048,4,32769,4096,45112,5293,42030,9356,4265,44196,4096,4097,43048,45236,4113,173,168,1212,1541]

theorem envBound33672 : H12AffineFastState.Bounded env33672 := by
  intro p hp
  have h : env33672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33671_33672 : H12AffineEnvironment.transform 13 185 env33671 = env33672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env33671 == env33672) = true)

theorem identity33672 : scanCanonicalize (H12AffineFastState.compose env33672 (packedSelected [0,2,3,4,5,6,11,16] rootPS)) = affineNative (2^(12+1) ^^^ 4632) := by decide +kernel

theorem selectedBound33672 : packedSelected [0,2,3,4,5,6,11,16] rootPS < 2^1333 := by decide +kernel

def env33673 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,4632,185,32768,37018,5125,39472,4,32769,4096,33312,5293,38454,5780,4265,40636,4096,4097,39472,33452,4113,173,168,1212,1541]

theorem envBound33673 : H12AffineFastState.Bounded env33673 := by
  intro p hp
  have h : env33673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33672_33673 : H12AffineEnvironment.transform 12 4632 env33672 = env33673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4632 env33672 == env33673) = true)

theorem identity33673 : scanCanonicalize (H12AffineFastState.compose env33673 (packedSelected [1,3,6,7,9,11,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound33673 : packedSelected [1,3,6,7,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env33674 : List Nat := [2,4,8,16,32,16,128,173,512,1024,146,4096,4632,185,32768,37018,5125,37538,4,32769,4096,33312,5293,38454,5780,4265,38446,4096,4097,37538,33452,4113,173,168,1212,1541]

theorem envBound33674 : H12AffineFastState.Bounded env33674 := by
  intro p hp
  have h : env33674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33673_33674 : H12AffineEnvironment.transform 10 146 env33673 = env33674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env33673 == env33674) = true)

theorem identity33674 : scanCanonicalize (H12AffineFastState.compose env33674 (packedSelected [0,2,3,5,7,15] rootPS)) = affineNative (2^(14+1) ^^^ 5773) := by decide +kernel

theorem selectedBound33674 : packedSelected [0,2,3,5,7,15] rootPS < 2^1333 := by decide +kernel

def env33675 : List Nat := [2,4,8,16,32,16,128,173,512,1024,146,4096,4632,185,5773,1559,5125,1071,4,5772,4096,5293,5293,187,5780,4265,163,4096,4097,1071,5153,4113,173,168,1212,1541]

theorem envBound33675 : H12AffineFastState.Bounded env33675 := by
  intro p hp
  have h : env33675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33674_33675 : H12AffineEnvironment.transform 14 5773 env33674 = env33675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5773 env33674 == env33675) = true)

theorem identity33675 : scanCanonicalize (H12AffineFastState.compose env33675 (packedSelected [0,1,2,3,4,5,7,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound33675 : packedSelected [0,1,2,3,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env33676 : List Nat := [2,4,8,16,32,16,128,173,43,1024,146,4096,4147,185,5286,1084,5125,1071,4,5287,4096,5293,5293,187,5311,4265,163,4096,4097,1071,5153,4113,173,168,1212,1070]

theorem envBound33676 : H12AffineFastState.Bounded env33676 := by
  intro p hp
  have h : env33676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33675_33676 : H12AffineEnvironment.transform 8 43 env33675 = env33676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env33675 == env33676) = true)

theorem identity33676 : scanCanonicalize (H12AffineFastState.compose env33676 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound33676 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env33677 : List Nat := [2,4,8,16,32,16,128,173,43,30,146,4096,4147,185,4280,34,4123,49,4,4281,4096,4275,4275,187,4257,4265,163,4096,4097,49,4159,4113,173,168,162,48]

theorem envBound33677 : H12AffineFastState.Bounded env33677 := by
  intro p hp
  have h : env33677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33676_33677 : H12AffineEnvironment.transform 9 30 env33676 = env33677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env33676 == env33677) = true)

theorem identity33677 : scanCanonicalize (H12AffineFastState.compose env33677 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33677 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33678 : List Nat := [2,4,8,16,32,16,9,36,43,30,27,4096,4147,48,4145,34,4123,49,4,4144,4096,4154,4154,50,4136,4128,42,4096,4097,49,4159,4113,36,33,43,48]

theorem envBound33678 : H12AffineFastState.Bounded env33678 := by
  intro p hp
  have h : env33678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33677_33678 : H12AffineEnvironment.transform 6 9 env33677 = env33678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33677 == env33678) = true)

theorem identity33678 : scanCanonicalize (H12AffineFastState.compose env33678 (packedSelected [1,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 42) := by decide +kernel

theorem selectedBound33678 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env33679 : List Nat := [2,4,8,16,32,16,9,36,43,30,27,42,25,48,27,34,49,49,4,26,42,16,16,50,2,10,42,42,43,49,21,59,36,33,43,48]

theorem envBound33679 : H12AffineFastState.Bounded env33679 := by
  intro p hp
  have h : env33679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33678_33679 : H12AffineEnvironment.transform 11 42 env33678 = env33679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 42 env33678 == env33679) = true)

theorem identity33679 : scanCanonicalize (H12AffineFastState.compose env33679 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound33679 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env33680 : List Nat := [2,4,8,16,11,16,9,15,0,30,27,1,25,27,27,9,26,26,4,26,1,16,16,25,2,10,1,1,0,26,21,16,15,10,0,27]

theorem envBound33680 : H12AffineFastState.Bounded env33680 := by
  intro p hp
  have h : env33680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33679_33680 : H12AffineEnvironment.transform 4 11 env33679 = env33680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env33679 == env33680) = true)

theorem identity33680 : scanCanonicalize (H12AffineFastState.compose env33680 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound33680 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env33681 : List Nat := [2,4,8,12,11,12,9,15,0,2,7,1,5,7,7,9,6,6,4,6,1,12,12,5,2,10,1,1,0,6,9,12,15,10,0,7]

theorem envBound33681 : H12AffineFastState.Bounded env33681 := by
  intro p hp
  have h : env33681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33680_33681 : H12AffineEnvironment.transform 3 12 env33680 = env33681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env33680 == env33681) = true)

def env33682 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,58519,143497,20496,508075,148669,148668,96266,90263,148652,173,16401,1213,135680]

theorem envBound33682 : H12AffineFastState.Bounded env33682 := by
  intro p hp
  have h : env33682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33667_33682 : H12AffineEnvironment.transform 5 17 env33667 = env33682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33667 == env33682) = true)

theorem identity33682 : scanCanonicalize (H12AffineFastState.compose env33682 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound33682 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env33683 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102559,32769,4096,61568,115854,58519,111639,20496,279605,114723,114722,96266,90263,114738,173,16401,1213,104094]

theorem envBound33683 : H12AffineFastState.Bounded env33683 := by
  intro p hp
  have h : env33683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33682_33683 : H12AffineEnvironment.transform 16 99486 env33682 = env33683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env33682 == env33683) = true)

theorem identity33683 : scanCanonicalize (H12AffineFastState.compose env33683 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound33683 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env33684 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,4096,8192,16384,32768,65536,98459,262144,102559,32769,4096,61568,114827,57490,110610,20496,278576,114723,114722,96266,90263,114738,173,16401,184,103067]

theorem envBound33684 : H12AffineFastState.Bounded env33684 := by
  intro p hp
  have h : env33684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33683_33684 : H12AffineEnvironment.transform 9 5 env33683 = env33684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env33683 == env33684) = true)

theorem identity33684 : scanCanonicalize (H12AffineFastState.compose env33684 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 37019) := by decide +kernel

theorem selectedBound33684 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env33685 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,4096,8192,16384,32768,37019,4096,262144,4,32769,4096,61568,20496,57490,8329,20496,278576,20664,20665,59537,61452,20649,173,16401,184,512]

theorem envBound33685 : H12AffineFastState.Bounded env33685 := by
  intro p hp
  have h : env33685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33684_33685 : H12AffineEnvironment.transform 15 37019 env33684 = env33685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37019 env33684 == env33685) = true)

theorem identity33685 : scanCanonicalize (H12AffineFastState.compose env33685 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound33685 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33686 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,4096,8192,185,32768,37019,4096,262144,4,32769,4096,45113,4265,41003,8329,4265,262281,4097,4096,43048,45237,4112,173,168,184,512]

theorem envBound33686 : H12AffineFastState.Bounded env33686 := by
  intro p hp
  have h : env33686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33685_33686 : H12AffineEnvironment.transform 13 185 env33685 = env33686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env33685 == env33686) = true)

theorem identity33686 : scanCanonicalize (H12AffineFastState.compose env33686 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 4649) := by decide +kernel

theorem selectedBound33686 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33687 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,4096,4649,185,32768,37019,4096,262144,4,32769,4096,33296,4265,37378,4768,4265,262281,4097,4096,39425,33436,4112,173,168,184,512]

theorem envBound33687 : H12AffineFastState.Bounded env33687 := by
  intro p hp
  have h : env33687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33686_33687 : H12AffineEnvironment.transform 12 4649 env33686 = env33687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4649 env33686 == env33687) = true)

theorem identity33687 : scanCanonicalize (H12AffineFastState.compose env33687 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 35512) := by decide +kernel

theorem selectedBound33687 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env33688 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,4096,4649,185,32768,37019,4096,35512,4,32769,4096,33296,4265,37378,4768,4265,35377,4097,4096,39425,33436,4112,173,168,184,512]

theorem envBound33688 : H12AffineFastState.Bounded env33688 := by
  intro p hp
  have h : env33688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33687_33688 : H12AffineEnvironment.transform 17 35512 env33687 = env33688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35512 env33687 == env33688) = true)

theorem identity33688 : scanCanonicalize (H12AffineFastState.compose env33688 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2586) := by decide +kernel

theorem selectedBound33688 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env33689 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,2586,2099,185,32768,35457,2586,35512,4,32769,2586,33296,2739,34840,2234,2739,35377,2587,2586,32795,33436,2570,173,168,184,512]

theorem envBound33689 : H12AffineFastState.Bounded env33689 := by
  intro p hp
  have h : env33689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33688_33689 : H12AffineEnvironment.transform 11 2586 env33688 = env33689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2586 env33688 == env33689) = true)

theorem identity33689 : scanCanonicalize (H12AffineFastState.compose env33689 (packedSelected [1,3,17] rootPS)) = affineNative (2^(14+1) ^^^ 561) := by decide +kernel

theorem selectedBound33689 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env33690 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,2586,2099,185,561,2224,2586,2185,4,560,2586,33,2739,2601,2234,2739,2048,2587,2586,554,173,2570,173,168,184,512]

theorem envBound33690 : H12AffineFastState.Bounded env33690 := by
  intro p hp
  have h : env33690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33689_33690 : H12AffineEnvironment.transform 14 561 env33689 = env33690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 561 env33689 == env33690) = true)

theorem identity33690 : scanCanonicalize (H12AffineFastState.compose env33690 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound33690 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env33691 : List Nat := [2,4,8,16,32,17,128,173,512,5,162,696,145,185,561,18,696,43,4,560,696,33,529,651,24,529,162,697,696,554,173,680,173,168,184,512]

theorem envBound33691 : H12AffineFastState.Bounded env33691 := by
  intro p hp
  have h : env33691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33690_33691 : H12AffineEnvironment.transform 10 162 env33690 = env33691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env33690 == env33691) = true)

theorem identity33691 : scanCanonicalize (H12AffineFastState.compose env33691 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound33691 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env33692 : List Nat := [2,4,8,11,32,10,128,173,512,5,162,675,138,162,554,9,675,43,4,555,675,33,522,651,3,522,162,674,675,554,173,680,173,168,163,512]

theorem envBound33692 : H12AffineFastState.Bounded env33692 := by
  intro p hp
  have h : env33692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33691_33692 : H12AffineEnvironment.transform 3 11 env33691 = env33692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env33691 == env33692) = true)

theorem identity33692 : scanCanonicalize (H12AffineFastState.compose env33692 (packedSelected [1,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound33692 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env33693 : List Nat := [2,4,8,11,32,10,128,173,136,5,162,43,138,162,162,9,43,43,4,163,43,33,130,3,3,130,162,42,43,162,173,32,173,168,163,136]

theorem envBound33693 : H12AffineFastState.Bounded env33693 := by
  intro p hp
  have h : env33693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33692_33693 : H12AffineEnvironment.transform 8 136 env33692 = env33693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env33692 == env33693) = true)

theorem identity33693 : scanCanonicalize (H12AffineFastState.compose env33693 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33693 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env33694 : List Nat := [2,4,8,11,32,10,8,37,0,5,42,43,2,42,42,9,43,43,4,43,43,33,10,3,3,10,42,42,43,42,37,32,37,32,43,0]

theorem envBound33694 : H12AffineFastState.Bounded env33694 := by
  intro p hp
  have h : env33694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33693_33694 : H12AffineEnvironment.transform 6 8 env33693 = env33694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33693 == env33694) = true)

theorem identity33694 : scanCanonicalize (H12AffineFastState.compose env33694 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound33694 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33695 : List Nat := [2,3,8,11,32,10,8,34,0,2,42,43,2,42,42,9,43,43,3,43,43,33,10,3,3,10,42,42,43,42,34,32,34,32,43,0]

theorem envBound33695 : H12AffineFastState.Bounded env33695 := by
  intro p hp
  have h : env33695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33694_33695 : H12AffineEnvironment.transform 1 3 env33694 = env33695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env33694 == env33695) = true)

def env33696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533640,672785,17245633,148801,545089,96347,16876544,16949354,256,676880,1344,525825]

theorem envBound33696 : H12AffineFastState.Bounded env33696 := by
  intro p hp
  have h : env33696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33575_33696 : H12AffineEnvironment.transform 26 17245633 env33575 = env33696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env33575 == env33696) = true)

theorem identity33696 : scanCanonicalize (H12AffineFastState.compose env33696 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41002) := by decide +kernel

theorem selectedBound33696 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env33697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,41002,533640,672785,493035,148801,545089,96347,74794,131136,256,676880,1344,525825]

theorem envBound33697 : H12AffineFastState.Bounded env33697 := by
  intro p hp
  have h : env33697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33696_33697 : H12AffineEnvironment.transform 23 41002 env33696 = env33697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41002 env33696 == env33697) = true)

def env33698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,41002,143496,20497,493035,148801,148801,96347,74794,131136,256,16400,1344,135681]

theorem envBound33698 : H12AffineFastState.Bounded env33698 := by
  intro p hp
  have h : env33698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33697_33698 : H12AffineEnvironment.transform 18 136192 env33697 = env33698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env33697 == env33698) = true)

def env33699 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,41002,143496,20497,492615,148717,148717,96347,74794,131136,172,16400,1260,135681]

theorem envBound33699 : H12AffineFastState.Bounded env33699 := by
  intro p hp
  have h : env33699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33698_33699 : H12AffineEnvironment.transform 7 172 env33698 = env33699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env33698 == env33699) = true)

def env33700 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,41002,143496,20497,492567,148669,148669,96267,74794,131088,172,16400,1212,135681]

theorem envBound33700 : H12AffineFastState.Bounded env33700 := by
  intro p hp
  have h : env33700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33699_33700 : H12AffineEnvironment.transform 5 16 env33699 = env33700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33699 == env33700) = true)

theorem identity33700 : scanCanonicalize (H12AffineFastState.compose env33700 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound33700 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env33701 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4096,61569,61617,41002,32808,20497,341175,62493,62493,96267,74794,45232,172,16400,1212,41633]

theorem envBound33701 : H12AffineFastState.Bounded env33701 := by
  intro p hp
  have h : env33701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33700_33701 : H12AffineEnvironment.transform 16 45216 env33700 = env33701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env33700 == env33701) = true)

theorem identity33701 : scanCanonicalize (H12AffineFastState.compose env33701 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound33701 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env33702 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,32768,65536,45216,262144,42144,32769,4096,46140,46092,41002,32808,5292,341175,45216,45216,81078,74794,45232,172,1197,1212,41633]

theorem envBound33702 : H12AffineFastState.Bounded env33702 := by
  intro p hp
  have h : env33702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33701_33702 : H12AffineEnvironment.transform 13 1213 env33701 = env33702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env33701 == env33702) = true)

theorem identity33702 : scanCanonicalize (H12AffineFastState.compose env33702 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 12347) := by decide +kernel

theorem selectedBound33702 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33703 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,32768,12347,45216,262144,42144,32769,4096,46140,46092,41002,32808,5292,263308,45216,45216,3213,5137,45232,172,1197,1212,41633]

theorem envBound33703 : H12AffineFastState.Bounded env33703 := by
  intro p hp
  have h : env33703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33702_33703 : H12AffineEnvironment.transform 15 12347 env33702 = env33703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12347 env33702 == env33703) = true)

theorem identity33703 : scanCanonicalize (H12AffineFastState.compose env33703 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound33703 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env33704 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,9380,12347,5124,262144,4,9381,4096,4248,4264,1166,9356,5292,263308,5124,5124,3213,5137,5140,172,1197,1212,1541]

theorem envBound33704 : H12AffineFastState.Bounded env33704 := by
  intro p hp
  have h : env33704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33703_33704 : H12AffineEnvironment.transform 14 9380 env33703 = env33704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env33703 == env33704) = true)

theorem identity33704 : scanCanonicalize (H12AffineFastState.compose env33704 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound33704 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env33705 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,9380,12347,5124,2184,4,9381,4096,4248,4264,1166,9356,5292,3076,5124,5124,3213,5137,5140,172,1197,1212,1541]

theorem envBound33705 : H12AffineFastState.Bounded env33705 := by
  intro p hp
  have h : env33705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33704_33705 : H12AffineEnvironment.transform 17 2184 env33704 = env33705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env33704 == env33705) = true)

theorem identity33705 : scanCanonicalize (H12AffineFastState.compose env33705 (packedSelected [1,2,3,4,5,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound33705 : packedSelected [1,2,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env33706 : List Nat := [2,4,8,16,32,16,128,172,1,1024,2048,4096,8192,1213,9380,12347,5124,2184,4,9381,4096,4248,4264,1166,9356,5292,3076,5124,5124,3213,5137,5140,172,1197,1212,1028]

theorem envBound33706 : H12AffineFastState.Bounded env33706 := by
  intro p hp
  have h : env33706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33705_33706 : H12AffineEnvironment.transform 8 1 env33705 = env33706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env33705 == env33706) = true)

theorem identity33706 : scanCanonicalize (H12AffineFastState.compose env33706 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2184) := by decide +kernel

theorem selectedBound33706 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env33707 : List Nat := [2,4,8,16,32,16,128,172,1,1024,2048,2184,8192,1213,9380,10419,3212,2184,4,9381,2184,2064,2080,1166,9356,3108,3076,3212,3212,3213,3225,3228,172,1197,1212,1028]

theorem envBound33707 : H12AffineFastState.Bounded env33707 := by
  intro p hp
  have h : env33707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33706_33707 : H12AffineEnvironment.transform 11 2184 env33706 = env33707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2184 env33706 == env33707) = true)

theorem identity33707 : scanCanonicalize (H12AffineFastState.compose env33707 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound33707 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33708 : List Nat := [2,4,8,16,32,16,128,172,1,1024,2048,2184,2088,1213,3212,155,3212,2184,4,3213,2184,2064,2080,1166,3236,3108,3076,3212,3212,3213,3225,3228,172,1197,1212,1028]

theorem envBound33708 : H12AffineFastState.Bounded env33708 := by
  intro p hp
  have h : env33708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33707_33708 : H12AffineEnvironment.transform 12 2088 env33707 = env33708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env33707 == env33708) = true)

theorem identity33708 : scanCanonicalize (H12AffineFastState.compose env33708 (packedSelected [3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound33708 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env33709 : List Nat := [2,4,8,16,32,16,128,172,1,1024,1212,1076,1172,1213,48,155,48,1076,4,49,1076,1196,1180,1166,24,152,184,48,48,49,37,32,172,1197,1212,1028]

theorem envBound33709 : H12AffineFastState.Bounded env33709 := by
  intro p hp
  have h : env33709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33708_33709 : H12AffineEnvironment.transform 10 1212 env33708 = env33709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env33708 == env33709) = true)

theorem identity33709 : scanCanonicalize (H12AffineFastState.compose env33709 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound33709 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env33710 : List Nat := [2,4,8,16,32,16,128,172,1,31,163,43,139,162,48,155,48,43,4,49,43,179,131,145,24,152,184,48,48,49,37,32,172,178,163,27]

theorem envBound33710 : H12AffineFastState.Bounded env33710 := by
  intro p hp
  have h : env33710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33709_33710 : H12AffineEnvironment.transform 9 31 env33709 = env33710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env33709 == env33710) = true)

theorem identity33710 : scanCanonicalize (H12AffineFastState.compose env33710 (packedSelected [0,4,10] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound33710 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env33711 : List Nat := [2,4,8,16,32,16,19,63,1,31,48,43,24,49,48,8,48,43,4,49,43,32,16,2,24,11,43,48,48,49,37,32,63,33,48,27]

theorem envBound33711 : H12AffineFastState.Bounded env33711 := by
  intro p hp
  have h : env33711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33710_33711 : H12AffineEnvironment.transform 6 19 env33710 = env33711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env33710 == env33711) = true)

theorem identity33711 : scanCanonicalize (H12AffineFastState.compose env33711 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound33711 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33712 : List Nat := [2,4,8,7,32,7,4,40,1,8,39,43,15,38,39,8,39,43,4,38,43,32,7,2,15,11,43,39,39,38,37,32,40,33,39,12]

theorem envBound33712 : H12AffineFastState.Bounded env33712 := by
  intro p hp
  have h : env33712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33711_33712 : H12AffineEnvironment.transform 3 7 env33711 = env33712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env33711 == env33712) = true)

theorem identity33712 : scanCanonicalize (H12AffineFastState.compose env33712 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound33712 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env33713 : List Nat := [2,4,4,7,32,7,4,36,1,4,39,39,3,38,39,4,39,39,4,38,39,32,7,2,3,7,39,39,39,38,37,32,36,33,39,0]

theorem envBound33713 : H12AffineFastState.Bounded env33713 := by
  intro p hp
  have h : env33713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33712_33713 : H12AffineEnvironment.transform 2 4 env33712 = env33713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env33712 == env33713) = true)

theorem identity33713 : scanCanonicalize (H12AffineFastState.compose env33713 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound33713 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33714 : List Nat := [2,0,0,3,32,3,0,32,1,0,35,35,3,34,35,0,35,35,0,34,35,32,3,2,3,3,35,35,35,34,33,32,32,33,35,0]

theorem envBound33714 : H12AffineFastState.Bounded env33714 := by
  intro p hp
  have h : env33714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33713_33714 : H12AffineEnvironment.transform 1 0 env33713 = env33714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env33713 == env33714) = true)

theorem identity33714 : scanCanonicalize (H12AffineFastState.compose env33714 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound33714 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33715 : List Nat := [2,0,0,3,3,3,0,3,1,0,0,0,3,1,0,0,0,0,0,1,0,3,3,2,3,3,0,0,0,1,2,3,3,2,0,0]

theorem envBound33715 : H12AffineFastState.Bounded env33715 := by
  intro p hp
  have h : env33715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33714_33715 : H12AffineEnvironment.transform 4 3 env33714 = env33715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env33714 == env33715) = true)

theorem identity33715 : scanCanonicalize (H12AffineFastState.compose env33715 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound33715 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33716 : List Nat := [0,0,0,1,1,1,0,1,1,0,0,0,1,1,0,0,0,0,0,1,0,1,1,0,1,1,0,0,0,1,0,1,1,0,0,0]

theorem envBound33716 : H12AffineFastState.Bounded env33716 := by
  intro p hp
  have h : env33716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33715_33716 : H12AffineEnvironment.transform 0 0 env33715 = env33716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env33715 == env33716) = true)

def env33717 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,41002,143496,20497,492566,148668,148668,96266,74794,131089,172,16400,1213,135681]

theorem envBound33717 : H12AffineFastState.Bounded env33717 := by
  intro p hp
  have h : env33717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33699_33717 : H12AffineEnvironment.transform 5 17 env33699 = env33717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33699 == env33717) = true)

theorem identity33717 : scanCanonicalize (H12AffineFastState.compose env33717 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound33717 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env33718 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4096,61568,147472,41002,143496,20497,105630,148668,148668,96266,74794,131089,172,16400,1213,135681]

theorem envBound33718 : H12AffineFastState.Bounded env33718 := by
  intro p hp
  have h : env33718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33717_33718 : H12AffineEnvironment.transform 17 137352 env33717 = env33718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env33717 == env33718) = true)

theorem identity33718 : scanCanonicalize (H12AffineFastState.compose env33718 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound33718 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env33719 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,13374,131072,137352,136192,32769,4096,61568,147472,41002,143496,20497,43168,148668,148668,19508,4116,131089,172,16400,1213,135681]

theorem envBound33719 : H12AffineFastState.Bounded env33719 := by
  intro p hp
  have h : env33719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33718_33719 : H12AffineEnvironment.transform 15 13374 env33718 = env33719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env33718 == env33719) = true)

theorem identity33719 : scanCanonicalize (H12AffineFastState.compose env33719 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound33719 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env33720 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,13374,131072,137352,136192,32769,4096,46141,132269,41002,143496,5292,43168,131073,131073,2185,4116,131089,172,1197,1213,135681]

theorem envBound33720 : H12AffineFastState.Bounded env33720 := by
  intro p hp
  have h : env33720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33719_33720 : H12AffineEnvironment.transform 13 1213 env33719 = env33720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env33719 == env33720) = true)

theorem identity33720 : scanCanonicalize (H12AffineFastState.compose env33720 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 40985) := by decide +kernel

theorem selectedBound33720 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env33721 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,13374,40985,47249,46105,32769,4096,46141,42164,41002,37009,5292,43168,40984,40984,2185,4116,40968,172,1197,1213,45592]

theorem envBound33721 : H12AffineFastState.Bounded env33721 := by
  intro p hp
  have h : env33721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33720_33721 : H12AffineEnvironment.transform 16 40985 env33720 = env33721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 40985 env33720 == env33721) = true)

theorem identity33721 : scanCanonicalize (H12AffineFastState.compose env33721 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(14+1) ^^^ 11270) := by decide +kernel

theorem selectedBound33721 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env33722 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,11270,13374,3103,5271,6175,11271,4096,6203,2226,3116,15511,5292,1190,3102,3102,2185,4116,3086,172,1197,1213,7710]

theorem envBound33722 : H12AffineFastState.Bounded env33722 := by
  intro p hp
  have h : env33722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33721_33722 : H12AffineEnvironment.transform 14 11270 env33721 = env33722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11270 env33721 == env33722) = true)

theorem identity33722 : scanCanonicalize (H12AffineFastState.compose env33722 (packedSelected [1,4,5,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 5284) := by decide +kernel

theorem selectedBound33722 : packedSelected [1,4,5,9,16] rootPS < 2^1333 := by decide +kernel

def env33723 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,5284,1213,6306,154,3103,5271,6175,6307,4096,6203,2226,3116,2099,5292,1190,3102,3102,2185,4116,3086,172,1197,1213,7710]

theorem envBound33723 : H12AffineFastState.Bounded env33723 := by
  intro p hp
  have h : env33723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33722_33723 : H12AffineEnvironment.transform 12 5284 env33722 = env33723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5284 env33722 == env33723) = true)

theorem identity33723 : scanCanonicalize (H12AffineFastState.compose env33723 (packedSelected [0,2,3,4,5,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound33723 : packedSelected [0,2,3,4,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env33724 : List Nat := [2,4,8,16,32,17,128,172,512,1024,43,4096,5284,1213,4233,154,1076,5271,4148,4232,4096,4112,153,1031,24,5292,1190,1077,1077,162,4116,1061,172,1197,1213,5685]

theorem envBound33724 : H12AffineFastState.Bounded env33724 := by
  intro p hp
  have h : env33724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33723_33724 : H12AffineEnvironment.transform 10 43 env33723 = env33724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env33723 == env33724) = true)

theorem identity33724 : scanCanonicalize (H12AffineFastState.compose env33724 (packedSelected [0,3,4,6,7,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1191) := by decide +kernel

theorem selectedBound33724 : packedSelected [0,3,4,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env33725 : List Nat := [2,4,8,16,32,17,128,172,512,1024,43,1191,3,1213,1070,154,1076,48,1171,1071,1191,1207,153,1031,24,11,1190,1077,1077,162,1203,1061,172,1197,1213,658]

theorem envBound33725 : H12AffineFastState.Bounded env33725 := by
  intro p hp
  have h : env33725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33724_33725 : H12AffineEnvironment.transform 11 1191 env33724 = env33725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1191 env33724 == env33725) = true)

theorem identity33725 : scanCanonicalize (H12AffineFastState.compose env33725 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound33725 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env33726 : List Nat := [2,4,8,16,32,17,128,172,512,542,43,697,3,675,560,154,554,48,653,561,697,681,153,537,24,11,696,555,555,162,685,571,172,691,675,658]

theorem envBound33726 : H12AffineFastState.Bounded env33726 := by
  intro p hp
  have h : env33726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33725_33726 : H12AffineEnvironment.transform 9 542 env33725 = env33726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env33725 == env33726) = true)

theorem identity33726 : scanCanonicalize (H12AffineFastState.compose env33726 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound33726 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env33727 : List Nat := [2,4,8,16,32,17,128,172,0,30,43,185,3,163,48,154,42,48,141,49,185,169,153,25,24,11,184,43,43,162,173,59,172,179,163,146]

theorem envBound33727 : H12AffineFastState.Bounded env33727 := by
  intro p hp
  have h : env33727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33726_33727 : H12AffineEnvironment.transform 8 0 env33726 = env33727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env33726 == env33727) = true)

theorem identity33727 : scanCanonicalize (H12AffineFastState.compose env33727 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound33727 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env33728 : List Nat := [2,4,8,10,32,11,128,172,0,4,43,163,3,163,42,128,42,42,141,43,163,169,131,3,2,11,162,43,43,162,173,33,172,169,163,136]

theorem envBound33728 : H12AffineFastState.Bounded env33728 := by
  intro p hp
  have h : env33728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33727_33728 : H12AffineEnvironment.transform 3 10 env33727 = env33728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env33727 == env33728) = true)

def env33729 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,41002,143496,20497,492614,148716,148716,96347,74794,131136,173,16400,1261,135681]

theorem envBound33729 : H12AffineFastState.Bounded env33729 := by
  intro p hp
  have h : env33729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33698_33729 : H12AffineEnvironment.transform 7 173 env33698 = env33729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env33698 == env33729) = true)

def env33730 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,41002,143496,20497,492566,148668,148668,96267,74794,131088,173,16400,1213,135681]

theorem envBound33730 : H12AffineFastState.Bounded env33730 := by
  intro p hp
  have h : env33730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33729_33730 : H12AffineEnvironment.transform 5 16 env33729 = env33730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33729 == env33730) = true)

theorem identity33730 : scanCanonicalize (H12AffineFastState.compose env33730 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound33730 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env33731 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119843,32769,4096,61569,98354,41002,127147,20497,279605,99487,99487,96267,74794,114739,173,16400,1213,119330]

theorem envBound33731 : H12AffineFastState.Bounded env33731 := by
  intro p hp
  have h : env33731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33730_33731 : H12AffineEnvironment.transform 16 114723 env33730 = env33731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env33730 == env33731) = true)

theorem identity33731 : scanCanonicalize (H12AffineFastState.compose env33731 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 59537) := by decide +kernel

theorem selectedBound33731 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env33732 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,59537,119843,32769,4096,61569,98354,41002,127147,20497,44196,99487,99487,96267,74794,114739,173,16400,1213,119330]

theorem envBound33732 : H12AffineFastState.Bounded env33732 := by
  intro p hp
  have h : env33732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33731_33732 : H12AffineEnvironment.transform 17 59537 env33731 = env33732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 59537 env33731 == env33732) = true)

theorem identity33732 : scanCanonicalize (H12AffineFastState.compose env33732 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound33732 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env33733 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53282,4097,59537,1025,32769,4096,61569,20496,41002,8329,20497,44196,21693,21693,43049,62472,4113,173,16400,1213,512]

theorem envBound33733 : H12AffineFastState.Bounded env33733 := by
  intro p hp
  have h : env33733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33732_33733 : H12AffineEnvironment.transform 15 53282 env33732 = env33733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env33732 == env33733) = true)

theorem identity33733 : scanCanonicalize (H12AffineFastState.compose env33733 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound33733 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33734 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,8192,16384,32768,53282,4097,59537,4,32769,4096,61569,20496,41002,8329,20497,43169,20664,20664,43049,61453,4113,173,16400,184,512]

theorem envBound33734 : H12AffineFastState.Bounded env33734 := by
  intro p hp
  have h : env33734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33733_33734 : H12AffineEnvironment.transform 9 5 env33733 = env33734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env33733 == env33734) = true)

theorem identity33734 : scanCanonicalize (H12AffineFastState.compose env33734 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 17032) := by decide +kernel

theorem selectedBound33734 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33735 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,8192,16384,17032,4778,4097,10777,4,17033,4096,12809,20496,25250,8329,20497,27177,20664,20664,27297,12933,4113,173,16400,184,512]

theorem envBound33735 : H12AffineFastState.Bounded env33735 := by
  intro p hp
  have h : env33735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33734_33735 : H12AffineEnvironment.transform 14 17032 env33734 = env33735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17032 env33734 == env33735) = true)

theorem identity33735 : scanCanonicalize (H12AffineFastState.compose env33735 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound33735 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env33736 : List Nat := [2,4,8,16,32,16,128,173,26,5,2048,4096,8192,16384,16530,4272,4097,10243,4,16531,4096,12307,20496,24760,8329,20497,26675,20664,20664,26811,12447,4113,173,16400,184,26]

theorem envBound33736 : H12AffineFastState.Bounded env33736 := by
  intro p hp
  have h : env33736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33735_33736 : H12AffineEnvironment.transform 8 26 env33735 = env33736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env33735 == env33736) = true)

theorem identity33736 : scanCanonicalize (H12AffineFastState.compose env33736 (packedSelected [1,2,4,5,7,11,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 14386) := by decide +kernel

theorem selectedBound33736 : packedSelected [1,2,4,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env33737 : List Nat := [2,4,8,16,32,16,128,173,26,5,2048,4096,8192,14386,14496,4272,4097,10243,4,14497,4096,12307,10274,6282,8329,10275,4097,10378,10378,4233,12447,4113,173,14370,184,26]

theorem envBound33737 : H12AffineFastState.Bounded env33737 := by
  intro p hp
  have h : env33737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33736_33737 : H12AffineEnvironment.transform 13 14386 env33736 = env33737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14386 env33736 == env33737) = true)

theorem identity33737 : scanCanonicalize (H12AffineFastState.compose env33737 (packedSelected [1,2,4,5,6,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 4146) := by decide +kernel

theorem selectedBound33737 : packedSelected [1,2,4,5,6,9,12] rootPS < 2^1333 := by decide +kernel

def env33738 : List Nat := [2,4,8,16,32,16,128,173,26,5,2048,4096,4146,2048,2194,4272,4097,6193,4,2195,4096,33,6160,6282,4283,6161,4097,6328,6328,4233,173,4113,173,2064,184,26]

theorem envBound33738 : H12AffineFastState.Bounded env33738 := by
  intro p hp
  have h : env33738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33737_33738 : H12AffineEnvironment.transform 12 4146 env33737 = env33738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4146 env33737 == env33738) = true)

theorem identity33738 : scanCanonicalize (H12AffineFastState.compose env33738 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound33738 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env33739 : List Nat := [2,4,8,16,32,16,128,173,26,5,2048,184,138,2048,2194,8,185,2185,4,2195,184,33,2216,2098,3,2217,185,2048,2048,49,173,169,173,2064,184,26]

theorem envBound33739 : H12AffineFastState.Bounded env33739 := by
  intro p hp
  have h : env33739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33738_33739 : H12AffineEnvironment.transform 11 184 env33738 = env33739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env33738 == env33739) = true)

theorem identity33739 : scanCanonicalize (H12AffineFastState.compose env33739 (packedSelected [0,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound33739 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env33740 : List Nat := [2,4,8,16,32,16,63,18,26,5,2048,7,53,2048,2093,8,6,2102,4,2092,7,33,2071,2098,3,2070,6,2048,2048,49,18,22,18,2064,7,26]

theorem envBound33740 : H12AffineFastState.Bounded env33740 := by
  intro p hp
  have h : env33740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33739_33740 : H12AffineEnvironment.transform 6 63 env33739 = env33740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env33739 == env33740) = true)

theorem identity33740 : scanCanonicalize (H12AffineFastState.compose env33740 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound33740 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env33741 : List Nat := [2,4,8,16,22,16,9,18,26,5,2048,7,3,2048,2075,8,6,2048,4,2074,7,23,2071,2052,3,2070,6,2048,2048,7,18,22,18,2064,7,26]

theorem envBound33741 : H12AffineFastState.Bounded env33741 := by
  intro p hp
  have h : env33741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33740_33741 : H12AffineEnvironment.transform 4 22 env33740 = env33741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env33740 == env33741) = true)

theorem identity33741 : scanCanonicalize (H12AffineFastState.compose env33741 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 29) := by decide +kernel

theorem selectedBound33741 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env33742 : List Nat := [2,4,8,16,22,16,9,18,26,5,29,7,3,29,6,8,6,29,4,7,7,23,10,25,3,11,6,29,29,7,18,22,18,13,7,26]

theorem envBound33742 : H12AffineFastState.Bounded env33742 := by
  intro p hp
  have h : env33742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33741_33742 : H12AffineEnvironment.transform 10 29 env33741 = env33742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 29 env33741 == env33742) = true)

theorem identity33742 : scanCanonicalize (H12AffineFastState.compose env33742 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound33742 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33743 : List Nat := [2,4,8,11,13,11,9,9,1,5,6,7,3,6,6,8,6,6,4,7,7,12,10,2,3,11,6,6,6,7,9,13,9,13,7,1]

theorem envBound33743 : H12AffineFastState.Bounded env33743 := by
  intro p hp
  have h : env33743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33742_33743 : H12AffineEnvironment.transform 3 11 env33742 = env33743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env33742 == env33743) = true)

def env33744 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,41002,143496,20497,492567,148669,148669,96266,74794,131089,173,16400,1212,135681]

theorem envBound33744 : H12AffineFastState.Bounded env33744 := by
  intro p hp
  have h : env33744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33729_33744 : H12AffineEnvironment.transform 5 17 env33729 = env33744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33729 == env33744) = true)

theorem identity33744 : scanCanonicalize (H12AffineFastState.compose env33744 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound33744 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env33745 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136192,32769,4096,61568,147472,41002,143496,20497,60445,148669,148669,96266,74794,131089,173,16400,1212,135681]

theorem envBound33745 : H12AffineFastState.Bounded env33745 := by
  intro p hp
  have h : env33745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33744_33745 : H12AffineEnvironment.transform 17 223242 env33744 = env33745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env33744 == env33745) = true)

theorem identity33745 : scanCanonicalize (H12AffineFastState.compose env33745 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound33745 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env33746 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,28803,131072,137353,136192,32769,4096,61568,147472,41002,143496,20497,60445,148669,148669,2185,21673,131089,173,16400,1212,135681]

theorem envBound33746 : H12AffineFastState.Bounded env33746 := by
  intro p hp
  have h : env33746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33745_33746 : H12AffineEnvironment.transform 15 28803 env33745 = env33746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env33745 == env33746) = true)

theorem identity33746 : scanCanonicalize (H12AffineFastState.compose env33746 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 61464) := by decide +kernel

theorem selectedBound33746 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env33747 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,28803,61464,59537,58392,32769,4096,61568,45064,41002,49296,20497,60445,46245,46245,2185,21673,61449,173,16400,1212,57881]

theorem envBound33747 : H12AffineFastState.Bounded env33747 := by
  intro p hp
  have h : env33747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33746_33747 : H12AffineEnvironment.transform 16 61464 env33746 = env33747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 61464 env33746 == env33747) = true)

theorem identity33747 : scanCanonicalize (H12AffineFastState.compose env33747 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound33747 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env33748 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,13375,46244,44077,41124,32769,4096,46140,45064,41002,33836,5293,43169,46245,46245,2185,4117,46261,173,1196,1212,42661]

theorem envBound33748 : H12AffineFastState.Bounded env33748 := by
  intro p hp
  have h : env33748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33747_33748 : H12AffineEnvironment.transform 13 1212 env33747 = env33748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env33747 == env33748) = true)

theorem identity33748 : scanCanonicalize (H12AffineFastState.compose env33748 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 7214) := by decide +kernel

theorem selectedBound33748 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env33749 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,7214,13375,10378,12291,15498,7215,4096,10258,11302,15364,6146,5293,13455,10379,10379,2185,4117,10395,173,1196,1212,14987]

theorem envBound33749 : H12AffineFastState.Bounded env33749 := by
  intro p hp
  have h : env33749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33748_33749 : H12AffineEnvironment.transform 14 7214 env33748 = env33749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7214 env33748 == env33749) = true)

theorem identity33749 : scanCanonicalize (H12AffineFastState.compose env33749 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound33749 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env33750 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,8192,1212,3222,9351,10378,8379,11314,3223,184,10258,11302,11452,2234,1045,9271,10379,10379,2185,173,10395,173,1196,1212,10803]

theorem envBound33750 : H12AffineFastState.Bounded env33750 := by
  intro p hp
  have h : env33750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33749_33750 : H12AffineEnvironment.transform 11 184 env33749 = env33750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env33749 == env33750) = true)

theorem identity33750 : scanCanonicalize (H12AffineFastState.compose env33750 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound33750 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env33751 : List Nat := [2,4,8,16,32,17,128,173,512,516,2048,184,8192,696,2706,8835,10378,8379,10806,2707,184,10258,10786,10936,2234,529,8755,10379,10379,2185,173,10395,173,680,696,10803]

theorem envBound33751 : H12AffineFastState.Bounded env33751 := by
  intro p hp
  have h : env33751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33750_33751 : H12AffineEnvironment.transform 9 516 env33750 = env33751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env33750 == env33751) = true)

theorem identity33751 : scanCanonicalize (H12AffineFastState.compose env33751 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound33751 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env33752 : List Nat := [2,4,8,16,32,17,128,173,512,516,163,184,8192,696,561,8835,8233,8379,8853,560,184,8369,8833,8731,25,529,8755,8232,8232,42,173,8248,173,680,696,8848]

theorem envBound33752 : H12AffineFastState.Bounded env33752 := by
  intro p hp
  have h : env33752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33751_33752 : H12AffineEnvironment.transform 10 163 env33751 = env33752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env33751 == env33752) = true)

theorem identity33752 : scanCanonicalize (H12AffineFastState.compose env33752 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound33752 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env33753 : List Nat := [2,4,8,16,32,17,19,62,512,516,48,43,8192,555,561,8720,8233,8232,8710,560,43,8226,8722,8731,25,529,8755,8232,8232,42,62,8248,62,571,555,8707]

theorem envBound33753 : H12AffineFastState.Bounded env33753 := by
  intro p hp
  have h : env33753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33752_33753 : H12AffineEnvironment.transform 6 19 env33752 = env33753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env33752 == env33753) = true)

theorem identity33753 : scanCanonicalize (H12AffineFastState.compose env33753 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(12+1) ^^^ 536) := by decide +kernel

theorem selectedBound33753 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2