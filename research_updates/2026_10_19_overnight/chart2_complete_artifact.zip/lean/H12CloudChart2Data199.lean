import H12CloudChart2Data198

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound50043 : H12AffineFastState.Bounded env50043 := by
  intro p hp
  have h : env50043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50042_50043 : H12AffineEnvironment.transform 9 517 env50042 = env50043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env50042 == env50043) = true)

def env50044 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,58518,143497,20497,508075,148668,148669,96267,90262,90258,172,222255,1212,135680]

theorem envBound50044 : H12AffineFastState.Bounded env50044 := by
  intro p hp
  have h : env50044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50032_50044 : H12AffineEnvironment.transform 5 17 env50032 = env50044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50032 == env50044) = true)

theorem identity50044 : scanCanonicalize (H12AffineFastState.compose env50044 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound50044 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env50045 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136192,32769,4097,61569,147473,58518,143497,20497,60444,148668,148669,96267,90262,90258,172,222255,1212,135680]

theorem envBound50045 : H12AffineFastState.Bounded env50045 := by
  intro p hp
  have h : env50045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50044_50045 : H12AffineEnvironment.transform 17 208055 env50044 = env50045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env50044 == env50045) = true)

theorem identity50045 : scanCanonicalize (H12AffineFastState.compose env50045 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound50045 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env50046 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53283,131072,195732,136192,32769,4097,61569,147473,58518,143497,20497,60444,148668,148669,43048,45237,45233,172,177164,1212,135680]

theorem envBound50046 : H12AffineFastState.Bounded env50046 := by
  intro p hp
  have h : env50046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50045_50046 : H12AffineEnvironment.transform 15 53283 env50045 = env50046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env50045 == env50046) = true)

theorem identity50046 : scanCanonicalize (H12AffineFastState.compose env50046 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound50046 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env50047 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53283,21692,43048,16572,32769,4097,61569,5293,58518,25653,20497,60444,4096,4097,43048,45237,45233,172,57520,1212,18108]

theorem envBound50047 : H12AffineFastState.Bounded env50047 := by
  intro p hp
  have h : env50047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50046_50047 : H12AffineEnvironment.transform 16 21692 env50046 = env50047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env50046 == env50047) = true)

theorem identity50047 : scanCanonicalize (H12AffineFastState.compose env50047 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound50047 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env50048 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,9380,29831,21692,3212,16572,9381,4097,21541,5293,16434,25653,20497,18616,4096,4097,3212,5137,5141,172,17428,1212,18108]

theorem envBound50048 : H12AffineFastState.Bounded env50048 := by
  intro p hp
  have h : env50048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50047_50048 : H12AffineEnvironment.transform 14 9380 env50047 = env50048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env50047 == env50048) = true)

theorem identity50048 : scanCanonicalize (H12AffineFastState.compose env50048 (packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 9756) := by decide +kernel

theorem selectedBound50048 : packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env50049 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,9756,9380,4763,12960,3212,9888,9381,4097,12857,5293,9774,553,13837,11940,4096,4097,3212,5137,5141,172,8712,1212,8352]

theorem envBound50049 : H12AffineFastState.Bounded env50049 := by
  intro p hp
  have h : env50049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50048_50049 : H12AffineEnvironment.transform 13 9756 env50048 = env50049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9756 env50048 == env50049) = true)

theorem identity50049 : scanCanonicalize (H12AffineFastState.compose env50049 (packedSelected [1,3,6,7,9,11,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 6794) := by decide +kernel

theorem selectedBound50049 : packedSelected [1,3,6,7,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env50050 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,6794,7318,7726,4763,2090,3212,7210,7727,4097,2227,5293,7332,553,3207,5166,4096,4097,3212,5137,5141,172,6274,1212,6698]

theorem envBound50050 : H12AffineFastState.Bounded env50050 := by
  intro p hp
  have h : env50050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50049_50050 : H12AffineEnvironment.transform 12 6794 env50049 = env50050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6794 env50049 == env50050) = true)

theorem identity50050 : scanCanonicalize (H12AffineFastState.compose env50050 (packedSelected [0,1,2,4,5,6,11,13,16] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound50050 : packedSelected [0,1,2,4,5,6,11,13,16] rootPS < 2^1333 := by decide +kernel

def env50051 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,136,2562,3102,3750,531,2090,3212,3234,3751,137,2227,1061,3116,553,3207,1190,136,137,3212,1177,1181,172,2058,1212,2722]

theorem envBound50051 : H12AffineFastState.Bounded env50051 := by
  intro p hp
  have h : env50051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50050_50051 : H12AffineEnvironment.transform 11 136 env50050 = env50051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env50050 == env50051) = true)

theorem identity50051 : scanCanonicalize (H12AffineFastState.compose env50051 (packedSelected [2,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound50051 : packedSelected [2,6,7,9] rootPS < 2^1333 := by decide +kernel

def env50052 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,136,2562,2074,2722,531,2090,2184,2214,2723,137,2227,33,2088,553,2179,162,136,137,2184,157,153,172,2058,184,2722]

theorem envBound50052 : H12AffineFastState.Bounded env50052 := by
  intro p hp
  have h : env50052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50051_50052 : H12AffineEnvironment.transform 9 4 env50051 = env50052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env50051 == env50052) = true)

theorem identity50052 : scanCanonicalize (H12AffineFastState.compose env50052 (packedSelected [2,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound50052 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env50053 : List Nat := [2,4,8,16,32,17,128,173,146,4,2048,136,2192,2074,2096,129,2090,2184,2214,2097,137,2227,33,2088,187,2179,162,136,137,2184,157,153,172,2058,184,2096]

theorem envBound50053 : H12AffineFastState.Bounded env50053 := by
  intro p hp
  have h : env50053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50052_50053 : H12AffineEnvironment.transform 8 146 env50052 = env50053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env50052 == env50053) = true)

theorem identity50053 : scanCanonicalize (H12AffineFastState.compose env50053 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 133) := by decide +kernel

theorem selectedBound50053 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env50054 : List Nat := [2,4,8,16,32,17,128,173,146,4,133,136,21,159,181,129,175,13,35,180,137,54,33,173,187,6,162,136,137,13,157,153,172,143,184,181]

theorem envBound50054 : H12AffineFastState.Bounded env50054 := by
  intro p hp
  have h : env50054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50053_50054 : H12AffineEnvironment.transform 10 133 env50053 = env50054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 133 env50053 == env50054) = true)

theorem identity50054 : scanCanonicalize (H12AffineFastState.compose env50054 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 53) := by decide +kernel

theorem selectedBound50054 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50055 : List Nat := [2,4,8,16,32,17,53,24,39,4,48,61,21,42,0,52,26,13,35,1,60,54,33,24,14,6,23,61,60,13,40,44,25,58,13,0]

theorem envBound50055 : H12AffineFastState.Bounded env50055 := by
  intro p hp
  have h : env50055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50054_50055 : H12AffineEnvironment.transform 6 53 env50054 = env50055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 53 env50054 == env50055) = true)

def env50056 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,58682,143496,20496,508155,148800,148800,96346,90426,90430,257,222335,1344,135681]

theorem envBound50056 : H12AffineFastState.Bounded env50056 := by
  intro p hp
  have h : env50056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49998_50056 : H12AffineEnvironment.transform 18 136193 env49998 = env50056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env49998 == env50056) = true)

def env50057 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,58518,143496,20496,508155,148716,148716,96346,90262,90258,173,222335,1260,135681]

theorem envBound50057 : H12AffineFastState.Bounded env50057 := by
  intro p hp
  have h : env50057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50056_50057 : H12AffineEnvironment.transform 7 172 env50056 = env50057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env50056 == env50057) = true)

def env50058 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,58518,143496,20496,508075,148668,148668,96266,90262,90258,173,222255,1212,135681]

theorem envBound50058 : H12AffineFastState.Bounded env50058 := by
  intro p hp
  have h : env50058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50057_50058 : H12AffineEnvironment.transform 5 16 env50057 = env50058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50057 == env50058) = true)

theorem identity50058 : scanCanonicalize (H12AffineFastState.compose env50058 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound50058 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env50059 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4097,61568,147472,58518,143496,20496,120866,148668,148668,96266,90262,90258,173,222255,1212,135681]

theorem envBound50059 : H12AffineFastState.Bounded env50059 := by
  intro p hp
  have h : env50059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50058_50059 : H12AffineEnvironment.transform 17 137353 env50058 = env50059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env50058 == env50059) = true)

theorem identity50059 : scanCanonicalize (H12AffineFastState.compose env50059 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound50059 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env50060 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,62492,60565,57373,32769,4097,61568,46092,58518,50324,20496,120866,45216,45216,96266,90262,90258,173,102451,1212,58909]

theorem envBound50060 : H12AffineFastState.Bounded env50060 := by
  intro p hp
  have h : env50060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50059_50060 : H12AffineEnvironment.transform 16 62492 env50059 = env50060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env50059 == env50060) = true)

theorem identity50060 : scanCanonicalize (H12AffineFastState.compose env50060 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound50060 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50061 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,8192,16384,32768,65536,61465,59536,57373,32769,4097,61568,45065,57491,49297,20496,120866,45216,45216,96266,90262,90258,173,102451,185,57880]

theorem envBound50061 : H12AffineFastState.Bounded env50061 := by
  intro p hp
  have h : env50061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50060_50061 : H12AffineEnvironment.transform 9 5 env50060 = env50061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env50060 == env50061) = true)

theorem identity50061 : scanCanonicalize (H12AffineFastState.compose env50061 (packedSelected [0,2,3,4,5,6,7,9,10,13,17,18,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 14889) := by decide +kernel

theorem selectedBound50061 : packedSelected [0,2,3,4,5,6,7,9,10,13,17,18,21,23] rootPS < 2^1333 := by decide +kernel

def env50062 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,8192,14889,32768,65536,35376,37561,39476,32769,4097,35497,45065,39610,47800,10809,107019,45216,45216,66083,72383,72379,173,102451,185,38961]

theorem envBound50062 : H12AffineFastState.Bounded env50062 := by
  intro p hp
  have h : env50062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50061_50062 : H12AffineEnvironment.transform 13 14889 env50061 = env50062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14889 env50061 == env50062) = true)

theorem identity50062 : scanCanonicalize (H12AffineFastState.compose env50062 (packedSelected [0,2,3,4,5,6,7,9,10,13,19,26] rootPS)) = affineNative (2^(15+1) ^^^ 43530) := by decide +kernel

theorem selectedBound50062 : packedSelected [0,2,3,4,5,6,7,9,10,13,19,26] rootPS < 2^1333 := by decide +kernel

def env50063 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,8192,14889,32768,43530,35376,37561,39476,32769,4097,35497,45065,39610,47800,10809,2049,45216,45216,43049,45237,45233,173,14905,185,38961]

theorem envBound50063 : H12AffineFastState.Bounded env50063 := by
  intro p hp
  have h : env50063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50062_50063 : H12AffineEnvironment.transform 15 43530 env50062 = env50063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 43530 env50062 == env50063) = true)

theorem identity50063 : scanCanonicalize (H12AffineFastState.compose env50063 (packedSelected [0,1,6,8,9,10,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 696) := by decide +kernel

theorem selectedBound50063 : packedSelected [0,1,6,8,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env50064 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,696,8192,10385,32768,43530,35376,32769,34956,32769,697,35497,41649,34818,43008,10809,2049,41496,41496,43049,41485,41481,173,10369,185,35465]

theorem envBound50064 : H12AffineFastState.Bounded env50064 := by
  intro p hp
  have h : env50064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50063_50064 : H12AffineEnvironment.transform 11 696 env50063 = env50064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 696 env50063 == env50064) = true)

theorem identity50064 : scanCanonicalize (H12AffineFastState.compose env50064 (packedSelected [5,8,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 10379) := by decide +kernel

theorem selectedBound50064 : packedSelected [5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env50065 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,696,8192,10385,10379,641,8891,10378,8199,10378,697,8738,2618,8329,139,10809,2049,2707,2707,162,2694,2690,173,10369,185,8706]

theorem envBound50065 : H12AffineFastState.Bounded env50065 := by
  intro p hp
  have h : env50065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50064_50065 : H12AffineEnvironment.transform 14 10379 env50064 = env50065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 10379 env50064 == env50065) = true)

theorem identity50065 : scanCanonicalize (H12AffineFastState.compose env50065 (packedSelected [1,3,4,9,13] rootPS)) = affineNative (2^(12+1) ^^^ 536) := by decide +kernel

theorem selectedBound50065 : packedSelected [1,3,4,9,13] rootPS < 2^1333 := by decide +kernel

def env50066 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,696,536,2697,2707,641,163,2706,543,2706,697,58,2618,657,139,2081,2049,2707,2707,162,2694,2690,173,2713,185,26]

theorem envBound50066 : H12AffineFastState.Bounded env50066 := by
  intro p hp
  have h : env50066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50065_50066 : H12AffineEnvironment.transform 12 536 env50065 = env50066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 536 env50065 == env50066) = true)

theorem identity50066 : scanCanonicalize (H12AffineFastState.compose env50066 (packedSelected [0,1,4,7,8,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound50066 : packedSelected [0,1,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env50067 : List Nat := [2,4,8,16,32,16,128,172,512,5,49,696,536,696,674,641,163,675,543,675,697,58,523,657,139,16,48,674,674,162,695,691,173,680,185,26]

theorem envBound50067 : H12AffineFastState.Bounded env50067 := by
  intro p hp
  have h : env50067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50066_50067 : H12AffineEnvironment.transform 10 49 env50066 = env50067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env50066 == env50067) = true)

theorem identity50067 : scanCanonicalize (H12AffineFastState.compose env50067 (packedSelected [1,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound50067 : packedSelected [1,6,8] rootPS < 2^1333 := by decide +kernel

def env50068 : List Nat := [2,4,8,16,32,16,128,172,136,5,49,48,144,48,42,9,163,43,151,43,49,58,131,25,139,16,48,42,42,162,63,59,173,32,185,26]

theorem envBound50068 : H12AffineFastState.Bounded env50068 := by
  intro p hp
  have h : env50068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50067_50068 : H12AffineEnvironment.transform 8 136 env50067 = env50068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env50067 == env50068) = true)

theorem identity50068 : scanCanonicalize (H12AffineFastState.compose env50068 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound50068 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env50069 : List Nat := [2,4,8,16,32,16,19,63,27,5,49,48,3,48,42,9,48,43,4,43,49,58,16,25,24,16,48,42,42,49,63,59,62,32,42,26]

theorem envBound50069 : H12AffineFastState.Bounded env50069 := by
  intro p hp
  have h : env50069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50068_50069 : H12AffineEnvironment.transform 6 19 env50068 = env50069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env50068 == env50069) = true)

theorem identity50069 : scanCanonicalize (H12AffineFastState.compose env50069 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound50069 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env50070 : List Nat := [2,4,1,16,32,16,19,54,18,5,49,48,3,48,35,0,48,34,4,34,49,51,16,16,17,16,48,35,35,49,54,50,55,32,35,19]

theorem envBound50070 : H12AffineFastState.Bounded env50070 := by
  intro p hp
  have h : env50070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50069_50070 : H12AffineEnvironment.transform 2 1 env50069 = env50070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env50069 == env50070) = true)

theorem identity50070 : scanCanonicalize (H12AffineFastState.compose env50070 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound50070 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env50071 : List Nat := [2,4,1,16,3,16,19,21,18,5,18,19,3,19,0,0,19,1,4,1,18,16,16,16,17,16,19,0,0,18,21,17,20,3,0,19]

theorem envBound50071 : H12AffineFastState.Bounded env50071 := by
  intro p hp
  have h : env50071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50070_50071 : H12AffineEnvironment.transform 4 3 env50070 = env50071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env50070 == env50071) = true)

theorem identity50071 : scanCanonicalize (H12AffineFastState.compose env50071 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound50071 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50072 : List Nat := [2,4,1,3,3,3,0,6,1,5,1,0,3,0,0,0,0,1,4,1,1,3,3,3,2,3,0,0,0,1,6,2,7,3,0,0]

theorem envBound50072 : H12AffineFastState.Bounded env50072 := by
  intro p hp
  have h : env50072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50071_50072 : H12AffineEnvironment.transform 3 3 env50071 = env50072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env50071 == env50072) = true)

theorem identity50072 : scanCanonicalize (H12AffineFastState.compose env50072 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50072 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50073 : List Nat := [2,2,1,3,3,3,0,0,1,3,1,0,3,0,0,0,0,1,2,1,1,3,3,3,2,3,0,0,0,1,0,2,1,3,0,0]

theorem envBound50073 : H12AffineFastState.Bounded env50073 := by
  intro p hp
  have h : env50073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50072_50073 : H12AffineEnvironment.transform 1 2 env50072 = env50073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50072 == env50073) = true)

theorem identity50073 : scanCanonicalize (H12AffineFastState.compose env50073 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound50073 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env50074 : List Nat := [1,1,1,0,0,0,0,0,1,0,1,0,0,0,0,0,0,1,1,1,1,0,0,0,1,0,0,0,0,1,0,1,1,0,0,0]

theorem envBound50074 : H12AffineFastState.Bounded env50074 := by
  intro p hp
  have h : env50074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50073_50074 : H12AffineEnvironment.transform 0 1 env50073 = env50074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env50073 == env50074) = true)

def env50075 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,58518,143496,20496,508074,148669,148669,96267,90262,90258,173,222254,1213,135681]

theorem envBound50075 : H12AffineFastState.Bounded env50075 := by
  intro p hp
  have h : env50075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50057_50075 : H12AffineEnvironment.transform 5 17 env50057 = env50075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50057 == env50075) = true)

theorem identity50075 : scanCanonicalize (H12AffineFastState.compose env50075 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound50075 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env50076 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4097,61569,61616,58518,32809,20496,356363,62492,62492,96267,90262,90258,173,119951,1213,41632]

theorem envBound50076 : H12AffineFastState.Bounded env50076 := by
  intro p hp
  have h : env50076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50075_50076 : H12AffineEnvironment.transform 16 45217 env50075 = env50076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env50075 == env50076) = true)

theorem identity50076 : scanCanonicalize (H12AffineFastState.compose env50076 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound50076 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env50077 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,2185,42144,32769,4097,61569,61616,58518,32809,20496,96386,62492,62492,96267,90262,90258,173,119951,1213,41632]

theorem envBound50077 : H12AffineFastState.Bounded env50077 := by
  intro p hp
  have h : env50077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50076_50077 : H12AffineEnvironment.transform 17 2185 env50076 = env50077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env50076 == env50077) = true)

theorem identity50077 : scanCanonicalize (H12AffineFastState.compose env50077 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 54310) := by decide +kernel

theorem selectedBound50077 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env50078 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,54310,45217,2185,42144,32769,4097,61569,61616,58518,32809,20496,44196,62492,62492,44077,46256,46260,173,169,1213,41632]

theorem envBound50078 : H12AffineFastState.Bounded env50078 := by
  intro p hp
  have h : env50078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50077_50078 : H12AffineEnvironment.transform 15 54310 env50077 = env50078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54310 env50077 == env50078) = true)

theorem identity50078 : scanCanonicalize (H12AffineFastState.compose env50078 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(14+1) ^^^ 24600) := by decide +kernel

theorem selectedBound50078 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env50079 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,24600,13374,20665,2185,17592,24601,4097,4249,4264,1166,24625,20496,19644,5124,5124,19509,21672,21676,173,169,1213,17080]

theorem envBound50079 : H12AffineFastState.Bounded env50079 := by
  intro p hp
  have h : env50079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50078_50079 : H12AffineEnvironment.transform 14 24600 env50078 = env50079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24600 env50078 == env50079) = true)

theorem identity50079 : scanCanonicalize (H12AffineFastState.compose env50079 (packedSelected [0,2,3,4,5,7,9,10,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 700) := by decide +kernel

theorem selectedBound50079 : packedSelected [0,2,3,4,5,7,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env50080 : List Nat := [2,4,8,16,32,17,128,172,512,700,2048,4096,8192,16384,24600,12930,20665,2185,16900,24601,4097,4249,4264,562,24625,20496,18944,4792,4792,19081,21012,21008,173,169,513,17080]

theorem envBound50080 : H12AffineFastState.Bounded env50080 := by
  intro p hp
  have h : env50080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50079_50080 : H12AffineEnvironment.transform 9 700 env50079 = env50080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 700 env50079 == env50080) = true)

theorem identity50080 : scanCanonicalize (H12AffineFastState.compose env50080 (packedSelected [0,3,4,6,8,10,11,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 6802) := by decide +kernel

theorem selectedBound50080 : packedSelected [0,3,4,6,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env50081 : List Nat := [2,4,8,16,32,17,128,172,512,700,2048,4096,8192,6802,14986,12930,2603,2185,6294,14987,4097,4249,4264,562,15011,2690,4242,4792,4792,4123,2182,2178,173,169,513,6186]

theorem envBound50081 : H12AffineFastState.Bounded env50081 := by
  intro p hp
  have h : env50081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50080_50081 : H12AffineEnvironment.transform 13 6802 env50080 = env50081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6802 env50080 == env50081) = true)

theorem identity50081 : scanCanonicalize (H12AffineFastState.compose env50081 (packedSelected [0,4,6,7,9,11,17] rootPS)) = affineNative (2^(12+1) ^^^ 4746) := by decide +kernel

theorem selectedBound50081 : packedSelected [0,4,6,7,9,11,17] rootPS < 2^1333 := by decide +kernel

def env50082 : List Nat := [2,4,8,16,32,17,128,172,512,700,2048,4096,4746,6802,2048,8,2603,2185,6294,2049,4097,4249,4264,562,2089,2690,4242,4792,4792,4123,2182,2178,173,169,513,6186]

theorem envBound50082 : H12AffineFastState.Bounded env50082 := by
  intro p hp
  have h : env50082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50081_50082 : H12AffineEnvironment.transform 12 4746 env50081 = env50082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4746 env50081 == env50082) = true)

theorem identity50082 : scanCanonicalize (H12AffineFastState.compose env50082 (packedSelected [1,2,3,4,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound50082 : packedSelected [1,2,3,4,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env50083 : List Nat := [2,4,8,16,32,17,128,172,512,700,538,4096,4746,4232,538,8,49,659,4748,539,4097,4249,4264,562,563,152,4242,4792,4792,4123,668,664,173,169,513,4656]

theorem envBound50083 : H12AffineFastState.Bounded env50083 := by
  intro p hp
  have h : env50083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50082_50083 : H12AffineEnvironment.transform 10 538 env50082 = env50083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env50082 == env50083) = true)

theorem identity50083 : scanCanonicalize (H12AffineFastState.compose env50083 (packedSelected [2,4,5,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 648) := by decide +kernel

theorem selectedBound50083 : packedSelected [2,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env50084 : List Nat := [2,4,8,16,32,17,128,172,512,700,538,648,2,512,538,8,49,659,4,539,649,529,544,562,563,152,538,48,48,659,668,664,173,169,513,184]

theorem envBound50084 : H12AffineFastState.Bounded env50084 := by
  intro p hp
  have h : env50084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50083_50084 : H12AffineEnvironment.transform 11 648 env50083 = env50084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 648 env50083 == env50084) = true)

theorem identity50084 : scanCanonicalize (H12AffineFastState.compose env50084 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound50084 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50085 : List Nat := [2,4,8,16,32,17,128,172,48,140,42,184,2,48,42,8,49,163,4,43,185,33,16,2,3,152,42,48,48,163,172,168,173,169,49,184]

theorem envBound50085 : H12AffineFastState.Bounded env50085 := by
  intro p hp
  have h : env50085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50084_50085 : H12AffineEnvironment.transform 8 48 env50084 = env50085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env50084 == env50085) = true)

theorem identity50085 : scanCanonicalize (H12AffineFastState.compose env50085 (packedSelected [0,2,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 30) := by decide +kernel

theorem selectedBound50085 : packedSelected [0,2,4,5] rootPS < 2^1333 := by decide +kernel

def env50086 : List Nat := [2,4,8,16,32,17,30,50,48,18,42,38,2,48,42,8,49,61,4,43,39,33,16,2,3,6,42,48,48,61,50,54,51,55,49,38]

theorem envBound50086 : H12AffineFastState.Bounded env50086 := by
  intro p hp
  have h : env50086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50085_50086 : H12AffineEnvironment.transform 6 30 env50085 = env50086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 30 env50085 == env50086) = true)

theorem identity50086 : scanCanonicalize (H12AffineFastState.compose env50086 (packedSelected [0,1,4,6] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound50086 : packedSelected [0,1,4,6] rootPS < 2^1333 := by decide +kernel

def env50087 : List Nat := [2,4,4,16,32,17,18,50,48,18,38,38,2,48,38,4,49,49,4,39,39,33,16,2,3,6,38,48,48,49,50,54,51,55,49,38]

theorem envBound50087 : H12AffineFastState.Bounded env50087 := by
  intro p hp
  have h : env50087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50086_50087 : H12AffineEnvironment.transform 2 4 env50086 = env50087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env50086 == env50087) = true)

theorem identity50087 : scanCanonicalize (H12AffineFastState.compose env50087 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound50087 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50088 : List Nat := [2,4,4,6,32,7,4,36,38,4,38,38,2,38,38,4,39,39,4,39,39,33,6,2,3,6,38,38,38,39,36,32,37,33,39,38]

theorem envBound50088 : H12AffineFastState.Bounded env50088 := by
  intro p hp
  have h : env50088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50087_50088 : H12AffineEnvironment.transform 3 6 env50087 = env50088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env50087 == env50088) = true)

theorem identity50088 : scanCanonicalize (H12AffineFastState.compose env50088 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound50088 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50089 : List Nat := [2,4,4,6,6,7,4,2,0,4,0,0,2,0,0,4,1,1,4,1,1,7,6,2,3,6,0,0,0,1,2,6,3,7,1,0]

theorem envBound50089 : H12AffineFastState.Bounded env50089 := by
  intro p hp
  have h : env50089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50088_50089 : H12AffineEnvironment.transform 4 6 env50088 = env50089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env50088 == env50089) = true)

def env50090 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,58519,143496,20496,508155,148717,148717,96346,90263,90259,172,222335,1261,135681]

theorem envBound50090 : H12AffineFastState.Bounded env50090 := by
  intro p hp
  have h : env50090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50056_50090 : H12AffineEnvironment.transform 7 173 env50056 = env50090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env50056 == env50090) = true)

def env50091 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,58519,143496,20496,508075,148669,148669,96266,90263,90259,172,222255,1213,135681]

theorem envBound50091 : H12AffineFastState.Bounded env50091 := by
  intro p hp
  have h : env50091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50090_50091 : H12AffineEnvironment.transform 5 16 env50090 = env50091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50090 == env50091) = true)

theorem identity50091 : scanCanonicalize (H12AffineFastState.compose env50091 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound50091 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env50092 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136193,32769,4097,61568,147472,58519,143496,20496,60445,148669,148669,96266,90263,90259,172,222255,1213,135681]

theorem envBound50092 : H12AffineFastState.Bounded env50092 := by
  intro p hp
  have h : env50092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50091_50092 : H12AffineEnvironment.transform 17 208054 env50091 = env50092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env50091 == env50092) = true)

theorem identity50092 : scanCanonicalize (H12AffineFastState.compose env50092 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound50092 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env50093 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53282,131072,195732,136193,32769,4097,61568,147472,58519,143496,20496,60445,148669,148669,43048,45237,45233,172,177165,1213,135681]

theorem envBound50093 : H12AffineFastState.Bounded env50093 := by
  intro p hp
  have h : env50093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50092_50093 : H12AffineEnvironment.transform 15 53282 env50092 = env50093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env50092 == env50093) = true)

theorem identity50093 : scanCanonicalize (H12AffineFastState.compose env50093 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound50093 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env50094 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53282,21692,43048,16573,32769,4097,61568,5292,58519,25652,20496,60445,4097,4097,43048,45237,45233,172,57521,1213,18109]

theorem envBound50094 : H12AffineFastState.Bounded env50094 := by
  intro p hp
  have h : env50094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50093_50094 : H12AffineEnvironment.transform 16 21692 env50093 = env50094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env50093 == env50094) = true)

theorem identity50094 : scanCanonicalize (H12AffineFastState.compose env50094 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound50094 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env50095 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,9381,29831,21692,3213,16573,9380,4097,21541,5292,16434,25652,20496,18616,4097,4097,3213,5136,5140,172,17428,1213,18109]

theorem envBound50095 : H12AffineFastState.Bounded env50095 := by
  intro p hp
  have h : env50095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50094_50095 : H12AffineEnvironment.transform 14 9381 env50094 = env50095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env50094 == env50095) = true)

theorem identity50095 : scanCanonicalize (H12AffineFastState.compose env50095 (packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 8728) := by decide +kernel

theorem selectedBound50095 : packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env50096 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,8728,9381,5791,13988,3213,8869,9380,4097,13885,5292,8746,1580,12808,10912,4097,4097,3213,5136,5140,172,9740,1213,9381]

theorem envBound50096 : H12AffineFastState.Bounded env50096 := by
  intro p hp
  have h : env50096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50095_50096 : H12AffineEnvironment.transform 13 8728 env50095 = env50096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8728 env50095 == env50096) = true)

theorem identity50096 : scanCanonicalize (H12AffineFastState.compose env50096 (packedSelected [1,3,4,6,7,11,13,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 3118) := by decide +kernel

theorem selectedBound50096 : packedSelected [1,3,4,6,7,11,13,15,16] rootPS < 2^1333 := by decide +kernel

def env50097 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,3118,8192,8728,9381,2737,10890,3213,8869,9380,3119,10771,2178,8746,1580,11814,10912,3119,3119,3213,2110,2106,172,9740,1213,9381]

theorem envBound50097 : H12AffineFastState.Bounded env50097 := by
  intro p hp
  have h : env50097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50096_50097 : H12AffineEnvironment.transform 11 3118 env50096 = env50097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3118 env50096 == env50097) = true)

theorem identity50097 : scanCanonicalize (H12AffineFastState.compose env50097 (packedSelected [0,1,2,5,6,9,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound50097 : packedSelected [0,1,2,5,6,9,11,13] rootPS < 2^1333 := by decide +kernel

def env50098 : List Nat := [2,4,8,16,32,16,128,173,512,1024,163,1165,8192,8728,9381,530,8745,1070,8869,9380,1164,8880,33,8746,1580,9861,8707,1164,1164,1070,157,153,172,9740,1213,9381]

theorem envBound50098 : H12AffineFastState.Bounded env50098 := by
  intro p hp
  have h : env50098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50097_50098 : H12AffineEnvironment.transform 10 163 env50097 = env50098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env50097 == env50098) = true)

theorem identity50098 : scanCanonicalize (H12AffineFastState.compose env50098 (packedSelected [3,4,6,7,8,10,11,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound50098 : packedSelected [3,4,6,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env50099 : List Nat := [2,4,8,16,11,16,128,134,512,1024,136,1165,8192,8728,9358,530,8706,1029,8846,9359,1164,8859,10,8705,1543,9861,8707,1164,1164,1029,157,153,135,9740,1174,9358]

theorem envBound50099 : H12AffineFastState.Bounded env50099 := by
  intro p hp
  have h : env50099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50098_50099 : H12AffineEnvironment.transform 4 11 env50098 = env50099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env50098 == env50099) = true)

theorem identity50099 : scanCanonicalize (H12AffineFastState.compose env50099 (packedSelected [0,4,5,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound50099 : packedSelected [0,4,5,8,10] rootPS < 2^1333 := by decide +kernel

def env50100 : List Nat := [2,4,8,16,11,16,128,134,512,516,136,649,8192,8728,8842,530,8706,513,8846,8843,648,8859,10,8705,3,8321,8707,648,648,513,157,153,135,8200,658,8842]

theorem envBound50100 : H12AffineFastState.Bounded env50100 := by
  intro p hp
  have h : env50100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50099_50100 : H12AffineEnvironment.transform 9 516 env50099 = env50100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env50099 == env50100) = true)

theorem identity50100 : scanCanonicalize (H12AffineFastState.compose env50100 (packedSelected [4,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound50100 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env50101 : List Nat := [2,4,8,16,11,16,128,134,512,516,136,649,656,136,26,530,146,513,30,27,648,11,10,145,3,529,147,648,648,513,157,153,135,664,658,26]

theorem envBound50101 : H12AffineFastState.Bounded env50101 := by
  intro p hp
  have h : env50101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50100_50101 : H12AffineEnvironment.transform 12 656 env50100 = env50101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env50100 == env50101) = true)

theorem identity50101 : scanCanonicalize (H12AffineFastState.compose env50101 (packedSelected [1,3,6] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound50101 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env50102 : List Nat := [2,4,8,11,11,11,128,134,512,516,136,649,651,136,1,521,137,513,5,0,648,11,10,138,3,522,136,648,648,513,134,130,135,643,649,1]

theorem envBound50102 : H12AffineFastState.Bounded env50102 := by
  intro p hp
  have h : env50102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50101_50102 : H12AffineEnvironment.transform 3 11 env50101 = env50102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env50101 == env50102) = true)

theorem identity50102 : scanCanonicalize (H12AffineFastState.compose env50102 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound50102 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50103 : List Nat := [2,4,8,11,11,11,128,134,13,9,136,132,134,136,1,4,137,12,5,0,133,11,10,138,3,7,136,133,133,12,134,130,135,142,132,1]

theorem envBound50103 : H12AffineFastState.Bounded env50103 := by
  intro p hp
  have h : env50103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50102_50103 : H12AffineEnvironment.transform 8 13 env50102 = env50103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env50102 == env50103) = true)

theorem identity50103 : scanCanonicalize (H12AffineFastState.compose env50103 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound50103 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50104 : List Nat := [2,4,8,11,11,11,8,14,13,9,0,12,14,0,1,4,1,12,5,0,13,11,10,2,3,7,0,13,13,12,14,10,15,6,12,1]

theorem envBound50104 : H12AffineFastState.Bounded env50104 := by
  intro p hp
  have h : env50104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50103_50104 : H12AffineEnvironment.transform 6 8 env50103 = env50104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50103 == env50104) = true)

def env50105 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,58519,143496,20496,508074,148668,148668,96267,90263,90259,172,222254,1212,135681]

theorem envBound50105 : H12AffineFastState.Bounded env50105 := by
  intro p hp
  have h : env50105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50090_50105 : H12AffineEnvironment.transform 5 17 env50090 = env50105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50090 == env50105) = true)

theorem identity50105 : scanCanonicalize (H12AffineFastState.compose env50105 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound50105 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env50106 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102558,32769,4097,61569,115854,58519,111639,20496,279605,114723,114723,96267,90263,90259,172,57521,1212,104094]

theorem envBound50106 : H12AffineFastState.Bounded env50106 := by
  intro p hp
  have h : env50106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50105_50106 : H12AffineEnvironment.transform 16 99487 env50105 = env50106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env50105 == env50106) = true)

theorem identity50106 : scanCanonicalize (H12AffineFastState.compose env50106 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 12347) := by decide +kernel

theorem selectedBound50106 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env50107 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,12347,46244,262144,41125,32769,4097,61569,62645,58519,33836,20496,279605,61464,61464,18480,20652,20648,172,57521,1212,42661]

theorem envBound50107 : H12AffineFastState.Bounded env50107 := by
  intro p hp
  have h : env50107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50106_50107 : H12AffineEnvironment.transform 15 12347 env50106 = env50107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12347 env50106 == env50107) = true)

theorem identity50107 : scanCanonicalize (H12AffineFastState.compose env50107 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound50107 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env50108 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,9381,12347,4097,262144,1024,9380,4097,21540,20496,16434,8329,20496,279605,21693,21693,18480,20652,20648,172,17428,1212,512]

theorem envBound50108 : H12AffineFastState.Bounded env50108 := by
  intro p hp
  have h : env50108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50107_50108 : H12AffineEnvironment.transform 14 9381 env50107 = env50108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env50107 == env50108) = true)

theorem identity50108 : scanCanonicalize (H12AffineFastState.compose env50108 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound50108 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50109 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,9381,12347,4097,262144,1024,9380,4097,4249,5293,1167,8329,5293,262280,4096,4096,3213,5137,5141,172,169,1212,512]

theorem envBound50109 : H12AffineFastState.Bounded env50109 := by
  intro p hp
  have h : env50109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50108_50109 : H12AffineEnvironment.transform 13 1213 env50108 = env50109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env50108 == env50109) = true)

theorem identity50109 : scanCanonicalize (H12AffineFastState.compose env50109 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 5676) := by decide +kernel

theorem selectedBound50109 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50110 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,5676,1213,4745,1559,4097,262144,1024,4744,4097,4249,5293,1167,5797,5293,262280,4096,4096,3213,5137,5141,172,169,1212,512]

theorem envBound50110 : H12AffineFastState.Bounded env50110 := by
  intro p hp
  have h : env50110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50109_50110 : H12AffineEnvironment.transform 12 5676 env50109 = env50110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5676 env50109 == env50110) = true)

theorem identity50110 : scanCanonicalize (H12AffineFastState.compose env50110 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 6193) := by decide +kernel

theorem selectedBound50110 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env50111 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,5676,1213,4745,1559,4097,6193,1024,4744,4097,4249,5293,1167,5797,5293,6329,4096,4096,3213,5137,5141,172,169,1212,512]

theorem envBound50111 : H12AffineFastState.Bounded env50111 := by
  intro p hp
  have h : env50111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50110_50111 : H12AffineEnvironment.transform 17 6193 env50110 = env50111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6193 env50110 == env50111) = true)

theorem identity50111 : scanCanonicalize (H12AffineFastState.compose env50111 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 3614) := by decide +kernel

theorem selectedBound50111 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env50112 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,3614,2098,1213,3223,1559,3615,1583,1024,3222,3615,3719,2739,1167,2235,2739,1703,3614,3614,3213,2575,2571,172,169,1212,512]

theorem envBound50112 : H12AffineFastState.Bounded env50112 := by
  intro p hp
  have h : env50112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50111_50112 : H12AffineEnvironment.transform 11 3614 env50111 = env50112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3614 env50111 == env50112) = true)

theorem identity50112 : scanCanonicalize (H12AffineFastState.compose env50112 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound50112 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env50113 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,2586,2098,185,2195,531,2587,555,4,2194,2587,2691,2739,139,2235,2739,675,2586,2586,2185,2575,2571,172,169,184,512]

theorem envBound50113 : H12AffineFastState.Bounded env50113 := by
  intro p hp
  have h : env50113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50112_50113 : H12AffineEnvironment.transform 9 4 env50112 = env50113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env50112 == env50113) = true)

theorem identity50113 : scanCanonicalize (H12AffineFastState.compose env50113 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound50113 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50114 : List Nat := [2,4,8,16,32,17,128,173,512,4,49,555,3,185,162,531,554,555,4,163,554,690,642,139,138,642,675,555,555,184,574,570,172,169,184,512]

theorem envBound50114 : H12AffineFastState.Bounded env50114 := by
  intro p hp
  have h : env50114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50113_50114 : H12AffineEnvironment.transform 10 49 env50113 = env50114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env50113 == env50114) = true)

theorem identity50114 : scanCanonicalize (H12AffineFastState.compose env50114 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound50114 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50115 : List Nat := [2,4,8,16,32,17,9,36,512,4,49,555,3,48,43,531,554,555,4,42,554,571,523,2,3,523,554,555,555,49,574,570,37,32,49,512]

theorem envBound50115 : H12AffineFastState.Bounded env50115 := by
  intro p hp
  have h : env50115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50114_50115 : H12AffineEnvironment.transform 6 9 env50114 = env50115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50114 == env50115) = true)

theorem identity50115 : scanCanonicalize (H12AffineFastState.compose env50115 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 45) := by decide +kernel

theorem selectedBound50115 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env50116 : List Nat := [2,4,8,16,32,17,9,36,45,4,49,6,3,48,43,62,7,6,4,42,7,22,38,2,3,38,7,6,6,49,19,23,37,32,49,45]

theorem envBound50116 : H12AffineFastState.Bounded env50116 := by
  intro p hp
  have h : env50116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50115_50116 : H12AffineEnvironment.transform 8 45 env50115 = env50116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 45 env50115 == env50116) = true)

theorem identity50116 : scanCanonicalize (H12AffineFastState.compose env50116 (packedSelected [0,1,5] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound50116 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env50117 : List Nat := [2,4,8,16,22,17,9,18,27,4,7,6,3,6,29,8,7,6,4,28,7,22,16,2,3,16,7,6,6,7,19,23,19,22,7,27]

theorem envBound50117 : H12AffineFastState.Bounded env50117 := by
  intro p hp
  have h : env50117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50116_50117 : H12AffineEnvironment.transform 4 22 env50116 = env50117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env50116 == env50117) = true)

theorem identity50117 : scanCanonicalize (H12AffineFastState.compose env50117 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound50117 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50118 : List Nat := [2,4,8,11,13,10,9,9,0,4,7,6,3,6,6,8,7,6,4,7,7,13,11,2,3,11,7,6,6,7,8,12,8,13,7,0]

theorem envBound50118 : H12AffineFastState.Bounded env50118 := by
  intro p hp
  have h : env50118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50117_50118 : H12AffineEnvironment.transform 3 11 env50117 = env50118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env50117 == env50118) = true)

def env50119 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,147521,16777216,33554432,672784,134217728,148801,33584585,2189403,50962569,4294967296,34088328,4347445490,34359738368,33563273]

theorem envBound50119 : H12AffineFastState.Bounded env50119 := by
  intro p hp
  have h : env50119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45451_50119 : H12AffineEnvironment.transform 22 147521 env45451 = env50119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147521 env45451 == env50119) = true)

def env50120 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,147521,16777216,33554432,672784,134217728,148801,33584585,2189403,50962569,4294967296,34088328,4347445490,151462016,33563273]

theorem envBound50120 : H12AffineFastState.Bounded env50120 := by
  intro p hp
  have h : env50120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50119_50120 : H12AffineEnvironment.transform 34 151462016 env50119 = env50120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 151462016 env50119 == env50120) = true)

def env50121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,33554432,672784,134217728,148801,33584585,96347,50962569,4294967296,34088328,4345352434,151462016,33563273]

theorem envBound50121 : H12AffineFastState.Bounded env50121 := by
  intro p hp
  have h : env50121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50120_50121 : H12AffineEnvironment.transform 20 4096 env50120 = env50121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env50120 == env50121) = true)

theorem identity50121 : scanCanonicalize (H12AffineFastState.compose env50121 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 34144422) := by decide +kernel

theorem selectedBound50121 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env50122 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,33554432,672784,134217728,148801,33584585,96347,50962569,34144422,34088328,17420372,151462016,33563273]

theorem envBound50122 : H12AffineFastState.Bounded env50122 := by
  intro p hp
  have h : env50122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50121_50122 : H12AffineEnvironment.transform 31 34144422 env50121 = env50122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 34144422 env50121 == env50122) = true)

def env50123 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533640,672784,134217728,148801,545089,96347,16876545,74798,256,17420372,151462016,525825]

theorem envBound50123 : H12AffineFastState.Bounded env50123 := by
  intro p hp
  have h : env50123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50122_50123 : H12AffineEnvironment.transform 24 533640 env50122 = env50123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env50122 == env50123) = true)

def env50124 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533640,672784,17245632,148801,545089,96347,16876545,74798,256,17420372,1344,525825]

theorem envBound50124 : H12AffineFastState.Bounded env50124 := by
  intro p hp
  have h : env50124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50123_50124 : H12AffineEnvironment.transform 26 17245632 env50123 = env50124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env50123 == env50124) = true)

theorem identity50124 : scanCanonicalize (H12AffineFastState.compose env50124 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74862) := by decide +kernel

theorem selectedBound50124 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env50125 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4096,61649,91183,16777216,533640,614526,17039790,90415,545089,96347,16876545,74798,256,17420372,1344,525825]

theorem envBound50125 : H12AffineFastState.Bounded env50125 := by
  intro p hp
  have h : env50125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50124_50125 : H12AffineEnvironment.transform 16 74862 env50124 = env50125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74862 env50124 == env50125) = true)

def env50126 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4096,61649,91183,123164,533640,614526,385202,90415,545089,96347,25885,74798,256,536904,1344,525825]

theorem envBound50126 : H12AffineFastState.Bounded env50126 := by
  intro p hp
  have h : env50126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50125_50126 : H12AffineEnvironment.transform 23 123164 env50125 = env50126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env50125 == env50126) = true)

def env50127 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4096,61649,91183,123164,28888,78894,385202,90415,1297,96347,25885,74798,256,25880,1344,21073]

theorem envBound50127 : H12AffineFastState.Bounded env50127 := by
  intro p hp
  have h : env50127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50126_50127 : H12AffineEnvironment.transform 18 21584 env50126 = env50127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env50126 == env50127) = true)

theorem identity50127 : scanCanonicalize (H12AffineFastState.compose env50127 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound50127 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env50128 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74862,262144,21584,13341,4096,17613,91183,87296,28888,78894,349358,90415,1297,96347,25885,74798,256,25880,1344,21073]

theorem envBound50128 : H12AffineFastState.Bounded env50128 := by
  intro p hp
  have h : env50128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50127_50128 : H12AffineEnvironment.transform 14 13340 env50127 = env50128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env50127 == env50128) = true)

def env50129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,262144,4416,13341,4096,477,74047,69648,13768,78894,332222,74815,1297,81227,8205,74798,256,8200,1344,5953]

theorem envBound50129 : H12AffineFastState.Bounded env50129 := by
  intro p hp
  have h : env50129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50128_50129 : H12AffineEnvironment.transform 13 1296 env50128 = env50129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env50128 == env50129) = true)

def env50130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65664,4416,13341,4096,477,74047,69648,13768,78894,4414,74815,1297,81227,8205,74798,256,8200,1344,5953]

theorem envBound50130 : H12AffineFastState.Bounded env50130 := by
  intro p hp
  have h : env50130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50129_50130 : H12AffineEnvironment.transform 17 65664 env50129 = env50130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env50129 == env50130) = true)

theorem identity50130 : scanCanonicalize (H12AffineFastState.compose env50130 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5385) := by decide +kernel

theorem selectedBound50130 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1296,277,65536,69991,65664,4416,276,4096,477,70710,69648,193,65831,4414,69942,1297,67650,5380,69927,256,5377,1344,5953]

theorem envBound50131 : H12AffineFastState.Bounded env50131 := by
  intro p hp
  have h : env50131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50130_50131 : H12AffineEnvironment.transform 12 5385 env50130 = env50131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env50130 == env50131) = true)

def env50132 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,5385,1296,277,65536,69991,65664,4416,276,4096,477,70710,69648,193,65831,4414,69942,1297,67650,5380,69927,256,5377,1344,5141]

theorem envBound50132 : H12AffineFastState.Bounded env50132 := by
  intro p hp
  have h : env50132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50131_50132 : H12AffineEnvironment.transform 8 340 env50131 = env50132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env50131 == env50132) = true)

def env50133 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,1289,1296,277,65536,65895,65664,320,276,0,477,66614,65552,193,65831,318,65846,1297,67650,1284,65831,256,1281,1344,1045]

theorem envBound50133 : H12AffineFastState.Bounded env50133 := by
  intro p hp
  have h : env50133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50132_50133 : H12AffineEnvironment.transform 11 0 env50132 = env50133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env50132 == env50133) = true)

theorem identity50133 : scanCanonicalize (H12AffineFastState.compose env50133 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound50133 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50134 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,1289,1296,277,115,276,243,320,276,0,477,1093,99,193,340,318,325,1297,2097,1284,340,256,1281,1344,1045]

theorem envBound50134 : H12AffineFastState.Bounded env50134 := by
  intro p hp
  have h : env50134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50133_50134 : H12AffineEnvironment.transform 15 115 env50133 = env50134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env50133 == env50134) = true)

theorem identity50134 : scanCanonicalize (H12AffineFastState.compose env50134 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 1119) := by decide +kernel

theorem selectedBound50134 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env50135 : List Nat := [2,4,8,16,32,64,128,256,340,1024,1119,0,1289,1296,277,115,276,243,320,276,0,477,1093,99,193,340,318,325,1297,1134,1284,340,256,1281,1344,1045]

theorem envBound50135 : H12AffineFastState.Bounded env50135 := by
  intro p hp
  have h : env50135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50134_50135 : H12AffineEnvironment.transform 10 1119 env50134 = env50135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1119 env50134 == env50135) = true)

theorem identity50135 : scanCanonicalize (H12AffineFastState.compose env50135 (packedSelected [0,4,5,7,8,9,10,12,15,17,18,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 177) := by decide +kernel

theorem selectedBound50135 : packedSelected [0,4,5,7,8,9,10,12,15,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env50136 : List Nat := [2,4,8,16,32,64,128,177,229,1024,1119,0,1208,1185,164,115,165,243,241,165,0,108,1093,99,193,229,143,244,1184,1134,1205,229,177,1200,1265,1045]

theorem envBound50136 : H12AffineFastState.Bounded env50136 := by
  intro p hp
  have h : env50136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50135_50136 : H12AffineEnvironment.transform 7 177 env50135 = env50136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 177 env50135 == env50136) = true)

theorem identity50136 : scanCanonicalize (H12AffineFastState.compose env50136 (packedSelected [0,3,4,5,9,10,16,27] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50136 : packedSelected [0,3,4,5,9,10,16,27] rootPS < 2^1333 := by decide +kernel

def env50137 : List Nat := [2,4,8,16,32,17,128,177,180,1024,1038,0,1208,1185,164,34,165,162,160,165,0,61,1044,50,144,180,143,165,1184,1087,1205,180,177,1200,1184,1045]

theorem envBound50137 : H12AffineFastState.Bounded env50137 := by
  intro p hp
  have h : env50137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50136_50137 : H12AffineEnvironment.transform 5 17 env50136 = env50137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50136 == env50137) = true)

theorem identity50137 : scanCanonicalize (H12AffineFastState.compose env50137 (packedSelected [2,5,8,12,13] rootPS)) = affineNative (2^(9+1) ^^^ 167) := by decide +kernel

theorem selectedBound50137 : packedSelected [2,5,8,12,13] rootPS < 2^1333 := by decide +kernel

def env50138 : List Nat := [2,4,8,16,32,17,128,177,180,167,169,0,31,6,164,34,165,162,160,165,0,61,179,50,144,180,143,165,7,152,18,180,177,23,7,178]

theorem envBound50138 : H12AffineFastState.Bounded env50138 := by
  intro p hp
  have h : env50138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50137_50138 : H12AffineEnvironment.transform 9 167 env50137 = env50138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 167 env50137 == env50138) = true)

theorem identity50138 : scanCanonicalize (H12AffineFastState.compose env50138 (packedSelected [0,1,2,5,7,8,10,11,12] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound50138 : packedSelected [0,1,2,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env50139 : List Nat := [2,4,4,16,32,17,128,177,180,167,165,0,19,6,164,34,165,162,160,165,0,49,179,50,144,180,131,165,7,148,18,180,177,23,7,178]

theorem envBound50139 : H12AffineFastState.Bounded env50139 := by
  intro p hp
  have h : env50139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50138_50139 : H12AffineEnvironment.transform 2 4 env50138 = env50139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env50138 == env50139) = true)

theorem identity50139 : scanCanonicalize (H12AffineFastState.compose env50139 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50139 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env50140 : List Nat := [2,4,4,16,1,17,128,144,149,134,132,0,19,6,133,3,132,131,129,132,0,16,146,19,144,149,131,132,7,148,18,149,144,23,7,147]

theorem envBound50140 : H12AffineFastState.Bounded env50140 := by
  intro p hp
  have h : env50140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50139_50140 : H12AffineEnvironment.transform 4 1 env50139 = env50140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50139 == env50140) = true)

theorem identity50140 : scanCanonicalize (H12AffineFastState.compose env50140 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound50140 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env50141 : List Nat := [2,4,4,16,1,17,5,21,16,3,1,0,19,6,0,3,1,6,4,1,0,16,23,19,21,16,6,1,7,17,18,16,21,23,7,22]

theorem envBound50141 : H12AffineFastState.Bounded env50141 := by
  intro p hp
  have h : env50141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50140_50141 : H12AffineEnvironment.transform 6 5 env50140 = env50141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env50140 == env50141) = true)

theorem identity50141 : scanCanonicalize (H12AffineFastState.compose env50141 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound50141 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50142 : List Nat := [2,4,4,7,1,6,5,2,7,3,1,0,4,6,0,3,1,6,4,1,0,7,0,4,2,7,6,1,7,6,5,7,2,0,7,1]

theorem envBound50142 : H12AffineFastState.Bounded env50142 := by
  intro p hp
  have h : env50142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50141_50142 : H12AffineEnvironment.transform 3 7 env50141 = env50142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env50141 == env50142) = true)

def env50143 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,1288,1296,277,65536,65894,65664,321,276,1,477,66615,65553,193,65831,319,65847,1297,67650,1285,65830,256,1280,1344,1044]

theorem envBound50143 : H12AffineFastState.Bounded env50143 := by
  intro p hp
  have h : env50143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50132_50143 : H12AffineEnvironment.transform 11 1 env50132 = env50143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env50132 == env50143) = true)

theorem identity50143 : scanCanonicalize (H12AffineFastState.compose env50143 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound50143 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50144 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,1288,1296,277,1331,1109,1459,321,276,1,477,260,1314,193,1044,319,1028,1297,3441,1285,1045,256,1280,1344,1044]

theorem envBound50144 : H12AffineFastState.Bounded env50144 := by
  intro p hp
  have h : env50144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50143_50144 : H12AffineEnvironment.transform 15 1331 env50143 = env50144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env50143 == env50144) = true)

theorem identity50144 : scanCanonicalize (H12AffineFastState.compose env50144 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1443) := by decide +kernel

theorem selectedBound50144 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env50145 : List Nat := [2,4,8,16,32,64,128,256,340,1024,1443,1,1288,1296,277,1331,1109,1459,321,276,1,477,260,1314,193,1044,319,1028,1297,210,1285,1045,256,1280,1344,1044]

theorem envBound50145 : H12AffineFastState.Bounded env50145 := by
  intro p hp
  have h : env50145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50144_50145 : H12AffineEnvironment.transform 10 1443 env50144 = env50145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1443 env50144 == env50145) = true)

theorem identity50145 : scanCanonicalize (H12AffineFastState.compose env50145 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50145 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50146 : List Nat := [2,4,8,16,32,17,128,256,261,1024,1443,1,1288,1296,277,1331,1028,1459,272,276,1,396,260,1314,144,1044,319,1028,1297,131,1285,1045,256,1280,1297,1044]

theorem envBound50146 : H12AffineFastState.Bounded env50146 := by
  intro p hp
  have h : env50146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50145_50146 : H12AffineEnvironment.transform 5 17 env50145 = env50146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50145 == env50146) = true)

theorem identity50146 : scanCanonicalize (H12AffineFastState.compose env50146 (packedSelected [1,2,3,5,13] rootPS)) = affineNative (2^(9+1) ^^^ 186) := by decide +kernel

theorem selectedBound50146 : packedSelected [1,2,3,5,13] rootPS < 2^1333 := by decide +kernel

def env50147 : List Nat := [2,4,8,16,32,17,128,256,261,186,281,1,434,426,277,393,190,265,272,276,1,396,260,408,144,174,319,190,427,131,447,175,256,442,427,174]

theorem envBound50147 : H12AffineFastState.Bounded env50147 := by
  intro p hp
  have h : env50147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50146_50147 : H12AffineEnvironment.transform 9 186 env50146 = env50147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 186 env50146 == env50147) = true)

theorem identity50147 : scanCanonicalize (H12AffineFastState.compose env50147 (packedSelected [1,2,3,8,15] rootPS)) = affineNative (2^(7+1) ^^^ 128) := by decide +kernel

theorem selectedBound50147 : packedSelected [1,2,3,8,15] rootPS < 2^1333 := by decide +kernel

def env50148 : List Nat := [2,4,8,16,32,17,128,128,133,186,153,1,50,42,149,9,190,137,144,148,1,12,132,24,144,174,191,190,43,131,63,175,128,58,43,174]

theorem envBound50148 : H12AffineFastState.Bounded env50148 := by
  intro p hp
  have h : env50148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50147_50148 : H12AffineEnvironment.transform 7 128 env50147 = env50148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env50147 == env50148) = true)

theorem identity50148 : scanCanonicalize (H12AffineFastState.compose env50148 (packedSelected [5,8] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound50148 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env50149 : List Nat := [2,4,8,16,32,17,20,20,17,46,13,1,50,42,1,9,42,29,4,0,1,12,16,24,4,58,43,42,43,23,63,59,20,58,43,58]

theorem envBound50149 : H12AffineFastState.Bounded env50149 := by
  intro p hp
  have h : env50149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50148_50149 : H12AffineEnvironment.transform 6 20 env50148 = env50149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env50148 == env50149) = true)

theorem identity50149 : scanCanonicalize (H12AffineFastState.compose env50149 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound50149 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50150 : List Nat := [2,4,8,16,16,17,20,20,17,30,13,1,2,26,1,9,26,29,4,0,1,12,16,24,4,10,27,26,27,23,15,11,20,10,27,10]

theorem envBound50150 : H12AffineFastState.Bounded env50150 := by
  intro p hp
  have h : env50150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50149_50150 : H12AffineEnvironment.transform 4 16 env50149 = env50150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env50149 == env50150) = true)

theorem identity50150 : scanCanonicalize (H12AffineFastState.compose env50150 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound50150 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env50151 : List Nat := [2,4,8,6,6,7,2,2,7,8,13,1,2,12,1,9,12,11,4,0,1,12,6,14,4,10,13,12,13,1,15,11,2,10,13,10]

theorem envBound50151 : H12AffineFastState.Bounded env50151 := by
  intro p hp
  have h : env50151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50150_50151 : H12AffineEnvironment.transform 3 6 env50150 = env50151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env50150 == env50151) = true)

theorem identity50151 : scanCanonicalize (H12AffineFastState.compose env50151 (packedSelected [0,2,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound50151 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env50152 : List Nat := [2,3,8,1,1,0,2,2,0,8,10,1,2,11,1,9,11,11,3,0,1,11,1,9,3,10,10,11,10,1,8,11,2,10,10,10]

theorem envBound50152 : H12AffineFastState.Bounded env50152 := by
  intro p hp
  have h : env50152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50151_50152 : H12AffineEnvironment.transform 1 3 env50151 = env50152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env50151 == env50152) = true)

theorem identity50152 : scanCanonicalize (H12AffineFastState.compose env50152 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound50152 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env50153 : List Nat := [2,3,2,1,1,0,2,2,0,2,0,1,2,1,1,3,1,1,3,0,1,1,1,3,3,0,0,1,0,1,2,1,2,0,0,0]

theorem envBound50153 : H12AffineFastState.Bounded env50153 := by
  intro p hp
  have h : env50153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50152_50153 : H12AffineEnvironment.transform 2 2 env50152 = env50153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env50152 == env50153) = true)

def env50154 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,5385,1296,277,65536,69991,65664,4416,276,4096,477,70710,69648,193,65831,4414,69942,1297,67650,5380,69927,256,5377,1344,5140]

theorem envBound50154 : H12AffineFastState.Bounded env50154 := by
  intro p hp
  have h : env50154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50131_50154 : H12AffineEnvironment.transform 8 341 env50131 = env50154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env50131 == env50154) = true)

def env50155 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,1289,1296,277,65536,65895,65664,320,276,0,477,66614,65552,193,65831,318,65846,1297,67650,1284,65831,256,1281,1344,1044]

theorem envBound50155 : H12AffineFastState.Bounded env50155 := by
  intro p hp
  have h : env50155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50154_50155 : H12AffineEnvironment.transform 11 0 env50154 = env50155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env50154 == env50155) = true)

theorem identity50155 : scanCanonicalize (H12AffineFastState.compose env50155 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound50155 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50156 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,1289,1296,277,115,276,243,320,276,0,477,1093,99,193,340,318,325,1297,2097,1284,340,256,1281,1344,1044]

theorem envBound50156 : H12AffineFastState.Bounded env50156 := by
  intro p hp
  have h : env50156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50155_50156 : H12AffineEnvironment.transform 15 115 env50155 = env50156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env50155 == env50156) = true)

theorem identity50156 : scanCanonicalize (H12AffineFastState.compose env50156 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 1118) := by decide +kernel

theorem selectedBound50156 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env50157 : List Nat := [2,4,8,16,32,64,128,256,341,1024,1118,0,1289,1296,277,115,276,243,320,276,0,477,1093,99,193,340,318,325,1297,1135,1284,340,256,1281,1344,1044]

theorem envBound50157 : H12AffineFastState.Bounded env50157 := by
  intro p hp
  have h : env50157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50156_50157 : H12AffineEnvironment.transform 10 1118 env50156 = env50157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1118 env50156 == env50157) = true)

theorem identity50157 : scanCanonicalize (H12AffineFastState.compose env50157 (packedSelected [0,4,5,7,8,9,10,12,15,17,18,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 484) := by decide +kernel

theorem selectedBound50157 : packedSelected [0,4,5,7,8,9,10,12,15,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env50158 : List Nat := [2,4,8,16,32,64,128,256,341,484,442,0,237,244,277,115,276,243,320,276,0,477,417,99,193,340,318,325,245,395,224,340,256,229,164,496]

theorem envBound50158 : H12AffineFastState.Bounded env50158 := by
  intro p hp
  have h : env50158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50157_50158 : H12AffineEnvironment.transform 9 484 env50157 = env50158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 484 env50157 == env50158) = true)

theorem identity50158 : scanCanonicalize (H12AffineFastState.compose env50158 (packedSelected [0,3,4,5,9,10,16,27] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50158 : packedSelected [0,3,4,5,9,10,16,27] rootPS < 2^1333 := by decide +kernel

def env50159 : List Nat := [2,4,8,16,32,17,128,256,260,437,442,0,188,165,277,34,276,162,273,276,0,396,417,50,144,261,318,276,164,395,177,261,256,180,164,417]

theorem envBound50159 : H12AffineFastState.Bounded env50159 := by
  intro p hp
  have h : env50159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50158_50159 : H12AffineEnvironment.transform 5 17 env50158 = env50159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50158 == env50159) = true)

theorem identity50159 : scanCanonicalize (H12AffineFastState.compose env50159 (packedSelected [2,5,8,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 183) := by decide +kernel

theorem selectedBound50159 : packedSelected [2,5,8,12,13] rootPS < 2^1333 := by decide +kernel

def env50160 : List Nat := [2,4,8,16,32,17,128,183,179,2,13,0,188,165,162,34,163,162,166,163,0,59,22,50,144,178,137,163,164,60,177,178,183,180,164,22]

theorem envBound50160 : H12AffineFastState.Bounded env50160 := by
  intro p hp
  have h : env50160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50159_50160 : H12AffineEnvironment.transform 7 183 env50159 = env50160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 183 env50159 == env50160) = true)

theorem identity50160 : scanCanonicalize (H12AffineFastState.compose env50160 (packedSelected [10] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound50160 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env50161 : List Nat := [2,4,8,16,32,17,15,56,60,2,13,0,51,42,45,34,44,45,41,44,0,59,22,50,31,61,6,44,43,60,62,61,56,59,43,22]

theorem envBound50161 : H12AffineFastState.Bounded env50161 := by
  intro p hp
  have h : env50161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50160_50161 : H12AffineEnvironment.transform 6 15 env50160 = env50161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env50160 == env50161) = true)

theorem identity50161 : scanCanonicalize (H12AffineFastState.compose env50161 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound50161 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env50162 : List Nat := [2,4,8,16,27,17,15,3,7,2,13,0,8,17,22,25,23,22,18,23,0,0,22,9,31,6,6,23,16,7,5,6,3,0,16,22]

theorem envBound50162 : H12AffineFastState.Bounded env50162 := by
  intro p hp
  have h : env50162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50161_50162 : H12AffineEnvironment.transform 4 27 env50161 = env50162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env50161 == env50162) = true)

theorem identity50162 : scanCanonicalize (H12AffineFastState.compose env50162 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound50162 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env50163 : List Nat := [2,4,8,6,13,7,15,3,7,2,13,0,8,7,0,15,1,0,4,1,0,0,0,9,9,6,6,1,6,7,5,6,3,0,6,0]

theorem envBound50163 : H12AffineFastState.Bounded env50163 := by
  intro p hp
  have h : env50163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50162_50163 : H12AffineEnvironment.transform 3 6 env50162 = env50163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env50162 == env50163) = true)

theorem identity50163 : scanCanonicalize (H12AffineFastState.compose env50163 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50163 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50164 : List Nat := [2,2,8,0,11,1,9,3,1,2,11,0,8,1,0,9,1,0,2,1,0,0,0,9,9,0,0,1,0,1,3,0,3,0,0,0]

theorem envBound50164 : H12AffineFastState.Bounded env50164 := by
  intro p hp
  have h : env50164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50163_50164 : H12AffineEnvironment.transform 1 2 env50163 = env50164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50163 == env50164) = true)

theorem identity50164 : scanCanonicalize (H12AffineFastState.compose env50164 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound50164 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50165 : List Nat := [2,2,0,0,3,1,1,3,1,2,3,0,0,1,0,1,1,0,2,1,0,0,0,1,1,0,0,1,0,1,3,0,3,0,0,0]

theorem envBound50165 : H12AffineFastState.Bounded env50165 := by
  intro p hp
  have h : env50165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50164_50165 : H12AffineEnvironment.transform 2 0 env50164 = env50165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env50164 == env50165) = true)

theorem identity50165 : scanCanonicalize (H12AffineFastState.compose env50165 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound50165 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50166 : List Nat := [0,0,0,0,1,1,1,1,1,0,1,0,0,1,0,1,1,0,0,1,0,0,0,1,1,0,0,1,0,1,1,0,1,0,0,0]

theorem envBound50166 : H12AffineFastState.Bounded env50166 := by
  intro p hp
  have h : env50166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50165_50166 : H12AffineEnvironment.transform 0 0 env50165 = env50166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env50165 == env50166) = true)

def env50167 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,1288,1296,277,65536,65894,65664,321,276,1,477,66615,65553,193,65831,319,65847,1297,67650,1285,65830,256,1280,1344,1045]

theorem envBound50167 : H12AffineFastState.Bounded env50167 := by
  intro p hp
  have h : env50167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50154_50167 : H12AffineEnvironment.transform 11 1 env50154 = env50167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env50154 == env50167) = true)

theorem identity50167 : scanCanonicalize (H12AffineFastState.compose env50167 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound50167 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50168 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,1288,1296,277,1331,1109,1459,321,276,1,477,260,1314,193,1044,319,1028,1297,3441,1285,1045,256,1280,1344,1045]

theorem envBound50168 : H12AffineFastState.Bounded env50168 := by
  intro p hp
  have h : env50168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50167_50168 : H12AffineEnvironment.transform 15 1331 env50167 = env50168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env50167 == env50168) = true)

theorem identity50168 : scanCanonicalize (H12AffineFastState.compose env50168 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1442) := by decide +kernel

theorem selectedBound50168 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env50169 : List Nat := [2,4,8,16,32,64,128,256,341,1024,1442,1,1288,1296,277,1331,1109,1459,321,276,1,477,260,1314,193,1044,319,1028,1297,211,1285,1045,256,1280,1344,1045]

theorem envBound50169 : H12AffineFastState.Bounded env50169 := by
  intro p hp
  have h : env50169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50168_50169 : H12AffineEnvironment.transform 10 1442 env50168 = env50169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1442 env50168 == env50169) = true)

theorem identity50169 : scanCanonicalize (H12AffineFastState.compose env50169 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50169 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50170 : List Nat := [2,4,8,16,32,17,128,256,260,1024,1442,1,1288,1296,277,1331,1028,1459,272,276,1,396,260,1314,144,1044,319,1028,1297,130,1285,1045,256,1280,1297,1045]

theorem envBound50170 : H12AffineFastState.Bounded env50170 := by
  intro p hp
  have h : env50170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50169_50170 : H12AffineEnvironment.transform 5 17 env50169 = env50170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50169 == env50170) = true)

theorem identity50170 : scanCanonicalize (H12AffineFastState.compose env50170 (packedSelected [1,2,3,5,13] rootPS)) = affineNative (2^(9+1) ^^^ 431) := by decide +kernel

theorem selectedBound50170 : packedSelected [1,2,3,5,13] rootPS < 2^1333 := by decide +kernel

def env50171 : List Nat := [2,4,8,16,32,17,128,256,260,431,13,1,167,191,277,156,427,28,272,276,1,396,260,141,144,443,319,427,190,130,170,442,256,175,190,442]

theorem envBound50171 : H12AffineFastState.Bounded env50171 := by
  intro p hp
  have h : env50171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50170_50171 : H12AffineEnvironment.transform 9 431 env50170 = env50171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 431 env50170 == env50171) = true)

theorem identity50171 : scanCanonicalize (H12AffineFastState.compose env50171 (packedSelected [1,2,3,8,15] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound50171 : packedSelected [1,2,3,8,15] rootPS < 2^1333 := by decide +kernel

def env50172 : List Nat := [2,4,8,16,11,17,128,256,260,388,13,1,140,148,277,156,384,28,272,276,1,396,260,141,144,400,276,384,149,130,129,401,256,132,149,401]

theorem envBound50172 : H12AffineFastState.Bounded env50172 := by
  intro p hp
  have h : env50172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50171_50172 : H12AffineEnvironment.transform 4 11 env50171 = env50172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env50171 == env50172) = true)

theorem identity50172 : scanCanonicalize (H12AffineFastState.compose env50172 (packedSelected [0,3,7,8,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound50172 : packedSelected [0,3,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env50173 : List Nat := [2,4,8,16,11,17,128,5,1,129,13,1,140,148,16,156,133,28,21,17,1,137,1,141,144,149,17,133,149,130,129,148,5,132,149,148]

theorem envBound50173 : H12AffineFastState.Bounded env50173 := by
  intro p hp
  have h : env50173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50172_50173 : H12AffineEnvironment.transform 7 5 env50172 = env50173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env50172 == env50173) = true)

theorem identity50173 : scanCanonicalize (H12AffineFastState.compose env50173 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound50173 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50174 : List Nat := [2,4,8,16,11,17,25,5,1,24,13,1,21,13,16,5,28,28,21,17,1,16,1,20,9,12,17,28,12,27,24,13,5,29,12,13]

theorem envBound50174 : H12AffineFastState.Bounded env50174 := by
  intro p hp
  have h : env50174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50173_50174 : H12AffineEnvironment.transform 6 25 env50173 = env50174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env50173 == env50174) = true)

theorem identity50174 : scanCanonicalize (H12AffineFastState.compose env50174 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound50174 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50175 : List Nat := [2,4,8,1,11,0,8,5,1,9,13,1,4,13,1,5,13,13,4,0,1,1,1,5,9,12,0,13,12,10,9,13,5,12,12,13]

theorem envBound50175 : H12AffineFastState.Bounded env50175 := by
  intro p hp
  have h : env50175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50174_50175 : H12AffineEnvironment.transform 3 1 env50174 = env50175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50174 == env50175) = true)

theorem identity50175 : scanCanonicalize (H12AffineFastState.compose env50175 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50175 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50176 : List Nat := [2,2,8,1,11,0,8,3,1,9,11,1,2,11,1,3,11,11,2,0,1,1,1,3,9,10,0,11,10,10,9,11,3,10,10,11]

theorem envBound50176 : H12AffineFastState.Bounded env50176 := by
  intro p hp
  have h : env50176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50175_50176 : H12AffineEnvironment.transform 1 2 env50175 = env50176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50175 == env50176) = true)

def env50177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65665,4416,13341,4096,477,74047,69648,13768,78894,4415,74815,1297,81227,8205,74798,256,8200,1344,5953]

theorem envBound50177 : H12AffineFastState.Bounded env50177 := by
  intro p hp
  have h : env50177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50129_50177 : H12AffineEnvironment.transform 17 65665 env50129 = env50177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env50129 == env50177) = true)

theorem identity50177 : scanCanonicalize (H12AffineFastState.compose env50177 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound50177 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1296,5205,65536,66599,65665,4416,5204,4096,477,65910,69648,5505,70759,4415,66678,1297,72962,68,66663,256,65,1344,5953]

theorem envBound50178 : H12AffineFastState.Bounded env50178 := by
  intro p hp
  have h : env50178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50177_50178 : H12AffineEnvironment.transform 12 73 env50177 = env50178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env50177 == env50178) = true)

def env50179 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,73,1296,5205,65536,66599,65665,4416,5204,4096,477,65910,69648,5505,70759,4415,66678,1297,72962,68,66663,256,65,1344,5141]

theorem envBound50179 : H12AffineFastState.Bounded env50179 := by
  intro p hp
  have h : env50179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50178_50179 : H12AffineEnvironment.transform 8 340 env50178 = env50179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env50178 == env50179) = true)

def env50180 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,73,80,4373,65536,65895,65665,4416,4372,4096,477,65910,69648,4289,69927,4415,65846,81,71746,68,65831,256,65,0,4437]

theorem envBound50180 : H12AffineFastState.Bounded env50180 := by
  intro p hp
  have h : env50180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50179_50180 : H12AffineEnvironment.transform 9 320 env50179 = env50180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env50179 == env50180) = true)

theorem identity50180 : scanCanonicalize (H12AffineFastState.compose env50180 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound50180 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50181 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,73,80,4373,115,276,242,4416,4372,4096,477,261,4195,4289,4436,4415,325,81,6193,68,340,256,65,0,4437]

theorem envBound50181 : H12AffineFastState.Bounded env50181 := by
  intro p hp
  have h : env50181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50180_50181 : H12AffineEnvironment.transform 15 115 env50180 = env50181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env50180 == env50181) = true)

theorem identity50181 : scanCanonicalize (H12AffineFastState.compose env50181 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 2138) := by decide +kernel

theorem selectedBound50181 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env50182 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,2138,73,80,2383,115,276,242,2330,2382,2138,477,261,2105,2203,2318,2405,325,81,107,68,340,256,65,0,2319]

theorem envBound50182 : H12AffineFastState.Bounded env50182 := by
  intro p hp
  have h : env50182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50181_50182 : H12AffineEnvironment.transform 11 2138 env50181 = env50182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2138 env50181 == env50182) = true)

theorem identity50182 : scanCanonicalize (H12AffineFastState.compose env50182 (packedSelected [2,3,4,8,9,11,12,13,15,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 177) := by decide +kernel

theorem selectedBound50182 : packedSelected [2,3,4,8,9,11,12,13,15,20,23,24] rootPS < 2^1333 := by decide +kernel

def env50183 : List Nat := [2,4,8,16,32,64,128,177,229,241,2048,2138,73,80,2302,115,165,242,2219,2303,2138,108,180,2105,2203,2239,2260,244,81,107,68,229,177,65,0,2238]

theorem envBound50183 : H12AffineFastState.Bounded env50183 := by
  intro p hp
  have h : env50183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50182_50183 : H12AffineEnvironment.transform 7 177 env50182 = env50183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 177 env50182 == env50183) = true)

theorem identity50183 : scanCanonicalize (H12AffineFastState.compose env50183 (packedSelected [0,3,4,5,9,10,16,27] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50183 : packedSelected [0,3,4,5,9,10,16,27] rootPS < 2^1333 := by decide +kernel

def env50184 : List Nat := [2,4,8,16,32,17,128,177,180,160,2048,2059,24,1,2223,34,165,163,2219,2222,2059,61,180,2105,2203,2239,2181,165,0,58,21,180,177,16,0,2238]

theorem envBound50184 : H12AffineFastState.Bounded env50184 := by
  intro p hp
  have h : env50184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50183_50184 : H12AffineEnvironment.transform 5 17 env50183 = env50184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50183 == env50184) = true)

theorem identity50184 : scanCanonicalize (H12AffineFastState.compose env50184 (packedSelected [1,2,3,5,13] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound50184 : packedSelected [1,2,3,5,13] rootPS < 2^1333 := by decide +kernel

def env50185 : List Nat := [2,4,8,16,32,17,128,177,180,160,136,131,24,1,39,34,165,163,35,38,131,61,180,177,19,55,13,165,0,58,21,180,177,16,0,54]

theorem envBound50185 : H12AffineFastState.Bounded env50185 := by
  intro p hp
  have h : env50185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50184_50185 : H12AffineEnvironment.transform 10 136 env50184 = env50185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env50184 == env50185) = true)

theorem identity50185 : scanCanonicalize (H12AffineFastState.compose env50185 (packedSelected [0,1,2,5,7,8,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound50185 : packedSelected [0,1,2,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env50186 : List Nat := [2,4,8,16,10,17,128,155,158,138,136,131,24,1,13,8,143,137,9,12,131,23,158,155,19,29,13,143,0,16,21,158,155,16,0,28]

theorem envBound50186 : H12AffineFastState.Bounded env50186 := by
  intro p hp
  have h : env50186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50185_50186 : H12AffineEnvironment.transform 4 10 env50185 = env50186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env50185 == env50186) = true)

theorem identity50186 : scanCanonicalize (H12AffineFastState.compose env50186 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound50186 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env50187 : List Nat := [2,4,8,6,10,7,128,141,136,138,136,131,14,1,13,8,143,137,9,12,131,1,136,141,5,11,13,143,0,6,3,136,141,6,0,10]

theorem envBound50187 : H12AffineFastState.Bounded env50187 := by
  intro p hp
  have h : env50187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50186_50187 : H12AffineEnvironment.transform 3 6 env50186 = env50187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env50186 == env50187) = true)

theorem identity50187 : scanCanonicalize (H12AffineFastState.compose env50187 (packedSelected [2,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50187 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env50188 : List Nat := [2,2,8,0,10,1,128,139,136,138,136,131,8,1,11,8,137,137,9,10,131,1,136,139,3,11,11,137,0,0,3,136,139,0,0,10]

theorem envBound50188 : H12AffineFastState.Bounded env50188 := by
  intro p hp
  have h : env50188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50187_50188 : H12AffineEnvironment.transform 1 2 env50187 = env50188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50187 == env50188) = true)

theorem identity50188 : scanCanonicalize (H12AffineFastState.compose env50188 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound50188 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50189 : List Nat := [2,2,3,0,1,1,128,128,131,129,131,131,3,1,0,3,130,130,2,1,131,1,131,128,3,0,0,130,0,0,3,131,128,0,0,1]

theorem envBound50189 : H12AffineFastState.Bounded env50189 := by
  intro p hp
  have h : env50189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50188_50189 : H12AffineEnvironment.transform 2 3 env50188 = env50189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env50188 == env50189) = true)

theorem identity50189 : scanCanonicalize (H12AffineFastState.compose env50189 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound50189 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50190 : List Nat := [2,2,3,0,1,1,2,2,1,3,1,1,3,1,0,3,0,0,2,1,1,1,1,2,3,0,0,0,0,0,3,1,2,0,0,1]

theorem envBound50190 : H12AffineFastState.Bounded env50190 := by
  intro p hp
  have h : env50190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50189_50190 : H12AffineEnvironment.transform 6 2 env50189 = env50190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env50189 == env50190) = true)

def env50191 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,73,81,4372,65536,65894,65665,4416,4373,4096,477,65910,69648,4288,69926,4415,65847,80,71747,68,65830,256,65,1,4436]

theorem envBound50191 : H12AffineFastState.Bounded env50191 := by
  intro p hp
  have h : env50191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50179_50191 : H12AffineEnvironment.transform 9 321 env50179 = env50191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env50179 == env50191) = true)

theorem identity50191 : scanCanonicalize (H12AffineFastState.compose env50191 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 4211) := by decide +kernel

theorem selectedBound50191 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50192 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,73,81,4372,4211,4373,4338,4416,4373,4096,477,4357,99,4288,341,4415,4420,80,2096,68,4437,256,65,1,4436]

theorem envBound50192 : H12AffineFastState.Bounded env50192 := by
  intro p hp
  have h : env50192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50191_50192 : H12AffineEnvironment.transform 15 4211 env50191 = env50192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4211 env50191 == env50192) = true)

theorem identity50192 : scanCanonicalize (H12AffineFastState.compose env50192 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50192 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50193 : List Nat := [2,4,8,16,32,17,128,256,261,272,2048,4096,24,0,4372,4130,4373,4259,4369,4373,4096,396,4357,50,4241,260,4415,4373,1,2096,21,4356,256,16,1,4357]

theorem envBound50193 : H12AffineFastState.Bounded env50193 := by
  intro p hp
  have h : env50193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50192_50193 : H12AffineEnvironment.transform 5 17 env50192 = env50193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50192 == env50193) = true)

theorem identity50193 : scanCanonicalize (H12AffineFastState.compose env50193 (packedSelected [0,3,4,5,7,9,10,11,16] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound50193 : packedSelected [0,3,4,5,7,9,10,11,16] rootPS < 2^1333 := by decide +kernel

def env50194 : List Nat := [2,4,8,0,32,1,128,256,261,256,2048,4096,8,0,4356,4130,4357,4259,4353,4357,4096,396,4357,34,4225,260,4399,4357,1,2080,5,4356,256,0,1,4357]

theorem envBound50194 : H12AffineFastState.Bounded env50194 := by
  intro p hp
  have h : env50194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50193_50194 : H12AffineEnvironment.transform 3 0 env50193 = env50194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env50193 == env50194) = true)

theorem identity50194 : scanCanonicalize (H12AffineFastState.compose env50194 (packedSelected [0,1,5,7,8,11,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound50194 : packedSelected [0,1,5,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env50195 : List Nat := [2,4,8,0,32,1,128,3,6,3,2048,4096,8,0,4103,4130,4102,4259,4098,4102,4096,143,4102,34,4225,7,4140,4102,1,2080,5,4103,3,0,1,4102]

theorem envBound50195 : H12AffineFastState.Bounded env50195 := by
  intro p hp
  have h : env50195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50194_50195 : H12AffineEnvironment.transform 7 3 env50194 = env50195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env50194 == env50195) = true)

theorem identity50195 : scanCanonicalize (H12AffineFastState.compose env50195 (packedSelected [1,2,3,10,12,17] rootPS)) = affineNative (2^(11+1) ^^^ 42) := by decide +kernel

theorem selectedBound50195 : packedSelected [1,2,3,10,12,17] rootPS < 2^1333 := by decide +kernel

def env50196 : List Nat := [2,4,8,0,32,1,128,3,6,3,2048,42,8,0,45,8,44,137,40,44,42,143,44,34,171,7,6,44,1,2080,5,45,3,0,1,44]

theorem envBound50196 : H12AffineFastState.Bounded env50196 := by
  intro p hp
  have h : env50196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50195_50196 : H12AffineEnvironment.transform 11 42 env50195 = env50196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 42 env50195 == env50196) = true)

theorem identity50196 : scanCanonicalize (H12AffineFastState.compose env50196 (packedSelected [2,8] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound50196 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env50197 : List Nat := [2,4,8,0,32,1,35,3,6,3,2048,42,8,0,45,8,44,42,40,44,42,44,44,34,8,7,6,44,1,2080,5,45,3,0,1,44]

theorem envBound50197 : H12AffineFastState.Bounded env50197 := by
  intro p hp
  have h : env50197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50196_50197 : H12AffineEnvironment.transform 6 35 env50196 = env50197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env50196 == env50197) = true)

theorem identity50197 : scanCanonicalize (H12AffineFastState.compose env50197 (packedSelected [1,4,9] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50197 : packedSelected [1,4,9] rootPS < 2^1333 := by decide +kernel

def env50198 : List Nat := [2,2,8,0,32,1,35,3,0,3,2048,42,8,0,43,8,42,42,40,42,42,42,42,34,8,1,0,42,1,2080,3,43,3,0,1,42]

theorem envBound50198 : H12AffineFastState.Bounded env50198 := by
  intro p hp
  have h : env50198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50197_50198 : H12AffineEnvironment.transform 1 2 env50197 = env50198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50197 == env50198) = true)

theorem identity50198 : scanCanonicalize (H12AffineFastState.compose env50198 (packedSelected [1,2] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound50198 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env50199 : List Nat := [2,2,8,0,32,1,35,3,0,3,11,42,8,0,43,8,42,42,40,42,42,42,42,34,8,1,0,42,1,43,3,43,3,0,1,42]

theorem envBound50199 : H12AffineFastState.Bounded env50199 := by
  intro p hp
  have h : env50199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50198_50199 : H12AffineEnvironment.transform 10 11 env50198 = env50199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env50198 == env50199) = true)

theorem identity50199 : scanCanonicalize (H12AffineFastState.compose env50199 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound50199 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50200 : List Nat := [2,2,8,0,10,1,9,3,0,3,11,0,8,0,1,8,0,0,2,0,0,0,0,8,8,1,0,0,1,1,3,1,3,0,1,0]

theorem envBound50200 : H12AffineFastState.Bounded env50200 := by
  intro p hp
  have h : env50200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50199_50200 : H12AffineEnvironment.transform 4 10 env50199 = env50200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env50199 == env50200) = true)

theorem identity50200 : scanCanonicalize (H12AffineFastState.compose env50200 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound50200 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50201 : List Nat := [2,2,2,0,0,1,3,3,0,3,1,0,2,0,1,2,0,0,2,0,0,0,0,2,2,1,0,0,1,1,3,1,3,0,1,0]

theorem envBound50201 : H12AffineFastState.Bounded env50201 := by
  intro p hp
  have h : env50201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50200_50201 : H12AffineEnvironment.transform 2 2 env50200 = env50201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env50200 == env50201) = true)

def env50202 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,73,1296,5205,65536,66599,65665,4416,5204,4096,477,65910,69648,5505,70759,4415,66678,1297,72962,68,66663,256,65,1344,5140]

theorem envBound50202 : H12AffineFastState.Bounded env50202 := by
  intro p hp
  have h : env50202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50178_50202 : H12AffineEnvironment.transform 8 341 env50178 = env50202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env50178 == env50202) = true)

def env50203 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,73,80,4373,65536,65895,65665,4416,4372,4096,477,65910,69648,4289,69927,4415,65846,81,71746,68,65831,256,65,0,4436]

theorem envBound50203 : H12AffineFastState.Bounded env50203 := by
  intro p hp
  have h : env50203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50202_50203 : H12AffineEnvironment.transform 9 320 env50202 = env50203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env50202 == env50203) = true)

theorem identity50203 : scanCanonicalize (H12AffineFastState.compose env50203 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound50203 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50204 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,73,80,4373,115,276,242,4416,4372,4096,477,261,4195,4289,4436,4415,325,81,6193,68,340,256,65,0,4436]

theorem envBound50204 : H12AffineFastState.Bounded env50204 := by
  intro p hp
  have h : env50204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50203_50204 : H12AffineEnvironment.transform 15 115 env50203 = env50204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env50203 == env50204) = true)

theorem identity50204 : scanCanonicalize (H12AffineFastState.compose env50204 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 2139) := by decide +kernel

theorem selectedBound50204 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env50205 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,2139,73,80,2382,115,276,242,2331,2383,2139,477,261,2104,2202,2319,2404,325,81,106,68,340,256,65,0,2319]

theorem envBound50205 : H12AffineFastState.Bounded env50205 := by
  intro p hp
  have h : env50205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50204_50205 : H12AffineEnvironment.transform 11 2139 env50204 = env50205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2139 env50204 == env50205) = true)

theorem identity50205 : scanCanonicalize (H12AffineFastState.compose env50205 (packedSelected [2,3,4,8,9,11,12,13,15,20,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound50205 : packedSelected [2,3,4,8,9,11,12,13,15,20,23,24] rootPS < 2^1333 := by decide +kernel

def env50206 : List Nat := [2,4,8,16,32,64,36,256,341,320,2048,2139,73,80,2382,115,276,86,2331,2383,2139,377,261,2104,2110,2319,2404,325,81,106,68,340,256,65,0,2319]

theorem envBound50206 : H12AffineFastState.Bounded env50206 := by
  intro p hp
  have h : env50206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50205_50206 : H12AffineEnvironment.transform 6 36 env50205 = env50206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env50205 == env50206) = true)

theorem identity50206 : scanCanonicalize (H12AffineFastState.compose env50206 (packedSelected [0,3,4,5,9,10,16,27] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50206 : packedSelected [0,3,4,5,9,10,16,27] rootPS < 2^1333 := by decide +kernel

def env50207 : List Nat := [2,4,8,16,32,17,36,256,260,273,2048,2058,24,1,2335,34,276,7,2331,2334,2058,296,261,2104,2110,2319,2357,276,0,59,21,261,256,16,0,2319]

theorem envBound50207 : H12AffineFastState.Bounded env50207 := by
  intro p hp
  have h : env50207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50206_50207 : H12AffineEnvironment.transform 5 17 env50206 = env50207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50206 == env50207) = true)

theorem identity50207 : scanCanonicalize (H12AffineFastState.compose env50207 (packedSelected [1,2,3,5,13] rootPS)) = affineNative (2^(10+1) ^^^ 44) := by decide +kernel

theorem selectedBound50207 : packedSelected [1,2,3,5,13] rootPS < 2^1333 := by decide +kernel

def env50208 : List Nat := [2,4,8,16,32,17,36,256,260,273,44,38,24,1,307,34,276,7,311,306,38,296,261,20,18,291,281,276,0,59,21,261,256,16,0,291]

theorem envBound50208 : H12AffineFastState.Bounded env50208 := by
  intro p hp
  have h : env50208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50207_50208 : H12AffineEnvironment.transform 10 44 env50207 = env50208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 44 env50207 == env50208) = true)

theorem identity50208 : scanCanonicalize (H12AffineFastState.compose env50208 (packedSelected [0,1,2,5,7,8,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound50208 : packedSelected [0,1,2,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env50209 : List Nat := [2,4,8,16,10,17,14,256,260,273,6,12,24,1,281,8,276,7,285,280,12,258,261,20,18,265,281,276,0,17,21,261,256,16,0,265]

theorem envBound50209 : H12AffineFastState.Bounded env50209 := by
  intro p hp
  have h : env50209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50208_50209 : H12AffineEnvironment.transform 4 10 env50208 = env50209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env50208 == env50209) = true)

theorem identity50209 : scanCanonicalize (H12AffineFastState.compose env50209 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound50209 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env50210 : List Nat := [2,4,8,16,10,17,14,15,11,30,6,12,24,1,22,8,27,7,18,23,12,13,10,20,18,6,22,27,0,17,21,10,15,16,0,6]

theorem envBound50210 : H12AffineFastState.Bounded env50210 := by
  intro p hp
  have h : env50210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50209_50210 : H12AffineEnvironment.transform 7 15 env50209 = env50210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env50209 == env50210) = true)

theorem identity50210 : scanCanonicalize (H12AffineFastState.compose env50210 (packedSelected [0,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound50210 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env50211 : List Nat := [2,4,8,0,10,1,14,15,11,14,6,12,8,1,6,8,11,7,2,7,12,13,10,4,2,6,6,11,0,1,5,10,15,0,0,6]

theorem envBound50211 : H12AffineFastState.Bounded env50211 := by
  intro p hp
  have h : env50211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50210_50211 : H12AffineEnvironment.transform 3 0 env50210 = env50211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env50210 == env50211) = true)

theorem identity50211 : scanCanonicalize (H12AffineFastState.compose env50211 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound50211 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50212 : List Nat := [2,3,8,0,10,1,9,8,11,9,1,11,8,1,1,8,11,0,2,0,11,10,10,3,2,1,1,11,0,1,2,10,8,0,0,1]

theorem envBound50212 : H12AffineFastState.Bounded env50212 := by
  intro p hp
  have h : env50212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50211_50212 : H12AffineEnvironment.transform 1 3 env50211 = env50212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env50211 == env50212) = true)

def env50213 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,73,81,4372,65536,65894,65665,4416,4373,4096,477,65910,69648,4288,69926,4415,65847,80,71747,68,65830,256,65,1,4437]

theorem envBound50213 : H12AffineFastState.Bounded env50213 := by
  intro p hp
  have h : env50213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50202_50213 : H12AffineEnvironment.transform 9 321 env50202 = env50213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env50202 == env50213) = true)

theorem identity50213 : scanCanonicalize (H12AffineFastState.compose env50213 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 4211) := by decide +kernel

theorem selectedBound50213 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50214 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,73,81,4372,4211,4373,4338,4416,4373,4096,477,4357,99,4288,341,4415,4420,80,2096,68,4437,256,65,1,4437]

theorem envBound50214 : H12AffineFastState.Bounded env50214 := by
  intro p hp
  have h : env50214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50213_50214 : H12AffineEnvironment.transform 15 4211 env50213 = env50214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4211 env50213 == env50214) = true)

theorem identity50214 : scanCanonicalize (H12AffineFastState.compose env50214 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50214 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50215 : List Nat := [2,4,8,16,32,17,128,256,260,272,2048,4096,24,0,4372,4130,4373,4259,4369,4373,4096,396,4357,50,4241,260,4415,4373,1,2096,21,4356,256,16,1,4356]

theorem envBound50215 : H12AffineFastState.Bounded env50215 := by
  intro p hp
  have h : env50215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50214_50215 : H12AffineEnvironment.transform 5 17 env50214 = env50215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50214 == env50215) = true)

theorem identity50215 : scanCanonicalize (H12AffineFastState.compose env50215 (packedSelected [0,3,4,5,7,9,10,11,16] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound50215 : packedSelected [0,3,4,5,7,9,10,11,16] rootPS < 2^1333 := by decide +kernel

def env50216 : List Nat := [2,4,8,16,32,17,128,256,260,272,2048,17,24,0,261,51,260,178,256,260,17,396,276,50,128,260,302,260,1,2096,21,277,256,16,1,277]

theorem envBound50216 : H12AffineFastState.Bounded env50216 := by
  intro p hp
  have h : env50216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50215_50216 : H12AffineEnvironment.transform 11 17 env50215 = env50216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env50215 == env50216) = true)

theorem identity50216 : scanCanonicalize (H12AffineFastState.compose env50216 (packedSelected [1,3,8,10,12,15] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound50216 : packedSelected [1,3,8,10,12,15] rootPS < 2^1333 := by decide +kernel

def env50217 : List Nat := [2,4,8,6,32,7,128,256,260,262,2048,7,14,0,261,37,260,164,256,260,7,396,258,36,128,260,302,260,1,2086,3,259,256,6,1,259]

theorem envBound50217 : H12AffineFastState.Bounded env50217 := by
  intro p hp
  have h : env50217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50216_50217 : H12AffineEnvironment.transform 3 6 env50216 = env50217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env50216 == env50217) = true)

theorem identity50217 : scanCanonicalize (H12AffineFastState.compose env50217 (packedSelected [0,1,2,5,7,11,12,17] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound50217 : packedSelected [0,1,2,5,7,11,12,17] rootPS < 2^1333 := by decide +kernel

def env50218 : List Nat := [2,4,8,6,10,7,128,256,260,262,2048,7,14,0,261,15,260,142,256,260,7,396,258,14,128,260,260,260,1,2060,3,259,256,6,1,259]

theorem envBound50218 : H12AffineFastState.Bounded env50218 := by
  intro p hp
  have h : env50218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50217_50218 : H12AffineEnvironment.transform 4 10 env50217 = env50218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env50217 == env50218) = true)

theorem identity50218 : scanCanonicalize (H12AffineFastState.compose env50218 (packedSelected [0,2,3,5,7,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound50218 : packedSelected [0,2,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env50219 : List Nat := [2,4,8,6,10,7,14,256,260,262,2048,7,14,0,261,15,260,0,256,260,7,258,258,14,14,260,260,260,1,2060,3,259,256,6,1,259]

theorem envBound50219 : H12AffineFastState.Bounded env50219 := by
  intro p hp
  have h : env50219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50218_50219 : H12AffineEnvironment.transform 6 14 env50218 = env50219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env50218 == env50219) = true)

theorem identity50219 : scanCanonicalize (H12AffineFastState.compose env50219 (packedSelected [3,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50219 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env50220 : List Nat := [2,2,8,0,10,1,8,256,258,256,2048,1,8,0,259,9,258,0,256,258,1,258,258,8,8,258,258,258,1,2058,3,259,256,0,1,259]

theorem envBound50220 : H12AffineFastState.Bounded env50220 := by
  intro p hp
  have h : env50220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50219_50220 : H12AffineEnvironment.transform 1 2 env50219 = env50220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50219 == env50220) = true)

def env50221 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,262144,4417,13341,4096,476,74046,69649,13769,78894,332223,74814,1297,81226,8204,74798,256,8201,1344,5952]

theorem envBound50221 : H12AffineFastState.Bounded env50221 := by
  intro p hp
  have h : env50221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50128_50221 : H12AffineEnvironment.transform 13 1297 env50128 = env50221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env50128 == env50221) = true)

def env50222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65664,4417,13341,4096,476,74046,69649,13769,78894,4415,74814,1297,81226,8204,74798,256,8201,1344,5952]

theorem envBound50222 : H12AffineFastState.Bounded env50222 := by
  intro p hp
  have h : env50222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50221_50222 : H12AffineEnvironment.transform 17 65664 env50221 = env50222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env50221 == env50222) = true)

theorem identity50222 : scanCanonicalize (H12AffineFastState.compose env50222 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound50222 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50223 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,12636,65536,74030,65664,4417,12637,4096,476,74046,69649,12425,78190,4415,74110,81,79882,8204,74094,256,8201,0,4608]

theorem envBound50223 : H12AffineFastState.Bounded env50223 := by
  intro p hp
  have h : env50223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50222_50223 : H12AffineEnvironment.transform 9 320 env50222 = env50223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env50222 == env50223) = true)

def env50224 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,8192,81,12636,65536,74030,65664,4417,12637,4096,476,74046,69649,12425,78190,4415,74110,81,79882,8204,74094,256,8201,0,4436]

theorem envBound50224 : H12AffineFastState.Bounded env50224 := by
  intro p hp
  have h : env50224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50223_50224 : H12AffineEnvironment.transform 8 340 env50223 = env50224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env50223 == env50224) = true)

def env50225 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,16,8192,81,8524,65536,74030,65664,337,8525,16,476,74046,65537,8345,74110,303,74110,81,75802,8204,74094,256,8201,0,324]

theorem envBound50225 : H12AffineFastState.Bounded env50225 := by
  intro p hp
  have h : env50225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50224_50225 : H12AffineEnvironment.transform 11 16 env50224 = env50225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env50224 == env50225) = true)

theorem identity50225 : scanCanonicalize (H12AffineFastState.compose env50225 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8230) := by decide +kernel

theorem selectedBound50225 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env50226 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,16,8192,81,8524,8230,264,8358,337,8525,16,476,280,8231,8345,344,303,344,81,2108,8204,328,256,8201,0,324]

theorem envBound50226 : H12AffineFastState.Bounded env50226 := by
  intro p hp
  have h : env50226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50225_50226 : H12AffineEnvironment.transform 15 8230 env50225 = env50226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8230 env50225 == env50226) = true)

def env50227 : List Nat := [2,4,8,0,32,64,128,256,324,320,2048,0,8192,65,8524,8230,264,8358,321,8525,0,460,264,8231,8329,328,303,328,65,2092,8204,328,256,8201,0,324]

theorem envBound50227 : H12AffineFastState.Bounded env50227 := by
  intro p hp
  have h : env50227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50226_50227 : H12AffineEnvironment.transform 3 0 env50226 = env50227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env50226 == env50227) = true)

theorem identity50227 : scanCanonicalize (H12AffineFastState.compose env50227 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 68) := by decide +kernel

theorem selectedBound50227 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50228 : List Nat := [2,4,8,0,32,64,128,256,324,320,2048,0,68,65,264,98,264,226,321,265,0,460,264,99,205,328,303,328,65,2092,72,328,256,77,0,324]

theorem envBound50228 : H12AffineFastState.Bounded env50228 := by
  intro p hp
  have h : env50228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50227_50228 : H12AffineEnvironment.transform 12 68 env50227 = env50228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 68 env50227 == env50228) = true)

theorem identity50228 : scanCanonicalize (H12AffineFastState.compose env50228 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound50228 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50229 : List Nat := [2,4,8,0,32,1,128,256,261,257,2048,0,5,0,264,35,264,163,256,265,0,397,264,34,140,265,303,265,0,2092,9,265,256,12,0,261]

theorem envBound50229 : H12AffineFastState.Bounded env50229 := by
  intro p hp
  have h : env50229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50228_50229 : H12AffineEnvironment.transform 5 1 env50228 = env50229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env50228 == env50229) = true)

theorem identity50229 : scanCanonicalize (H12AffineFastState.compose env50229 (packedSelected [0,3,7,8,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 416) := by decide +kernel

theorem selectedBound50229 : packedSelected [0,3,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env50230 : List Nat := [2,4,8,0,32,1,128,256,261,257,416,0,5,0,264,35,264,163,256,265,0,397,264,34,140,265,303,265,0,396,9,265,256,12,0,261]

theorem envBound50230 : H12AffineFastState.Bounded env50230 := by
  intro p hp
  have h : env50230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50229_50230 : H12AffineEnvironment.transform 10 416 env50229 = env50230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 416 env50229 == env50230) = true)

theorem identity50230 : scanCanonicalize (H12AffineFastState.compose env50230 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 170) := by decide +kernel

theorem selectedBound50230 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env50231 : List Nat := [2,4,8,0,32,1,128,170,175,171,10,0,5,0,162,35,162,163,170,163,0,39,162,34,140,163,133,163,0,38,9,163,170,12,0,175]

theorem envBound50231 : H12AffineFastState.Bounded env50231 := by
  intro p hp
  have h : env50231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50230_50231 : H12AffineEnvironment.transform 7 170 env50230 = env50231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 170 env50230 == env50231) = true)

theorem identity50231 : scanCanonicalize (H12AffineFastState.compose env50231 (packedSelected [0,2,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound50231 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env50232 : List Nat := [2,4,8,0,32,1,9,35,38,34,10,0,5,0,43,35,43,42,35,42,0,39,43,34,5,42,12,42,0,38,9,42,35,12,0,38]

theorem envBound50232 : H12AffineFastState.Bounded env50232 := by
  intro p hp
  have h : env50232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50231_50232 : H12AffineEnvironment.transform 6 9 env50231 = env50232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50231 == env50232) = true)

theorem identity50232 : scanCanonicalize (H12AffineFastState.compose env50232 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound50232 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env50233 : List Nat := [2,4,8,0,12,1,9,15,10,14,10,0,5,0,7,15,7,6,15,6,0,11,7,14,5,6,12,6,0,10,9,6,15,12,0,10]

theorem envBound50233 : H12AffineFastState.Bounded env50233 := by
  intro p hp
  have h : env50233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50232_50233 : H12AffineEnvironment.transform 4 12 env50232 = env50233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env50232 == env50233) = true)

def env50234 : List Nat := [2,4,8,1,32,64,128,256,325,320,2048,1,8192,64,8524,8230,264,8358,320,8525,1,461,265,8231,8328,329,303,329,64,2093,8204,328,256,8201,0,324]

theorem envBound50234 : H12AffineFastState.Bounded env50234 := by
  intro p hp
  have h : env50234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50226_50234 : H12AffineEnvironment.transform 3 1 env50226 = env50234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50226 == env50234) = true)

theorem identity50234 : scanCanonicalize (H12AffineFastState.compose env50234 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound50234 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50235 : List Nat := [2,4,8,1,32,64,128,256,325,320,2048,1,269,64,65,299,264,427,320,64,1,461,265,298,389,329,303,329,64,2093,257,328,256,260,0,324]

theorem envBound50235 : H12AffineFastState.Bounded env50235 := by
  intro p hp
  have h : env50235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50234_50235 : H12AffineEnvironment.transform 12 269 env50234 = env50235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env50234 == env50235) = true)

theorem identity50235 : scanCanonicalize (H12AffineFastState.compose env50235 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound50235 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50236 : List Nat := [2,4,5,1,32,64,128,256,325,320,2048,1,256,64,65,294,261,422,320,64,1,448,260,295,389,324,290,324,64,2080,257,325,256,260,0,324]

theorem envBound50236 : H12AffineFastState.Bounded env50236 := by
  intro p hp
  have h : env50236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50235_50236 : H12AffineEnvironment.transform 2 5 env50235 = env50236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env50235 == env50236) = true)

theorem identity50236 : scanCanonicalize (H12AffineFastState.compose env50236 (packedSelected [0,1,2,5,7,8,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 71) := by decide +kernel

theorem selectedBound50236 : packedSelected [0,1,2,5,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env50237 : List Nat := [2,4,5,1,32,64,128,256,325,320,71,1,256,64,65,294,261,422,320,64,1,448,260,295,389,324,290,324,64,103,257,325,256,260,0,324]

theorem envBound50237 : H12AffineFastState.Bounded env50237 := by
  intro p hp
  have h : env50237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50236_50237 : H12AffineEnvironment.transform 10 71 env50236 = env50237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 71 env50236 == env50237) = true)

theorem identity50237 : scanCanonicalize (H12AffineFastState.compose env50237 (packedSelected [0,3,5,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 99) := by decide +kernel

theorem selectedBound50237 : packedSelected [0,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env50238 : List Nat := [2,4,5,1,32,64,128,99,38,35,71,1,99,64,65,69,102,197,35,64,1,163,103,68,230,39,65,39,64,103,98,38,99,103,0,39]

theorem envBound50238 : H12AffineFastState.Bounded env50238 := by
  intro p hp
  have h : env50238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50237_50238 : H12AffineEnvironment.transform 7 99 env50237 = env50238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 99 env50237 == env50238) = true)

theorem identity50238 : scanCanonicalize (H12AffineFastState.compose env50238 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound50238 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env50239 : List Nat := [2,4,5,1,32,3,128,32,38,35,4,1,32,3,2,6,37,134,35,3,1,163,36,7,165,39,2,39,3,36,33,38,32,36,0,39]

theorem envBound50239 : H12AffineFastState.Bounded env50239 := by
  intro p hp
  have h : env50239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50238_50239 : H12AffineEnvironment.transform 5 3 env50238 = env50239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env50238 == env50239) = true)

theorem identity50239 : scanCanonicalize (H12AffineFastState.compose env50239 (packedSelected [1,5] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound50239 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env50240 : List Nat := [2,0,1,1,32,3,128,32,34,35,0,1,32,3,2,2,33,130,35,3,1,163,32,3,161,35,2,35,3,32,33,34,32,32,0,35]

theorem envBound50240 : H12AffineFastState.Bounded env50240 := by
  intro p hp
  have h : env50240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50239_50240 : H12AffineEnvironment.transform 1 0 env50239 = env50240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env50239 == env50240) = true)

theorem identity50240 : scanCanonicalize (H12AffineFastState.compose env50240 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound50240 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50241 : List Nat := [2,0,1,1,32,3,34,32,34,35,0,1,32,3,2,2,33,32,35,3,1,1,32,3,3,35,2,35,3,32,33,34,32,32,0,35]

theorem envBound50241 : H12AffineFastState.Bounded env50241 := by
  intro p hp
  have h : env50241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50240_50241 : H12AffineEnvironment.transform 6 34 env50240 = env50241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env50240 == env50241) = true)

theorem identity50241 : scanCanonicalize (H12AffineFastState.compose env50241 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound50241 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50242 : List Nat := [2,0,1,1,2,3,0,2,0,1,0,1,2,3,2,2,3,2,1,3,1,1,2,3,3,1,2,1,3,2,3,0,2,2,0,1]

theorem envBound50242 : H12AffineFastState.Bounded env50242 := by
  intro p hp
  have h : env50242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50241_50242 : H12AffineEnvironment.transform 4 2 env50241 = env50242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env50241 == env50242) = true)

theorem identity50242 : scanCanonicalize (H12AffineFastState.compose env50242 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound50242 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env50243 : List Nat := [1,0,1,1,1,0,0,1,0,1,0,1,1,0,1,1,0,1,1,0,1,1,1,0,0,1,1,1,0,1,0,0,1,1,0,1]

theorem envBound50243 : H12AffineFastState.Bounded env50243 := by
  intro p hp
  have h : env50243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50242_50243 : H12AffineEnvironment.transform 0 1 env50242 = env50243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env50242 == env50243) = true)

def env50244 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,17,8192,81,8525,65536,74030,65664,336,8524,17,476,74046,65536,8344,74111,302,74110,81,75803,8204,74094,256,8201,0,325]

theorem envBound50244 : H12AffineFastState.Bounded env50244 := by
  intro p hp
  have h : env50244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50224_50244 : H12AffineEnvironment.transform 11 17 env50224 = env50244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env50224 == env50244) = true)

theorem identity50244 : scanCanonicalize (H12AffineFastState.compose env50244 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 110) := by decide +kernel

theorem selectedBound50244 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env50245 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,17,8192,81,8525,110,8512,238,336,8524,17,476,8528,110,8344,8465,302,8464,81,10357,8204,8448,256,8201,0,325]

theorem envBound50245 : H12AffineFastState.Bounded env50245 := by
  intro p hp
  have h : env50245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50244_50245 : H12AffineEnvironment.transform 15 110 env50244 = env50245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 110 env50244 == env50245) = true)

def env50246 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,17,256,81,77,110,64,238,336,76,17,476,80,110,408,17,302,16,81,2421,268,0,256,265,0,325]

theorem envBound50246 : H12AffineFastState.Bounded env50246 := by
  intro p hp
  have h : env50246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50245_50246 : H12AffineEnvironment.transform 12 256 env50245 = env50246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 256 env50245 == env50246) = true)

theorem identity50246 : scanCanonicalize (H12AffineFastState.compose env50246 (packedSelected [4,9,16] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound50246 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50247 : List Nat := [2,4,5,16,32,64,128,256,340,320,2048,17,256,81,64,99,64,227,336,65,17,465,80,99,405,17,291,16,81,2421,257,0,256,260,0,325]

theorem envBound50247 : H12AffineFastState.Bounded env50247 := by
  intro p hp
  have h : env50247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50246_50247 : H12AffineEnvironment.transform 2 5 env50246 = env50247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env50246 == env50247) = true)

theorem identity50247 : scanCanonicalize (H12AffineFastState.compose env50247 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound50247 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50248 : List Nat := [2,4,5,16,32,0,128,256,276,256,2048,17,256,17,0,35,0,163,272,1,17,401,16,35,405,17,291,16,17,2357,257,0,256,260,0,261]

theorem envBound50248 : H12AffineFastState.Bounded env50248 := by
  intro p hp
  have h : env50248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50247_50248 : H12AffineEnvironment.transform 5 0 env50247 = env50248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env50247 == env50248) = true)

theorem identity50248 : scanCanonicalize (H12AffineFastState.compose env50248 (packedSelected [0,3,5,7,8,10,11,12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 160) := by decide +kernel

theorem selectedBound50248 : packedSelected [0,3,5,7,8,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env50249 : List Nat := [2,4,5,16,32,0,128,160,180,160,2048,17,160,17,0,35,0,163,176,1,17,49,16,35,53,17,131,16,17,2197,161,0,160,164,0,165]

theorem envBound50249 : H12AffineFastState.Bounded env50249 := by
  intro p hp
  have h : env50249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50248_50249 : H12AffineEnvironment.transform 7 160 env50248 = env50249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 160 env50248 == env50249) = true)

theorem identity50249 : scanCanonicalize (H12AffineFastState.compose env50249 (packedSelected [2,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50249 : packedSelected [2,5,10] rootPS < 2^1333 := by decide +kernel

def env50250 : List Nat := [2,4,5,16,1,0,128,129,149,129,2048,17,129,17,0,2,0,130,145,1,17,16,16,2,20,17,131,16,17,2197,128,0,129,133,0,132]

theorem envBound50250 : H12AffineFastState.Bounded env50250 := by
  intro p hp
  have h : env50250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50249_50250 : H12AffineEnvironment.transform 4 1 env50249 = env50250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50249 == env50250) = true)

def env50251 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,17,257,81,76,110,65,238,336,77,17,476,81,110,409,16,302,17,81,2420,269,1,256,264,0,325]

theorem envBound50251 : H12AffineFastState.Bounded env50251 := by
  intro p hp
  have h : env50251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50245_50251 : H12AffineEnvironment.transform 12 257 env50245 = env50251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 257 env50245 == env50251) = true)

theorem identity50251 : scanCanonicalize (H12AffineFastState.compose env50251 (packedSelected [4,9,16] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound50251 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50252 : List Nat := [2,4,8,12,32,64,128,256,328,320,2048,13,257,77,76,110,65,238,332,77,13,448,77,110,389,12,302,13,77,2408,269,1,256,264,0,325]

theorem envBound50252 : H12AffineFastState.Bounded env50252 := by
  intro p hp
  have h : env50252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50251_50252 : H12AffineEnvironment.transform 3 12 env50251 = env50252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env50251 == env50252) = true)

theorem identity50252 : scanCanonicalize (H12AffineFastState.compose env50252 (packedSelected [0,1,2,3,7,8,12,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 99) := by decide +kernel

theorem selectedBound50252 : packedSelected [0,1,2,3,7,8,12,15,18] rootPS < 2^1333 := by decide +kernel

def env50253 : List Nat := [2,4,8,12,32,64,128,99,43,35,2048,13,98,77,76,110,65,238,47,77,13,163,77,110,230,12,77,13,77,2059,110,1,99,107,0,38]

theorem envBound50253 : H12AffineFastState.Bounded env50253 := by
  intro p hp
  have h : env50253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50252_50253 : H12AffineEnvironment.transform 7 99 env50252 = env50253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 99 env50252 == env50253) = true)

theorem identity50253 : scanCanonicalize (H12AffineFastState.compose env50253 (packedSelected [1,13,15] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound50253 : packedSelected [1,13,15] rootPS < 2^1333 := by decide +kernel

def env50254 : List Nat := [2,4,8,12,32,0,128,35,43,35,2048,13,34,13,12,46,1,174,47,13,13,163,13,46,166,12,13,13,13,2059,46,1,35,43,0,38]

theorem envBound50254 : H12AffineFastState.Bounded env50254 := by
  intro p hp
  have h : env50254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50253_50254 : H12AffineEnvironment.transform 5 0 env50253 = env50254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env50253 == env50254) = true)

def env50255 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,8192,81,12636,65536,74030,65664,4417,12637,4096,476,74046,69649,12425,78190,4415,74110,81,79882,8204,74094,256,8201,0,4437]

theorem envBound50255 : H12AffineFastState.Bounded env50255 := by
  intro p hp
  have h : env50255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50223_50255 : H12AffineEnvironment.transform 8 341 env50223 = env50255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env50223 == env50255) = true)

def env50256 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,16,8192,81,8524,65536,74030,65664,337,8525,16,476,74046,65537,8345,74110,303,74110,81,75802,8204,74094,256,8201,0,325]

theorem envBound50256 : H12AffineFastState.Bounded env50256 := by
  intro p hp
  have h : env50256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50255_50256 : H12AffineEnvironment.transform 11 16 env50255 = env50256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env50255 == env50256) = true)

theorem identity50256 : scanCanonicalize (H12AffineFastState.compose env50256 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound50256 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env50257 : List Nat := [2,4,8,16,32,64,128,9,92,73,2048,16,8192,81,8261,65536,73767,65664,88,8260,16,213,73783,65537,8345,73847,38,73847,81,75802,8204,73831,9,8201,0,76]

theorem envBound50257 : H12AffineFastState.Bounded env50257 := by
  intro p hp
  have h : env50257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50256_50257 : H12AffineEnvironment.transform 7 9 env50256 = env50257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env50256 == env50257) = true)

def env50258 : List Nat := [2,4,8,0,32,64,128,9,76,73,2048,0,8192,65,8261,65536,73767,65664,72,8260,0,197,73767,65537,8329,73831,38,73831,65,75786,8204,73831,9,8201,0,76]

theorem envBound50258 : H12AffineFastState.Bounded env50258 := by
  intro p hp
  have h : env50258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50257_50258 : H12AffineEnvironment.transform 3 0 env50257 = env50258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env50257 == env50258) = true)

theorem identity50258 : scanCanonicalize (H12AffineFastState.compose env50258 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound50258 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50259 : List Nat := [2,4,8,0,32,64,128,9,76,73,2048,0,8192,65,8261,98,8261,226,72,8260,0,197,8261,99,8329,8197,38,8197,65,10344,8204,8197,9,8201,0,76]

theorem envBound50259 : H12AffineFastState.Bounded env50259 := by
  intro p hp
  have h : env50259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50258_50259 : H12AffineEnvironment.transform 15 98 env50258 = env50259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env50258 == env50259) = true)

theorem identity50259 : scanCanonicalize (H12AffineFastState.compose env50259 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound50259 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50260 : List Nat := [2,4,8,0,32,1,128,9,13,8,2048,0,8192,0,8196,35,8196,163,9,8197,0,132,8196,34,8329,8197,38,8197,0,10281,8204,8197,9,8201,0,13]

theorem envBound50260 : H12AffineFastState.Bounded env50260 := by
  intro p hp
  have h : env50260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50259_50260 : H12AffineEnvironment.transform 5 1 env50259 = env50260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env50259 == env50260) = true)

theorem identity50260 : scanCanonicalize (H12AffineFastState.compose env50260 (packedSelected [0,3,7,8,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 168) := by decide +kernel

theorem selectedBound50260 : packedSelected [0,3,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env50261 : List Nat := [2,4,8,0,32,1,128,9,13,8,168,0,8192,0,8196,35,8196,163,9,8197,0,132,8196,34,8329,8197,38,8197,0,8321,8204,8197,9,8201,0,13]

theorem envBound50261 : H12AffineFastState.Bounded env50261 := by
  intro p hp
  have h : env50261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50260_50261 : H12AffineEnvironment.transform 10 168 env50260 = env50261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env50260 == env50261) = true)

theorem identity50261 : scanCanonicalize (H12AffineFastState.compose env50261 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 167) := by decide +kernel

theorem selectedBound50261 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env50262 : List Nat := [2,4,8,0,32,1,128,9,13,8,168,0,167,0,163,35,163,163,9,162,0,132,163,34,46,162,38,162,0,38,171,162,9,174,0,13]

theorem envBound50262 : H12AffineFastState.Bounded env50262 := by
  intro p hp
  have h : env50262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50261_50262 : H12AffineEnvironment.transform 12 167 env50261 = env50262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 167 env50261 == env50262) = true)

theorem identity50262 : scanCanonicalize (H12AffineFastState.compose env50262 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound50262 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env50263 : List Nat := [2,4,8,0,10,1,128,9,13,8,130,0,141,0,137,9,137,137,9,136,0,132,137,8,4,136,12,136,0,12,129,136,9,132,0,13]

theorem envBound50263 : H12AffineFastState.Bounded env50263 := by
  intro p hp
  have h : env50263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50262_50263 : H12AffineEnvironment.transform 4 10 env50262 = env50263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env50262 == env50263) = true)

theorem identity50263 : scanCanonicalize (H12AffineFastState.compose env50263 (packedSelected [0,2,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound50263 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env50264 : List Nat := [2,3,8,0,10,1,128,9,10,8,130,0,138,0,137,9,137,137,9,136,0,131,137,8,3,136,11,136,0,11,129,136,9,131,0,10]

theorem envBound50264 : H12AffineFastState.Bounded env50264 := by
  intro p hp
  have h : env50264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50263_50264 : H12AffineEnvironment.transform 1 3 env50263 = env50264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env50263 == env50264) = true)

theorem identity50264 : scanCanonicalize (H12AffineFastState.compose env50264 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound50264 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50265 : List Nat := [2,3,8,0,10,1,8,9,10,8,10,0,2,0,1,9,1,1,9,0,0,11,1,8,3,0,11,0,0,11,9,0,9,11,0,10]

theorem envBound50265 : H12AffineFastState.Bounded env50265 := by
  intro p hp
  have h : env50265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50264_50265 : H12AffineEnvironment.transform 6 8 env50264 = env50265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50264 == env50265) = true)

theorem identity50265 : scanCanonicalize (H12AffineFastState.compose env50265 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound50265 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50266 : List Nat := [2,3,3,0,1,1,3,2,1,3,1,0,2,0,1,2,1,1,2,0,0,0,1,3,3,0,0,0,0,0,2,0,2,0,0,1]

theorem envBound50266 : H12AffineFastState.Bounded env50266 := by
  intro p hp
  have h : env50266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50265_50266 : H12AffineEnvironment.transform 2 3 env50265 = env50266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env50265 == env50266) = true)

def env50267 : List Nat := [2,4,8,1,32,64,128,9,77,73,2048,1,8192,64,8261,65536,73767,65664,73,8260,1,196,73766,65537,8328,73830,38,73830,64,75787,8204,73831,9,8201,0,76]

theorem envBound50267 : H12AffineFastState.Bounded env50267 := by
  intro p hp
  have h : env50267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50257_50267 : H12AffineEnvironment.transform 3 1 env50257 = env50267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50257 == env50267) = true)

theorem identity50267 : scanCanonicalize (H12AffineFastState.compose env50267 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4) := by decide +kernel

theorem selectedBound50267 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50268 : List Nat := [2,4,8,1,32,64,128,9,77,73,2048,1,4,64,65,65536,65571,65664,73,64,1,196,65570,65537,140,65634,38,65634,64,67599,8,65635,9,13,0,76]

theorem envBound50268 : H12AffineFastState.Bounded env50268 := by
  intro p hp
  have h : env50268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50267_50268 : H12AffineEnvironment.transform 12 4 env50267 = env50268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4 env50267 == env50268) = true)

theorem identity50268 : scanCanonicalize (H12AffineFastState.compose env50268 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 47) := by decide +kernel

theorem selectedBound50268 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50269 : List Nat := [2,4,8,1,32,64,128,9,77,73,2048,1,4,64,65,47,12,175,73,64,1,196,13,46,140,77,38,77,64,2080,8,76,9,13,0,76]

theorem envBound50269 : H12AffineFastState.Bounded env50269 := by
  intro p hp
  have h : env50269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50268_50269 : H12AffineEnvironment.transform 15 47 env50268 = env50269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 47 env50268 == env50269) = true)

theorem identity50269 : scanCanonicalize (H12AffineFastState.compose env50269 (packedSelected [0,1,2,5,7,8,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 71) := by decide +kernel

theorem selectedBound50269 : packedSelected [0,1,2,5,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env50270 : List Nat := [2,4,8,1,32,64,128,9,77,73,71,1,4,64,65,47,12,175,73,64,1,196,13,46,140,77,38,77,64,103,8,76,9,13,0,76]

theorem envBound50270 : H12AffineFastState.Bounded env50270 := by
  intro p hp
  have h : env50270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50269_50270 : H12AffineEnvironment.transform 10 71 env50269 = env50270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 71 env50269 == env50270) = true)

theorem identity50270 : scanCanonicalize (H12AffineFastState.compose env50270 (packedSelected [1,2,3,5,12] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound50270 : packedSelected [1,2,3,5,12] rootPS < 2^1333 := by decide +kernel

def env50271 : List Nat := [2,4,8,1,13,64,128,9,77,73,71,1,4,64,65,2,12,130,73,64,1,196,13,3,140,77,11,77,64,74,8,76,9,13,0,76]

theorem envBound50271 : H12AffineFastState.Bounded env50271 := by
  intro p hp
  have h : env50271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50270_50271 : H12AffineEnvironment.transform 4 13 env50270 = env50271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env50270 == env50271) = true)

theorem identity50271 : scanCanonicalize (H12AffineFastState.compose env50271 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 68) := by decide +kernel

theorem selectedBound50271 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50272 : List Nat := [2,4,8,1,13,64,68,9,77,73,71,1,4,64,65,2,12,70,73,64,1,0,13,3,72,77,11,77,64,74,8,76,9,13,0,76]

theorem envBound50272 : H12AffineFastState.Bounded env50272 := by
  intro p hp
  have h : env50272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50271_50272 : H12AffineEnvironment.transform 6 68 env50271 = env50272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 68 env50271 == env50272) = true)

theorem identity50272 : scanCanonicalize (H12AffineFastState.compose env50272 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound50272 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50273 : List Nat := [2,4,8,1,13,6,2,9,11,15,1,1,4,6,7,2,12,0,15,6,1,0,13,3,14,11,11,11,6,12,8,10,9,13,0,10]

theorem envBound50273 : H12AffineFastState.Bounded env50273 := by
  intro p hp
  have h : env50273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50272_50273 : H12AffineEnvironment.transform 5 6 env50272 = env50273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env50272 == env50273) = true)

theorem identity50273 : scanCanonicalize (H12AffineFastState.compose env50273 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound50273 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50274 : List Nat := [2,1,8,1,8,3,2,9,11,10,1,1,1,3,2,2,9,0,10,3,1,0,8,3,11,11,11,11,3,9,8,10,9,8,0,10]

theorem envBound50274 : H12AffineFastState.Bounded env50274 := by
  intro p hp
  have h : env50274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50273_50274 : H12AffineEnvironment.transform 1 1 env50273 = env50274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env50273 == env50274) = true)

theorem identity50274 : scanCanonicalize (H12AffineFastState.compose env50274 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound50274 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50275 : List Nat := [0,1,8,1,8,1,0,9,9,8,1,1,1,1,0,0,9,0,8,1,1,0,8,1,9,9,9,9,1,9,8,8,9,8,0,8]

theorem envBound50275 : H12AffineFastState.Bounded env50275 := by
  intro p hp
  have h : env50275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50274_50275 : H12AffineEnvironment.transform 0 0 env50274 = env50275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env50274 == env50275) = true)

theorem identity50275 : scanCanonicalize (H12AffineFastState.compose env50275 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound50275 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env50276 : List Nat := [0,1,0,1,0,1,0,1,1,0,1,1,1,1,0,0,1,0,0,1,1,0,0,1,1,1,1,1,1,1,0,0,1,0,0,0]

theorem envBound50276 : H12AffineFastState.Bounded env50276 := by
  intro p hp
  have h : env50276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50275_50276 : H12AffineEnvironment.transform 2 0 env50275 = env50276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env50275 == env50276) = true)

def env50277 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,17,8192,81,8525,65536,74030,65664,336,8524,17,476,74046,65536,8344,74111,302,74110,81,75803,8204,74094,256,8201,0,324]

theorem envBound50277 : H12AffineFastState.Bounded env50277 := by
  intro p hp
  have h : env50277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50255_50277 : H12AffineEnvironment.transform 11 17 env50255 = env50277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env50255 == env50277) = true)

theorem identity50277 : scanCanonicalize (H12AffineFastState.compose env50277 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 321) := by decide +kernel

theorem selectedBound50277 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env50278 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,17,321,81,12,65536,65647,65664,336,13,17,476,65663,65536,473,65598,302,65599,81,67930,333,65583,256,328,0,324]

theorem envBound50278 : H12AffineFastState.Bounded env50278 := by
  intro p hp
  have h : env50278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50277_50278 : H12AffineEnvironment.transform 12 321 env50277 = env50278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 321 env50277 == env50278) = true)

def env50279 : List Nat := [2,4,8,16,32,64,128,8,93,72,2048,17,73,81,12,65536,65647,65664,88,13,17,212,65663,65536,209,65598,38,65599,81,67666,69,65583,8,64,0,76]

theorem envBound50279 : H12AffineFastState.Bounded env50279 := by
  intro p hp
  have h : env50279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50278_50279 : H12AffineEnvironment.transform 7 8 env50278 = env50279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env50278 == env50279) = true)

theorem identity50279 : scanCanonicalize (H12AffineFastState.compose env50279 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound50279 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50280 : List Nat := [2,4,8,16,32,64,128,8,93,72,2048,17,73,81,12,99,12,227,88,13,17,212,28,99,209,93,38,92,81,2097,69,76,8,64,0,76]

theorem envBound50280 : H12AffineFastState.Bounded env50280 := by
  intro p hp
  have h : env50280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50279_50280 : H12AffineEnvironment.transform 15 99 env50279 = env50280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env50279 == env50280) = true)

theorem identity50280 : scanCanonicalize (H12AffineFastState.compose env50280 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound50280 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50281 : List Nat := [2,4,8,16,32,0,128,8,29,8,2048,17,9,17,12,35,12,163,24,13,17,148,28,35,145,29,38,28,17,2097,5,12,8,0,0,12]

theorem envBound50281 : H12AffineFastState.Bounded env50281 := by
  intro p hp
  have h : env50281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50280_50281 : H12AffineEnvironment.transform 5 0 env50280 = env50281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env50280 == env50281) = true)

theorem identity50281 : scanCanonicalize (H12AffineFastState.compose env50281 (packedSelected [0,1,7,10,11,13] rootPS)) = affineNative (2^(6+1) ^^^ 30) := by decide +kernel

theorem selectedBound50281 : packedSelected [0,1,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env50282 : List Nat := [2,4,8,16,32,0,30,8,29,8,2048,17,9,17,12,35,12,61,24,13,17,10,28,35,15,29,38,28,17,2097,5,12,8,0,0,12]

theorem envBound50282 : H12AffineFastState.Bounded env50282 := by
  intro p hp
  have h : env50282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50281_50282 : H12AffineEnvironment.transform 6 30 env50281 = env50282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 30 env50281 == env50282) = true)

theorem identity50282 : scanCanonicalize (H12AffineFastState.compose env50282 (packedSelected [0,1,5,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound50282 : packedSelected [0,1,5,7,11] rootPS < 2^1333 := by decide +kernel

def env50283 : List Nat := [2,4,8,16,32,0,30,8,29,8,58,17,9,17,12,35,12,61,24,13,17,10,28,35,15,29,38,28,17,11,5,12,8,0,0,12]

theorem envBound50283 : H12AffineFastState.Bounded env50283 := by
  intro p hp
  have h : env50283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50282_50283 : H12AffineEnvironment.transform 10 58 env50282 = env50283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env50282 == env50283) = true)

theorem identity50283 : scanCanonicalize (H12AffineFastState.compose env50283 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound50283 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50284 : List Nat := [2,4,8,6,32,0,8,8,11,8,44,7,9,7,12,35,12,43,14,13,7,10,10,35,15,11,38,10,7,11,5,12,8,0,0,12]

theorem envBound50284 : H12AffineFastState.Bounded env50284 := by
  intro p hp
  have h : env50284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50283_50284 : H12AffineEnvironment.transform 3 6 env50283 = env50284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env50283 == env50284) = true)

theorem identity50284 : scanCanonicalize (H12AffineFastState.compose env50284 (packedSelected [0,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound50284 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env50285 : List Nat := [2,4,8,6,12,0,8,8,11,8,0,7,9,7,12,15,12,7,14,13,7,10,10,15,15,11,10,10,7,11,5,12,8,0,0,12]

theorem envBound50285 : H12AffineFastState.Bounded env50285 := by
  intro p hp
  have h : env50285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50284_50285 : H12AffineEnvironment.transform 4 12 env50284 = env50285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env50284 == env50285) = true)

theorem identity50285 : scanCanonicalize (H12AffineFastState.compose env50285 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50285 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50286 : List Nat := [2,2,8,0,10,0,8,8,11,8,0,1,9,1,10,9,10,1,8,11,1,10,10,9,9,11,10,10,1,11,3,10,8,0,0,10]

theorem envBound50286 : H12AffineFastState.Bounded env50286 := by
  intro p hp
  have h : env50286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50285_50286 : H12AffineEnvironment.transform 1 2 env50285 = env50286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50285 == env50286) = true)

theorem identity50286 : scanCanonicalize (H12AffineFastState.compose env50286 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound50286 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50287 : List Nat := [2,2,0,0,2,0,0,0,3,0,0,1,1,1,2,1,2,1,0,3,1,2,2,1,1,3,2,2,1,3,3,2,0,0,0,2]

theorem envBound50287 : H12AffineFastState.Bounded env50287 := by
  intro p hp
  have h : env50287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50286_50287 : H12AffineEnvironment.transform 2 0 env50286 = env50287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env50286 == env50287) = true)

theorem identity50287 : scanCanonicalize (H12AffineFastState.compose env50287 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound50287 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env50288 : List Nat := [0,0,0,0,0,0,0,0,1,0,0,1,1,1,0,1,0,1,0,1,1,0,0,1,1,1,0,0,1,1,1,0,0,0,0,0]

theorem envBound50288 : H12AffineFastState.Bounded env50288 := by
  intro p hp
  have h : env50288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50287_50288 : H12AffineEnvironment.transform 0 0 env50287 = env50288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env50287 == env50288) = true)

def env50289 : List Nat := [2,4,8,16,32,64,128,9,92,73,2048,17,72,81,12,65536,65647,65664,89,13,17,213,65663,65536,208,65598,39,65599,81,67667,68,65583,9,65,0,77]

theorem envBound50289 : H12AffineFastState.Bounded env50289 := by
  intro p hp
  have h : env50289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50278_50289 : H12AffineEnvironment.transform 7 9 env50278 = env50289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env50278 == env50289) = true)

theorem identity50289 : scanCanonicalize (H12AffineFastState.compose env50289 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound50289 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50290 : List Nat := [2,4,8,16,32,64,128,9,92,73,2048,17,72,81,12,114,29,242,89,13,17,213,13,114,208,76,39,77,81,2081,68,93,9,65,0,77]

theorem envBound50290 : H12AffineFastState.Bounded env50290 := by
  intro p hp
  have h : env50290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50289_50290 : H12AffineEnvironment.transform 15 114 env50289 = env50290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env50289 == env50290) = true)

theorem identity50290 : scanCanonicalize (H12AffineFastState.compose env50290 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 22) := by decide +kernel

theorem selectedBound50290 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env50291 : List Nat := [2,4,8,16,32,64,128,9,92,73,22,17,72,81,12,114,29,242,89,13,17,213,13,114,208,76,39,77,81,55,68,93,9,65,0,77]

theorem envBound50291 : H12AffineFastState.Bounded env50291 := by
  intro p hp
  have h : env50291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50290_50291 : H12AffineEnvironment.transform 10 22 env50290 = env50291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 22 env50290 == env50291) = true)

theorem identity50291 : scanCanonicalize (H12AffineFastState.compose env50291 (packedSelected [0,1,2,5,7,10,12,13,15,20] rootPS)) = affineNative (2^(5+1) ^^^ 55) := by decide +kernel

theorem selectedBound50291 : packedSelected [0,1,2,5,7,10,12,13,15,20] rootPS < 2^1333 := by decide +kernel

def env50292 : List Nat := [2,4,8,16,32,55,128,9,43,62,22,17,63,38,12,5,29,133,46,13,17,162,13,5,167,59,39,58,38,55,51,42,9,54,0,58]

theorem envBound50292 : H12AffineFastState.Bounded env50292 := by
  intro p hp
  have h : env50292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50291_50292 : H12AffineEnvironment.transform 5 55 env50291 = env50292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 55 env50291 == env50292) = true)

theorem identity50292 : scanCanonicalize (H12AffineFastState.compose env50292 (packedSelected [0,2,4,5,8,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound50292 : packedSelected [0,2,4,5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env50293 : List Nat := [2,4,8,16,32,55,14,9,43,62,22,17,63,38,12,5,29,11,46,13,17,44,13,5,41,59,39,58,38,55,51,42,9,54,0,58]

theorem envBound50293 : H12AffineFastState.Bounded env50293 := by
  intro p hp
  have h : env50293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50292_50293 : H12AffineEnvironment.transform 6 14 env50292 = env50293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env50292 == env50293) = true)

theorem identity50293 : scanCanonicalize (H12AffineFastState.compose env50293 (packedSelected [2,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound50293 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env50294 : List Nat := [2,4,8,11,32,44,14,9,43,37,13,10,36,38,12,5,6,11,46,13,10,44,13,5,41,32,39,33,38,44,40,42,9,45,0,33]

theorem envBound50294 : H12AffineFastState.Bounded env50294 := by
  intro p hp
  have h : env50294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50293_50294 : H12AffineEnvironment.transform 3 11 env50293 = env50294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env50293 == env50294) = true)

theorem identity50294 : scanCanonicalize (H12AffineFastState.compose env50294 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound50294 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50295 : List Nat := [2,4,4,7,32,32,2,5,39,37,1,6,36,38,0,5,6,7,34,1,6,32,1,5,37,32,39,33,38,32,36,38,5,33,0,33]

theorem envBound50295 : H12AffineFastState.Bounded env50295 := by
  intro p hp
  have h : env50295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50294_50295 : H12AffineEnvironment.transform 2 4 env50294 = env50295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env50294 == env50295) = true)

def env50296 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65665,4417,13341,4096,476,74046,69649,13769,78894,4414,74814,1297,81226,8204,74798,256,8201,1344,5952]

theorem envBound50296 : H12AffineFastState.Bounded env50296 := by
  intro p hp
  have h : env50296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50221_50296 : H12AffineEnvironment.transform 17 65665 env50221 = env50296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env50221 == env50296) = true)

theorem identity50296 : scanCanonicalize (H12AffineFastState.compose env50296 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound50296 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,9245,65536,74862,65665,320,9244,1,476,74046,65552,9672,74799,319,74814,1297,77131,8204,74798,256,8201,1344,1857]

theorem envBound50297 : H12AffineFastState.Bounded env50297 := by
  intro p hp
  have h : env50297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50296_50297 : H12AffineEnvironment.transform 11 1 env50296 = env50297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env50296 == env50297) = true)

def env50298 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,8192,1297,9245,65536,74862,65665,320,9244,1,476,74046,65552,9672,74799,319,74814,1297,77131,8204,74798,256,8201,1344,1045]

theorem envBound50298 : H12AffineFastState.Bounded env50298 := by
  intro p hp
  have h : env50298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50297_50298 : H12AffineEnvironment.transform 8 340 env50297 = env50298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env50297 == env50298) = true)

def env50299 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,1,8192,1281,9229,65536,74862,65665,320,9228,1,460,74030,65536,9672,74799,303,74798,1281,77131,8204,74798,256,8201,1344,1029]

theorem envBound50299 : H12AffineFastState.Bounded env50299 := by
  intro p hp
  have h : env50299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50298_50299 : H12AffineEnvironment.transform 3 0 env50298 = env50299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env50298 == env50299) = true)

theorem identity50299 : scanCanonicalize (H12AffineFastState.compose env50299 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 110) := by decide +kernel

theorem selectedBound50299 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env50300 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,1,8192,1281,9229,110,9216,239,320,9228,1,460,8512,110,9672,9281,303,9280,1281,11557,8204,9280,256,8201,1344,1029]

theorem envBound50300 : H12AffineFastState.Bounded env50300 := by
  intro p hp
  have h : env50300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50299_50300 : H12AffineEnvironment.transform 15 110 env50299 = env50300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 110 env50299 == env50300) = true)

def env50301 : List Nat := [2,4,8,0,32,64,128,256,324,72,2048,1,8192,329,8261,110,8264,239,320,8260,1,460,8512,110,8576,8201,303,8200,329,10605,8204,8200,256,8201,264,77]

theorem envBound50301 : H12AffineFastState.Bounded env50301 := by
  intro p hp
  have h : env50301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50300_50301 : H12AffineEnvironment.transform 9 72 env50300 = env50301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 72 env50300 == env50301) = true)

theorem identity50301 : scanCanonicalize (H12AffineFastState.compose env50301 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound50301 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50302 : List Nat := [2,4,8,0,32,13,128,256,265,5,2048,1,8192,260,8200,35,8197,162,269,8201,1,385,8461,35,8576,8201,303,8200,260,10528,8204,8200,256,8201,264,0]

theorem envBound50302 : H12AffineFastState.Bounded env50302 := by
  intro p hp
  have h : env50302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50301_50302 : H12AffineEnvironment.transform 5 13 env50301 = env50302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env50301 == env50302) = true)

theorem identity50302 : scanCanonicalize (H12AffineFastState.compose env50302 (packedSelected [1,2,4,5,9,10,12,15,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound50302 : packedSelected [1,2,4,5,9,10,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env50303 : List Nat := [2,4,8,0,32,13,128,256,265,5,2048,1,2056,260,2048,35,2061,162,269,2049,1,385,2309,35,2440,2049,303,2048,260,296,2052,2048,256,2049,264,0]

end H12CloudChart2