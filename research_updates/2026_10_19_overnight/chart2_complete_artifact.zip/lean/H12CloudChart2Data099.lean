import H12CloudChart2Data098

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env24298 : List Nat := [2,4,8,16,27,10,18,31,26,1024,26,1039,18,1038,1,24,1039,27,1025,0,1038,1,16,24,8,10,26,1038,1038,27,1024,26,31,1,1039,26]

theorem envBound24298 : H12AffineFastState.Bounded env24298 := by
  intro p hp
  have h : env24298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24297_24298 : H12AffineEnvironment.transform 4 27 env24297 = env24298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env24297 == env24298) = true)

def leafEnv24298 : List Nat := [2,4,8,16,27,10,18,31,26,1024,26,1039,18,1038,1,24,1039,27,1025,0,1038,1,16,24,1025,8,1,10,26,1038,1038,27,1024,26,31,1,4,2,1039,26,0,1039,1]

def active24298 : List Nat := [0,1,2,3,9]

def tree24298 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24298 : H12WitnessSearch.Good tree24298 := H12GlobalWitnessIndex.good

theorem leafIdentity24298 : H12AffineFastState.composeSystem env24298 rootObs = leafEnv24298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24298 rootObs == leafEnv24298) = true)

theorem terminalChecked24298 : H12PackedTerminal.terminalCheckFast leafEnv24298 active24298 tree24298 = true := by decide +kernel

def env24299 : List Nat := [2,4,8,16,32,64,89,85,81,1024,80,1093,88,1076,112,35,1093,81,1137,113,1076,1,96,82,9,48,80,1092,1092,81,1024,81,37,112,1077,81]

theorem envBound24299 : H12AffineFastState.Bounded env24299 := by
  intro p hp
  have h : env24299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24295_24299 : H12AffineEnvironment.transform 6 89 env24295 = env24299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env24295 == env24299) = true)

theorem identity24299 : scanCanonicalize (H12AffineFastState.compose env24299 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 126) := by decide +kernel

theorem selectedBound24299 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24300 : List Nat := [2,4,8,16,32,64,89,85,81,126,80,59,88,74,112,35,59,81,15,113,74,1,96,82,9,48,80,58,58,81,126,81,37,112,75,81]

theorem envBound24300 : H12AffineFastState.Bounded env24300 := by
  intro p hp
  have h : env24300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24299_24300 : H12AffineEnvironment.transform 9 126 env24299 = env24300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 126 env24299 == env24300) = true)

def leafEnv24300 : List Nat := [2,4,8,16,32,64,89,85,81,126,80,59,88,74,112,35,59,81,15,113,74,1,96,82,15,9,1,48,80,58,58,81,126,81,37,112,116,115,75,81,0,75,1]

def active24300 : List Nat := [0,1,2,3,4,5]

def tree24300 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24300 : H12WitnessSearch.Good tree24300 := H12GlobalWitnessIndex.good

theorem leafIdentity24300 : H12AffineFastState.composeSystem env24300 rootObs = leafEnv24300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24300 rootObs == leafEnv24300) = true)

theorem terminalChecked24300 : H12PackedTerminal.terminalCheckFast leafEnv24300 active24300 tree24300 = true := by decide +kernel

def env24301 : List Nat := [2,4,8,16,32,64,128,85,136,1024,81,1093,89,1261,113,34,1093,80,1192,112,1261,1,185,82,209,233,81,1092,1092,80,1024,4294967296,252,4294967544,1260,136]

theorem envBound24301 : H12AffineFastState.Bounded env24301 := by
  intro p hp
  have h : env24301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24293_24301 : H12AffineEnvironment.transform 10 81 env24293 = env24301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env24293 == env24301) = true)

theorem identity24301 : scanCanonicalize (H12AffineFastState.compose env24301 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 81) := by decide +kernel

theorem selectedBound24301 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24302 : List Nat := [2,4,8,16,32,64,128,85,136,1024,81,1093,89,1261,113,34,1093,80,1192,112,1261,1,185,82,209,233,81,1092,1092,80,1024,81,252,169,1260,136]

theorem envBound24302 : H12AffineFastState.Bounded env24302 := by
  intro p hp
  have h : env24302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24301_24302 : H12AffineEnvironment.transform 31 81 env24301 = env24302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 81 env24301 == env24302) = true)

def env24303 : List Nat := [2,4,8,16,32,64,88,85,80,1024,81,1093,89,1077,113,34,1093,80,1136,112,1077,1,97,82,9,49,81,1092,1092,80,1024,81,36,113,1076,80]

theorem envBound24303 : H12AffineFastState.Bounded env24303 := by
  intro p hp
  have h : env24303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24302_24303 : H12AffineEnvironment.transform 6 88 env24302 = env24303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24302 == env24303) = true)

theorem identity24303 : scanCanonicalize (H12AffineFastState.compose env24303 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound24303 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24304 : List Nat := [2,4,8,16,32,43,51,62,59,1024,58,1070,50,1077,26,34,1070,59,1051,27,1077,1,10,57,9,49,58,1071,1071,59,1024,58,36,26,1076,59]

theorem envBound24304 : H12AffineFastState.Bounded env24304 := by
  intro p hp
  have h : env24304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24303_24304 : H12AffineEnvironment.transform 5 43 env24303 = env24304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env24303 == env24304) = true)

theorem identity24304 : scanCanonicalize (H12AffineFastState.compose env24304 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound24304 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24305 : List Nat := [2,4,8,16,27,16,8,5,0,1024,1,1045,9,1038,26,25,1045,0,1051,27,1038,1,10,2,9,10,1,1044,1044,0,1024,1,31,26,1039,0]

theorem envBound24305 : H12AffineFastState.Bounded env24305 := by
  intro p hp
  have h : env24305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24304_24305 : H12AffineEnvironment.transform 4 27 env24304 = env24305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env24304 == env24305) = true)

def leafEnv24305 : List Nat := [2,4,8,16,27,16,8,5,0,1024,1,1045,9,1038,26,25,1045,0,1051,27,1038,1,10,2,1051,9,1,10,1,1044,1044,0,1024,1,31,26,30,25,1039,0,0,1039,1]

def active24305 : List Nat := [0,1,2,3,9]

def tree24305 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24305 : H12WitnessSearch.Good tree24305 := H12GlobalWitnessIndex.good

theorem leafIdentity24305 : H12AffineFastState.composeSystem env24305 rootObs = leafEnv24305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24305 rootObs == leafEnv24305) = true)

theorem terminalChecked24305 : H12PackedTerminal.terminalCheckFast leafEnv24305 active24305 tree24305 = true := by decide +kernel

def env24306 : List Nat := [2,4,8,16,32,64,89,85,81,1024,81,1093,89,1076,113,34,1093,80,1137,112,1076,1,96,82,8,48,81,1092,1092,80,1024,81,37,112,1077,81]

theorem envBound24306 : H12AffineFastState.Bounded env24306 := by
  intro p hp
  have h : env24306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24302_24306 : H12AffineEnvironment.transform 6 89 env24302 = env24306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env24302 == env24306) = true)

theorem identity24306 : scanCanonicalize (H12AffineFastState.compose env24306 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 127) := by decide +kernel

theorem selectedBound24306 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24307 : List Nat := [2,4,8,16,32,64,89,85,81,127,81,58,89,75,113,34,58,80,14,112,75,1,96,82,8,48,81,59,59,80,127,81,37,112,74,81]

theorem envBound24307 : H12AffineFastState.Bounded env24307 := by
  intro p hp
  have h : env24307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24306_24307 : H12AffineEnvironment.transform 9 127 env24306 = env24307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 127 env24306 == env24307) = true)

def leafEnv24307 : List Nat := [2,4,8,16,32,64,89,85,81,127,81,58,89,75,113,34,58,80,14,112,75,1,96,82,14,8,1,48,81,59,59,80,127,81,37,112,116,114,74,81,0,74,1]

def active24307 : List Nat := [0,1,2,3,4,5]

def tree24307 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24307 : H12WitnessSearch.Good tree24307 := H12GlobalWitnessIndex.good

theorem leafIdentity24307 : H12AffineFastState.composeSystem env24307 rootObs = leafEnv24307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24307 rootObs == leafEnv24307) = true)

theorem terminalChecked24307 : H12PackedTerminal.terminalCheckFast leafEnv24307 active24307 tree24307 = true := by decide +kernel

def env24308 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,14837,2081,65536,4096,8200,14565,2080,11493,5189,15604,72805,8328,15524,8200,1297,1297,2048,4165,4294967296,15844,4295035019,11492,136]

theorem envBound24308 : H12AffineFastState.Bounded env24308 := by
  intro p hp
  have h : env24308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24268_24308 : H12AffineEnvironment.transform 14 2081 env24268 = env24308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2081 env24268 == env24308) = true)

theorem identity24308 : scanCanonicalize (H12AffineFastState.compose env24308 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound24308 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24309 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,2056,4605,2081,65536,4096,2048,4333,2080,1261,5189,5372,72805,2176,5292,2048,1297,1297,2048,4165,4294967296,5612,4295035019,1260,136]

theorem envBound24309 : H12AffineFastState.Bounded env24309 := by
  intro p hp
  have h : env24309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24308_24309 : H12AffineEnvironment.transform 12 2056 env24308 = env24309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env24308 == env24309) = true)

theorem identity24309 : scanCanonicalize (H12AffineFastState.compose env24309 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound24309 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env24310 : List Nat := [2,4,8,16,32,64,128,84,136,1024,2048,4096,2056,4265,2081,65536,4096,2048,4333,2080,1261,5189,5372,72805,2176,5292,2048,1093,1093,2048,4165,4294967296,5304,4295035019,1260,136]

theorem envBound24310 : H12AffineFastState.Bounded env24310 := by
  intro p hp
  have h : env24310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24309_24310 : H12AffineEnvironment.transform 7 84 env24309 = env24310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env24309 == env24310) = true)

theorem identity24310 : scanCanonicalize (H12AffineFastState.compose env24310 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 1181) := by decide +kernel

theorem selectedBound24310 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env24311 : List Nat := [2,4,8,16,32,64,128,84,136,1024,2048,1181,2056,1076,2081,65536,1181,2048,1136,2080,1261,216,97,67832,2176,49,2048,1093,1093,2048,1240,4294967296,37,4295035019,1260,136]

theorem envBound24311 : H12AffineFastState.Bounded env24311 := by
  intro p hp
  have h : env24311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24310_24311 : H12AffineEnvironment.transform 11 1181 env24310 = env24311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1181 env24310 == env24311) = true)

theorem identity24311 : scanCanonicalize (H12AffineFastState.compose env24311 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound24311 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24312 : List Nat := [2,4,8,16,32,64,88,84,80,1024,2048,1093,2056,1076,2081,65536,1093,2048,1136,2080,1077,0,97,67616,2136,49,2048,1093,1093,2048,1024,4294967296,37,4295034963,1076,80]

theorem envBound24312 : H12AffineFastState.Bounded env24312 := by
  intro p hp
  have h : env24312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24311_24312 : H12AffineEnvironment.transform 6 88 env24311 = env24312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24311 == env24312) = true)

def env24313 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4096,262144,524288,32769,529409,566401,525329,103492,8328,67108864,831684,1297,1297,1073741824,67638276,4294967296,525569,4295569518,67113025,136]

theorem envBound24313 : H12AffineFastState.Bounded env24313 := by
  intro p hp
  have h : env24313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24262_24313 : H12AffineEnvironment.transform 20 529409 env24262 = env24313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529409 env24262 == env24313) = true)

def env24314 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4096,262144,524288,32769,529409,566401,525329,103492,8328,525376,831684,1297,1297,1073741824,4164,4294967296,525569,4295569518,529409,136]

theorem envBound24314 : H12AffineFastState.Bounded env24314 := by
  intro p hp
  have h : env24314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24313_24314 : H12AffineEnvironment.transform 25 525376 env24313 = env24314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 525376 env24313 == env24314) = true)

theorem identity24314 : scanCanonicalize (H12AffineFastState.compose env24314 (packedSelected [3,5,24] rootPS)) = affineNative (2^(18+1) ^^^ 42113) := by decide +kernel

theorem selectedBound24314 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env24315 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4096,262144,42113,32769,45184,0,41104,103492,8328,41153,267333,1297,1297,1073741824,4164,4294967296,41344,4295070959,45184,136]

theorem envBound24315 : H12AffineFastState.Bounded env24315 := by
  intro p hp
  have h : env24315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24314_24315 : H12AffineEnvironment.transform 18 42113 env24314 = env24315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 42113 env24314 == env24315) = true)

def env24316 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4096,262144,524288,32769,529409,566401,525329,103492,8328,525377,831684,1297,1297,1073741824,4165,4294967296,525569,4295569518,529408,136]

theorem envBound24316 : H12AffineFastState.Bounded env24316 := by
  intro p hp
  have h : env24316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24313_24316 : H12AffineEnvironment.transform 25 525377 env24313 = env24316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 525377 env24313 == env24316) = true)

theorem identity24316 : scanCanonicalize (H12AffineFastState.compose env24316 (packedSelected [3,5,24] rootPS)) = affineNative (2^(17+1) ^^^ 8200) := by decide +kernel

theorem selectedBound24316 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env24317 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4096,8200,524288,32769,529409,566401,525329,103492,8328,525377,561356,1297,1297,1073741824,4165,4294967296,525569,4295569518,529408,136]

theorem envBound24317 : H12AffineFastState.Bounded env24317 := by
  intro p hp
  have h : env24317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24316_24317 : H12AffineEnvironment.transform 17 8200 env24316 = env24317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8200 env24316 == env24317) = true)

theorem identity24317 : scanCanonicalize (H12AffineFastState.compose env24317 (packedSelected [0,27] rootPS)) = affineNative (2^(18+1) ^^^ 16657) := by decide +kernel

theorem selectedBound24317 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env24318 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4096,8200,16657,32769,21776,58768,17664,103492,8328,17744,53725,1297,1297,1073741824,4165,4294967296,17424,4295061887,21777,136]

theorem envBound24318 : H12AffineFastState.Bounded env24318 := by
  intro p hp
  have h : env24318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24317_24318 : H12AffineEnvironment.transform 18 16657 env24317 = env24318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 16657 env24317 == env24318) = true)

theorem identity24318 : scanCanonicalize (H12AffineFastState.compose env24318 (packedSelected [1,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 29172) := by decide +kernel

theorem selectedBound24318 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env24319 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4096,8200,16657,32769,21776,58768,17664,103492,8328,17744,53725,1297,1297,29172,4165,4294967296,17424,4295061887,21777,136]

theorem envBound24319 : H12AffineFastState.Bounded env24319 := by
  intro p hp
  have h : env24319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24318_24319 : H12AffineEnvironment.transform 29 29172 env24318 = env24319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 29172 env24318 == env24319) = true)

theorem identity24319 : scanCanonicalize (H12AffineFastState.compose env24319 (packedSelected [5,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 2081) := by decide +kernel

theorem selectedBound24319 : packedSelected [5,12,15] rootPS < 2^1333 := by decide +kernel

def env24320 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,2081,65536,4096,8200,16657,2080,21776,28081,17664,72805,8328,17744,23036,1297,1297,29172,4165,4294967296,17424,4295061887,21777,136]

theorem envBound24320 : H12AffineFastState.Bounded env24320 := by
  intro p hp
  have h : env24320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24319_24320 : H12AffineEnvironment.transform 14 2081 env24319 = env24320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2081 env24319 == env24320) = true)

def env24321 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1296,8192,16384,2081,65536,1296,8200,16657,2080,16384,28081,17664,67957,8328,17744,19692,1297,1297,25828,1365,4294967296,17424,4295058543,16385,136]

theorem envBound24321 : H12AffineFastState.Bounded env24321 := by
  intro p hp
  have h : env24321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24320_24321 : H12AffineEnvironment.transform 11 1296 env24320 = env24321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env24320 == env24321) = true)

theorem identity24321 : scanCanonicalize (H12AffineFastState.compose env24321 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 8494) := by decide +kernel

theorem selectedBound24321 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24322 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1296,8192,16384,2081,8494,1296,8200,16657,2080,16384,28081,17664,10331,8328,17744,19692,1297,1297,25828,1365,4294967296,17424,4294985025,16385,136]

theorem envBound24322 : H12AffineFastState.Bounded env24322 := by
  intro p hp
  have h : env24322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24321_24322 : H12AffineEnvironment.transform 15 8494 env24321 = env24322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8494 env24321 == env24322) = true)

theorem identity24322 : scanCanonicalize (H12AffineFastState.compose env24322 (packedSelected [5] rootPS)) = affineNative (2^(13+1) ^^^ 1260) := by decide +kernel

theorem selectedBound24322 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24323 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1296,8192,1260,2081,8494,1296,8200,1533,2080,1260,10589,492,10331,8328,444,2048,1297,1297,8200,1365,4294967296,252,4294967725,1261,136]

theorem envBound24323 : H12AffineFastState.Bounded env24323 := by
  intro p hp
  have h : env24323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24322_24323 : H12AffineEnvironment.transform 13 1260 env24322 = env24323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1260 env24322 == env24323) = true)

theorem identity24323 : scanCanonicalize (H12AffineFastState.compose env24323 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound24323 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env24324 : List Nat := [2,4,8,16,32,64,128,85,136,1024,2048,1093,8192,1260,2081,8315,1093,8200,1192,2080,1260,10248,185,10331,8328,233,2048,1092,1092,8200,1024,4294967296,252,4294967544,1261,136]

theorem envBound24324 : H12AffineFastState.Bounded env24324 := by
  intro p hp
  have h : env24324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24323_24324 : H12AffineEnvironment.transform 7 85 env24323 = env24324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env24323 == env24324) = true)

theorem identity24324 : scanCanonicalize (H12AffineFastState.compose env24324 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 2057) := by decide +kernel

theorem selectedBound24324 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24325 : List Nat := [2,4,8,16,32,64,128,85,136,1024,2048,1093,2057,1260,2081,2162,1093,2049,1192,2080,1260,1,185,82,2177,233,2048,1092,1092,2049,1024,4294967296,252,4294967544,1261,136]

theorem envBound24325 : H12AffineFastState.Bounded env24325 := by
  intro p hp
  have h : env24325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24324_24325 : H12AffineEnvironment.transform 12 2057 env24324 = env24325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env24324 == env24325) = true)

def env24326 : List Nat := [2,4,8,16,32,64,128,85,136,1024,80,1093,89,1260,113,34,1093,81,1192,112,1260,1,185,82,209,233,80,1092,1092,81,1024,4294967296,252,4294967544,1261,136]

theorem envBound24326 : H12AffineFastState.Bounded env24326 := by
  intro p hp
  have h : env24326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24325_24326 : H12AffineEnvironment.transform 10 80 env24325 = env24326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env24325 == env24326) = true)

theorem identity24326 : scanCanonicalize (H12AffineFastState.compose env24326 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 81) := by decide +kernel

theorem selectedBound24326 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24327 : List Nat := [2,4,8,16,32,64,128,85,136,1024,80,1093,89,1260,113,34,1093,81,1192,112,1260,1,185,82,209,233,80,1092,1092,81,1024,81,252,169,1261,136]

theorem envBound24327 : H12AffineFastState.Bounded env24327 := by
  intro p hp
  have h : env24327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24326_24327 : H12AffineEnvironment.transform 31 81 env24326 = env24327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 81 env24326 == env24327) = true)

def env24328 : List Nat := [2,4,8,16,32,64,88,85,80,1024,80,1093,89,1076,113,34,1093,81,1136,112,1076,1,97,82,9,49,80,1092,1092,81,1024,81,36,113,1077,80]

theorem envBound24328 : H12AffineFastState.Bounded env24328 := by
  intro p hp
  have h : env24328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24327_24328 : H12AffineEnvironment.transform 6 88 env24327 = env24328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24327 == env24328) = true)

theorem identity24328 : scanCanonicalize (H12AffineFastState.compose env24328 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound24328 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24329 : List Nat := [2,4,8,16,32,43,51,62,59,1024,59,1070,50,1076,26,34,1070,58,1051,27,1076,1,10,57,9,49,59,1071,1071,58,1024,58,36,26,1077,59]

theorem envBound24329 : H12AffineFastState.Bounded env24329 := by
  intro p hp
  have h : env24329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24328_24329 : H12AffineEnvironment.transform 5 43 env24328 = env24329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env24328 == env24329) = true)

theorem identity24329 : scanCanonicalize (H12AffineFastState.compose env24329 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound24329 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24330 : List Nat := [2,4,8,16,27,16,8,5,0,1024,0,1045,9,1039,26,25,1045,1,1051,27,1039,1,10,2,9,10,0,1044,1044,1,1024,1,31,26,1038,0]

theorem envBound24330 : H12AffineFastState.Bounded env24330 := by
  intro p hp
  have h : env24330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24329_24330 : H12AffineEnvironment.transform 4 27 env24329 = env24330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env24329 == env24330) = true)

def leafEnv24330 : List Nat := [2,4,8,16,27,16,8,5,0,1024,0,1045,9,1039,26,25,1045,1,1051,27,1039,1,10,2,1051,9,1,10,0,1044,1044,1,1024,1,31,26,30,25,1038,0,0,1038,1]

def active24330 : List Nat := [0,1,2,3,9]

def tree24330 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24330 : H12WitnessSearch.Good tree24330 := H12GlobalWitnessIndex.good

theorem leafIdentity24330 : H12AffineFastState.composeSystem env24330 rootObs = leafEnv24330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24330 rootObs == leafEnv24330) = true)

theorem terminalChecked24330 : H12PackedTerminal.terminalCheckFast leafEnv24330 active24330 tree24330 = true := by decide +kernel

def env24331 : List Nat := [2,4,8,16,32,64,89,85,81,1024,80,1093,89,1077,113,34,1093,81,1137,112,1077,1,96,82,8,48,80,1092,1092,81,1024,81,37,112,1076,81]

theorem envBound24331 : H12AffineFastState.Bounded env24331 := by
  intro p hp
  have h : env24331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24327_24331 : H12AffineEnvironment.transform 6 89 env24327 = env24331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env24327 == env24331) = true)

theorem identity24331 : scanCanonicalize (H12AffineFastState.compose env24331 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 127) := by decide +kernel

theorem selectedBound24331 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24332 : List Nat := [2,4,8,16,32,64,89,85,81,127,80,58,89,74,113,34,58,81,14,112,74,1,96,82,8,48,80,59,59,81,127,81,37,112,75,81]

theorem envBound24332 : H12AffineFastState.Bounded env24332 := by
  intro p hp
  have h : env24332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24331_24332 : H12AffineEnvironment.transform 9 127 env24331 = env24332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 127 env24331 == env24332) = true)

def leafEnv24332 : List Nat := [2,4,8,16,32,64,89,85,81,127,80,58,89,74,113,34,58,81,14,112,74,1,96,82,14,8,1,48,80,59,59,81,127,81,37,112,116,114,75,81,0,75,1]

def active24332 : List Nat := [0,1,2,3,4,5]

def tree24332 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24332 : H12WitnessSearch.Good tree24332 := H12GlobalWitnessIndex.good

theorem leafIdentity24332 : H12AffineFastState.composeSystem env24332 rootObs = leafEnv24332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24332 rootObs == leafEnv24332) = true)

theorem terminalChecked24332 : H12PackedTerminal.terminalCheckFast leafEnv24332 active24332 tree24332 = true := by decide +kernel

def env24333 : List Nat := [2,4,8,16,32,64,128,85,136,1024,81,1093,88,1260,112,35,1093,80,1192,113,1260,1,185,82,208,233,81,1092,1092,80,1024,4294967296,252,4294967544,1261,136]

theorem envBound24333 : H12AffineFastState.Bounded env24333 := by
  intro p hp
  have h : env24333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24325_24333 : H12AffineEnvironment.transform 10 81 env24325 = env24333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env24325 == env24333) = true)

theorem identity24333 : scanCanonicalize (H12AffineFastState.compose env24333 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 136) := by decide +kernel

theorem selectedBound24333 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24334 : List Nat := [2,4,8,16,32,64,128,85,136,1024,81,1093,88,1260,112,35,1093,80,1192,113,1260,1,185,82,208,233,81,1092,1092,80,1024,136,252,112,1261,136]

theorem envBound24334 : H12AffineFastState.Bounded env24334 := by
  intro p hp
  have h : env24334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24333_24334 : H12AffineEnvironment.transform 31 136 env24333 = env24334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 136 env24333 == env24334) = true)

def env24335 : List Nat := [2,4,8,16,32,64,88,85,80,1024,81,1093,88,1076,112,35,1093,80,1136,113,1076,1,97,82,8,49,81,1092,1092,80,1024,80,36,112,1077,80]

theorem envBound24335 : H12AffineFastState.Bounded env24335 := by
  intro p hp
  have h : env24335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24334_24335 : H12AffineEnvironment.transform 6 88 env24334 = env24335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24334 == env24335) = true)

theorem identity24335 : scanCanonicalize (H12AffineFastState.compose env24335 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound24335 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24336 : List Nat := [2,4,8,16,32,10,18,31,26,1024,27,1039,18,1076,58,35,1039,26,1082,59,1076,1,43,24,8,49,27,1038,1038,26,1024,26,36,58,1077,26]

theorem envBound24336 : H12AffineFastState.Bounded env24336 := by
  intro p hp
  have h : env24336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24335_24336 : H12AffineEnvironment.transform 5 10 env24335 = env24336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env24335 == env24336) = true)

theorem identity24336 : scanCanonicalize (H12AffineFastState.compose env24336 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound24336 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24337 : List Nat := [2,4,8,16,27,10,18,31,26,1024,27,1039,18,1039,1,24,1039,26,1025,0,1039,1,16,24,8,10,27,1038,1038,26,1024,26,31,1,1038,26]

theorem envBound24337 : H12AffineFastState.Bounded env24337 := by
  intro p hp
  have h : env24337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24336_24337 : H12AffineEnvironment.transform 4 27 env24336 = env24337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env24336 == env24337) = true)

def leafEnv24337 : List Nat := [2,4,8,16,27,10,18,31,26,1024,27,1039,18,1039,1,24,1039,26,1025,0,1039,1,16,24,1025,8,1,10,27,1038,1038,26,1024,26,31,1,4,2,1038,26,0,1038,1]

def active24337 : List Nat := [0,1,2,3,9]

def tree24337 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24337 : H12WitnessSearch.Good tree24337 := H12GlobalWitnessIndex.good

theorem leafIdentity24337 : H12AffineFastState.composeSystem env24337 rootObs = leafEnv24337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24337 rootObs == leafEnv24337) = true)

theorem terminalChecked24337 : H12PackedTerminal.terminalCheckFast leafEnv24337 active24337 tree24337 = true := by decide +kernel

def env24338 : List Nat := [2,4,8,16,32,64,89,85,81,1024,81,1093,88,1077,112,35,1093,80,1137,113,1077,1,96,82,9,48,81,1092,1092,80,1024,81,37,112,1076,81]

theorem envBound24338 : H12AffineFastState.Bounded env24338 := by
  intro p hp
  have h : env24338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24334_24338 : H12AffineEnvironment.transform 6 89 env24334 = env24338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env24334 == env24338) = true)

theorem identity24338 : scanCanonicalize (H12AffineFastState.compose env24338 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 126) := by decide +kernel

theorem selectedBound24338 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24339 : List Nat := [2,4,8,16,32,64,89,85,81,126,81,59,88,75,112,35,59,80,15,113,75,1,96,82,9,48,81,58,58,80,126,81,37,112,74,81]

theorem envBound24339 : H12AffineFastState.Bounded env24339 := by
  intro p hp
  have h : env24339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24338_24339 : H12AffineEnvironment.transform 9 126 env24338 = env24339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 126 env24338 == env24339) = true)

def leafEnv24339 : List Nat := [2,4,8,16,32,64,89,85,81,126,81,59,88,75,112,35,59,80,15,113,75,1,96,82,15,9,1,48,81,58,58,80,126,81,37,112,116,115,74,81,0,74,1]

def active24339 : List Nat := [0,1,2,3,4,5]

def tree24339 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24339 : H12WitnessSearch.Good tree24339 := H12GlobalWitnessIndex.good

theorem leafIdentity24339 : H12AffineFastState.composeSystem env24339 rootObs = leafEnv24339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24339 rootObs == leafEnv24339) = true)

theorem terminalChecked24339 : H12PackedTerminal.terminalCheckFast leafEnv24339 active24339 tree24339 = true := by decide +kernel

def env24340 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1297,8192,16384,2081,65536,1297,8200,16657,2080,16385,28081,17664,67956,8328,17744,19693,1297,1297,25829,1364,4294967296,17424,4295058542,16384,136]

theorem envBound24340 : H12AffineFastState.Bounded env24340 := by
  intro p hp
  have h : env24340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24320_24340 : H12AffineEnvironment.transform 11 1297 env24320 = env24340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env24320 == env24340) = true)

theorem identity24340 : scanCanonicalize (H12AffineFastState.compose env24340 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 1076) := by decide +kernel

theorem selectedBound24340 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24341 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1297,8192,1076,2081,65536,1297,8200,1317,2080,1077,10629,308,67956,8328,356,2265,1297,1297,8401,1364,4294967296,36,4295041114,1076,136]

theorem envBound24341 : H12AffineFastState.Bounded env24341 := by
  intro p hp
  have h : env24341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24340_24341 : H12AffineEnvironment.transform 13 1076 env24340 = env24341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1076 env24340 == env24341) = true)

theorem identity24341 : scanCanonicalize (H12AffineFastState.compose env24341 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound24341 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24342 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1297,2056,1076,2081,65536,1297,2048,1317,2080,1077,397,308,67956,2176,356,2265,1297,1297,2265,1364,4294967296,36,4295034962,1076,136]

theorem envBound24342 : H12AffineFastState.Bounded env24342 := by
  intro p hp
  have h : env24342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24341_24342 : H12AffineEnvironment.transform 12 2056 env24341 = env24342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env24341 == env24342) = true)

theorem identity24342 : scanCanonicalize (H12AffineFastState.compose env24342 (packedSelected [12] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound24342 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env24343 : List Nat := [2,4,8,16,32,64,128,84,136,1024,2048,1093,2056,1076,2081,65536,1093,2048,1137,2080,1077,217,96,67616,2176,48,2265,1093,1093,2265,1024,4294967296,36,4295034962,1076,136]

theorem envBound24343 : H12AffineFastState.Bounded env24343 := by
  intro p hp
  have h : env24343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24342_24343 : H12AffineEnvironment.transform 7 84 env24342 = env24343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env24342 == env24343) = true)

theorem identity24343 : scanCanonicalize (H12AffineFastState.compose env24343 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound24343 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env24344 : List Nat := [2,4,8,16,32,64,88,84,80,1024,2048,1093,2056,1076,2081,65536,1093,2048,1137,2080,1077,1,96,67616,2136,48,2049,1093,1093,2049,1024,4294967296,36,4295034962,1076,80]

theorem envBound24344 : H12AffineFastState.Bounded env24344 := by
  intro p hp
  have h : env24344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24343_24344 : H12AffineEnvironment.transform 6 88 env24343 = env24344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24343 == env24344) = true)

def env24345 : List Nat := [2,4,8,16,32,64,88,84,80,1024,32,1093,40,1076,1,65536,1093,32,1137,0,1077,1,96,65536,120,48,33,1093,1093,33,1024,4294967296,36,4295032946,1076,80]

theorem envBound24345 : H12AffineFastState.Bounded env24345 := by
  intro p hp
  have h : env24345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24344_24345 : H12AffineEnvironment.transform 10 32 env24344 = env24345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env24344 == env24345) = true)

theorem identity24345 : scanCanonicalize (H12AffineFastState.compose env24345 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65538) := by decide +kernel

theorem selectedBound24345 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24346 : List Nat := [2,4,8,16,32,64,88,84,80,1024,32,1093,40,1076,1,65536,1093,32,1137,0,1077,1,96,65536,120,48,33,1093,1093,33,1024,65538,36,112,1076,80]

theorem envBound24346 : H12AffineFastState.Bounded env24346 := by
  intro p hp
  have h : env24346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24345_24346 : H12AffineEnvironment.transform 31 65538 env24345 = env24346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65538 env24345 == env24346) = true)

def env24347 : List Nat := [2,4,8,16,32,64,88,84,80,20,32,81,40,32,1,65536,81,32,101,0,33,1,96,65536,120,48,33,81,81,33,20,65538,36,112,32,80]

theorem envBound24347 : H12AffineFastState.Bounded env24347 := by
  intro p hp
  have h : env24347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24346_24347 : H12AffineEnvironment.transform 9 20 env24346 = env24347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env24346 == env24347) = true)

theorem identity24347 : scanCanonicalize (H12AffineFastState.compose env24347 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound24347 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24348 : List Nat := [2,4,8,11,32,64,67,79,75,15,32,74,40,32,1,65536,74,32,101,0,33,1,96,65536,99,43,33,74,74,33,15,65538,36,107,32,75]

theorem envBound24348 : H12AffineFastState.Bounded env24348 := by
  intro p hp
  have h : env24348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24347_24348 : H12AffineEnvironment.transform 3 11 env24347 = env24348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env24347 == env24348) = true)

def env24349 : List Nat := [2,4,8,11,0,64,67,79,75,15,0,74,8,0,1,65536,74,0,69,0,1,1,64,65536,67,11,1,74,74,1,15,65538,4,75,0,75]

theorem envBound24349 : H12AffineFastState.Bounded env24349 := by
  intro p hp
  have h : env24349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24348_24349 : H12AffineEnvironment.transform 4 0 env24348 = env24349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24348 == env24349) = true)

theorem identity24349 : scanCanonicalize (H12AffineFastState.compose env24349 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 72) := by decide +kernel

theorem selectedBound24349 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24350 : List Nat := [2,4,8,11,0,64,67,79,75,15,0,74,8,0,1,72,74,0,69,0,1,1,64,72,67,11,1,74,74,1,15,74,4,75,0,75]

theorem envBound24350 : H12AffineFastState.Bounded env24350 := by
  intro p hp
  have h : env24350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24349_24350 : H12AffineEnvironment.transform 15 72 env24349 = env24350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 72 env24349 == env24350) = true)

def leafEnv24350 : List Nat := [2,4,8,11,0,64,67,79,75,15,0,74,8,0,1,72,74,0,69,0,1,1,64,72,69,67,1,11,1,74,74,1,15,74,4,75,79,2,0,75,0,1,1]

def active24350 : List Nat := [0,1,2,5]

def tree24350 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24350 : H12WitnessSearch.Good tree24350 := H12GlobalWitnessIndex.good

theorem leafIdentity24350 : H12AffineFastState.composeSystem env24350 rootObs = leafEnv24350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24350 rootObs == leafEnv24350) = true)

theorem terminalChecked24350 : H12PackedTerminal.terminalCheckFast leafEnv24350 active24350 tree24350 = true := by decide +kernel

def env24351 : List Nat := [2,4,8,11,1,64,67,79,75,15,1,74,9,1,1,65536,74,1,68,0,0,1,65,65536,66,10,0,74,74,0,15,65538,5,74,1,75]

theorem envBound24351 : H12AffineFastState.Bounded env24351 := by
  intro p hp
  have h : env24351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24348_24351 : H12AffineEnvironment.transform 4 1 env24348 = env24351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24348 == env24351) = true)

def leafEnv24351 : List Nat := [2,4,8,11,1,64,67,79,75,15,1,74,9,1,1,65536,74,1,68,0,0,1,65,65536,68,66,1,10,0,74,74,0,15,65538,5,74,78,2,1,75,0,0,1]

def active24351 : List Nat := [0,1,2,5,15]

def tree24351 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24351 : H12WitnessSearch.Good tree24351 := H12GlobalWitnessIndex.good

theorem leafIdentity24351 : H12AffineFastState.composeSystem env24351 rootObs = leafEnv24351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24351 rootObs == leafEnv24351) = true)

theorem terminalChecked24351 : H12PackedTerminal.terminalCheckFast leafEnv24351 active24351 tree24351 = true := by decide +kernel

def env24352 : List Nat := [2,4,8,16,32,64,88,84,80,21,32,80,40,33,1,65536,80,32,100,0,32,1,96,65536,120,48,33,80,80,33,21,65538,36,112,33,80]

theorem envBound24352 : H12AffineFastState.Bounded env24352 := by
  intro p hp
  have h : env24352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24346_24352 : H12AffineEnvironment.transform 9 21 env24346 = env24352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env24346 == env24352) = true)

theorem identity24352 : scanCanonicalize (H12AffineFastState.compose env24352 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 73) := by decide +kernel

theorem selectedBound24352 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24353 : List Nat := [2,4,8,16,32,64,88,84,80,21,32,80,40,33,1,73,80,32,100,0,32,1,96,73,120,48,33,80,80,33,21,75,36,112,33,80]

theorem envBound24353 : H12AffineFastState.Bounded env24353 := by
  intro p hp
  have h : env24353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24352_24353 : H12AffineEnvironment.transform 15 73 env24352 = env24353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 73 env24352 == env24353) = true)

def env24354 : List Nat := [2,4,8,16,0,64,88,84,80,21,0,80,8,1,1,73,80,0,68,0,0,1,64,73,88,16,1,80,80,1,21,75,4,80,1,80]

theorem envBound24354 : H12AffineFastState.Bounded env24354 := by
  intro p hp
  have h : env24354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24353_24354 : H12AffineEnvironment.transform 4 0 env24353 = env24354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24353 == env24354) = true)

theorem identity24354 : scanCanonicalize (H12AffineFastState.compose env24354 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound24354 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24355 : List Nat := [2,4,8,10,0,64,66,78,74,15,0,74,8,1,1,73,74,0,68,0,0,1,64,73,66,10,1,74,74,1,15,75,4,74,1,74]

theorem envBound24355 : H12AffineFastState.Bounded env24355 := by
  intro p hp
  have h : env24355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24354_24355 : H12AffineEnvironment.transform 3 10 env24354 = env24355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env24354 == env24355) = true)

def leafEnv24355 : List Nat := [2,4,8,10,0,64,66,78,74,15,0,74,8,1,1,73,74,0,68,0,0,1,64,73,68,66,1,10,1,74,74,1,15,75,4,74,78,2,1,74,0,0,1]

def active24355 : List Nat := [0,1,2,5]

def tree24355 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24355 : H12WitnessSearch.Good tree24355 := H12GlobalWitnessIndex.good

theorem leafIdentity24355 : H12AffineFastState.composeSystem env24355 rootObs = leafEnv24355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24355 rootObs == leafEnv24355) = true)

theorem terminalChecked24355 : H12PackedTerminal.terminalCheckFast leafEnv24355 active24355 tree24355 = true := by decide +kernel

def env24356 : List Nat := [2,4,8,16,1,64,88,84,80,21,1,80,9,0,1,73,80,1,69,0,1,1,65,73,89,17,0,80,80,0,21,75,5,81,0,80]

theorem envBound24356 : H12AffineFastState.Bounded env24356 := by
  intro p hp
  have h : env24356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24353_24356 : H12AffineEnvironment.transform 4 1 env24353 = env24356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24353 == env24356) = true)

def leafEnv24356 : List Nat := [2,4,8,16,1,64,88,84,80,21,1,80,9,0,1,73,80,1,69,0,1,1,65,73,69,89,1,17,0,80,80,0,21,75,5,81,85,2,0,80,0,1,1]

def active24356 : List Nat := [0,1,2,3,5]

def tree24356 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24356 : H12WitnessSearch.Good tree24356 := H12GlobalWitnessIndex.good

theorem leafIdentity24356 : H12AffineFastState.composeSystem env24356 rootObs = leafEnv24356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24356 rootObs == leafEnv24356) = true)

theorem terminalChecked24356 : H12PackedTerminal.terminalCheckFast leafEnv24356 active24356 tree24356 = true := by decide +kernel

def env24357 : List Nat := [2,4,8,16,32,64,88,84,80,1024,33,1093,41,1076,0,65536,1093,33,1137,1,1077,1,96,65537,121,48,32,1093,1093,32,1024,4294967296,36,4295032947,1076,80]

theorem envBound24357 : H12AffineFastState.Bounded env24357 := by
  intro p hp
  have h : env24357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24344_24357 : H12AffineEnvironment.transform 10 33 env24344 = env24357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env24344 == env24357) = true)

theorem identity24357 : scanCanonicalize (H12AffineFastState.compose env24357 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 81) := by decide +kernel

theorem selectedBound24357 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24358 : List Nat := [2,4,8,16,32,64,88,84,80,1024,33,1093,41,1076,0,65536,1093,33,1137,1,1077,1,96,65537,121,48,32,1093,1093,32,1024,81,36,65570,1076,80]

theorem envBound24358 : H12AffineFastState.Bounded env24358 := by
  intro p hp
  have h : env24358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24357_24358 : H12AffineEnvironment.transform 31 81 env24357 = env24358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 81 env24357 == env24358) = true)

def env24359 : List Nat := [2,4,8,16,32,64,88,84,80,52,33,113,41,0,0,65536,113,33,69,1,1,1,96,65537,121,48,32,113,113,32,52,81,36,65570,0,80]

theorem envBound24359 : H12AffineFastState.Bounded env24359 := by
  intro p hp
  have h : env24359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24358_24359 : H12AffineEnvironment.transform 9 52 env24358 = env24359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env24358 == env24359) = true)

theorem identity24359 : scanCanonicalize (H12AffineFastState.compose env24359 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound24359 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24360 : List Nat := [2,4,8,16,26,64,88,84,80,14,27,75,19,0,0,65536,75,27,69,1,1,1,90,65537,67,10,26,75,75,26,14,81,30,65560,0,80]

theorem envBound24360 : H12AffineFastState.Bounded env24360 := by
  intro p hp
  have h : env24360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24359_24360 : H12AffineEnvironment.transform 4 26 env24359 = env24360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env24359 == env24360) = true)

def leafEnv24360 : List Nat := [2,4,8,16,26,64,88,84,80,14,27,75,19,0,0,65536,75,27,69,1,1,1,90,65537,69,67,1,10,26,75,75,26,14,81,30,65560,78,3,0,80,0,1,1]

def active24360 : List Nat := [0,1,2,3,5,15]

def tree24360 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24360 : H12WitnessSearch.Good tree24360 := H12GlobalWitnessIndex.good

theorem leafIdentity24360 : H12AffineFastState.composeSystem env24360 rootObs = leafEnv24360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24360 rootObs == leafEnv24360) = true)

theorem terminalChecked24360 : H12PackedTerminal.terminalCheckFast leafEnv24360 active24360 tree24360 = true := by decide +kernel

def env24361 : List Nat := [2,4,8,16,32,64,88,84,80,53,33,112,41,1,0,65536,112,33,68,1,0,1,96,65537,121,48,32,112,112,32,53,81,36,65570,1,80]

theorem envBound24361 : H12AffineFastState.Bounded env24361 := by
  intro p hp
  have h : env24361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24358_24361 : H12AffineEnvironment.transform 9 53 env24358 = env24361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env24358 == env24361) = true)

theorem identity24361 : scanCanonicalize (H12AffineFastState.compose env24361 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 105) := by decide +kernel

theorem selectedBound24361 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24362 : List Nat := [2,4,8,16,32,64,88,84,80,53,33,112,41,1,0,105,112,33,68,1,0,1,96,104,121,48,32,112,112,32,53,81,36,75,1,80]

theorem envBound24362 : H12AffineFastState.Bounded env24362 := by
  intro p hp
  have h : env24362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24361_24362 : H12AffineEnvironment.transform 15 105 env24361 = env24362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 105 env24361 == env24362) = true)

def leafEnv24362 : List Nat := [2,4,8,16,32,64,88,84,80,53,33,112,41,1,0,105,112,33,68,1,0,1,96,104,68,121,1,48,32,112,112,32,53,81,36,75,116,3,1,80,0,0,1]

def active24362 : List Nat := [0,1,2,3,4,5]

def tree24362 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24362 : H12WitnessSearch.Good tree24362 := H12GlobalWitnessIndex.good

theorem leafIdentity24362 : H12AffineFastState.composeSystem env24362 rootObs = leafEnv24362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24362 rootObs == leafEnv24362) = true)

theorem terminalChecked24362 : H12PackedTerminal.terminalCheckFast leafEnv24362 active24362 tree24362 = true := by decide +kernel

def env24363 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,2097152,4194304,525328,16777216,8328,67108864,21331969,16879957,16879956,1073741824,84508737,4294967296,525569,4315938987,86609925,136]

theorem envBound24363 : H12AffineFastState.Bounded env24363 := by
  intro p hp
  have h : env24363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24078_24363 : H12AffineEnvironment.transform 16 4097 env24078 = env24363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env24078 == env24363) = true)

theorem identity24363 : scanCanonicalize (H12AffineFastState.compose env24363 (packedSelected [3,5,10] rootPS)) = affineNative (2^(29+1) ^^^ 17348686) := by decide +kernel

theorem selectedBound24363 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24364 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,2097152,4194304,525328,16777216,8328,67108864,21331969,16879957,16879956,17348686,84508737,4294967296,525569,4315938987,86609925,136]

theorem envBound24364 : H12AffineFastState.Bounded env24364 := by
  intro p hp
  have h : env24364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24363_24364 : H12AffineEnvironment.transform 29 17348686 env24363 = env24364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 17348686 env24363 == env24364) = true)

def env24365 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,2097152,4194304,525328,16777216,8328,2642256,21331969,16879957,16879956,17348686,18993425,4294967296,525569,4315938987,16892245,136]

theorem envBound24365 : H12AffineFastState.Bounded env24365 := by
  intro p hp
  have h : env24365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24364_24365 : H12AffineEnvironment.transform 25 2642256 env24364 = env24365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 2642256 env24364 == env24365) = true)

def env24366 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,2097152,4194304,525328,16777216,8328,2642257,21331969,16879957,16879956,17348686,18993424,4294967296,525569,4315938987,16892244,136]

theorem envBound24366 : H12AffineFastState.Bounded env24366 := by
  intro p hp
  have h : env24366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24364_24366 : H12AffineEnvironment.transform 25 2642257 env24364 = env24366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 2642257 env24364 == env24366) = true)

theorem identity24366 : scanCanonicalize (H12AffineFastState.compose env24366 (packedSelected [0,14,27] rootPS)) = affineNative (2^(20+1) ^^^ 21777) := by decide +kernel

theorem selectedBound24366 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env24367 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21777,4194304,525328,16777216,8328,525376,21331969,16879957,16879956,17348686,16876545,4294967296,525569,4315938987,16892244,136]

theorem envBound24367 : H12AffineFastState.Bounded env24367 := by
  intro p hp
  have h : env24367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24366_24367 : H12AffineEnvironment.transform 20 21777 env24366 = env24367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 21777 env24366 == env24367) = true)

def env24368 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21777,4194304,525328,70976,8328,525376,4494657,33813,33812,634126,37185,4294967296,525569,4299232747,54292,136]

theorem envBound24368 : H12AffineFastState.Bounded env24368 := by
  intro p hp
  have h : env24368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24367_24368 : H12AffineEnvironment.transform 23 70976 env24367 = env24368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 70976 env24367 == env24368) = true)

def env24369 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21777,41088,525328,70976,8328,525376,275905,33813,33812,634126,37185,4294967296,525569,4295079275,54292,136]

theorem envBound24369 : H12AffineFastState.Bounded env24369 := by
  intro p hp
  have h : env24369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24368_24369 : H12AffineEnvironment.transform 21 41088 env24368 = env24369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env24368 == env24369) = true)

theorem identity24369 : scanCanonicalize (H12AffineFastState.compose env24369 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 103778) := by decide +kernel

theorem selectedBound24369 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24370 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21777,41088,525328,70976,8328,525376,275905,33813,33812,634126,37185,103778,525569,8201,54292,136]

theorem envBound24370 : H12AffineFastState.Bounded env24370 := by
  intro p hp
  have h : env24370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24369_24370 : H12AffineEnvironment.transform 31 103778 env24369 = env24370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 103778 env24369 == env24370) = true)

def env24371 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21741,41088,525328,70844,8328,525376,275517,33813,33812,634098,37053,103582,525565,8201,54292,136]

theorem envBound24371 : H12AffineFastState.Bounded env24371 := by
  intro p hp
  have h : env24371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24370_24371 : H12AffineEnvironment.transform 7 252 env24370 = env24371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env24370 == env24371) = true)

theorem identity24371 : scanCanonicalize (H12AffineFastState.compose env24371 (packedSelected [1,13,17,18,23,24] rootPS)) = affineNative (2^(18+1) ^^^ 102607) := by decide +kernel

theorem selectedBound24371 : packedSelected [1,13,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env24372 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,32768,65536,4097,262144,102607,32769,21741,41088,103647,70844,8328,103567,275517,33813,33812,15421,37053,103582,103474,8201,54292,136]

theorem envBound24372 : H12AffineFastState.Bounded env24372 := by
  intro p hp
  have h : env24372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24371_24372 : H12AffineEnvironment.transform 18 102607 env24371 = env24372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 102607 env24371 == env24372) = true)

theorem identity24372 : scanCanonicalize (H12AffineFastState.compose env24372 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound24372 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24373 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,32768,65536,4097,43049,102607,32769,21741,41088,103647,70844,8328,103567,39956,33813,33812,15421,37053,103582,103474,8201,54292,136]

theorem envBound24373 : H12AffineFastState.Bounded env24373 := by
  intro p hp
  have h : env24373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24372_24373 : H12AffineEnvironment.transform 17 43049 env24372 = env24373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env24372 == env24373) = true)

def env24374 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,5140,65536,4097,15421,66779,5141,21741,13460,65739,70844,8328,65691,2048,4097,4096,15421,1193,65674,65574,8201,16384,136]

theorem envBound24374 : H12AffineFastState.Bounded env24374 := by
  intro p hp
  have h : env24374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24373_24374 : H12AffineEnvironment.transform 14 5140 env24373 = env24374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5140 env24373 == env24374) = true)

theorem identity24374 : scanCanonicalize (H12AffineFastState.compose env24374 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound24374 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24375 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,5140,2,4097,15421,1241,5141,21741,13460,201,5310,8328,153,2048,4097,4096,15421,1193,136,36,8201,16384,136]

theorem envBound24375 : H12AffineFastState.Bounded env24375 := by
  intro p hp
  have h : env24375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24374_24375 : H12AffineEnvironment.transform 15 2 env24374 = env24375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env24374 == env24375) = true)

theorem identity24375 : scanCanonicalize (H12AffineFastState.compose env24375 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 3228) := by decide +kernel

theorem selectedBound24375 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env24376 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,3228,8192,16384,2184,2,3229,8353,1241,2185,18545,10248,201,2082,8328,153,2048,3229,3228,8353,1193,136,36,8201,16384,136]

theorem envBound24376 : H12AffineFastState.Bounded env24376 := by
  intro p hp
  have h : env24376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24375_24376 : H12AffineEnvironment.transform 11 3228 env24375 = env24376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3228 env24375 == env24376) = true)

theorem identity24376 : scanCanonicalize (H12AffineFastState.compose env24376 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 2209) := by decide +kernel

theorem selectedBound24376 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24377 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,3228,2209,16384,2184,2,3229,2048,1241,2185,18545,169,201,2082,2089,153,2048,3229,3228,2048,1193,136,36,2216,16384,136]

theorem envBound24377 : H12AffineFastState.Bounded env24377 := by
  intro p hp
  have h : env24377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24376_24377 : H12AffineEnvironment.transform 12 2209 env24376 = env24377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2209 env24376 == env24377) = true)

theorem identity24377 : scanCanonicalize (H12AffineFastState.compose env24377 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound24377 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24378 : List Nat := [2,4,8,16,32,64,41,85,33,1024,2048,3125,2056,16384,2081,2,3124,2048,1136,2080,18545,0,96,2082,2089,48,2048,3124,3125,2048,1024,33,36,2049,16384,33]

theorem envBound24378 : H12AffineFastState.Bounded env24378 := by
  intro p hp
  have h : env24378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24377_24378 : H12AffineEnvironment.transform 6 41 env24377 = env24378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env24377 == env24378) = true)

def env24379 : List Nat := [2,4,8,16,32,64,41,85,33,1024,112,1093,120,16384,81,2,1092,112,1136,80,16385,0,96,82,89,48,112,1092,1093,112,1024,33,36,113,16384,33]

theorem envBound24379 : H12AffineFastState.Bounded env24379 := by
  intro p hp
  have h : env24379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24378_24379 : H12AffineEnvironment.transform 10 112 env24378 = env24379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 112 env24378 == env24379) = true)

theorem identity24379 : scanCanonicalize (H12AffineFastState.compose env24379 (packedSelected [0] rootPS)) = affineNative (2^(13+1) ^^^ 1077) := by decide +kernel

theorem selectedBound24379 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24380 : List Nat := [2,4,8,16,32,64,41,85,33,1024,112,1093,120,1077,81,2,1092,112,1136,80,1076,0,96,82,89,48,112,1092,1093,112,1024,33,36,113,1077,33]

theorem envBound24380 : H12AffineFastState.Bounded env24380 := by
  intro p hp
  have h : env24380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24379_24380 : H12AffineEnvironment.transform 13 1077 env24379 = env24380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1077 env24379 == env24380) = true)

def env24381 : List Nat := [2,4,8,16,32,48,41,37,33,1024,0,1077,8,1077,33,2,1076,0,1024,32,1076,0,16,34,41,48,0,1076,1077,0,1024,33,36,1,1077,33]

theorem envBound24381 : H12AffineFastState.Bounded env24381 := by
  intro p hp
  have h : env24381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24380_24381 : H12AffineEnvironment.transform 5 48 env24380 = env24381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env24380 == env24381) = true)

theorem identity24381 : scanCanonicalize (H12AffineFastState.compose env24381 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound24381 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24382 : List Nat := [2,4,8,16,32,48,41,37,33,14,0,59,8,59,33,2,58,0,14,32,58,0,16,34,41,48,0,58,59,0,14,33,36,1,59,33]

theorem envBound24382 : H12AffineFastState.Bounded env24382 := by
  intro p hp
  have h : env24382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24381_24382 : H12AffineEnvironment.transform 9 14 env24381 = env24382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env24381 == env24382) = true)

def env24383 : List Nat := [2,4,8,16,32,49,41,36,33,1024,1,1076,9,1077,32,2,1077,1,1025,33,1076,0,17,35,40,48,1,1077,1076,1,1024,33,36,0,1077,33]

theorem envBound24383 : H12AffineFastState.Bounded env24383 := by
  intro p hp
  have h : env24383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24380_24383 : H12AffineEnvironment.transform 5 49 env24380 = env24383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env24380 == env24383) = true)

theorem identity24383 : scanCanonicalize (H12AffineFastState.compose env24383 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound24383 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24384 : List Nat := [2,4,8,16,26,11,19,30,27,1024,1,1038,9,1039,26,2,1039,1,1025,27,1038,0,17,25,18,10,1,1039,1038,1,1024,27,30,0,1039,27]

theorem envBound24384 : H12AffineFastState.Bounded env24384 := by
  intro p hp
  have h : env24384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24383_24384 : H12AffineEnvironment.transform 4 26 env24383 = env24384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env24383 == env24384) = true)

theorem identity24384 : scanCanonicalize (H12AffineFastState.compose env24384 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound24384 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24385 : List Nat := [2,4,8,10,0,11,9,4,1,1024,1,1038,9,1039,0,2,1039,1,1025,1,1038,0,11,3,8,10,1,1039,1038,1,1024,1,4,0,1039,1]

theorem envBound24385 : H12AffineFastState.Bounded env24385 := by
  intro p hp
  have h : env24385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24384_24385 : H12AffineEnvironment.transform 3 10 env24384 = env24385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env24384 == env24385) = true)

def leafEnv24385 : List Nat := [2,4,8,10,0,11,9,4,1,1024,1,1038,9,1039,0,2,1039,1,1025,1,1038,0,11,3,1025,8,1,10,1,1039,1038,1,1024,1,4,0,4,3,1039,1,0,1038,1]

def active24385 : List Nat := [0,1,2,9]

def tree24385 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24385 : H12WitnessSearch.Good tree24385 := H12GlobalWitnessIndex.good

theorem leafIdentity24385 : H12AffineFastState.composeSystem env24385 rootObs = leafEnv24385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24385 rootObs == leafEnv24385) = true)

theorem terminalChecked24385 : H12PackedTerminal.terminalCheckFast leafEnv24385 active24385 tree24385 = true := by decide +kernel

def env24386 : List Nat := [2,4,8,16,32,64,41,85,33,1024,113,1092,121,16384,80,2,1093,113,1136,81,16384,0,96,83,88,48,113,1093,1092,113,1024,33,36,112,16384,33]

theorem envBound24386 : H12AffineFastState.Bounded env24386 := by
  intro p hp
  have h : env24386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24378_24386 : H12AffineEnvironment.transform 10 113 env24378 = env24386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 113 env24378 == env24386) = true)

def env24387 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,5141,65536,4097,15420,66778,5140,21741,13461,65738,70844,8328,65690,2049,4096,4097,15421,1192,65675,65575,8201,16385,136]

theorem envBound24387 : H12AffineFastState.Bounded env24387 := by
  intro p hp
  have h : env24387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24373_24387 : H12AffineEnvironment.transform 14 5141 env24373 = env24387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5141 env24373 == env24387) = true)

theorem identity24387 : scanCanonicalize (H12AffineFastState.compose env24387 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 5349) := by decide +kernel

theorem selectedBound24387 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24388 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,5349,16384,5141,65536,4097,2265,66778,5140,21741,112,65738,70844,5229,65690,2049,4096,4097,2264,1192,65675,65575,5356,16385,136]

theorem envBound24388 : H12AffineFastState.Bounded env24388 := by
  intro p hp
  have h : env24388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24387_24388 : H12AffineEnvironment.transform 12 5349 env24387 = env24388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5349 env24387 == env24388) = true)

theorem identity24388 : scanCanonicalize (H12AffineFastState.compose env24388 (packedSelected [0,2,4] rootPS)) = affineNative (2^(15+1) ^^^ 17462) := by decide +kernel

theorem selectedBound24388 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env24389 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,5349,16384,5141,17462,4097,2265,16620,5140,21741,112,17660,20618,5229,17580,2049,4096,4097,2264,1192,17597,17425,5356,16385,136]

theorem envBound24389 : H12AffineFastState.Bounded env24389 := by
  intro p hp
  have h : env24389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24388_24389 : H12AffineEnvironment.transform 15 17462 env24388 = env24389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 17462 env24388 == env24389) = true)

theorem identity24389 : scanCanonicalize (H12AffineFastState.compose env24389 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1261) := by decide +kernel

theorem selectedBound24389 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24390 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,1261,8,16384,248,17462,1260,2265,16620,249,16384,112,17660,17511,128,17580,2049,1261,1260,2264,1192,17597,17425,1,16385,136]

theorem envBound24390 : H12AffineFastState.Bounded env24390 := by
  intro p hp
  have h : env24390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24389_24390 : H12AffineEnvironment.transform 11 1261 env24389 = env24390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1261 env24389 == env24390) = true)

theorem identity24390 : scanCanonicalize (H12AffineFastState.compose env24390 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound24390 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24391 : List Nat := [2,4,8,16,32,64,40,84,32,1024,2048,1093,8,16384,80,17462,1092,2161,16452,81,16384,112,17492,17511,40,17412,2049,1093,1092,2160,1024,17429,17425,1,16385,32]

theorem envBound24391 : H12AffineFastState.Bounded env24391 := by
  intro p hp
  have h : env24391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24390_24391 : H12AffineEnvironment.transform 6 40 env24390 = env24391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env24390 == env24391) = true)

theorem identity24391 : scanCanonicalize (H12AffineFastState.compose env24391 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1093) := by decide +kernel

theorem selectedBound24391 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24392 : List Nat := [2,4,8,16,32,64,40,84,32,1024,2048,1093,8,1093,80,115,1092,2161,1025,81,1093,112,17,34,40,65,2049,1093,1092,2160,1024,80,84,1,1092,32]

theorem envBound24392 : H12AffineFastState.Bounded env24392 := by
  intro p hp
  have h : env24392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24391_24392 : H12AffineEnvironment.transform 13 1093 env24391 = env24392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1093 env24391 == env24392) = true)

theorem identity24392 : scanCanonicalize (H12AffineFastState.compose env24392 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 107) := by decide +kernel

theorem selectedBound24392 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24393 : List Nat := [2,4,8,16,32,64,40,84,32,1024,107,1093,8,1093,80,115,1092,26,1025,81,1093,112,17,34,40,65,106,1093,1092,27,1024,80,84,1,1092,32]

theorem envBound24393 : H12AffineFastState.Bounded env24393 := by
  intro p hp
  have h : env24393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24392_24393 : H12AffineEnvironment.transform 10 107 env24392 = env24393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 107 env24392 == env24393) = true)

def env24394 : List Nat := [2,4,8,16,32,48,40,36,32,1024,27,1077,8,1077,32,3,1076,26,1025,33,1077,0,17,34,40,49,26,1077,1076,27,1024,32,36,1,1076,32]

theorem envBound24394 : H12AffineFastState.Bounded env24394 := by
  intro p hp
  have h : env24394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24393_24394 : H12AffineEnvironment.transform 5 48 env24393 = env24394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env24393 == env24394) = true)

theorem identity24394 : scanCanonicalize (H12AffineFastState.compose env24394 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound24394 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24395 : List Nat := [2,4,8,10,32,42,40,36,32,1024,1,1071,8,1071,32,3,1070,0,1025,33,1071,0,11,34,40,43,0,1071,1070,1,1024,32,36,1,1070,32]

theorem envBound24395 : H12AffineFastState.Bounded env24395 := by
  intro p hp
  have h : env24395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24394_24395 : H12AffineEnvironment.transform 3 10 env24394 = env24395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env24394 == env24395) = true)

def leafEnv24395 : List Nat := [2,4,8,10,32,42,40,36,32,1024,1,1071,8,1071,32,3,1070,0,1025,33,1071,0,11,34,1025,40,1,43,0,1071,1070,1,1024,32,36,1,4,35,1070,32,0,1070,1]

def active24395 : List Nat := [0,1,2,4,9]

def tree24395 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24395 : H12WitnessSearch.Good tree24395 := H12GlobalWitnessIndex.good

theorem leafIdentity24395 : H12AffineFastState.composeSystem env24395 rootObs = leafEnv24395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24395 rootObs == leafEnv24395) = true)

theorem terminalChecked24395 : H12PackedTerminal.terminalCheckFast leafEnv24395 active24395 tree24395 = true := by decide +kernel

def env24396 : List Nat := [2,4,8,16,32,49,40,37,32,1024,26,1076,8,1076,33,2,1077,26,1025,32,1076,1,17,34,40,48,27,1076,1077,27,1024,33,37,1,1077,32]

theorem envBound24396 : H12AffineFastState.Bounded env24396 := by
  intro p hp
  have h : env24396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24393_24396 : H12AffineEnvironment.transform 5 49 env24393 = env24396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env24393 == env24396) = true)

def env24397 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21740,41088,525328,70845,8328,525376,275516,33813,33812,634099,37052,103583,525564,8201,54292,136]

theorem envBound24397 : H12AffineFastState.Bounded env24397 := by
  intro p hp
  have h : env24397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24370_24397 : H12AffineEnvironment.transform 7 253 env24370 = env24397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env24370 == env24397) = true)

theorem identity24397 : scanCanonicalize (H12AffineFastState.compose env24397 (packedSelected [1,13,17,18,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound24397 : packedSelected [1,13,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env24398 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,32768,65536,4097,43049,524288,32769,21740,41088,525328,70845,8328,525376,39957,33813,33812,634099,37052,103583,525564,8201,54292,136]

theorem envBound24398 : H12AffineFastState.Bounded env24398 := by
  intro p hp
  have h : env24398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24397_24398 : H12AffineEnvironment.transform 17 43049 env24397 = env24398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env24397 == env24398) = true)

theorem identity24398 : scanCanonicalize (H12AffineFastState.compose env24398 (packedSelected [11,15] rootPS)) = affineNative (2^(18+1) ^^^ 23664) := by decide +kernel

theorem selectedBound24398 : packedSelected [11,15] rootPS < 2^1333 := by decide +kernel

def env24399 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,32768,65536,4097,43049,23664,32769,21740,41088,22624,70845,8328,22576,39957,33813,33812,127107,37052,103583,22668,8201,54292,136]

theorem envBound24399 : H12AffineFastState.Bounded env24399 := by
  intro p hp
  have h : env24399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24398_24399 : H12AffineEnvironment.transform 18 23664 env24398 = env24399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 23664 env24398 == env24399) = true)

theorem identity24399 : scanCanonicalize (H12AffineFastState.compose env24399 (packedSelected [11] rootPS)) = affineNative (2^(15+1) ^^^ 52415) := by decide +kernel

theorem selectedBound24399 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env24400 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,32768,52415,4097,43049,23664,32769,21740,41088,22624,55298,8328,22576,39957,33813,33812,15420,37052,22560,22668,8201,54292,136]

theorem envBound24400 : H12AffineFastState.Bounded env24400 := by
  intro p hp
  have h : env24400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24399_24400 : H12AffineEnvironment.transform 15 52415 env24399 = env24400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 52415 env24399 == env24400) = true)

theorem identity24400 : scanCanonicalize (H12AffineFastState.compose env24400 (packedSelected [0,7,12] rootPS)) = affineNative (2^(14+1) ^^^ 13509) := by decide +kernel

theorem selectedBound24400 : packedSelected [0,7,12] rootPS < 2^1333 := by decide +kernel

def env24401 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,13509,30842,4097,7404,23664,13508,21740,5189,22624,27847,8328,22576,10448,12496,12497,15420,9337,22560,22668,8201,24785,136]

theorem envBound24401 : H12AffineFastState.Bounded env24401 := by
  intro p hp
  have h : env24401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24400_24401 : H12AffineEnvironment.transform 14 13509 env24400 = env24401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13509 env24400 == env24401) = true)

theorem identity24401 : scanCanonicalize (H12AffineFastState.compose env24401 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound24401 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24402 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,121,16384,5308,22531,4097,7404,23664,5309,21740,5189,22624,19646,241,22576,2217,4265,4264,7237,1024,22560,22668,112,16552,136]

theorem envBound24402 : H12AffineFastState.Bounded env24402 := by
  intro p hp
  have h : env24402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24401_24402 : H12AffineEnvironment.transform 12 121 env24401 = env24402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env24401 == env24402) = true)

def env24403 : List Nat := [2,4,8,16,32,48,128,141,136,1024,2048,4096,9,16384,5308,22531,4097,7324,23552,5309,21660,5173,22544,19646,129,22576,2217,4265,4264,7221,1024,22560,22668,0,16552,136]

theorem envBound24403 : H12AffineFastState.Bounded env24403 := by
  intro p hp
  have h : env24403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24402_24403 : H12AffineEnvironment.transform 5 48 env24402 = env24403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env24402 == env24403) = true)

theorem identity24403 : scanCanonicalize (H12AffineFastState.compose env24403 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 6176) := by decide +kernel

theorem selectedBound24403 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env24404 : List Nat := [2,4,8,16,32,48,128,141,136,1024,2048,4096,9,6176,5308,35,4097,7324,1056,5309,3260,5173,48,5278,129,16,2217,4265,4264,7221,1024,0,172,0,6280,136]

theorem envBound24404 : H12AffineFastState.Bounded env24404 := by
  intro p hp
  have h : env24404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24403_24404 : H12AffineEnvironment.transform 13 6176 env24403 = env24404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6176 env24403 == env24404) = true)

def env24405 : List Nat := [2,4,8,16,32,48,128,141,136,1024,2048,136,9,2216,1076,35,137,3092,1056,1077,3260,1213,48,1046,129,16,2217,33,32,3261,1024,0,172,0,2048,136]

theorem envBound24405 : H12AffineFastState.Bounded env24405 := by
  intro p hp
  have h : env24405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24404_24405 : H12AffineEnvironment.transform 11 136 env24404 = env24405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env24404 == env24405) = true)

theorem identity24405 : scanCanonicalize (H12AffineFastState.compose env24405 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound24405 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24406 : List Nat := [2,4,8,16,27,11,128,141,136,1024,2048,136,9,2195,1039,24,137,3092,1051,1038,3207,1158,11,1046,129,16,2194,26,27,3206,1024,0,151,0,2048,136]

theorem envBound24406 : H12AffineFastState.Bounded env24406 := by
  intro p hp
  have h : env24406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24405_24406 : H12AffineEnvironment.transform 4 27 env24405 = env24406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env24405 == env24406) = true)

def env24407 : List Nat := [2,4,8,16,27,11,128,141,136,156,2048,136,9,2195,147,24,137,2184,135,146,2075,26,11,138,129,16,2194,26,27,2074,156,0,151,0,2048,136]

theorem envBound24407 : H12AffineFastState.Bounded env24407 := by
  intro p hp
  have h : env24407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24406_24407 : H12AffineEnvironment.transform 9 156 env24406 = env24407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 156 env24406 == env24407) = true)

theorem identity24407 : scanCanonicalize (H12AffineFastState.compose env24407 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound24407 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24408 : List Nat := [2,4,8,16,27,11,19,30,27,15,2048,27,9,2048,0,24,26,2075,20,1,2075,26,11,25,18,16,2049,26,27,2074,15,0,4,0,2048,27]

theorem envBound24408 : H12AffineFastState.Bounded env24408 := by
  intro p hp
  have h : env24408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24407_24408 : H12AffineEnvironment.transform 6 19 env24407 = env24408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env24407 == env24408) = true)

def leafEnv24408 : List Nat := [2,4,8,16,27,11,19,30,27,15,2048,27,9,2048,0,24,26,2075,20,1,2075,26,11,25,20,18,1,16,2049,26,27,2074,15,0,4,0,30,3,2048,27,0,2075,1]

def active24408 : List Nat := [0,1,2,3,10]

def tree24408 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24408 : H12WitnessSearch.Good tree24408 := H12GlobalWitnessIndex.good

theorem leafIdentity24408 : H12AffineFastState.composeSystem env24408 rootObs = leafEnv24408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24408 rootObs == leafEnv24408) = true)

theorem terminalChecked24408 : H12PackedTerminal.terminalCheckFast leafEnv24408 active24408 tree24408 = true := by decide +kernel

def env24409 : List Nat := [2,4,8,16,27,11,128,141,136,157,2048,136,9,2195,146,24,137,2185,134,147,2074,27,11,139,129,16,2194,26,27,2075,157,0,151,0,2048,136]

theorem envBound24409 : H12AffineFastState.Bounded env24409 := by
  intro p hp
  have h : env24409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24406_24409 : H12AffineEnvironment.transform 9 157 env24406 = env24409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 157 env24406 == env24409) = true)

def env24410 : List Nat := [2,4,8,16,32,48,128,141,136,1024,2048,137,9,2217,1077,35,136,3093,1056,1076,3260,1212,48,1047,129,16,2217,32,33,3260,1024,0,172,0,2049,136]

theorem envBound24410 : H12AffineFastState.Bounded env24410 := by
  intro p hp
  have h : env24410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24404_24410 : H12AffineEnvironment.transform 11 137 env24404 = env24410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 137 env24404 == env24410) = true)

theorem identity24410 : scanCanonicalize (H12AffineFastState.compose env24410 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 166) := by decide +kernel

theorem selectedBound24410 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24411 : List Nat := [2,4,8,16,32,48,128,141,136,166,2048,137,9,2217,147,35,136,2227,134,146,2074,26,48,177,129,16,2217,32,33,2074,166,0,172,0,2049,136]

theorem envBound24411 : H12AffineFastState.Bounded env24411 := by
  intro p hp
  have h : env24411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24410_24411 : H12AffineEnvironment.transform 9 166 env24410 = env24411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 166 env24410 == env24411) = true)

def env24412 : List Nat := [2,4,8,16,32,48,40,37,32,14,2048,33,9,2049,59,35,32,2075,46,58,2074,26,48,25,41,16,2049,32,33,2074,14,0,4,0,2049,32]

theorem envBound24412 : H12AffineFastState.Bounded env24412 := by
  intro p hp
  have h : env24412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24411_24412 : H12AffineEnvironment.transform 6 40 env24411 = env24412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env24411 == env24412) = true)

theorem identity24412 : scanCanonicalize (H12AffineFastState.compose env24412 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound24412 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24413 : List Nat := [2,4,8,16,27,11,19,30,27,14,2048,26,9,2049,0,24,27,2075,21,1,2074,26,11,25,18,16,2049,27,26,2074,14,0,4,0,2049,27]

theorem envBound24413 : H12AffineFastState.Bounded env24413 := by
  intro p hp
  have h : env24413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24412_24413 : H12AffineEnvironment.transform 4 27 env24412 = env24413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env24412 == env24413) = true)

def leafEnv24413 : List Nat := [2,4,8,16,27,11,19,30,27,14,2048,26,9,2049,0,24,27,2075,21,1,2074,26,11,25,21,18,1,16,2049,27,26,2074,14,0,4,0,30,3,2049,27,0,2074,1]

def active24413 : List Nat := [0,1,2,3,10]

def tree24413 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24413 : H12WitnessSearch.Good tree24413 := H12GlobalWitnessIndex.good

theorem leafIdentity24413 : H12AffineFastState.composeSystem env24413 rootObs = leafEnv24413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24413 rootObs == leafEnv24413) = true)

theorem terminalChecked24413 : H12PackedTerminal.terminalCheckFast leafEnv24413 active24413 tree24413 = true := by decide +kernel

def env24414 : List Nat := [2,4,8,16,32,48,41,36,33,15,2048,32,9,2048,58,35,33,2074,47,59,2074,26,48,24,40,16,2048,32,33,2074,15,0,5,0,2049,33]

theorem envBound24414 : H12AffineFastState.Bounded env24414 := by
  intro p hp
  have h : env24414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24411_24414 : H12AffineEnvironment.transform 6 41 env24411 = env24414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env24411 == env24414) = true)

def env24415 : List Nat := [2,4,8,16,32,49,128,140,136,1024,2048,4096,8,16384,5308,22531,4097,7325,23553,5309,21661,5172,22545,19646,128,22576,2217,4265,4264,7220,1024,22560,22668,1,16552,136]

theorem envBound24415 : H12AffineFastState.Bounded env24415 := by
  intro p hp
  have h : env24415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24402_24415 : H12AffineEnvironment.transform 5 49 env24402 = env24415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env24402 == env24415) = true)

theorem identity24415 : scanCanonicalize (H12AffineFastState.compose env24415 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 3125) := by decide +kernel

theorem selectedBound24415 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env24416 : List Nat := [2,4,8,16,32,49,128,140,136,1024,2048,4096,8,3125,5308,5174,4097,7325,4148,5309,6312,5172,5156,139,128,5125,2217,4265,4264,7220,1024,5141,5305,1,3229,136]

theorem envBound24416 : H12AffineFastState.Bounded env24416 := by
  intro p hp
  have h : env24416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24415_24416 : H12AffineEnvironment.transform 13 3125 env24415 = env24416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3125 env24415 == env24416) = true)

theorem identity24416 : scanCanonicalize (H12AffineFastState.compose env24416 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 178) := by decide +kernel

theorem selectedBound24416 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24417 : List Nat := [2,4,8,16,32,49,128,140,136,1024,2048,178,8,3125,1038,1156,179,3119,134,1039,2074,1158,1174,139,128,1207,2217,27,26,3206,1024,1191,1035,1,3229,136]

theorem envBound24417 : H12AffineFastState.Bounded env24417 := by
  intro p hp
  have h : env24417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24416_24417 : H12AffineEnvironment.transform 11 178 env24416 = env24417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 178 env24416 == env24417) = true)

def leafEnv24417 : List Nat := [2,4,8,16,32,49,128,140,136,1024,2048,178,8,3125,1038,1156,179,3119,134,1039,2074,1158,1174,139,134,128,1,1207,2217,27,26,3206,1024,1191,1035,1,1155,1037,3229,136,0,2226,1]

def active24417 : List Nat := [0,1,2,3,4,6,9,10]

def tree24417 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24417 : H12WitnessSearch.Good tree24417 := H12GlobalWitnessIndex.good

theorem leafIdentity24417 : H12AffineFastState.composeSystem env24417 rootObs = leafEnv24417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24417 rootObs == leafEnv24417) = true)

theorem terminalChecked24417 : H12PackedTerminal.terminalCheckFast leafEnv24417 active24417 tree24417 = true := by decide +kernel

def env24418 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21777,41089,525328,70976,8328,525376,275904,33813,33812,634126,37185,4294967296,525569,4295079274,54292,136]

theorem envBound24418 : H12AffineFastState.Bounded env24418 := by
  intro p hp
  have h : env24418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24368_24418 : H12AffineEnvironment.transform 21 41089 env24368 = env24418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env24368 == env24418) = true)

theorem identity24418 : scanCanonicalize (H12AffineFastState.compose env24418 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 111978) := by decide +kernel

theorem selectedBound24418 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24419 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21777,41089,525328,70976,8328,525376,275904,33813,33812,634126,37185,111978,525569,0,54292,136]

theorem envBound24419 : H12AffineFastState.Bounded env24419 := by
  intro p hp
  have h : env24419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24418_24419 : H12AffineEnvironment.transform 31 111978 env24418 = env24419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 111978 env24418 == env24419) = true)

def env24420 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21741,41089,525328,70844,8328,525376,275516,33813,33812,634098,37053,111766,525565,0,54292,136]

theorem envBound24420 : H12AffineFastState.Bounded env24420 := by
  intro p hp
  have h : env24420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24419_24420 : H12AffineEnvironment.transform 7 252 env24419 = env24420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env24419 == env24420) = true)

theorem identity24420 : scanCanonicalize (H12AffineFastState.compose env24420 (packedSelected [1,13,17,18,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound24420 : packedSelected [1,13,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env24421 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,32768,65536,4097,43049,524288,32769,21741,41089,525328,70844,8328,525376,39957,33813,33812,634098,37053,111766,525565,0,54292,136]

theorem envBound24421 : H12AffineFastState.Bounded env24421 := by
  intro p hp
  have h : env24421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24420_24421 : H12AffineEnvironment.transform 17 43049 env24420 = env24421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env24420 == env24421) = true)

theorem identity24421 : scanCanonicalize (H12AffineFastState.compose env24421 (packedSelected [11,15] rootPS)) = affineNative (2^(18+1) ^^^ 23664) := by decide +kernel

theorem selectedBound24421 : packedSelected [11,15] rootPS < 2^1333 := by decide +kernel

def env24422 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,32768,65536,4097,43049,23664,32769,21741,41089,22624,70844,8328,22576,39957,33813,33812,127106,37053,111766,22669,0,54292,136]

theorem envBound24422 : H12AffineFastState.Bounded env24422 := by
  intro p hp
  have h : env24422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24421_24422 : H12AffineEnvironment.transform 18 23664 env24421 = env24422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 23664 env24421 == env24422) = true)

theorem identity24422 : scanCanonicalize (H12AffineFastState.compose env24422 (packedSelected [11] rootPS)) = affineNative (2^(15+1) ^^^ 52414) := by decide +kernel

theorem selectedBound24422 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env24423 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,32768,52414,4097,43049,23664,32769,21741,41089,22624,55298,8328,22576,39957,33813,33812,15420,37053,30760,22669,0,54292,136]

theorem envBound24423 : H12AffineFastState.Bounded env24423 := by
  intro p hp
  have h : env24423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24422_24423 : H12AffineEnvironment.transform 15 52414 env24422 = env24423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 52414 env24422 == env24423) = true)

theorem identity24423 : scanCanonicalize (H12AffineFastState.compose env24423 (packedSelected [0,7,12] rootPS)) = affineNative (2^(14+1) ^^^ 13508) := by decide +kernel

theorem selectedBound24423 : packedSelected [0,7,12] rootPS < 2^1333 := by decide +kernel

def env24424 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,13508,30842,4097,7405,23664,13509,21741,5189,22624,27846,8328,22576,10449,12497,12496,15420,9337,30760,22669,0,24784,136]

theorem envBound24424 : H12AffineFastState.Bounded env24424 := by
  intro p hp
  have h : env24424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24423_24424 : H12AffineEnvironment.transform 14 13508 env24423 = env24424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13508 env24423 == env24424) = true)

theorem identity24424 : scanCanonicalize (H12AffineFastState.compose env24424 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound24424 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24425 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,121,16384,5309,22531,4097,7405,23664,5308,21741,5189,22624,19647,241,22576,2216,4264,4265,7237,1024,22609,22669,0,16553,136]

theorem envBound24425 : H12AffineFastState.Bounded env24425 := by
  intro p hp
  have h : env24425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24424_24425 : H12AffineEnvironment.transform 12 121 env24424 = env24425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env24424 == env24425) = true)

def env24426 : List Nat := [2,4,8,16,32,64,88,36,80,1024,2048,4096,121,16384,5221,22531,4097,7221,23664,5220,21557,5189,22624,19559,41,22576,2160,4208,4209,7237,1024,22609,22613,0,16497,80]

theorem envBound24426 : H12AffineFastState.Bounded env24426 := by
  intro p hp
  have h : env24426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24425_24426 : H12AffineEnvironment.transform 6 88 env24425 = env24426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24425 == env24426) = true)

theorem identity24426 : scanCanonicalize (H12AffineFastState.compose env24426 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound24426 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24427 : List Nat := [2,4,8,16,32,48,40,36,32,1024,2048,4096,9,16384,5141,22531,4097,7221,23552,5140,21557,5173,22544,19479,41,22576,2048,4096,4097,7221,1024,22561,22565,0,16385,32]

theorem envBound24427 : H12AffineFastState.Bounded env24427 := by
  intro p hp
  have h : env24427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24426_24427 : H12AffineEnvironment.transform 5 48 env24426 = env24427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env24426 == env24427) = true)

def env24428 : List Nat := [2,4,8,16,32,48,40,36,32,1024,2048,32,9,16384,1077,18467,33,3093,19488,1076,17429,1045,18480,19479,41,18448,2048,32,33,3093,1024,18433,18437,0,16385,32]

theorem envBound24428 : H12AffineFastState.Bounded env24428 := by
  intro p hp
  have h : env24428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24427_24428 : H12AffineEnvironment.transform 11 32 env24427 = env24428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env24427 == env24428) = true)

theorem identity24428 : scanCanonicalize (H12AffineFastState.compose env24428 (packedSelected [1] rootPS)) = affineNative (2^(13+1) ^^^ 3087) := by decide +kernel

theorem selectedBound24428 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24429 : List Nat := [2,4,8,16,32,48,40,36,32,1024,2048,32,9,3087,1077,1068,33,3093,47,1076,2074,1045,1087,24,41,1055,2048,32,33,3093,1024,1038,1034,0,3086,32]

theorem envBound24429 : H12AffineFastState.Bounded env24429 := by
  intro p hp
  have h : env24429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24428_24429 : H12AffineEnvironment.transform 13 3087 env24428 = env24429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3087 env24428 == env24429) = true)

def leafEnv24429 : List Nat := [2,4,8,16,32,48,40,36,32,1024,2048,32,9,3087,1077,1068,33,3093,47,1076,2074,1045,1087,24,47,41,1,1055,2048,32,33,3093,1024,1038,1034,0,1066,1078,3086,32,0,2075,1]

def active24429 : List Nat := [0,1,2,3,4,9,10]

def tree24429 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24429 : H12WitnessSearch.Good tree24429 := H12GlobalWitnessIndex.good

theorem leafIdentity24429 : H12AffineFastState.composeSystem env24429 rootObs = leafEnv24429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24429 rootObs == leafEnv24429) = true)

theorem terminalChecked24429 : H12PackedTerminal.terminalCheckFast leafEnv24429 active24429 tree24429 = true := by decide +kernel

def env24430 : List Nat := [2,4,8,16,32,48,40,36,32,1024,2048,33,9,16384,1076,18466,32,3092,19489,1077,17428,1044,18481,19479,41,18449,2048,33,32,3092,1024,18432,18436,0,16385,32]

theorem envBound24430 : H12AffineFastState.Bounded env24430 := by
  intro p hp
  have h : env24430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24427_24430 : H12AffineEnvironment.transform 11 33 env24427 = env24430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env24427 == env24430) = true)

theorem identity24430 : scanCanonicalize (H12AffineFastState.compose env24430 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound24430 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24431 : List Nat := [2,4,8,16,26,10,18,30,26,1024,2048,27,9,16384,1038,18456,26,3092,19483,1039,17428,1044,18443,19479,19,18449,2048,27,26,3092,1024,18432,18436,0,16385,26]

theorem envBound24431 : H12AffineFastState.Bounded env24431 := by
  intro p hp
  have h : env24431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24430_24431 : H12AffineEnvironment.transform 4 26 env24430 = env24431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env24430 == env24431) = true)

def leafEnv24431 : List Nat := [2,4,8,16,26,10,18,30,26,1024,2048,27,9,16384,1038,18456,26,3092,19483,1039,17428,1044,18443,19479,19483,19,1,18449,2048,27,26,3092,1024,18432,18436,0,18462,1037,16385,26,0,17429,1]

def active24431 : List Nat := [0,1,2,3,9,10,13]

def tree24431 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24431 : H12WitnessSearch.Good tree24431 := H12GlobalWitnessIndex.good

theorem leafIdentity24431 : H12AffineFastState.composeSystem env24431 rootObs = leafEnv24431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24431 rootObs == leafEnv24431) = true)

theorem terminalChecked24431 : H12PackedTerminal.terminalCheckFast leafEnv24431 active24431 tree24431 = true := by decide +kernel

def env24432 : List Nat := [2,4,8,16,32,64,89,37,81,1024,2048,4096,121,16384,5220,22531,4097,7220,23664,5221,21556,5189,22624,19558,40,22576,2161,4209,4208,7237,1024,22609,22612,0,16496,81]

theorem envBound24432 : H12AffineFastState.Bounded env24432 := by
  intro p hp
  have h : env24432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24425_24432 : H12AffineEnvironment.transform 6 89 env24425 = env24432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env24425 == env24432) = true)

theorem identity24432 : scanCanonicalize (H12AffineFastState.compose env24432 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 3140) := by decide +kernel

theorem selectedBound24432 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24433 : List Nat := [2,4,8,16,32,64,89,37,81,1024,2048,4096,121,3140,5220,5191,4097,7220,4148,5221,6256,5189,5156,34,40,5236,2161,4209,4208,7237,1024,5141,5136,0,3124,81]

theorem envBound24433 : H12AffineFastState.Bounded env24433 := by
  intro p hp
  have h : env24433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24432_24433 : H12AffineEnvironment.transform 13 3140 env24432 = env24433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3140 env24432 == env24433) = true)

theorem identity24433 : scanCanonicalize (H12AffineFastState.compose env24433 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound24433 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24434 : List Nat := [2,4,8,16,32,48,41,37,33,1024,2048,4096,9,3124,5140,5175,4097,7220,4148,5141,6144,5173,5156,34,40,5124,2049,4097,4096,7221,1024,5141,5136,0,3124,33]

theorem envBound24434 : H12AffineFastState.Bounded env24434 := by
  intro p hp
  have h : env24434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24433_24434 : H12AffineEnvironment.transform 5 48 env24433 = env24434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env24433 == env24434) = true)

theorem identity24434 : scanCanonicalize (H12AffineFastState.compose env24434 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 26) := by decide +kernel

theorem selectedBound24434 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24435 : List Nat := [2,4,8,16,32,48,41,37,33,1024,2048,26,9,3124,1038,1069,27,3118,46,1039,2074,1071,1086,34,40,1054,2049,27,26,3119,1024,1039,1034,0,3124,33]

theorem envBound24435 : H12AffineFastState.Bounded env24435 := by
  intro p hp
  have h : env24435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24434_24435 : H12AffineEnvironment.transform 11 26 env24434 = env24435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 26 env24434 == env24435) = true)

def leafEnv24435 : List Nat := [2,4,8,16,32,48,41,37,33,1024,2048,26,9,3124,1038,1069,27,3118,46,1039,2074,1071,1086,34,46,40,1,1054,2049,27,26,3119,1024,1039,1034,0,1067,1037,3124,33,0,2074,1]

def active24435 : List Nat := [0,1,2,3,4,9,10]

def tree24435 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24435 : H12WitnessSearch.Good tree24435 := H12GlobalWitnessIndex.good

theorem leafIdentity24435 : H12AffineFastState.composeSystem env24435 rootObs = leafEnv24435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24435 rootObs == leafEnv24435) = true)

theorem terminalChecked24435 : H12PackedTerminal.terminalCheckFast leafEnv24435 active24435 tree24435 = true := by decide +kernel

def env24436 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21740,41089,525328,70845,8328,525376,275517,33813,33812,634099,37052,111767,525564,0,54292,136]

theorem envBound24436 : H12AffineFastState.Bounded env24436 := by
  intro p hp
  have h : env24436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24419_24436 : H12AffineEnvironment.transform 7 253 env24419 = env24436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env24419 == env24436) = true)

theorem identity24436 : scanCanonicalize (H12AffineFastState.compose env24436 (packedSelected [1,13,17,18,23,24] rootPS)) = affineNative (2^(18+1) ^^^ 102606) := by decide +kernel

theorem selectedBound24436 : packedSelected [1,13,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env24437 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,32768,65536,4097,262144,102606,32769,21740,41089,103646,70845,8328,103566,275517,33813,33812,15421,37052,111767,103474,0,54292,136]

theorem envBound24437 : H12AffineFastState.Bounded env24437 := by
  intro p hp
  have h : env24437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24436_24437 : H12AffineEnvironment.transform 18 102606 env24436 = env24437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 102606 env24436 == env24437) = true)

theorem identity24437 : scanCanonicalize (H12AffineFastState.compose env24437 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound24437 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24438 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,32768,65536,4097,43049,102606,32769,21740,41089,103646,70845,8328,103566,39956,33813,33812,15421,37052,111767,103474,0,54292,136]

theorem envBound24438 : H12AffineFastState.Bounded env24438 := by
  intro p hp
  have h : env24438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24437_24438 : H12AffineEnvironment.transform 17 43049 env24437 = env24438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env24437 == env24438) = true)

def env24439 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,5140,65536,4097,15421,66778,5141,21740,13461,65738,70845,8328,65690,2048,4097,4096,15421,1192,73859,65574,0,16384,136]

theorem envBound24439 : H12AffineFastState.Bounded env24439 := by
  intro p hp
  have h : env24439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24438_24439 : H12AffineEnvironment.transform 14 5140 env24438 = env24439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5140 env24438 == env24439) = true)

theorem identity24439 : scanCanonicalize (H12AffineFastState.compose env24439 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound24439 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24440 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,5140,2,4097,15421,1240,5141,21740,13461,200,5311,8328,152,2048,4097,4096,15421,1192,8321,36,0,16384,136]

theorem envBound24440 : H12AffineFastState.Bounded env24440 := by
  intro p hp
  have h : env24440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24439_24440 : H12AffineEnvironment.transform 15 2 env24439 = env24440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env24439 == env24440) = true)

theorem identity24440 : scanCanonicalize (H12AffineFastState.compose env24440 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 3229) := by decide +kernel

theorem selectedBound24440 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env24441 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,3229,8192,16384,2185,2,3228,8352,1240,2184,18545,10248,200,2082,8328,152,2048,3228,3229,8352,1192,8321,36,0,16384,136]

theorem envBound24441 : H12AffineFastState.Bounded env24441 := by
  intro p hp
  have h : env24441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24440_24441 : H12AffineEnvironment.transform 11 3229 env24440 = env24441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3229 env24440 == env24441) = true)

theorem identity24441 : scanCanonicalize (H12AffineFastState.compose env24441 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 2208) := by decide +kernel

theorem selectedBound24441 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24442 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,3229,2208,16384,2185,2,3228,2048,1240,2184,18545,168,200,2082,2088,152,2048,3228,3229,2048,1192,2081,36,0,16384,136]

theorem envBound24442 : H12AffineFastState.Bounded env24442 := by
  intro p hp
  have h : env24442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24441_24442 : H12AffineEnvironment.transform 12 2208 env24441 = env24442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2208 env24441 == env24442) = true)

theorem identity24442 : scanCanonicalize (H12AffineFastState.compose env24442 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound24442 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24443 : List Nat := [2,4,8,16,32,64,40,85,32,1024,2048,3125,2056,16384,2081,2,3124,2048,1136,2080,18545,0,96,2082,2088,48,2048,3124,3125,2048,1024,2081,36,0,16384,32]

theorem envBound24443 : H12AffineFastState.Bounded env24443 := by
  intro p hp
  have h : env24443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24442_24443 : H12AffineEnvironment.transform 6 40 env24442 = env24443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env24442 == env24443) = true)

theorem identity24443 : scanCanonicalize (H12AffineFastState.compose env24443 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound24443 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24444 : List Nat := [2,4,8,16,32,64,40,85,32,1024,1,1076,9,16384,32,2,1077,1,1136,33,16496,0,96,35,41,48,1,1077,1076,1,1024,32,36,0,16384,32]

theorem envBound24444 : H12AffineFastState.Bounded env24444 := by
  intro p hp
  have h : env24444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24443_24444 : H12AffineEnvironment.transform 10 1 env24443 = env24444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env24443 == env24444) = true)

theorem identity24444 : scanCanonicalize (H12AffineFastState.compose env24444 (packedSelected [1] rootPS)) = affineNative (2^(13+1) ^^^ 59) := by decide +kernel

theorem selectedBound24444 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24445 : List Nat := [2,4,8,16,32,64,40,85,32,1024,1,1076,9,59,32,2,1077,1,1136,33,75,0,96,35,41,48,1,1077,1076,1,1024,32,36,0,59,32]

theorem envBound24445 : H12AffineFastState.Bounded env24445 := by
  intro p hp
  have h : env24445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24444_24445 : H12AffineEnvironment.transform 13 59 env24444 = env24445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 59 env24444 == env24445) = true)

def env24446 : List Nat := [2,4,8,16,32,48,40,37,32,1024,1,1076,9,59,32,2,1077,1,1024,33,59,0,16,35,41,48,1,1077,1076,1,1024,32,36,0,59,32]

theorem envBound24446 : H12AffineFastState.Bounded env24446 := by
  intro p hp
  have h : env24446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24445_24446 : H12AffineEnvironment.transform 5 48 env24445 = env24446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env24445 == env24446) = true)

def env24447 : List Nat := [2,4,8,16,32,49,40,36,32,1024,1,1076,9,59,32,2,1077,1,1025,33,58,0,17,35,41,48,1,1077,1076,1,1024,32,36,0,59,32]

theorem envBound24447 : H12AffineFastState.Bounded env24447 := by
  intro p hp
  have h : env24447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24445_24447 : H12AffineEnvironment.transform 5 49 env24445 = env24447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env24445 == env24447) = true)

theorem identity24447 : scanCanonicalize (H12AffineFastState.compose env24447 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound24447 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24448 : List Nat := [2,4,8,16,32,49,40,36,32,14,1,58,9,59,32,2,59,1,15,33,58,0,17,35,41,48,1,59,58,1,14,32,36,0,59,32]

theorem envBound24448 : H12AffineFastState.Bounded env24448 := by
  intro p hp
  have h : env24448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24447_24448 : H12AffineEnvironment.transform 9 14 env24447 = env24448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env24447 == env24448) = true)

def leafEnv24448 : List Nat := [2,4,8,16,32,49,40,36,32,14,1,58,9,59,32,2,59,1,15,33,58,0,17,35,15,41,1,48,1,59,58,1,14,32,36,0,4,35,59,32,0,58,1]

def active24448 : List Nat := [0,1,2,3,4]

def tree24448 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24448 : H12WitnessSearch.Good tree24448 := H12GlobalWitnessIndex.good

theorem leafIdentity24448 : H12AffineFastState.composeSystem env24448 rootObs = leafEnv24448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24448 rootObs == leafEnv24448) = true)

theorem terminalChecked24448 : H12PackedTerminal.terminalCheckFast leafEnv24448 active24448 tree24448 = true := by decide +kernel

def env24449 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,5141,65536,4097,15420,66779,5140,21740,13460,65739,70845,8328,65691,2049,4096,4097,15421,1193,73858,65575,0,16385,136]

theorem envBound24449 : H12AffineFastState.Bounded env24449 := by
  intro p hp
  have h : env24449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24438_24449 : H12AffineEnvironment.transform 14 5141 env24438 = env24449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5141 env24438 == env24449) = true)

theorem identity24449 : scanCanonicalize (H12AffineFastState.compose env24449 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 5349) := by decide +kernel

theorem selectedBound24449 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24450 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,5349,16384,5141,65536,4097,2265,66779,5140,21740,113,65739,70845,5229,65691,2049,4096,4097,2264,1193,70759,65575,0,16385,136]

theorem envBound24450 : H12AffineFastState.Bounded env24450 := by
  intro p hp
  have h : env24450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24449_24450 : H12AffineEnvironment.transform 12 5349 env24449 = env24450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5349 env24449 == env24450) = true)

theorem identity24450 : scanCanonicalize (H12AffineFastState.compose env24450 (packedSelected [0,2,4] rootPS)) = affineNative (2^(15+1) ^^^ 17462) := by decide +kernel

theorem selectedBound24450 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env24451 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,5349,16384,5141,17462,4097,2265,16621,5140,21740,113,17661,20619,5229,17581,2049,4096,4097,2264,1193,20561,17425,0,16385,136]

theorem envBound24451 : H12AffineFastState.Bounded env24451 := by
  intro p hp
  have h : env24451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24450_24451 : H12AffineEnvironment.transform 15 17462 env24450 = env24451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 17462 env24450 == env24451) = true)

theorem identity24451 : scanCanonicalize (H12AffineFastState.compose env24451 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1260) := by decide +kernel

theorem selectedBound24451 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24452 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,1260,9,16384,249,17462,1261,2265,16621,248,16384,113,17661,17511,129,17581,2049,1260,1261,2264,1193,17597,17425,0,16385,136]

theorem envBound24452 : H12AffineFastState.Bounded env24452 := by
  intro p hp
  have h : env24452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24451_24452 : H12AffineEnvironment.transform 11 1260 env24451 = env24452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1260 env24451 == env24452) = true)

theorem identity24452 : scanCanonicalize (H12AffineFastState.compose env24452 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound24452 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24453 : List Nat := [2,4,8,16,32,64,41,84,33,1024,2048,1093,9,16384,80,17462,1092,2160,16452,81,16384,113,17492,17511,40,17412,2049,1093,1092,2161,1024,17428,17425,0,16385,33]

theorem envBound24453 : H12AffineFastState.Bounded env24453 := by
  intro p hp
  have h : env24453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24452_24453 : H12AffineEnvironment.transform 6 41 env24452 = env24453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env24452 == env24453) = true)

def env24454 : List Nat := [2,4,8,16,32,64,41,84,33,1024,0,1093,9,16384,80,17462,1092,112,16452,81,16384,113,17492,17511,40,17412,1,1093,1092,113,1024,17428,17425,0,16385,33]

theorem envBound24454 : H12AffineFastState.Bounded env24454 := by
  intro p hp
  have h : env24454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24453_24454 : H12AffineEnvironment.transform 10 0 env24453 = env24454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env24453 == env24454) = true)

theorem identity24454 : scanCanonicalize (H12AffineFastState.compose env24454 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound24454 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24455 : List Nat := [2,4,8,16,32,49,41,37,33,1024,0,1076,9,16384,33,17462,1077,1,16437,32,16384,0,17445,17430,40,17412,1,1076,1077,0,1024,17428,17425,0,16385,33]

theorem envBound24455 : H12AffineFastState.Bounded env24455 := by
  intro p hp
  have h : env24455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24454_24455 : H12AffineEnvironment.transform 5 49 env24454 = env24455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env24454 == env24455) = true)

def env24456 : List Nat := [2,4,8,16,32,49,41,37,33,1024,0,1076,9,32,33,1046,1077,1,21,32,32,0,1029,1078,40,1060,1,1076,1077,0,1024,1076,1073,0,33,33]

theorem envBound24456 : H12AffineFastState.Bounded env24456 := by
  intro p hp
  have h : env24456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24455_24456 : H12AffineEnvironment.transform 13 32 env24455 = env24456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 32 env24455 == env24456) = true)

theorem identity24456 : scanCanonicalize (H12AffineFastState.compose env24456 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound24456 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24457 : List Nat := [2,4,8,10,32,43,41,37,33,1024,0,1070,9,32,33,1036,1071,1,15,32,32,0,1029,1068,40,1060,1,1070,1071,0,1024,1070,1067,0,33,33]

theorem envBound24457 : H12AffineFastState.Bounded env24457 := by
  intro p hp
  have h : env24457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24456_24457 : H12AffineEnvironment.transform 3 10 env24456 = env24457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env24456 == env24457) = true)

def leafEnv24457 : List Nat := [2,4,8,10,32,43,41,37,33,1024,0,1070,9,32,33,1036,1071,1,15,32,32,0,1029,1068,15,40,1,1060,1,1070,1071,0,1024,1070,1067,0,1034,34,33,33,0,33,1]

def active24457 : List Nat := [0,1,2,4,9]

def tree24457 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24457 : H12WitnessSearch.Good tree24457 := H12GlobalWitnessIndex.good

theorem leafIdentity24457 : H12AffineFastState.composeSystem env24457 rootObs = leafEnv24457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24457 rootObs == leafEnv24457) = true)

theorem terminalChecked24457 : H12PackedTerminal.terminalCheckFast leafEnv24457 active24457 tree24457 = true := by decide +kernel

def env24458 : List Nat := [2,4,8,16,32,49,41,37,33,1024,0,1076,9,33,33,1047,1077,1,20,32,33,0,1028,1079,40,1061,1,1076,1077,0,1024,1077,1072,0,32,33]

theorem envBound24458 : H12AffineFastState.Bounded env24458 := by
  intro p hp
  have h : env24458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24455_24458 : H12AffineEnvironment.transform 13 33 env24455 = env24458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 33 env24455 == env24458) = true)

theorem identity24458 : scanCanonicalize (H12AffineFastState.compose env24458 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound24458 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24459 : List Nat := [2,4,8,16,32,49,41,37,33,14,0,58,9,33,33,25,59,1,20,32,33,0,10,57,40,43,1,58,59,0,14,59,62,0,32,33]

theorem envBound24459 : H12AffineFastState.Bounded env24459 := by
  intro p hp
  have h : env24459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24458_24459 : H12AffineEnvironment.transform 9 14 env24458 = env24459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env24458 == env24459) = true)

def leafEnv24459 : List Nat := [2,4,8,16,32,49,41,37,33,14,0,58,9,33,33,25,59,1,20,32,33,0,10,57,20,40,1,43,1,58,59,0,14,59,62,0,31,34,32,33,0,32,1]

def active24459 : List Nat := [0,1,2,3,4]

def tree24459 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24459 : H12WitnessSearch.Good tree24459 := H12GlobalWitnessIndex.good

theorem leafIdentity24459 : H12AffineFastState.composeSystem env24459 rootObs = leafEnv24459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24459 rootObs == leafEnv24459) = true)

theorem terminalChecked24459 : H12PackedTerminal.terminalCheckFast leafEnv24459 active24459 tree24459 = true := by decide +kernel

def env24460 : List Nat := [2,4,8,16,32,64,41,84,33,1024,1,1093,9,16384,80,17462,1092,113,16452,81,16384,113,17492,17511,40,17412,0,1093,1092,112,1024,17428,17425,0,16385,33]

theorem envBound24460 : H12AffineFastState.Bounded env24460 := by
  intro p hp
  have h : env24460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24453_24460 : H12AffineEnvironment.transform 10 1 env24453 = env24460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env24453 == env24460) = true)

def env24461 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21777,4194304,525328,70977,8328,525376,4494656,33812,33813,634127,37184,4294967296,525569,4299232746,54293,136]

theorem envBound24461 : H12AffineFastState.Bounded env24461 := by
  intro p hp
  have h : env24461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24367_24461 : H12AffineEnvironment.transform 23 70977 env24367 = env24461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 70977 env24367 == env24461) = true)

def env24462 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21777,41088,525328,70977,8328,525376,275904,33812,33813,634127,37184,4294967296,525569,4295079274,54293,136]

theorem envBound24462 : H12AffineFastState.Bounded env24462 := by
  intro p hp
  have h : env24462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24461_24462 : H12AffineEnvironment.transform 21 41088 env24461 = env24462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env24461 == env24462) = true)

theorem identity24462 : scanCanonicalize (H12AffineFastState.compose env24462 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 594023) := by decide +kernel

theorem selectedBound24462 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24463 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21777,41088,525328,70977,8328,525376,275904,33812,33813,634127,37184,594023,525569,566541,54293,136]

theorem envBound24463 : H12AffineFastState.Bounded env24463 := by
  intro p hp
  have h : env24463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24462_24463 : H12AffineEnvironment.transform 31 594023 env24462 = env24463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 594023 env24462 == env24463) = true)

def env24464 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21741,41088,525328,70845,8328,525376,275516,33812,33813,634099,37052,594023,525565,566513,54293,136]

theorem envBound24464 : H12AffineFastState.Bounded env24464 := by
  intro p hp
  have h : env24464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24463_24464 : H12AffineEnvironment.transform 7 252 env24463 = env24464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env24463 == env24464) = true)

theorem identity24464 : scanCanonicalize (H12AffineFastState.compose env24464 (packedSelected [1,13,17,18,23,24] rootPS)) = affineNative (2^(18+1) ^^^ 102607) := by decide +kernel

theorem selectedBound24464 : packedSelected [1,13,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env24465 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,32768,65536,4097,262144,102607,32769,21741,41088,103647,70845,8328,103567,275516,33812,33813,15420,37052,32936,103474,78910,54293,136]

theorem envBound24465 : H12AffineFastState.Bounded env24465 := by
  intro p hp
  have h : env24465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24464_24465 : H12AffineEnvironment.transform 18 102607 env24464 = env24465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 102607 env24464 == env24465) = true)

theorem identity24465 : scanCanonicalize (H12AffineFastState.compose env24465 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound24465 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24466 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,32768,65536,4097,43049,102607,32769,21741,41088,103647,70845,8328,103567,39957,33812,33813,15420,37052,32936,103474,78910,54293,136]

theorem envBound24466 : H12AffineFastState.Bounded env24466 := by
  intro p hp
  have h : env24466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24465_24466 : H12AffineEnvironment.transform 17 43049 env24465 = env24466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env24465 == env24466) = true)

def env24467 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,5140,65536,4097,15421,66779,5141,21741,13460,65739,70845,8328,65691,2049,4096,4097,15420,1192,5308,65574,78910,16385,136]

theorem envBound24467 : H12AffineFastState.Bounded env24467 := by
  intro p hp
  have h : env24467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24466_24467 : H12AffineEnvironment.transform 14 5140 env24466 = env24467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5140 env24466 == env24467) = true)

theorem identity24467 : scanCanonicalize (H12AffineFastState.compose env24467 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 5348) := by decide +kernel

theorem selectedBound24467 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24468 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,5348,16384,5140,65536,4097,2265,66779,5141,21741,112,65739,70845,5228,65691,2049,4096,4097,2264,1192,5308,65574,65754,16385,136]

theorem envBound24468 : H12AffineFastState.Bounded env24468 := by
  intro p hp
  have h : env24468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24467_24468 : H12AffineEnvironment.transform 12 5348 env24467 = env24468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5348 env24467 == env24468) = true)

theorem identity24468 : scanCanonicalize (H12AffineFastState.compose env24468 (packedSelected [0,2,4] rootPS)) = affineNative (2^(15+1) ^^^ 17463) := by decide +kernel

theorem selectedBound24468 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env24469 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,5348,16384,5140,17463,4097,2265,16620,5141,21741,112,17660,20618,5228,17580,2049,4096,4097,2264,1192,5308,17425,17645,16385,136]

theorem envBound24469 : H12AffineFastState.Bounded env24469 := by
  intro p hp
  have h : env24469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24468_24469 : H12AffineEnvironment.transform 15 17463 env24468 = env24469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 17463 env24468 == env24469) = true)

theorem identity24469 : scanCanonicalize (H12AffineFastState.compose env24469 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1261) := by decide +kernel

theorem selectedBound24469 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24470 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,1261,9,16384,249,17463,1260,2265,16620,248,16384,112,17660,17511,129,17580,2049,1261,1260,2264,1192,81,17425,17645,16385,136]

theorem envBound24470 : H12AffineFastState.Bounded env24470 := by
  intro p hp
  have h : env24470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24469_24470 : H12AffineEnvironment.transform 11 1261 env24469 = env24470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1261 env24469 == env24470) = true)

theorem identity24470 : scanCanonicalize (H12AffineFastState.compose env24470 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound24470 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24471 : List Nat := [2,4,8,16,32,64,40,84,32,1024,2048,1093,9,16384,81,17463,1092,2161,16452,80,16384,112,17492,17511,41,17412,2049,1093,1092,2160,1024,81,17425,17477,16385,32]

theorem envBound24471 : H12AffineFastState.Bounded env24471 := by
  intro p hp
  have h : env24471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24470_24471 : H12AffineEnvironment.transform 6 40 env24470 = env24471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env24470 == env24471) = true)

def env24472 : List Nat := [2,4,8,16,32,64,40,84,32,1024,0,1093,9,16384,81,17463,1092,113,16452,80,16384,112,17492,17511,41,17412,1,1093,1092,112,1024,81,17425,17477,16385,32]

theorem envBound24472 : H12AffineFastState.Bounded env24472 := by
  intro p hp
  have h : env24472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24471_24472 : H12AffineEnvironment.transform 10 0 env24471 = env24472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env24471 == env24472) = true)

theorem identity24472 : scanCanonicalize (H12AffineFastState.compose env24472 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound24472 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24473 : List Nat := [2,4,8,16,32,48,40,36,32,1024,0,1077,9,16384,33,17463,1076,1,16436,32,16384,0,17444,17431,41,17412,1,1077,1076,0,1024,33,17425,17461,16385,32]

theorem envBound24473 : H12AffineFastState.Bounded env24473 := by
  intro p hp
  have h : env24473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24472_24473 : H12AffineEnvironment.transform 5 48 env24472 = env24473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env24472 == env24473) = true)

def env24474 : List Nat := [2,4,8,16,32,48,40,36,32,1024,0,1077,9,0,33,1079,1076,1,52,32,0,0,1060,1047,41,1028,1,1077,1076,0,1024,33,1041,1077,1,32]

theorem envBound24474 : H12AffineFastState.Bounded env24474 := by
  intro p hp
  have h : env24474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24473_24474 : H12AffineEnvironment.transform 13 0 env24473 = env24474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env24473 == env24474) = true)

theorem identity24474 : scanCanonicalize (H12AffineFastState.compose env24474 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound24474 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24475 : List Nat := [2,4,8,16,27,11,19,31,27,1024,0,1038,9,0,26,1036,1039,1,15,27,0,0,1055,1047,18,1028,1,1038,1039,0,1024,26,1041,1038,1,27]

theorem envBound24475 : H12AffineFastState.Bounded env24475 := by
  intro p hp
  have h : env24475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24474_24475 : H12AffineEnvironment.transform 4 27 env24474 = env24475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env24474 == env24475) = true)

def env24476 : List Nat := [2,4,8,16,27,11,19,31,27,20,0,26,9,0,26,24,27,1,15,27,0,0,11,3,18,16,1,26,27,0,20,26,5,26,1,27]

theorem envBound24476 : H12AffineFastState.Bounded env24476 := by
  intro p hp
  have h : env24476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24475_24476 : H12AffineEnvironment.transform 9 20 env24475 = env24476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env24475 == env24476) = true)

def env24477 : List Nat := [2,4,8,16,27,11,19,31,27,21,0,27,9,0,26,25,26,1,15,27,0,0,10,2,18,17,1,27,26,0,21,26,4,27,1,27]

theorem envBound24477 : H12AffineFastState.Bounded env24477 := by
  intro p hp
  have h : env24477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24475_24477 : H12AffineEnvironment.transform 9 21 env24475 = env24477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env24475 == env24477) = true)

theorem identity24477 : scanCanonicalize (H12AffineFastState.compose env24477 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound24477 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24478 : List Nat := [2,4,8,11,0,11,8,4,0,14,0,0,9,0,1,2,1,1,15,0,0,0,10,2,9,10,1,0,1,0,14,1,4,0,1,0]

theorem envBound24478 : H12AffineFastState.Bounded env24478 := by
  intro p hp
  have h : env24478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24477_24478 : H12AffineEnvironment.transform 3 11 env24477 = env24478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env24477 == env24478) = true)

def leafEnv24478 : List Nat := [2,4,8,11,0,11,8,4,0,14,0,0,9,0,1,2,1,1,15,0,0,0,10,2,15,9,1,10,1,0,1,0,14,1,4,0,4,2,1,0,0,1,1]

def active24478 : List Nat := [0,1,2]

def tree24478 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24478 : H12WitnessSearch.Good tree24478 := H12GlobalWitnessIndex.good

theorem leafIdentity24478 : H12AffineFastState.composeSystem env24478 rootObs = leafEnv24478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24478 rootObs == leafEnv24478) = true)

theorem terminalChecked24478 : H12PackedTerminal.terminalCheckFast leafEnv24478 active24478 tree24478 = true := by decide +kernel

def env24479 : List Nat := [2,4,8,16,32,48,40,36,32,1024,0,1077,9,1,33,1078,1076,1,53,32,1,0,1061,1046,41,1029,1,1077,1076,0,1024,33,1040,1076,0,32]

theorem envBound24479 : H12AffineFastState.Bounded env24479 := by
  intro p hp
  have h : env24479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24473_24479 : H12AffineEnvironment.transform 13 1 env24473 = env24479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env24473 == env24479) = true)

theorem identity24479 : scanCanonicalize (H12AffineFastState.compose env24479 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound24479 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24480 : List Nat := [2,4,8,16,32,48,40,36,32,15,0,58,9,1,33,57,59,1,53,32,1,0,42,25,41,10,1,58,59,0,15,33,31,59,0,32]

theorem envBound24480 : H12AffineFastState.Bounded env24480 := by
  intro p hp
  have h : env24480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24479_24480 : H12AffineEnvironment.transform 9 15 env24479 = env24480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env24479 == env24480) = true)

def env24481 : List Nat := [2,4,8,16,0,16,8,4,0,15,0,26,9,1,1,25,27,1,21,0,1,0,10,25,9,10,1,26,27,0,15,1,31,27,0,0]

theorem envBound24481 : H12AffineFastState.Bounded env24481 := by
  intro p hp
  have h : env24481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24480_24481 : H12AffineEnvironment.transform 4 0 env24480 = env24481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24480 == env24481) = true)

theorem identity24481 : scanCanonicalize (H12AffineFastState.compose env24481 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound24481 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24482 : List Nat := [2,4,8,11,0,11,8,4,0,15,0,1,9,1,1,2,0,1,14,0,1,0,10,2,9,10,1,1,0,0,15,1,4,0,0,0]

theorem envBound24482 : H12AffineFastState.Bounded env24482 := by
  intro p hp
  have h : env24482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24481_24482 : H12AffineEnvironment.transform 3 11 env24481 = env24482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env24481 == env24482) = true)

def leafEnv24482 : List Nat := [2,4,8,11,0,11,8,4,0,15,0,1,9,1,1,2,0,1,14,0,1,0,10,2,14,9,1,10,1,1,0,0,15,1,4,0,4,2,0,0,0,0,1]

def active24482 : List Nat := [0,1,2]

def tree24482 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24482 : H12WitnessSearch.Good tree24482 := H12GlobalWitnessIndex.good

theorem leafIdentity24482 : H12AffineFastState.composeSystem env24482 rootObs = leafEnv24482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24482 rootObs == leafEnv24482) = true)

theorem terminalChecked24482 : H12PackedTerminal.terminalCheckFast leafEnv24482 active24482 tree24482 = true := by decide +kernel

def env24483 : List Nat := [2,4,8,16,1,17,9,5,1,15,0,27,9,1,0,24,26,1,20,1,1,0,11,25,8,10,1,27,26,0,15,0,31,26,0,1]

theorem envBound24483 : H12AffineFastState.Bounded env24483 := by
  intro p hp
  have h : env24483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24480_24483 : H12AffineEnvironment.transform 4 1 env24480 = env24483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24480 == env24483) = true)

def env24484 : List Nat := [2,4,8,16,32,64,40,84,32,1024,1,1093,9,16384,81,17463,1092,112,16452,80,16384,112,17492,17511,41,17412,0,1093,1092,113,1024,81,17425,17477,16385,32]

theorem envBound24484 : H12AffineFastState.Bounded env24484 := by
  intro p hp
  have h : env24484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24471_24484 : H12AffineEnvironment.transform 10 1 env24471 = env24484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env24471 == env24484) = true)

def env24485 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,5141,65536,4097,15420,66778,5140,21741,13461,65738,70845,8328,65690,2048,4097,4096,15420,1193,5309,65575,78910,16384,136]

theorem envBound24485 : H12AffineFastState.Bounded env24485 := by
  intro p hp
  have h : env24485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24466_24485 : H12AffineEnvironment.transform 14 5141 env24466 = env24485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5141 env24466 == env24485) = true)

theorem identity24485 : scanCanonicalize (H12AffineFastState.compose env24485 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound24485 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24486 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,5141,3,4097,15420,1241,5140,21741,13461,201,5310,8328,153,2048,4097,4096,15420,1193,5309,36,13373,16384,136]

theorem envBound24486 : H12AffineFastState.Bounded env24486 := by
  intro p hp
  have h : env24486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24485_24486 : H12AffineEnvironment.transform 15 3 env24485 = env24486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env24485 == env24486) = true)

theorem identity24486 : scanCanonicalize (H12AffineFastState.compose env24486 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 3229) := by decide +kernel

theorem selectedBound24486 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env24487 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,3229,8192,16384,2184,3,3228,8353,1241,2185,18544,10248,201,2083,8328,153,2048,3228,3229,8353,1193,2080,36,10400,16384,136]

theorem envBound24487 : H12AffineFastState.Bounded env24487 := by
  intro p hp
  have h : env24487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24486_24487 : H12AffineEnvironment.transform 11 3229 env24486 = env24487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3229 env24486 == env24487) = true)

theorem identity24487 : scanCanonicalize (H12AffineFastState.compose env24487 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 2209) := by decide +kernel

theorem selectedBound24487 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24488 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,3229,2209,16384,2184,3,3228,2048,1241,2185,18544,169,201,2083,2089,153,2048,3228,3229,2048,1193,2080,36,1,16384,136]

theorem envBound24488 : H12AffineFastState.Bounded env24488 := by
  intro p hp
  have h : env24488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24487_24488 : H12AffineEnvironment.transform 12 2209 env24487 = env24488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2209 env24487 == env24488) = true)

theorem identity24488 : scanCanonicalize (H12AffineFastState.compose env24488 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound24488 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24489 : List Nat := [2,4,8,16,32,64,41,85,33,1024,2048,3124,2056,16384,2081,3,3125,2048,1136,2080,18544,0,96,2083,2089,48,2048,3125,3124,2048,1024,2080,36,1,16384,33]

theorem envBound24489 : H12AffineFastState.Bounded env24489 := by
  intro p hp
  have h : env24489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24488_24489 : H12AffineEnvironment.transform 6 41 env24488 = env24489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env24488 == env24489) = true)

theorem identity24489 : scanCanonicalize (H12AffineFastState.compose env24489 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound24489 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24490 : List Nat := [2,4,8,16,32,64,41,85,33,1024,0,1076,8,16384,33,3,1077,0,1136,32,16496,0,96,35,41,48,0,1077,1076,0,1024,32,36,1,16384,33]

theorem envBound24490 : H12AffineFastState.Bounded env24490 := by
  intro p hp
  have h : env24490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24489_24490 : H12AffineEnvironment.transform 10 0 env24489 = env24490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env24489 == env24490) = true)

theorem identity24490 : scanCanonicalize (H12AffineFastState.compose env24490 (packedSelected [1] rootPS)) = affineNative (2^(13+1) ^^^ 1119) := by decide +kernel

theorem selectedBound24490 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24491 : List Nat := [2,4,8,16,32,64,41,85,33,1024,0,1076,8,1119,33,3,1077,0,1136,32,1071,0,96,35,41,48,0,1077,1076,0,1024,32,36,1,1119,33]

theorem envBound24491 : H12AffineFastState.Bounded env24491 := by
  intro p hp
  have h : env24491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24490_24491 : H12AffineEnvironment.transform 13 1119 env24490 = env24491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1119 env24490 == env24491) = true)

def env24492 : List Nat := [2,4,8,16,32,48,41,37,33,1024,0,1076,8,1071,33,3,1077,0,1024,32,1071,0,16,35,41,48,0,1077,1076,0,1024,32,36,1,1071,33]

theorem envBound24492 : H12AffineFastState.Bounded env24492 := by
  intro p hp
  have h : env24492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24491_24492 : H12AffineEnvironment.transform 5 48 env24491 = env24492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env24491 == env24492) = true)

def env24493 : List Nat := [2,4,8,16,32,49,41,36,33,1024,0,1076,8,1070,33,3,1077,0,1025,32,1071,0,17,35,41,48,0,1077,1076,0,1024,32,36,1,1070,33]

theorem envBound24493 : H12AffineFastState.Bounded env24493 := by
  intro p hp
  have h : env24493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24491_24493 : H12AffineEnvironment.transform 5 49 env24491 = env24493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env24491 == env24493) = true)

theorem identity24493 : scanCanonicalize (H12AffineFastState.compose env24493 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound24493 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24494 : List Nat := [2,4,8,11,32,42,41,36,33,1024,0,1071,8,1070,33,3,1070,0,1025,32,1071,0,10,35,41,43,0,1070,1071,0,1024,32,36,1,1070,33]

theorem envBound24494 : H12AffineFastState.Bounded env24494 := by
  intro p hp
  have h : env24494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24493_24494 : H12AffineEnvironment.transform 3 11 env24493 = env24494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env24493 == env24494) = true)

def leafEnv24494 : List Nat := [2,4,8,11,32,42,41,36,33,1024,0,1071,8,1070,33,3,1070,0,1025,32,1071,0,10,35,1025,41,1,43,0,1070,1071,0,1024,32,36,1,4,34,1070,33,0,1071,1]

def active24494 : List Nat := [0,1,2,4,9]

def tree24494 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24494 : H12WitnessSearch.Good tree24494 := H12GlobalWitnessIndex.good

theorem leafIdentity24494 : H12AffineFastState.composeSystem env24494 rootObs = leafEnv24494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24494 rootObs == leafEnv24494) = true)

theorem terminalChecked24494 : H12PackedTerminal.terminalCheckFast leafEnv24494 active24494 tree24494 = true := by decide +kernel

def env24495 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21740,41088,525328,70844,8328,525376,275517,33812,33813,634098,37053,594023,525564,566512,54293,136]

theorem envBound24495 : H12AffineFastState.Bounded env24495 := by
  intro p hp
  have h : env24495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24463_24495 : H12AffineEnvironment.transform 7 253 env24463 = env24495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env24463 == env24495) = true)

theorem identity24495 : scanCanonicalize (H12AffineFastState.compose env24495 (packedSelected [1,13,17,18,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound24495 : packedSelected [1,13,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env24496 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,32768,65536,4097,43049,524288,32769,21740,41088,525328,70844,8328,525376,39956,33812,33813,634098,37053,594023,525564,566512,54293,136]

theorem envBound24496 : H12AffineFastState.Bounded env24496 := by
  intro p hp
  have h : env24496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24495_24496 : H12AffineEnvironment.transform 17 43049 env24495 = env24496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env24495 == env24496) = true)

theorem identity24496 : scanCanonicalize (H12AffineFastState.compose env24496 (packedSelected [11,15] rootPS)) = affineNative (2^(18+1) ^^^ 23665) := by decide +kernel

theorem selectedBound24496 : packedSelected [11,15] rootPS < 2^1333 := by decide +kernel

def env24497 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,32768,65536,4097,43049,23665,32769,21740,41088,22625,70844,8328,22577,39956,33812,33813,127107,37053,85014,22669,63617,54293,136]

theorem envBound24497 : H12AffineFastState.Bounded env24497 := by
  intro p hp
  have h : env24497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24496_24497 : H12AffineEnvironment.transform 18 23665 env24496 = env24497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 23665 env24496 == env24497) = true)

theorem identity24497 : scanCanonicalize (H12AffineFastState.compose env24497 (packedSelected [11] rootPS)) = affineNative (2^(15+1) ^^^ 52414) := by decide +kernel

theorem selectedBound24497 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env24498 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,32768,52414,4097,43049,23665,32769,21740,41088,22625,55298,8328,22577,39956,33812,33813,15421,37053,32936,22669,63617,54293,136]

theorem envBound24498 : H12AffineFastState.Bounded env24498 := by
  intro p hp
  have h : env24498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24497_24498 : H12AffineEnvironment.transform 15 52414 env24497 = env24498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 52414 env24497 == env24498) = true)

theorem identity24498 : scanCanonicalize (H12AffineFastState.compose env24498 (packedSelected [0,7,12] rootPS)) = affineNative (2^(14+1) ^^^ 13509) := by decide +kernel

theorem selectedBound24498 : packedSelected [0,7,12] rootPS < 2^1333 := by decide +kernel

def env24499 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,13509,30843,4097,7404,23665,13508,21740,5189,22625,27847,8328,22577,10449,12497,12496,15421,9336,13421,22669,19524,24784,136]

theorem envBound24499 : H12AffineFastState.Bounded env24499 := by
  intro p hp
  have h : env24499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24498_24499 : H12AffineEnvironment.transform 14 13509 env24498 = env24499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13509 env24498 == env24499) = true)

theorem identity24499 : scanCanonicalize (H12AffineFastState.compose env24499 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound24499 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24500 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,120,16384,5309,22531,4097,7404,23665,5308,21740,5189,22625,19647,240,22577,2217,4265,4264,7237,1024,5141,22669,19524,16552,136]

theorem envBound24500 : H12AffineFastState.Bounded env24500 := by
  intro p hp
  have h : env24500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24499_24500 : H12AffineEnvironment.transform 12 120 env24499 = env24500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env24499 == env24500) = true)

def env24501 : List Nat := [2,4,8,16,32,64,40,85,32,1024,2048,4096,120,16384,5141,22531,4097,7236,23665,5140,21572,5189,22625,19479,88,22577,2049,4097,4096,7237,1024,5141,22565,19524,16384,32]

theorem envBound24501 : H12AffineFastState.Bounded env24501 := by
  intro p hp
  have h : env24501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24500_24501 : H12AffineEnvironment.transform 6 40 env24500 = env24501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env24500 == env24501) = true)

theorem identity24501 : scanCanonicalize (H12AffineFastState.compose env24501 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 3141) := by decide +kernel

theorem selectedBound24501 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24502 : List Nat := [2,4,8,16,32,64,40,85,32,1024,2048,4096,120,3141,5141,5190,4097,7236,4148,5140,6145,5189,5156,82,88,5236,2049,4097,4096,7237,1024,5141,5216,1,3141,32]

theorem envBound24502 : H12AffineFastState.Bounded env24502 := by
  intro p hp
  have h : env24502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24501_24502 : H12AffineEnvironment.transform 13 3141 env24501 = env24502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3141 env24501 == env24502) = true)

theorem identity24502 : scanCanonicalize (H12AffineFastState.compose env24502 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound24502 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24503 : List Nat := [2,4,8,16,32,49,40,36,32,1024,2048,4096,9,3124,5141,5175,4097,7221,4148,5140,6145,5172,5156,35,41,5125,2049,4097,4096,7220,1024,5141,5137,1,3124,32]

theorem envBound24503 : H12AffineFastState.Bounded env24503 := by
  intro p hp
  have h : env24503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24502_24503 : H12AffineEnvironment.transform 5 49 env24502 = env24503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env24502 == env24503) = true)

theorem identity24503 : scanCanonicalize (H12AffineFastState.compose env24503 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 27) := by decide +kernel

theorem selectedBound24503 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24504 : List Nat := [2,4,8,16,32,49,40,36,32,1024,2048,27,9,3124,1038,1068,26,3118,47,1039,2074,1071,1087,35,41,1054,2049,26,27,3119,1024,1038,1034,1,3124,32]

theorem envBound24504 : H12AffineFastState.Bounded env24504 := by
  intro p hp
  have h : env24504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24503_24504 : H12AffineEnvironment.transform 11 27 env24503 = env24504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 27 env24503 == env24504) = true)

def leafEnv24504 : List Nat := [2,4,8,16,32,49,40,36,32,1024,2048,27,9,3124,1038,1068,26,3118,47,1039,2074,1071,1087,35,47,41,1,1054,2049,26,27,3119,1024,1038,1034,1,1066,1037,3124,32,0,2074,1]

def active24504 : List Nat := [0,1,2,3,4,9,10]

def tree24504 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24504 : H12WitnessSearch.Good tree24504 := H12GlobalWitnessIndex.good

theorem leafIdentity24504 : H12AffineFastState.composeSystem env24504 rootObs = leafEnv24504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24504 rootObs == leafEnv24504) = true)

theorem terminalChecked24504 : H12PackedTerminal.terminalCheckFast leafEnv24504 active24504 tree24504 = true := by decide +kernel

def env24505 : List Nat := [2,4,8,16,32,64,41,84,33,1024,2048,4096,120,16384,5140,22531,4097,7237,23665,5141,21573,5189,22625,19478,89,22577,2048,4096,4097,7237,1024,5141,22564,19524,16385,33]

theorem envBound24505 : H12AffineFastState.Bounded env24505 := by
  intro p hp
  have h : env24505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24500_24505 : H12AffineEnvironment.transform 6 41 env24500 = env24505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env24500 == env24505) = true)

theorem identity24505 : scanCanonicalize (H12AffineFastState.compose env24505 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound24505 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24506 : List Nat := [2,4,8,16,32,49,41,37,33,1024,2048,4096,9,16384,5140,22531,4097,7220,23552,5141,21556,5172,22544,19478,40,22577,2048,4096,4097,7220,1024,5141,22564,19509,16385,33]

theorem envBound24506 : H12AffineFastState.Bounded env24506 := by
  intro p hp
  have h : env24506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24505_24506 : H12AffineEnvironment.transform 5 49 env24505 = env24506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env24505 == env24506) = true)

def env24507 : List Nat := [2,4,8,16,32,49,41,37,33,1024,2048,4096,9,2048,5140,4099,4097,7220,5120,5141,7220,5172,4112,1046,40,4145,2048,4096,4097,7220,1024,5141,4132,1077,2049,33]

theorem envBound24507 : H12AffineFastState.Bounded env24507 := by
  intro p hp
  have h : env24507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24506_24507 : H12AffineEnvironment.transform 13 2048 env24506 = env24507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env24506 == env24507) = true)

theorem identity24507 : scanCanonicalize (H12AffineFastState.compose env24507 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 26) := by decide +kernel

theorem selectedBound24507 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24508 : List Nat := [2,4,8,16,32,49,41,37,33,1024,2048,26,9,2048,1038,25,27,3118,1050,1039,3118,1070,10,1046,40,43,2048,26,27,3118,1024,1039,62,1077,2049,33]

theorem envBound24508 : H12AffineFastState.Bounded env24508 := by
  intro p hp
  have h : env24508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24507_24508 : H12AffineEnvironment.transform 11 26 env24507 = env24508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 26 env24507 == env24508) = true)

def env24509 : List Nat := [2,4,8,16,32,49,41,37,33,52,2048,26,9,2048,58,25,27,2074,46,59,2074,26,10,34,40,43,2048,26,27,2074,52,59,62,1,2049,33]

theorem envBound24509 : H12AffineFastState.Bounded env24509 := by
  intro p hp
  have h : env24509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24508_24509 : H12AffineEnvironment.transform 9 52 env24508 = env24509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env24508 == env24509) = true)

def leafEnv24509 : List Nat := [2,4,8,16,32,49,41,37,33,52,2048,26,9,2048,58,25,27,2074,46,59,2074,26,10,34,46,40,1,43,2048,26,27,2074,52,59,62,1,31,57,2049,33,0,2075,1]

def active24509 : List Nat := [0,1,2,3,4,10]

def tree24509 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24509 : H12WitnessSearch.Good tree24509 := H12GlobalWitnessIndex.good

theorem leafIdentity24509 : H12AffineFastState.composeSystem env24509 rootObs = leafEnv24509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24509 rootObs == leafEnv24509) = true)

theorem terminalChecked24509 : H12PackedTerminal.terminalCheckFast leafEnv24509 active24509 tree24509 = true := by decide +kernel

def env24510 : List Nat := [2,4,8,16,32,49,41,37,33,53,2048,26,9,2048,59,25,27,2075,47,58,2075,27,10,35,40,43,2048,26,27,2075,53,58,62,0,2049,33]

theorem envBound24510 : H12AffineFastState.Bounded env24510 := by
  intro p hp
  have h : env24510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24508_24510 : H12AffineEnvironment.transform 9 53 env24508 = env24510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env24508 == env24510) = true)

theorem identity24510 : scanCanonicalize (H12AffineFastState.compose env24510 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound24510 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24511 : List Nat := [2,4,8,16,26,11,19,31,27,15,2048,26,9,2048,1,25,27,2075,21,0,2075,27,10,25,18,17,2048,26,27,2075,15,0,4,0,2049,27]

theorem envBound24511 : H12AffineFastState.Bounded env24511 := by
  intro p hp
  have h : env24511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24510_24511 : H12AffineEnvironment.transform 4 26 env24510 = env24511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env24510 == env24511) = true)

def leafEnv24511 : List Nat := [2,4,8,16,26,11,19,31,27,15,2048,26,9,2048,1,25,27,2075,21,0,2075,27,10,25,21,18,1,17,2048,26,27,2075,15,0,4,0,31,2,2049,27,0,2074,1]

def active24511 : List Nat := [0,1,2,3,10]

def tree24511 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24511 : H12WitnessSearch.Good tree24511 := H12GlobalWitnessIndex.good

theorem leafIdentity24511 : H12AffineFastState.composeSystem env24511 rootObs = leafEnv24511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24511 rootObs == leafEnv24511) = true)

theorem terminalChecked24511 : H12PackedTerminal.terminalCheckFast leafEnv24511 active24511 tree24511 = true := by decide +kernel

def env24512 : List Nat := [2,4,8,16,32,49,41,37,33,1024,2048,4096,9,2049,5140,4098,4097,7220,5121,5141,7221,5172,4113,1047,40,4144,2048,4096,4097,7220,1024,5141,4133,1076,2048,33]

theorem envBound24512 : H12AffineFastState.Bounded env24512 := by
  intro p hp
  have h : env24512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24506_24512 : H12AffineEnvironment.transform 13 2049 env24506 = env24512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2049 env24506 == env24512) = true)

theorem identity24512 : scanCanonicalize (H12AffineFastState.compose env24512 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 1071) := by decide +kernel

theorem selectedBound24512 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24513 : List Nat := [2,4,8,16,32,49,41,37,33,1024,2048,1071,9,2049,59,1069,1070,2075,46,58,2074,27,1086,1047,40,1055,2048,1071,1070,2075,1024,58,1034,1076,2048,33]

theorem envBound24513 : H12AffineFastState.Bounded env24513 := by
  intro p hp
  have h : env24513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24512_24513 : H12AffineEnvironment.transform 11 1071 env24512 = env24513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1071 env24512 == env24513) = true)

def env24514 : List Nat := [2,4,8,16,32,49,41,37,33,52,2048,27,9,2049,59,25,26,2075,46,58,2074,27,10,35,40,43,2048,27,26,2075,52,58,62,0,2048,33]

theorem envBound24514 : H12AffineFastState.Bounded env24514 := by
  intro p hp
  have h : env24514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24513_24514 : H12AffineEnvironment.transform 9 52 env24513 = env24514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env24513 == env24514) = true)

theorem identity24514 : scanCanonicalize (H12AffineFastState.compose env24514 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound24514 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24515 : List Nat := [2,4,8,16,26,11,19,31,27,14,2048,27,9,2049,1,25,26,2075,20,0,2074,27,10,25,18,17,2048,27,26,2075,14,0,4,0,2048,27]

theorem envBound24515 : H12AffineFastState.Bounded env24515 := by
  intro p hp
  have h : env24515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24514_24515 : H12AffineEnvironment.transform 4 26 env24514 = env24515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env24514 == env24515) = true)

def leafEnv24515 : List Nat := [2,4,8,16,26,11,19,31,27,14,2048,27,9,2049,1,25,26,2075,20,0,2074,27,10,25,20,18,1,17,2048,27,26,2075,14,0,4,0,31,2,2048,27,0,2075,1]

def active24515 : List Nat := [0,1,2,3,10]

def tree24515 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24515 : H12WitnessSearch.Good tree24515 := H12GlobalWitnessIndex.good

theorem leafIdentity24515 : H12AffineFastState.composeSystem env24515 rootObs = leafEnv24515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24515 rootObs == leafEnv24515) = true)

theorem terminalChecked24515 : H12PackedTerminal.terminalCheckFast leafEnv24515 active24515 tree24515 = true := by decide +kernel

def env24516 : List Nat := [2,4,8,16,32,49,41,37,33,53,2048,26,9,2049,59,24,27,2075,46,58,2074,27,11,34,40,42,2048,26,27,2075,53,58,63,1,2048,33]

theorem envBound24516 : H12AffineFastState.Bounded env24516 := by
  intro p hp
  have h : env24516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24513_24516 : H12AffineEnvironment.transform 9 53 env24513 = env24516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env24513 == env24516) = true)

def leafEnv24516 : List Nat := [2,4,8,16,32,49,41,37,33,53,2048,26,9,2049,59,24,27,2075,46,58,2074,27,11,34,46,40,1,42,2048,26,27,2075,53,58,63,1,30,56,2048,33,0,2075,1]

def active24516 : List Nat := [0,1,2,3,4,10]

def tree24516 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24516 : H12WitnessSearch.Good tree24516 := H12GlobalWitnessIndex.good

theorem leafIdentity24516 : H12AffineFastState.composeSystem env24516 rootObs = leafEnv24516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24516 rootObs == leafEnv24516) = true)

theorem terminalChecked24516 : H12PackedTerminal.terminalCheckFast leafEnv24516 active24516 tree24516 = true := by decide +kernel

def env24517 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21777,41089,525328,70977,8328,525376,275905,33812,33813,634127,37184,4294967296,525569,4295079275,54293,136]

theorem envBound24517 : H12AffineFastState.Bounded env24517 := by
  intro p hp
  have h : env24517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24461_24517 : H12AffineEnvironment.transform 21 41089 env24461 = env24517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env24461 == env24517) = true)

theorem identity24517 : scanCanonicalize (H12AffineFastState.compose env24517 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 602223) := by decide +kernel

theorem selectedBound24517 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24518 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21777,41089,525328,70977,8328,525376,275905,33812,33813,634127,37184,602223,525569,558340,54293,136]

theorem envBound24518 : H12AffineFastState.Bounded env24518 := by
  intro p hp
  have h : env24518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24517_24518 : H12AffineEnvironment.transform 31 602223 env24517 = env24518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 602223 env24517 == env24518) = true)

def env24519 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21741,41089,525328,70845,8328,525376,275517,33812,33813,634099,37052,602223,525565,558328,54293,136]

theorem envBound24519 : H12AffineFastState.Bounded env24519 := by
  intro p hp
  have h : env24519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24518_24519 : H12AffineEnvironment.transform 7 252 env24518 = env24519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env24518 == env24519) = true)

theorem identity24519 : scanCanonicalize (H12AffineFastState.compose env24519 (packedSelected [1,13,17,18,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound24519 : packedSelected [1,13,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env24520 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,32768,65536,4097,43049,524288,32769,21741,41089,525328,70845,8328,525376,39956,33812,33813,634099,37052,602223,525565,558328,54293,136]

theorem envBound24520 : H12AffineFastState.Bounded env24520 := by
  intro p hp
  have h : env24520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24519_24520 : H12AffineEnvironment.transform 17 43049 env24519 = env24520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env24519 == env24520) = true)

theorem identity24520 : scanCanonicalize (H12AffineFastState.compose env24520 (packedSelected [11,15] rootPS)) = affineNative (2^(18+1) ^^^ 23665) := by decide +kernel

theorem selectedBound24520 : packedSelected [11,15] rootPS < 2^1333 := by decide +kernel

def env24521 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,32768,65536,4097,43049,23665,32769,21741,41089,22625,70845,8328,22577,39956,33812,33813,127106,37052,93214,22668,55433,54293,136]

theorem envBound24521 : H12AffineFastState.Bounded env24521 := by
  intro p hp
  have h : env24521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24520_24521 : H12AffineEnvironment.transform 18 23665 env24520 = env24521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 23665 env24520 == env24521) = true)

theorem identity24521 : scanCanonicalize (H12AffineFastState.compose env24521 (packedSelected [11] rootPS)) = affineNative (2^(15+1) ^^^ 52415) := by decide +kernel

theorem selectedBound24521 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env24522 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,32768,52415,4097,43049,23665,32769,21741,41089,22625,55298,8328,22577,39956,33812,33813,15421,37052,41121,22668,55433,54293,136]

theorem envBound24522 : H12AffineFastState.Bounded env24522 := by
  intro p hp
  have h : env24522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24521_24522 : H12AffineEnvironment.transform 15 52415 env24521 = env24522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 52415 env24521 == env24522) = true)

theorem identity24522 : scanCanonicalize (H12AffineFastState.compose env24522 (packedSelected [0,7,12] rootPS)) = affineNative (2^(14+1) ^^^ 13508) := by decide +kernel

theorem selectedBound24522 : packedSelected [0,7,12] rootPS < 2^1333 := by decide +kernel

def env24523 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,13508,30843,4097,7405,23665,13509,21741,5189,22625,27846,8328,22577,10448,12496,12497,15421,9336,5221,22668,27725,24785,136]

theorem envBound24523 : H12AffineFastState.Bounded env24523 := by
  intro p hp
  have h : env24523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24522_24523 : H12AffineEnvironment.transform 14 13508 env24522 = env24523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13508 env24522 == env24523) = true)

theorem identity24523 : scanCanonicalize (H12AffineFastState.compose env24523 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound24523 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24524 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,120,16384,5308,22531,4097,7405,23665,5309,21741,5189,22625,19646,240,22577,2216,4264,4265,7237,1024,5221,22668,19509,16553,136]

theorem envBound24524 : H12AffineFastState.Bounded env24524 := by
  intro p hp
  have h : env24524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24523_24524 : H12AffineEnvironment.transform 12 120 env24523 = env24524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env24523 == env24524) = true)

def env24525 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,120,6280,5308,139,4097,7405,1273,5309,3173,5189,233,5174,240,185,2216,4264,4265,7237,1024,5221,4,5309,6177,136]

theorem envBound24525 : H12AffineFastState.Bounded env24525 := by
  intro p hp
  have h : env24525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24524_24525 : H12AffineEnvironment.transform 13 6280 env24524 = env24525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6280 env24524 == env24525) = true)

theorem identity24525 : scanCanonicalize (H12AffineFastState.compose env24525 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1229) := by decide +kernel

theorem selectedBound24525 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24526 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,1229,120,3141,113,139,1228,2080,1273,112,3173,136,233,251,240,185,2216,1125,1124,2184,1024,168,4,112,3308,136]

theorem envBound24526 : H12AffineFastState.Bounded env24526 := by
  intro p hp
  have h : env24526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24525_24526 : H12AffineEnvironment.transform 11 1229 env24525 = env24526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1229 env24525 == env24526) = true)

def env24527 : List Nat := [2,4,8,16,32,48,128,140,136,1024,2048,1213,8,3125,1,139,1212,2080,1161,0,3093,136,153,139,128,185,2216,1045,1044,2184,1024,168,4,0,3228,136]

theorem envBound24527 : H12AffineFastState.Bounded env24527 := by
  intro p hp
  have h : env24527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24526_24527 : H12AffineEnvironment.transform 5 48 env24526 = env24527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env24526 == env24527) = true)

theorem identity24527 : scanCanonicalize (H12AffineFastState.compose env24527 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound24527 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24528 : List Nat := [2,4,8,16,32,48,128,140,136,15,2048,178,8,2106,1,139,179,2080,134,0,2074,136,153,139,128,185,2216,26,27,2184,15,168,4,0,2195,136]

theorem envBound24528 : H12AffineFastState.Bounded env24528 := by
  intro p hp
  have h : env24528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24527_24528 : H12AffineEnvironment.transform 9 15 env24527 = env24528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env24527 == env24528) = true)

def leafEnv24528 : List Nat := [2,4,8,16,32,48,128,140,136,15,2048,178,8,2106,1,139,179,2080,134,0,2074,136,153,139,134,128,1,185,2216,26,27,2184,15,168,4,0,140,2,2195,136,0,2227,1]

def active24528 : List Nat := [0,1,2,3,4,6,10]

def tree24528 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24528 : H12WitnessSearch.Good tree24528 := H12GlobalWitnessIndex.good

theorem leafIdentity24528 : H12AffineFastState.composeSystem env24528 rootObs = leafEnv24528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24528 rootObs == leafEnv24528) = true)

theorem terminalChecked24528 : H12PackedTerminal.terminalCheckFast leafEnv24528 active24528 tree24528 = true := by decide +kernel

def env24529 : List Nat := [2,4,8,16,32,49,128,141,136,1024,2048,1212,9,3124,0,139,1213,2080,1160,1,3092,136,152,138,129,185,2216,1044,1045,2184,1024,168,4,1,3229,136]

theorem envBound24529 : H12AffineFastState.Bounded env24529 := by
  intro p hp
  have h : env24529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24526_24529 : H12AffineEnvironment.transform 5 49 env24526 = env24529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env24526 == env24529) = true)

theorem identity24529 : scanCanonicalize (H12AffineFastState.compose env24529 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound24529 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24530 : List Nat := [2,4,8,16,32,49,18,31,26,1024,2048,1070,9,3124,0,25,1071,2080,1050,1,3092,26,10,24,19,43,2106,1044,1045,2074,1024,58,4,1,3087,26]

theorem envBound24530 : H12AffineFastState.Bounded env24530 := by
  intro p hp
  have h : env24530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24529_24530 : H12AffineEnvironment.transform 6 18 env24529 = env24530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env24529 == env24530) = true)

theorem identity24530 : scanCanonicalize (H12AffineFastState.compose env24530 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound24530 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env24531 : List Nat := [2,4,8,16,27,10,18,31,26,1024,2048,1045,9,3087,0,25,1044,2075,1050,1,3092,26,10,24,19,16,2049,1044,1045,2074,1024,1,4,1,3087,26]

theorem envBound24531 : H12AffineFastState.Bounded env24531 := by
  intro p hp
  have h : env24531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24530_24531 : H12AffineEnvironment.transform 4 27 env24530 = env24531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env24530 == env24531) = true)

def leafEnv24531 : List Nat := [2,4,8,16,27,10,18,31,26,1024,2048,1045,9,3087,0,25,1044,2075,1050,1,3092,26,10,24,1050,19,1,16,2049,1044,1045,2074,1024,1,4,1,31,3,3087,26,0,3092,1]

def active24531 : List Nat := [0,1,2,3,9,10]

def tree24531 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24531 : H12WitnessSearch.Good tree24531 := H12GlobalWitnessIndex.good

theorem leafIdentity24531 : H12AffineFastState.composeSystem env24531 rootObs = leafEnv24531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24531 rootObs == leafEnv24531) = true)

theorem terminalChecked24531 : H12PackedTerminal.terminalCheckFast leafEnv24531 active24531 tree24531 = true := by decide +kernel

def env24532 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,120,6281,5308,138,4097,7405,1272,5309,3172,5189,232,5175,240,184,2216,4264,4265,7237,1024,5221,5,5308,6176,136]

theorem envBound24532 : H12AffineFastState.Bounded env24532 := by
  intro p hp
  have h : env24532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24524_24532 : H12AffineEnvironment.transform 13 6281 env24524 = env24532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6281 env24524 == env24532) = true)

theorem identity24532 : scanCanonicalize (H12AffineFastState.compose env24532 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound24532 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24533 : List Nat := [2,4,8,16,32,48,128,140,136,1024,2048,4096,8,6281,5308,138,4097,7325,1160,5309,3092,5173,152,5175,128,184,2216,4264,4265,7221,1024,5141,5,5308,6176,136]

theorem envBound24533 : H12AffineFastState.Bounded env24533 := by
  intro p hp
  have h : env24533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24532_24533 : H12AffineEnvironment.transform 5 48 env24532 = env24533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env24532 == env24533) = true)

end H12CloudChart2