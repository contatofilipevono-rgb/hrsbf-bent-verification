import H12CloudChart2Data076

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans18879_18880 : H12AffineEnvironment.transform 6 24 env18879 = env18880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env18879 == env18880) = true)

def env18881 : List Nat := [2,4,8,16,0,17,24,256,17,272,16,0,25,0,17,19,0,16,272,16,1,261,16,262,9,16,17,1,1,17,20,277,256,260,0,17]

theorem envBound18881 : H12AffineFastState.Bounded env18881 := by
  intro p hp
  have h : env18881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18880_18881 : H12AffineEnvironment.transform 4 0 env18880 = env18881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18880 == env18881) = true)

theorem identity18881 : scanCanonicalize (H12AffineFastState.compose env18881 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18881 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18882 : List Nat := [2,4,8,0,0,1,8,256,1,256,0,0,9,0,1,3,0,0,256,0,1,261,0,262,9,0,1,1,1,1,4,261,256,260,0,1]

theorem envBound18882 : H12AffineFastState.Bounded env18882 := by
  intro p hp
  have h : env18882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18881_18882 : H12AffineEnvironment.transform 3 0 env18881 = env18882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18881 == env18882) = true)

theorem identity18882 : scanCanonicalize (H12AffineFastState.compose env18882 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound18882 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18883 : List Nat := [2,4,8,0,0,1,8,5,1,5,0,0,9,0,1,3,0,0,5,0,1,0,0,3,9,0,1,1,1,1,4,0,5,1,0,1]

theorem envBound18883 : H12AffineFastState.Bounded env18883 := by
  intro p hp
  have h : env18883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18882_18883 : H12AffineEnvironment.transform 7 5 env18882 = env18883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env18882 == env18883) = true)

def leafEnv18883 : List Nat := [2,4,8,0,0,1,8,5,1,5,0,0,9,0,1,3,0,0,5,0,1,0,0,3,5,9,1,0,1,1,1,1,4,0,5,1,5,2,0,1,0,1,1]

def active18883 : List Nat := [0,1,2]

def tree18883 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18883 : H12WitnessSearch.Good tree18883 := H12GlobalWitnessIndex.good

theorem leafIdentity18883 : H12AffineFastState.composeSystem env18883 rootObs = leafEnv18883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18883 rootObs == leafEnv18883) = true)

theorem terminalChecked18883 : H12PackedTerminal.terminalCheckFast leafEnv18883 active18883 tree18883 = true := by decide +kernel

def env18884 : List Nat := [2,4,8,16,1,17,24,256,17,272,17,0,25,0,17,19,0,16,272,16,1,260,16,262,9,16,16,1,1,17,20,276,256,261,0,17]

theorem envBound18884 : H12AffineFastState.Bounded env18884 := by
  intro p hp
  have h : env18884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18880_18884 : H12AffineEnvironment.transform 4 1 env18880 = env18884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18880 == env18884) = true)

theorem identity18884 : scanCanonicalize (H12AffineFastState.compose env18884 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound18884 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18885 : List Nat := [2,4,8,16,1,17,24,20,17,4,17,0,25,0,17,19,0,16,4,16,1,16,16,18,9,16,16,1,1,17,20,0,20,17,0,17]

theorem envBound18885 : H12AffineFastState.Bounded env18885 := by
  intro p hp
  have h : env18885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18884_18885 : H12AffineEnvironment.transform 7 20 env18884 = env18885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env18884 == env18885) = true)

def env18886 : List Nat := [2,4,8,16,32,17,128,256,137,272,169,0,129,0,136,138,0,136,272,137,1,292,16,262,9,16,168,1,1,137,20,428,256,292,0,137]

theorem envBound18886 : H12AffineFastState.Bounded env18886 := by
  intro p hp
  have h : env18886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18878_18886 : H12AffineEnvironment.transform 10 169 env18878 = env18886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 169 env18878 == env18886) = true)

theorem identity18886 : scanCanonicalize (H12AffineFastState.compose env18886 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 188) := by decide +kernel

theorem selectedBound18886 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18887 : List Nat := [2,4,8,16,32,17,128,188,137,172,169,0,129,0,136,138,0,136,172,137,1,152,16,186,9,16,168,1,1,137,20,16,188,152,0,137]

theorem envBound18887 : H12AffineFastState.Bounded env18887 := by
  intro p hp
  have h : env18887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18886_18887 : H12AffineEnvironment.transform 7 188 env18886 = env18887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env18886 == env18887) = true)

def env18888 : List Nat := [2,4,8,16,0,17,128,156,137,140,137,0,129,0,136,138,0,136,140,137,1,152,16,154,9,16,136,1,1,137,20,16,156,152,0,137]

theorem envBound18888 : H12AffineFastState.Bounded env18888 := by
  intro p hp
  have h : env18888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18887_18888 : H12AffineEnvironment.transform 4 0 env18887 = env18888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18887 == env18888) = true)

def env18889 : List Nat := [2,4,8,0,0,1,128,140,137,140,137,0,129,0,136,138,0,136,140,137,1,136,0,138,9,0,136,1,1,137,4,0,140,136,0,137]

theorem envBound18889 : H12AffineFastState.Bounded env18889 := by
  intro p hp
  have h : env18889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18888_18889 : H12AffineEnvironment.transform 3 0 env18888 = env18889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18888 == env18889) = true)

def env18890 : List Nat := [2,4,8,1,0,0,128,141,137,140,137,0,129,0,136,138,0,136,140,137,1,137,1,139,9,1,136,1,1,137,5,1,141,137,0,137]

theorem envBound18890 : H12AffineFastState.Bounded env18890 := by
  intro p hp
  have h : env18890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18888_18890 : H12AffineEnvironment.transform 3 1 env18888 = env18890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18888 == env18890) = true)

theorem identity18890 : scanCanonicalize (H12AffineFastState.compose env18890 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18890 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18891 : List Nat := [2,4,8,1,0,0,9,4,0,5,0,0,8,0,1,3,0,1,5,0,1,0,1,2,9,1,1,1,1,0,5,1,4,0,0,0]

theorem envBound18891 : H12AffineFastState.Bounded env18891 := by
  intro p hp
  have h : env18891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18890_18891 : H12AffineEnvironment.transform 6 9 env18890 = env18891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18890 == env18891) = true)

def leafEnv18891 : List Nat := [2,4,8,1,0,0,9,4,0,5,0,0,8,0,1,3,0,1,5,0,1,0,1,2,4,9,1,1,1,1,1,0,5,1,4,0,5,3,0,0,0,1,1]

def active18891 : List Nat := [0,1,2]

def tree18891 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18891 : H12WitnessSearch.Good tree18891 := H12GlobalWitnessIndex.good

theorem leafIdentity18891 : H12AffineFastState.composeSystem env18891 rootObs = leafEnv18891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18891 rootObs == leafEnv18891) = true)

theorem terminalChecked18891 : H12PackedTerminal.terminalCheckFast leafEnv18891 active18891 tree18891 = true := by decide +kernel

def env18892 : List Nat := [2,4,8,16,1,17,128,157,137,141,136,0,129,0,136,138,0,136,141,137,1,152,16,155,9,16,137,1,1,137,20,16,157,152,0,137]

theorem envBound18892 : H12AffineFastState.Bounded env18892 := by
  intro p hp
  have h : env18892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18887_18892 : H12AffineEnvironment.transform 4 1 env18887 = env18892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18887 == env18892) = true)

theorem identity18892 : scanCanonicalize (H12AffineFastState.compose env18892 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound18892 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18893 : List Nat := [2,4,8,16,1,17,25,4,16,20,17,0,24,0,17,19,0,17,20,16,1,1,16,2,9,16,16,1,1,16,20,16,4,1,0,16]

theorem envBound18893 : H12AffineFastState.Bounded env18893 := by
  intro p hp
  have h : env18893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18892_18893 : H12AffineEnvironment.transform 6 25 env18892 = env18893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env18892 == env18893) = true)

theorem identity18893 : scanCanonicalize (H12AffineFastState.compose env18893 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18893 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18894 : List Nat := [2,4,8,0,1,1,9,4,0,4,1,0,8,0,1,3,0,1,4,0,1,1,0,2,9,0,0,1,1,0,4,0,4,1,0,0]

theorem envBound18894 : H12AffineFastState.Bounded env18894 := by
  intro p hp
  have h : env18894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18893_18894 : H12AffineEnvironment.transform 3 0 env18893 = env18894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18893 == env18894) = true)

def leafEnv18894 : List Nat := [2,4,8,0,1,1,9,4,0,4,1,0,8,0,1,3,0,1,4,0,1,1,0,2,5,9,1,0,0,1,1,0,4,0,4,1,5,3,0,0,0,1,1]

def active18894 : List Nat := [0,1,2]

def tree18894 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18894 : H12WitnessSearch.Good tree18894 := H12GlobalWitnessIndex.good

theorem leafIdentity18894 : H12AffineFastState.composeSystem env18894 rootObs = leafEnv18894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18894 rootObs == leafEnv18894) = true)

theorem terminalChecked18894 : H12PackedTerminal.terminalCheckFast leafEnv18894 active18894 tree18894 = true := by decide +kernel

def env18895 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,129,1,32768,65536,1,262144,273,32769,0,4194304,16,360844,9,16,4194700,0,0,1073741824,262301,4194440,256,360878,1,512]

theorem envBound18895 : H12AffineFastState.Bounded env18895 := by
  intro p hp
  have h : env18895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18871_18895 : H12AffineEnvironment.transform 9 273 env18871 = env18895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env18871 == env18895) = true)

theorem identity18895 : scanCanonicalize (H12AffineFastState.compose env18895 (packedSelected [5] rootPS)) = affineNative (2^(29+1) ^^^ 262145) := by decide +kernel

theorem selectedBound18895 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18896 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,129,1,32768,65536,1,262144,273,32769,0,4194304,16,360844,9,16,4194700,0,0,262145,262301,4194440,256,360878,1,512]

theorem envBound18896 : H12AffineFastState.Bounded env18896 := by
  intro p hp
  have h : env18896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18895_18896 : H12AffineEnvironment.transform 29 262145 env18895 = env18896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 262145 env18895 == env18896) = true)

theorem identity18896 : scanCanonicalize (H12AffineFastState.compose env18896 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 33196) := by decide +kernel

theorem selectedBound18896 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18897 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,129,1,32768,65536,1,262144,273,32769,0,33196,16,360844,9,16,32800,0,0,262145,262301,33060,256,360878,1,512]

theorem envBound18897 : H12AffineFastState.Bounded env18897 := by
  intro p hp
  have h : env18897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18896_18897 : H12AffineEnvironment.transform 21 33196 env18896 = env18897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33196 env18896 == env18897) = true)

theorem identity18897 : scanCanonicalize (H12AffineFastState.compose env18897 (packedSelected [1,3,8] rootPS)) = affineNative (2^(17+1) ^^^ 34985) := by decide +kernel

theorem selectedBound18897 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env18898 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,129,1,32768,65536,1,34985,273,32769,0,33196,16,67877,9,16,32800,0,0,34984,34868,33060,256,67847,1,512]

theorem envBound18898 : H12AffineFastState.Bounded env18898 := by
  intro p hp
  have h : env18898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18897_18898 : H12AffineEnvironment.transform 17 34985 env18897 = env18898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34985 env18897 == env18898) = true)

theorem identity18898 : scanCanonicalize (H12AffineFastState.compose env18898 (packedSelected [0,7,12] rootPS)) = affineNative (2^(14+1) ^^^ 2081) := by decide +kernel

theorem selectedBound18898 : packedSelected [0,7,12] rootPS < 2^1333 := by decide +kernel

def env18899 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,129,1,2081,65536,1,136,273,2080,0,2445,16,67877,9,16,2049,0,0,137,21,2309,256,67847,1,512]

theorem envBound18899 : H12AffineFastState.Bounded env18899 := by
  intro p hp
  have h : env18899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18898_18899 : H12AffineEnvironment.transform 14 2081 env18898 = env18899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2081 env18898 == env18899) = true)

theorem identity18899 : scanCanonicalize (H12AffineFastState.compose env18899 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound18899 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18900 : List Nat := [2,4,8,16,32,17,128,256,260,273,2048,1,129,1,2081,65536,1,136,273,2080,0,2445,16,67877,9,16,2049,0,0,137,21,2309,256,67847,1,260]

theorem envBound18900 : H12AffineFastState.Bounded env18900 := by
  intro p hp
  have h : env18900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18899_18900 : H12AffineEnvironment.transform 8 260 env18899 = env18900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env18899 == env18900) = true)

theorem identity18900 : scanCanonicalize (H12AffineFastState.compose env18900 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound18900 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18901 : List Nat := [2,4,8,16,32,17,128,141,137,156,2048,1,129,1,2081,65536,1,136,156,2080,0,2048,16,67752,9,16,2049,0,0,137,21,2184,141,67722,1,137]

theorem envBound18901 : H12AffineFastState.Bounded env18901 := by
  intro p hp
  have h : env18901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18900_18901 : H12AffineEnvironment.transform 7 141 env18900 = env18901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env18900 == env18901) = true)

def env18902 : List Nat := [2,4,8,16,32,17,128,141,137,156,0,1,129,1,33,65536,1,136,156,32,0,0,16,65704,9,16,1,0,0,137,21,136,141,65674,1,137]

theorem envBound18902 : H12AffineFastState.Bounded env18902 := by
  intro p hp
  have h : env18902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18901_18902 : H12AffineEnvironment.transform 10 0 env18901 = env18902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env18901 == env18902) = true)

theorem identity18902 : scanCanonicalize (H12AffineFastState.compose env18902 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 155) := by decide +kernel

theorem selectedBound18902 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18903 : List Nat := [2,4,8,16,32,17,128,141,137,156,0,1,129,1,33,155,1,136,156,32,0,0,16,51,9,16,1,0,0,137,21,136,141,17,1,137]

theorem envBound18903 : H12AffineFastState.Bounded env18903 := by
  intro p hp
  have h : env18903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18902_18903 : H12AffineEnvironment.transform 15 155 env18902 = env18903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 155 env18902 == env18903) = true)

def env18904 : List Nat := [2,4,8,16,0,17,128,141,137,156,0,1,129,1,1,155,1,136,156,0,0,0,16,19,9,16,1,0,0,137,21,136,141,17,1,137]

theorem envBound18904 : H12AffineFastState.Bounded env18904 := by
  intro p hp
  have h : env18904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18903_18904 : H12AffineEnvironment.transform 4 0 env18903 = env18904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18903 == env18904) = true)

def env18905 : List Nat := [2,4,8,16,1,17,128,141,137,156,0,1,129,1,0,155,1,136,156,1,0,0,16,18,9,16,1,0,0,137,21,136,141,17,1,137]

theorem envBound18905 : H12AffineFastState.Bounded env18905 := by
  intro p hp
  have h : env18905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18903_18905 : H12AffineEnvironment.transform 4 1 env18903 = env18905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18903 == env18905) = true)

theorem identity18905 : scanCanonicalize (H12AffineFastState.compose env18905 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound18905 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18906 : List Nat := [2,4,8,16,1,17,25,20,16,5,0,1,24,1,0,2,1,17,5,1,0,0,16,18,9,16,1,0,0,16,21,17,20,17,1,16]

theorem envBound18906 : H12AffineFastState.Bounded env18906 := by
  intro p hp
  have h : env18906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18905_18906 : H12AffineEnvironment.transform 6 25 env18905 = env18906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env18905 == env18906) = true)

def leafEnv18906 : List Nat := [2,4,8,16,1,17,25,20,16,5,0,1,24,1,0,2,1,17,5,1,0,0,16,18,20,9,1,16,1,0,0,16,21,17,20,17,5,18,1,16,0,0,1]

def active18906 : List Nat := [0,1,2,3]

def tree18906 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18906 : H12WitnessSearch.Good tree18906 := H12GlobalWitnessIndex.good

theorem leafIdentity18906 : H12AffineFastState.composeSystem env18906 rootObs = leafEnv18906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18906 rootObs == leafEnv18906) = true)

theorem terminalChecked18906 : H12PackedTerminal.terminalCheckFast leafEnv18906 active18906 tree18906 = true := by decide +kernel

def env18907 : List Nat := [2,4,8,16,32,17,128,141,137,156,1,1,129,1,32,65536,1,136,156,33,0,1,16,65705,9,16,0,0,0,137,21,137,141,65675,1,137]

theorem envBound18907 : H12AffineFastState.Bounded env18907 := by
  intro p hp
  have h : env18907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18901_18907 : H12AffineEnvironment.transform 10 1 env18901 = env18907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env18901 == env18907) = true)

theorem identity18907 : scanCanonicalize (H12AffineFastState.compose env18907 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound18907 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18908 : List Nat := [2,4,8,16,32,17,128,141,137,156,1,1,129,1,32,50,1,136,156,33,0,1,16,155,9,16,0,0,0,137,21,137,141,185,1,137]

theorem envBound18908 : H12AffineFastState.Bounded env18908 := by
  intro p hp
  have h : env18908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18907_18908 : H12AffineEnvironment.transform 15 50 env18907 = env18908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env18907 == env18908) = true)

def env18909 : List Nat := [2,4,8,16,0,17,128,141,137,156,1,1,129,1,0,18,1,136,156,1,0,1,16,155,9,16,0,0,0,137,21,137,141,153,1,137]

theorem envBound18909 : H12AffineFastState.Bounded env18909 := by
  intro p hp
  have h : env18909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18908_18909 : H12AffineEnvironment.transform 4 0 env18908 = env18909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18908 == env18909) = true)

theorem identity18909 : scanCanonicalize (H12AffineFastState.compose env18909 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18909 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18910 : List Nat := [2,4,8,0,0,1,128,141,137,140,1,1,129,1,0,2,1,136,140,1,0,1,0,139,9,0,0,0,0,137,5,137,141,137,1,137]

theorem envBound18910 : H12AffineFastState.Bounded env18910 := by
  intro p hp
  have h : env18910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18909_18910 : H12AffineEnvironment.transform 3 0 env18909 = env18910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18909 == env18910) = true)

theorem identity18910 : scanCanonicalize (H12AffineFastState.compose env18910 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18910 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18911 : List Nat := [2,4,8,0,0,1,9,4,0,5,1,1,8,1,0,2,1,1,5,1,0,1,0,2,9,0,0,0,0,0,5,0,4,0,1,0]

theorem envBound18911 : H12AffineFastState.Bounded env18911 := by
  intro p hp
  have h : env18911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18910_18911 : H12AffineEnvironment.transform 6 9 env18910 = env18911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18910 == env18911) = true)

def leafEnv18911 : List Nat := [2,4,8,0,0,1,9,4,0,5,1,1,8,1,0,2,1,1,5,1,0,1,0,2,4,9,1,0,0,0,0,0,5,0,4,0,5,2,1,0,0,0,1]

def active18911 : List Nat := [0,1,2]

def tree18911 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18911 : H12WitnessSearch.Good tree18911 := H12GlobalWitnessIndex.good

theorem leafIdentity18911 : H12AffineFastState.composeSystem env18911 rootObs = leafEnv18911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18911 rootObs == leafEnv18911) = true)

theorem terminalChecked18911 : H12PackedTerminal.terminalCheckFast leafEnv18911 active18911 tree18911 = true := by decide +kernel

def env18912 : List Nat := [2,4,8,16,1,17,128,141,137,156,1,1,129,1,1,19,1,136,156,0,0,1,16,155,9,16,0,0,0,137,21,137,141,152,1,137]

theorem envBound18912 : H12AffineFastState.Bounded env18912 := by
  intro p hp
  have h : env18912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18908_18912 : H12AffineEnvironment.transform 4 1 env18908 = env18912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18908 == env18912) = true)

def env18913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914001,134217728,8519744,2769921,1073741824,27513921,4294967296,10637633,4315938986,164610305,512]

theorem envBound18913 : H12AffineFastState.Bounded env18913 := by
  intro p hp
  have h : env18913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17942_18913 : H12AffineEnvironment.transform 28 2769921 env17942 = env18913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 2769921 env17942 == env18913) = true)

def env18914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,8388608,16777216,8328,8914001,134217728,8519744,676865,1073741824,25412673,4294967296,8536385,4315938986,164610305,512]

theorem envBound18914 : H12AffineFastState.Bounded env18914 := by
  intro p hp
  have h : env18914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18913_18914 : H12AffineEnvironment.transform 20 4096 env18913 = env18914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env18913 == env18914) = true)

def env18915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,147520,16777216,8328,672785,134217728,16384,676865,1073741824,16876545,4294967296,257,4315938986,156074305,512]

theorem envBound18915 : H12AffineFastState.Bounded env18915 := by
  intro p hp
  have h : env18915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18914_18915 : H12AffineEnvironment.transform 22 147520 env18914 = env18915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env18914 == env18915) = true)

def env18916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,147520,16777216,8328,672785,21857280,16384,676865,1073741824,16876545,4294967296,257,4315938986,1345,512]

theorem envBound18916 : H12AffineFastState.Bounded env18916 := by
  intro p hp
  have h : env18916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18915_18916 : H12AffineEnvironment.transform 26 21857280 env18915 = env18916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21857280 env18915 == env18916) = true)

theorem identity18916 : scanCanonicalize (H12AffineFastState.compose env18916 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 230469) := by decide +kernel

theorem selectedBound18916 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env18917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,147520,230469,8328,672785,5111877,16384,676865,1073741824,131140,4294967296,257,4299392239,1345,512]

theorem envBound18917 : H12AffineFastState.Bounded env18917 := by
  intro p hp
  have h : env18917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18916_18917 : H12AffineEnvironment.transform 23 230469 env18916 = env18917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230469 env18916 == env18917) = true)

def env18918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,10248,147520,230469,8328,672785,927821,16384,676865,1073741824,131140,4294967296,257,4295208167,1345,512]

theorem envBound18918 : H12AffineFastState.Bounded env18918 := by
  intro p hp
  have h : env18918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18917_18918 : H12AffineEnvironment.transform 21 10248 env18917 = env18918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env18917 == env18918) = true)

def env18919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,8200,147520,230469,8328,672785,925773,16384,676865,1073741824,131140,4294967296,257,4295206119,1345,512]

theorem envBound18919 : H12AffineFastState.Bounded env18919 := by
  intro p hp
  have h : env18919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18918_18919 : H12AffineEnvironment.transform 10 0 env18918 = env18919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env18918 == env18919) = true)

def env18920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,8200,17664,98565,8328,541009,795917,16384,545089,1073741824,1284,4294967296,257,4295074215,1345,512]

theorem envBound18920 : H12AffineFastState.Bounded env18920 := by
  intro p hp
  have h : env18920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18919_18920 : H12AffineEnvironment.transform 16 1344 env18919 = env18920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env18919 == env18920) = true)

theorem identity18920 : scanCanonicalize (H12AffineFastState.compose env18920 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 835637) := by decide +kernel

theorem selectedBound18920 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env18921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,8200,17664,98565,8328,541009,795917,16384,545089,835637,1284,4294967296,257,4295074215,1345,512]

theorem envBound18921 : H12AffineFastState.Bounded env18921 := by
  intro p hp
  have h : env18921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18920_18921 : H12AffineEnvironment.transform 29 835637 env18920 = env18921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 835637 env18920 == env18921) = true)

theorem identity18921 : scanCanonicalize (H12AffineFastState.compose env18921 (packedSelected [4,9,16] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound18921 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env18922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,1025,32769,4096,8200,17664,98565,8328,17744,270604,16384,21824,312372,1284,4294967296,257,4295074215,1345,512]

theorem envBound18922 : H12AffineFastState.Bounded env18922 := by
  intro p hp
  have h : env18922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18921_18922 : H12AffineEnvironment.transform 18 1025 env18921 = env18922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env18921 == env18922) = true)

theorem identity18922 : scanCanonicalize (H12AffineFastState.compose env18922 (packedSelected [1,5,8,15,17,21,24,38] rootPS)) = affineNative (2^(17+1) ^^^ 91318) := by decide +kernel

theorem selectedBound18922 : packedSelected [1,5,8,15,17,21,24,38] rootPS < 2^1333 := by decide +kernel

def env18923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,91318,1025,32769,4096,8200,17664,98565,8328,17744,83386,16384,21824,106626,1284,4294967296,257,4295074215,1345,512]

theorem envBound18923 : H12AffineFastState.Bounded env18923 := by
  intro p hp
  have h : env18923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18922_18923 : H12AffineEnvironment.transform 17 91318 env18922 = env18923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 91318 env18922 == env18923) = true)

theorem identity18923 : scanCanonicalize (H12AffineFastState.compose env18923 (packedSelected [13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound18923 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env18924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,32768,65536,1344,79079,1025,32769,4096,8200,5457,98565,8328,5377,71147,4177,1297,106626,1284,4294967296,257,4295074215,1345,512]

theorem envBound18924 : H12AffineFastState.Bounded env18924 := by
  intro p hp
  have h : env18924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18923_18924 : H12AffineEnvironment.transform 13 4177 env18923 = env18924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env18923 == env18924) = true)

theorem identity18924 : scanCanonicalize (H12AffineFastState.compose env18924 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 8320) := by decide +kernel

theorem selectedBound18924 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,32768,65536,1344,79079,1025,32769,4096,8200,5457,98565,8328,5377,71147,4177,1297,106626,1284,8320,257,98599,1345,512]

theorem envBound18925 : H12AffineFastState.Bounded env18925 := by
  intro p hp
  have h : env18925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18924_18925 : H12AffineEnvironment.transform 31 8320 env18924 = env18925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8320 env18924 == env18925) = true)

theorem identity18925 : scanCanonicalize (H12AffineFastState.compose env18925 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 38095) := by decide +kernel

theorem selectedBound18925 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env18926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,32768,38095,1344,41000,1025,32769,4096,8200,5457,5578,8328,5377,33060,4177,1297,13389,1284,8320,257,5608,1345,512]

theorem envBound18926 : H12AffineFastState.Bounded env18926 := by
  intro p hp
  have h : env18926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18925_18926 : H12AffineEnvironment.transform 15 38095 env18925 = env18926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38095 env18925 == env18926) = true)

theorem identity18926 : scanCanonicalize (H12AffineFastState.compose env18926 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound18926 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env18927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,469,4177,32768,38095,1344,33277,1025,32769,4096,477,5457,5578,349,5377,33060,4177,1297,5528,1284,341,257,5608,1345,512]

theorem envBound18927 : H12AffineFastState.Bounded env18927 := by
  intro p hp
  have h : env18927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18926_18927 : H12AffineEnvironment.transform 12 469 env18926 = env18927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env18926 == env18927) = true)

theorem identity18927 : scanCanonicalize (H12AffineFastState.compose env18927 (packedSelected [1,2,3,4,5,6,8,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 940) := by decide +kernel

theorem selectedBound18927 : packedSelected [1,2,3,4,5,6,8,9,12] rootPS < 2^1333 := by decide +kernel

def env18928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,940,469,1021,32768,34659,1344,33277,1025,32769,940,477,1789,1638,349,1709,33060,1021,1297,1588,1284,341,257,1604,1345,512]

theorem envBound18928 : H12AffineFastState.Bounded env18928 := by
  intro p hp
  have h : env18928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18927_18928 : H12AffineEnvironment.transform 11 940 env18927 = env18928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 940 env18927 == env18928) = true)

theorem identity18928 : scanCanonicalize (H12AffineFastState.compose env18928 (packedSelected [1,2,4,5,6,9,17] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound18928 : packedSelected [1,2,4,5,6,9,17] rootPS < 2^1333 := by decide +kernel

def env18929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,940,469,1021,136,2027,1344,373,1025,137,940,477,1789,1638,349,1709,428,1021,1297,1588,1284,341,257,1604,1345,512]

theorem envBound18929 : H12AffineFastState.Bounded env18929 := by
  intro p hp
  have h : env18929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18928_18929 : H12AffineEnvironment.transform 14 136 env18928 = env18929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env18928 == env18929) = true)

theorem identity18929 : scanCanonicalize (H12AffineFastState.compose env18929 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 533) := by decide +kernel

theorem selectedBound18929 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env18930 : List Nat := [2,4,8,16,32,64,128,256,512,533,0,940,469,1021,136,510,853,373,532,137,940,477,232,115,349,184,428,1021,772,33,785,341,257,81,852,512]

theorem envBound18930 : H12AffineFastState.Bounded env18930 := by
  intro p hp
  have h : env18930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18929_18930 : H12AffineEnvironment.transform 9 533 env18929 = env18930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 533 env18929 == env18930) = true)

theorem identity18930 : scanCanonicalize (H12AffineFastState.compose env18930 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18930 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env18931 : List Nat := [2,4,8,16,32,17,128,256,512,533,0,940,388,940,136,431,772,292,532,137,940,396,185,34,268,184,428,940,772,33,785,260,257,0,773,512]

theorem envBound18931 : H12AffineFastState.Bounded env18931 := by
  intro p hp
  have h : env18931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18930_18931 : H12AffineEnvironment.transform 5 17 env18930 = env18931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18930 == env18931) = true)

theorem identity18931 : scanCanonicalize (H12AffineFastState.compose env18931 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 189) := by decide +kernel

theorem selectedBound18931 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18932 : List Nat := [2,4,8,16,32,17,128,189,512,533,0,529,57,529,136,18,697,153,532,137,529,49,185,34,177,184,17,529,697,33,684,185,188,0,696,512]

theorem envBound18932 : H12AffineFastState.Bounded env18932 := by
  intro p hp
  have h : env18932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18931_18932 : H12AffineEnvironment.transform 7 189 env18931 = env18932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env18931 == env18932) = true)

def env18933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,8200,17665,98564,8328,541008,795916,16384,545088,1073741824,1285,4294967296,257,4295074214,1345,512]

theorem envBound18933 : H12AffineFastState.Bounded env18933 := by
  intro p hp
  have h : env18933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18919_18933 : H12AffineEnvironment.transform 16 1345 env18919 = env18933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env18919 == env18933) = true)

theorem identity18933 : scanCanonicalize (H12AffineFastState.compose env18933 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 835684) := by decide +kernel

theorem selectedBound18933 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env18934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,8200,17665,98564,8328,541008,795916,16384,545088,835684,1285,4294967296,257,4295074214,1345,512]

theorem envBound18934 : H12AffineFastState.Bounded env18934 := by
  intro p hp
  have h : env18934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18933_18934 : H12AffineEnvironment.transform 29 835684 env18933 = env18934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 835684 env18933 == env18934) = true)

def env18935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,304168,32769,4096,8200,17665,98564,8328,320888,33060,16384,324968,25676,1285,4294967296,257,4295074214,1345,512]

theorem envBound18935 : H12AffineFastState.Bounded env18935 := by
  intro p hp
  have h : env18935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18934_18935 : H12AffineEnvironment.transform 18 304168 env18934 = env18935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304168 env18934 == env18935) = true)

theorem identity18935 : scanCanonicalize (H12AffineFastState.compose env18935 (packedSelected [3,13,15,17,19,21,28] rootPS)) = affineNative (2^(17+1) ^^^ 58728) := by decide +kernel

theorem selectedBound18935 : packedSelected [3,13,15,17,19,21,28] rootPS < 2^1333 := by decide +kernel

def env18936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,58728,16704,32769,4096,8200,17665,98564,8328,16,33060,16384,4096,25676,1285,4294967296,257,4295074214,1345,512]

theorem envBound18936 : H12AffineFastState.Bounded env18936 := by
  intro p hp
  have h : env18936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18935_18936 : H12AffineEnvironment.transform 17 58728 env18935 = env18936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 58728 env18935 == env18936) = true)

def env18937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,25960,65536,1345,0,16704,25961,4096,8200,17665,91244,8328,16,25676,16384,4096,25676,1285,4294967296,257,4295050446,1345,512]

theorem envBound18937 : H12AffineFastState.Bounded env18937 := by
  intro p hp
  have h : env18937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18936_18937 : H12AffineEnvironment.transform 14 25960 env18936 = env18937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25960 env18936 == env18937) = true)

theorem identity18937 : scanCanonicalize (H12AffineFastState.compose env18937 (packedSelected [4,9] rootPS)) = affineNative (2^(13+1) ^^^ 1345) := by decide +kernel

theorem selectedBound18937 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env18938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1345,8233,65536,1345,0,1025,8232,4096,8200,64,74029,8328,16,8461,1345,4096,8461,1285,4294967296,257,4295033231,1345,512]

theorem envBound18938 : H12AffineFastState.Bounded env18938 := by
  intro p hp
  have h : env18938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18937_18938 : H12AffineEnvironment.transform 13 1345 env18937 = env18938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env18937 == env18938) = true)

theorem identity18938 : scanCanonicalize (H12AffineFastState.compose env18938 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound18938 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env18939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,268,1345,293,65536,1345,0,1025,292,4096,260,64,65569,388,16,1,1345,4096,1,1285,4294967296,257,4295033231,1345,512]

theorem envBound18939 : H12AffineFastState.Bounded env18939 := by
  intro p hp
  have h : env18939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18938_18939 : H12AffineEnvironment.transform 12 268 env18938 = env18939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env18938 == env18939) = true)

def env18940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1344,268,1345,293,65536,1345,0,1025,292,1344,260,64,65569,388,16,1,1345,1344,1,1285,4294967296,257,4295033231,1345,512]

theorem envBound18940 : H12AffineFastState.Bounded env18940 := by
  intro p hp
  have h : env18940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18939_18940 : H12AffineEnvironment.transform 11 1344 env18939 = env18940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env18939 == env18940) = true)

theorem identity18940 : scanCanonicalize (H12AffineFastState.compose env18940 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(15+1) ^^^ 250) := by decide +kernel

theorem selectedBound18940 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env18941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1344,268,1345,293,250,1345,0,1025,292,1344,260,64,219,388,16,1,1345,1344,1,1285,4294967296,257,4294967669,1345,512]

theorem envBound18941 : H12AffineFastState.Bounded env18941 := by
  intro p hp
  have h : env18941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18940_18941 : H12AffineEnvironment.transform 15 250 env18940 = env18941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 250 env18940 == env18941) = true)

theorem identity18941 : scanCanonicalize (H12AffineFastState.compose env18941 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18941 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18942 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,1296,268,1297,293,170,1297,0,1025,292,1296,260,16,139,388,16,1,1297,1296,1,1285,4294967296,257,4294967589,1297,512]

theorem envBound18942 : H12AffineFastState.Bounded env18942 := by
  intro p hp
  have h : env18942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18941_18942 : H12AffineEnvironment.transform 5 16 env18941 = env18942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18941 == env18942) = true)

theorem identity18942 : scanCanonicalize (H12AffineFastState.compose env18942 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound18942 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18943 : List Nat := [2,4,8,16,32,16,128,36,512,1024,0,1076,40,1077,1,170,1077,0,1025,0,1076,32,16,139,160,16,1,1077,1076,1,1057,4294967296,37,4294967297,1077,512]

theorem envBound18943 : H12AffineFastState.Bounded env18943 := by
  intro p hp
  have h : env18943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18942_18943 : H12AffineEnvironment.transform 7 36 env18942 = env18943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env18942 == env18943) = true)

theorem identity18943 : scanCanonicalize (H12AffineFastState.compose env18943 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound18943 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18944 : List Nat := [2,4,8,16,32,16,128,36,33,1024,0,1076,40,1077,1,170,1077,0,1025,0,1076,32,16,139,160,16,1,1077,1076,1,1057,4294967296,37,4294967297,1077,33]

theorem envBound18944 : H12AffineFastState.Bounded env18944 := by
  intro p hp
  have h : env18944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18943_18944 : H12AffineEnvironment.transform 8 33 env18943 = env18944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env18943 == env18944) = true)

theorem identity18944 : scanCanonicalize (H12AffineFastState.compose env18944 (packedSelected [0,4] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound18944 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18945 : List Nat := [2,4,8,16,32,16,128,36,33,1024,0,1076,40,1077,1,170,1077,0,1025,0,1076,32,16,139,160,16,1,1077,1076,1,1057,0,37,1,1077,33]

theorem envBound18945 : H12AffineFastState.Bounded env18945 := by
  intro p hp
  have h : env18945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18944_18945 : H12AffineEnvironment.transform 31 0 env18944 = env18945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env18944 == env18945) = true)

def env18946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1345,268,1345,293,65536,1345,0,1025,292,1345,260,64,65569,388,16,1,1345,1345,1,1285,4294967296,257,4295033231,1345,512]

theorem envBound18946 : H12AffineFastState.Bounded env18946 := by
  intro p hp
  have h : env18946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18939_18946 : H12AffineEnvironment.transform 11 1345 env18939 = env18946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env18939 == env18946) = true)

theorem identity18946 : scanCanonicalize (H12AffineFastState.compose env18946 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18946 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env18947 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1296,268,1296,293,65536,1296,0,1025,292,1296,260,17,65569,388,16,1,1296,1296,1,1285,4294967296,257,4295033231,1296,512]

theorem envBound18947 : H12AffineFastState.Bounded env18947 := by
  intro p hp
  have h : env18947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18946_18947 : H12AffineEnvironment.transform 5 17 env18946 = env18947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18946 == env18947) = true)

theorem identity18947 : scanCanonicalize (H12AffineFastState.compose env18947 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound18947 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18948 : List Nat := [2,4,8,16,32,17,128,256,137,1024,0,1296,268,1296,293,65536,1296,0,1025,292,1296,260,17,65569,388,16,1,1296,1296,1,1285,4294967296,257,4295033231,1296,137]

theorem envBound18948 : H12AffineFastState.Bounded env18948 := by
  intro p hp
  have h : env18948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18947_18948 : H12AffineEnvironment.transform 8 137 env18947 = env18948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env18947 == env18948) = true)

theorem identity18948 : scanCanonicalize (H12AffineFastState.compose env18948 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound18948 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env18949 : List Nat := [2,4,8,16,32,17,128,256,137,1024,0,1296,268,1296,293,170,1296,0,1025,292,1296,260,17,139,388,16,1,1296,1296,1,1285,4294967296,257,4294967589,1296,137]

theorem envBound18949 : H12AffineFastState.Bounded env18949 := by
  intro p hp
  have h : env18949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18948_18949 : H12AffineEnvironment.transform 15 170 env18948 = env18949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env18948 == env18949) = true)

theorem identity18949 : scanCanonicalize (H12AffineFastState.compose env18949 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18949 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env18950 : List Nat := [2,4,8,16,32,17,9,256,0,1024,0,1296,268,1296,293,35,1296,0,1025,292,1296,260,17,2,269,16,1,1296,1296,1,1285,4294967296,257,4294967589,1296,0]

theorem envBound18950 : H12AffineFastState.Bounded env18950 := by
  intro p hp
  have h : env18950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18949_18950 : H12AffineEnvironment.transform 6 9 env18949 = env18950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18949 == env18950) = true)

theorem identity18950 : scanCanonicalize (H12AffineFastState.compose env18950 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 293) := by decide +kernel

theorem selectedBound18950 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18951 : List Nat := [2,4,8,16,32,17,9,256,0,1024,0,1296,268,1296,293,35,1296,0,1025,292,1296,260,17,2,269,16,1,1296,1296,1,1285,293,257,0,1296,0]

theorem envBound18951 : H12AffineFastState.Bounded env18951 := by
  intro p hp
  have h : env18951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18950_18951 : H12AffineEnvironment.transform 31 293 env18950 = env18951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 293 env18950 == env18951) = true)

def env18952 : List Nat := [2,4,8,16,0,17,9,256,0,1024,0,1296,268,1296,261,3,1296,0,1025,260,1296,260,17,2,269,16,1,1296,1296,1,1285,261,257,0,1296,0]

theorem envBound18952 : H12AffineFastState.Bounded env18952 := by
  intro p hp
  have h : env18952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18951_18952 : H12AffineEnvironment.transform 4 0 env18951 = env18952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18951 == env18952) = true)

theorem identity18952 : scanCanonicalize (H12AffineFastState.compose env18952 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound18952 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18953 : List Nat := [2,4,8,16,0,17,9,4,0,1024,0,1044,8,1044,1,3,1044,0,1025,0,1044,0,17,2,9,16,1,1044,1044,1,1025,1,5,0,1044,0]

theorem envBound18953 : H12AffineFastState.Bounded env18953 := by
  intro p hp
  have h : env18953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18952_18953 : H12AffineEnvironment.transform 7 4 env18952 = env18953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18952 == env18953) = true)

def leafEnv18953 : List Nat := [2,4,8,16,0,17,9,4,0,1024,0,1044,8,1044,1,3,1044,0,1025,0,1044,0,17,2,1024,9,1,16,1,1044,1044,1,1025,1,5,0,5,3,1044,0,0,1044,1]

def active18953 : List Nat := [0,1,2,3,9]

def tree18953 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18953 : H12WitnessSearch.Good tree18953 := H12GlobalWitnessIndex.good

theorem leafIdentity18953 : H12AffineFastState.composeSystem env18953 rootObs = leafEnv18953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18953 rootObs == leafEnv18953) = true)

theorem terminalChecked18953 : H12PackedTerminal.terminalCheckFast leafEnv18953 active18953 tree18953 = true := by decide +kernel

def env18954 : List Nat := [2,4,8,16,1,17,9,256,0,1024,0,1296,268,1296,260,2,1296,0,1025,261,1296,260,17,2,269,16,1,1296,1296,1,1285,260,257,0,1296,0]

theorem envBound18954 : H12AffineFastState.Bounded env18954 := by
  intro p hp
  have h : env18954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18951_18954 : H12AffineEnvironment.transform 4 1 env18951 = env18954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18951 == env18954) = true)

def env18955 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,25961,65536,1345,1,16704,25960,4096,8200,17665,91245,8328,16,25677,16384,4096,25676,1285,4294967296,257,4295050447,1345,512]

theorem envBound18955 : H12AffineFastState.Bounded env18955 := by
  intro p hp
  have h : env18955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18936_18955 : H12AffineEnvironment.transform 14 25961 env18936 = env18955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25961 env18936 == env18955) = true)

theorem identity18955 : scanCanonicalize (H12AffineFastState.compose env18955 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound18955 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env18956 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,269,16384,17508,65536,1345,1,16704,17509,4096,261,17665,83296,389,16,17728,16384,4096,17729,1285,4294967296,257,4295050447,1345,512]

theorem envBound18956 : H12AffineFastState.Bounded env18956 := by
  intro p hp
  have h : env18956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18955_18956 : H12AffineEnvironment.transform 12 269 env18955 = env18956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env18955 == env18956) = true)

theorem identity18956 : scanCanonicalize (H12AffineFastState.compose env18956 (packedSelected [0,1,3,7,10,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 1345) := by decide +kernel

theorem selectedBound18956 : packedSelected [0,1,3,7,10,12,13] rootPS < 2^1333 := by decide +kernel

def env18957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,269,1345,293,65536,1345,1,1025,292,4096,261,64,65569,389,16,1,1345,4096,0,1285,4294967296,257,4295033230,1345,512]

theorem envBound18957 : H12AffineFastState.Bounded env18957 := by
  intro p hp
  have h : env18957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18956_18957 : H12AffineEnvironment.transform 13 1345 env18956 = env18957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env18956 == env18957) = true)

def env18958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1344,269,1345,293,65536,1345,1,1025,292,1344,261,64,65569,389,16,1,1345,1344,0,1285,4294967296,257,4295033230,1345,512]

theorem envBound18958 : H12AffineFastState.Bounded env18958 := by
  intro p hp
  have h : env18958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18957_18958 : H12AffineEnvironment.transform 11 1344 env18957 = env18958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env18957 == env18958) = true)

theorem identity18958 : scanCanonicalize (H12AffineFastState.compose env18958 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(15+1) ^^^ 250) := by decide +kernel

theorem selectedBound18958 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env18959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1344,269,1345,293,250,1345,1,1025,292,1344,261,64,219,389,16,1,1345,1344,0,1285,4294967296,257,4294967668,1345,512]

theorem envBound18959 : H12AffineFastState.Bounded env18959 := by
  intro p hp
  have h : env18959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18958_18959 : H12AffineEnvironment.transform 15 250 env18958 = env18959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 250 env18958 == env18959) = true)

theorem identity18959 : scanCanonicalize (H12AffineFastState.compose env18959 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18959 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18960 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,1296,269,1297,293,170,1297,1,1025,292,1296,261,16,139,389,16,1,1297,1296,0,1285,4294967296,257,4294967588,1297,512]

theorem envBound18960 : H12AffineFastState.Bounded env18960 := by
  intro p hp
  have h : env18960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18959_18960 : H12AffineEnvironment.transform 5 16 env18959 = env18960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18959 == env18960) = true)

theorem identity18960 : scanCanonicalize (H12AffineFastState.compose env18960 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound18960 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18961 : List Nat := [2,4,8,16,32,16,128,36,512,1024,0,1076,41,1077,1,170,1077,1,1025,0,1076,33,16,139,161,16,1,1077,1076,0,1057,4294967296,37,4294967296,1077,512]

theorem envBound18961 : H12AffineFastState.Bounded env18961 := by
  intro p hp
  have h : env18961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18960_18961 : H12AffineEnvironment.transform 7 36 env18960 = env18961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env18960 == env18961) = true)

theorem identity18961 : scanCanonicalize (H12AffineFastState.compose env18961 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 513) := by decide +kernel

theorem selectedBound18961 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18962 : List Nat := [2,4,8,16,32,16,128,36,512,1024,0,1076,41,1077,1,170,1077,1,1025,0,1076,33,16,139,161,16,1,1077,1076,0,1057,513,37,513,1077,512]

theorem envBound18962 : H12AffineFastState.Bounded env18962 := by
  intro p hp
  have h : env18962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18961_18962 : H12AffineEnvironment.transform 31 513 env18961 = env18962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 513 env18961 == env18962) = true)

theorem identity18962 : scanCanonicalize (H12AffineFastState.compose env18962 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound18962 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18963 : List Nat := [2,4,8,16,32,16,128,36,136,1024,0,1076,41,1077,1,170,1077,1,1025,0,1076,33,16,139,161,16,1,1077,1076,0,1057,137,37,137,1077,136]

theorem envBound18963 : H12AffineFastState.Bounded env18963 := by
  intro p hp
  have h : env18963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18962_18963 : H12AffineEnvironment.transform 8 136 env18962 = env18963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env18962 == env18963) = true)

def leafEnv18963 : List Nat := [2,4,8,16,32,16,128,36,136,1024,0,1076,41,1077,1,170,1077,1,1025,0,1076,33,16,139,1056,161,1,16,1,1077,1076,0,1057,137,37,137,5,35,1077,136,0,1076,1]

def active18963 : List Nat := [0,1,2,3,4,6,9]

def tree18963 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18963 : H12WitnessSearch.Good tree18963 := H12GlobalWitnessIndex.good

theorem leafIdentity18963 : H12AffineFastState.composeSystem env18963 rootObs = leafEnv18963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18963 rootObs == leafEnv18963) = true)

theorem terminalChecked18963 : H12PackedTerminal.terminalCheckFast leafEnv18963 active18963 tree18963 = true := by decide +kernel

def env18964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1345,269,1345,293,65536,1345,1,1025,292,1345,261,64,65569,389,16,1,1345,1345,0,1285,4294967296,257,4295033230,1345,512]

theorem envBound18964 : H12AffineFastState.Bounded env18964 := by
  intro p hp
  have h : env18964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18957_18964 : H12AffineEnvironment.transform 11 1345 env18957 = env18964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env18957 == env18964) = true)

theorem identity18964 : scanCanonicalize (H12AffineFastState.compose env18964 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18964 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env18965 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1296,269,1296,293,65536,1296,1,1025,292,1296,261,17,65569,389,16,1,1296,1296,0,1285,4294967296,257,4295033230,1296,512]

theorem envBound18965 : H12AffineFastState.Bounded env18965 := by
  intro p hp
  have h : env18965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18964_18965 : H12AffineEnvironment.transform 5 17 env18964 = env18965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18964 == env18965) = true)

theorem identity18965 : scanCanonicalize (H12AffineFastState.compose env18965 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound18965 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18966 : List Nat := [2,4,8,16,32,17,128,256,136,1024,0,1296,269,1296,293,65536,1296,1,1025,292,1296,261,17,65569,389,16,1,1296,1296,0,1285,4294967296,257,4295033230,1296,136]

theorem envBound18966 : H12AffineFastState.Bounded env18966 := by
  intro p hp
  have h : env18966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18965_18966 : H12AffineEnvironment.transform 8 136 env18965 = env18966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env18965 == env18966) = true)

def env18967 : List Nat := [2,4,8,16,32,17,128,36,136,1024,0,1076,41,1076,1,65536,1076,1,1025,0,1076,33,17,65569,161,16,1,1076,1076,0,1057,4294967296,37,4295033002,1076,136]

theorem envBound18967 : H12AffineFastState.Bounded env18967 := by
  intro p hp
  have h : env18967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18966_18967 : H12AffineEnvironment.transform 7 36 env18966 = env18967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env18966 == env18967) = true)

theorem identity18967 : scanCanonicalize (H12AffineFastState.compose env18967 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65570) := by decide +kernel

theorem selectedBound18967 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18968 : List Nat := [2,4,8,16,32,17,128,36,136,1024,0,1076,41,1076,1,65536,1076,1,1025,0,1076,33,17,65569,161,16,1,1076,1076,0,1057,65570,37,136,1076,136]

theorem envBound18968 : H12AffineFastState.Bounded env18968 := by
  intro p hp
  have h : env18968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18967_18968 : H12AffineEnvironment.transform 31 65570 env18967 = env18968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65570 env18967 == env18968) = true)

def env18969 : List Nat := [2,4,8,16,32,17,128,36,136,52,0,0,41,0,1,65536,0,1,53,0,0,33,17,65569,161,16,1,0,0,0,21,65570,37,136,0,136]

theorem envBound18969 : H12AffineFastState.Bounded env18969 := by
  intro p hp
  have h : env18969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18968_18969 : H12AffineEnvironment.transform 9 52 env18968 = env18969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env18968 == env18969) = true)

theorem identity18969 : scanCanonicalize (H12AffineFastState.compose env18969 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound18969 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18970 : List Nat := [2,4,8,16,32,17,128,36,136,52,0,0,41,0,1,170,0,1,53,0,0,33,17,139,161,16,1,0,0,0,21,136,37,136,0,136]

theorem envBound18970 : H12AffineFastState.Bounded env18970 := by
  intro p hp
  have h : env18970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18969_18970 : H12AffineEnvironment.transform 15 170 env18969 = env18970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env18969 == env18970) = true)

def leafEnv18970 : List Nat := [2,4,8,16,32,17,128,36,136,52,0,0,41,0,1,170,0,1,53,0,0,33,17,139,20,161,1,16,1,0,0,0,21,136,37,136,5,35,0,136,0,0,1]

def active18970 : List Nat := [0,1,2,3,4,6]

def tree18970 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18970 : H12WitnessSearch.Good tree18970 := H12GlobalWitnessIndex.good

theorem leafIdentity18970 : H12AffineFastState.composeSystem env18970 rootObs = leafEnv18970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18970 rootObs == leafEnv18970) = true)

theorem terminalChecked18970 : H12PackedTerminal.terminalCheckFast leafEnv18970 active18970 tree18970 = true := by decide +kernel

def env18971 : List Nat := [2,4,8,16,32,17,128,36,136,53,0,1,41,1,1,65536,1,1,52,0,1,33,17,65569,161,16,1,1,1,0,20,65570,37,136,1,136]

theorem envBound18971 : H12AffineFastState.Bounded env18971 := by
  intro p hp
  have h : env18971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18968_18971 : H12AffineEnvironment.transform 9 53 env18968 = env18971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env18968 == env18971) = true)

def env18972 : List Nat := [2,4,8,16,0,17,128,4,136,21,0,1,9,1,1,65536,1,1,20,0,1,1,17,65537,129,16,1,1,1,0,20,65538,5,136,1,136]

theorem envBound18972 : H12AffineFastState.Bounded env18972 := by
  intro p hp
  have h : env18972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18971_18972 : H12AffineEnvironment.transform 4 0 env18971 = env18972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18971 == env18972) = true)

theorem identity18972 : scanCanonicalize (H12AffineFastState.compose env18972 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound18972 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18973 : List Nat := [2,4,8,16,0,17,128,4,136,21,0,1,9,1,1,138,1,1,20,0,1,1,17,139,129,16,1,1,1,0,20,136,5,136,1,136]

theorem envBound18973 : H12AffineFastState.Bounded env18973 := by
  intro p hp
  have h : env18973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18972_18973 : H12AffineEnvironment.transform 15 138 env18972 = env18973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env18972 == env18973) = true)

def leafEnv18973 : List Nat := [2,4,8,16,0,17,128,4,136,21,0,1,9,1,1,138,1,1,20,0,1,1,17,139,21,129,1,16,1,1,1,0,20,136,5,136,5,3,1,136,0,1,1]

def active18973 : List Nat := [0,1,2,3,6]

def tree18973 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18973 : H12WitnessSearch.Good tree18973 := H12GlobalWitnessIndex.good

theorem leafIdentity18973 : H12AffineFastState.composeSystem env18973 rootObs = leafEnv18973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18973 rootObs == leafEnv18973) = true)

theorem terminalChecked18973 : H12PackedTerminal.terminalCheckFast leafEnv18973 active18973 tree18973 = true := by decide +kernel

def env18974 : List Nat := [2,4,8,16,1,17,128,5,136,20,0,1,8,1,1,65536,1,1,21,0,1,0,17,65536,128,16,1,1,1,0,20,65539,4,136,1,136]

theorem envBound18974 : H12AffineFastState.Bounded env18974 := by
  intro p hp
  have h : env18974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18971_18974 : H12AffineEnvironment.transform 4 1 env18971 = env18974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18971 == env18974) = true)

def leafEnv18974 : List Nat := [2,4,8,16,1,17,128,5,136,20,0,1,8,1,1,65536,1,1,21,0,1,0,17,65536,21,128,1,16,1,1,1,0,20,65539,4,136,5,2,1,136,0,1,1]

def active18974 : List Nat := [0,1,2,3,6,15]

def tree18974 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18974 : H12WitnessSearch.Good tree18974 := H12GlobalWitnessIndex.good

theorem leafIdentity18974 : H12AffineFastState.composeSystem env18974 rootObs = leafEnv18974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18974 rootObs == leafEnv18974) = true)

theorem terminalChecked18974 : H12PackedTerminal.terminalCheckFast leafEnv18974 active18974 tree18974 = true := by decide +kernel

def env18975 : List Nat := [2,4,8,16,32,17,128,37,136,1024,0,1077,40,1077,0,65536,1077,1,1025,1,1077,32,17,65569,160,16,1,1077,1077,0,1056,4294967296,36,4295033003,1077,136]

theorem envBound18975 : H12AffineFastState.Bounded env18975 := by
  intro p hp
  have h : env18975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18966_18975 : H12AffineEnvironment.transform 7 37 env18966 = env18975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18966 == env18975) = true)

theorem identity18975 : scanCanonicalize (H12AffineFastState.compose env18975 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 1) := by decide +kernel

theorem selectedBound18975 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18976 : List Nat := [2,4,8,16,32,17,128,37,136,1024,0,1077,40,1077,0,65536,1077,1,1025,1,1077,32,17,65569,160,16,1,1077,1077,0,1056,1,36,65706,1077,136]

theorem envBound18976 : H12AffineFastState.Bounded env18976 := by
  intro p hp
  have h : env18976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18975_18976 : H12AffineEnvironment.transform 31 1 env18975 = env18976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1 env18975 == env18976) = true)

def env18977 : List Nat := [2,4,8,16,32,17,128,37,136,52,0,1,40,1,0,65536,1,1,53,1,1,32,17,65569,160,16,1,1,1,0,20,1,36,65706,1,136]

theorem envBound18977 : H12AffineFastState.Bounded env18977 := by
  intro p hp
  have h : env18977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18976_18977 : H12AffineEnvironment.transform 9 52 env18976 = env18977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env18976 == env18977) = true)

def env18978 : List Nat := [2,4,8,16,32,17,8,37,0,52,0,1,40,1,0,65536,1,1,53,1,1,32,17,65569,40,16,1,1,1,0,20,1,36,65570,1,0]

theorem envBound18978 : H12AffineFastState.Bounded env18978 := by
  intro p hp
  have h : env18978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18977_18978 : H12AffineEnvironment.transform 6 8 env18977 = env18978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18977 == env18978) = true)

theorem identity18978 : scanCanonicalize (H12AffineFastState.compose env18978 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound18978 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18979 : List Nat := [2,4,8,16,32,17,8,37,0,52,0,1,40,1,0,2,1,1,53,1,1,32,17,35,40,16,1,1,1,0,20,1,36,32,1,0]

theorem envBound18979 : H12AffineFastState.Bounded env18979 := by
  intro p hp
  have h : env18979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18978_18979 : H12AffineEnvironment.transform 15 2 env18978 = env18979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env18978 == env18979) = true)

theorem identity18979 : scanCanonicalize (H12AffineFastState.compose env18979 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound18979 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18980 : List Nat := [2,4,8,16,0,17,8,5,0,20,0,1,8,1,0,2,1,1,21,1,1,0,17,3,8,16,1,1,1,0,20,1,4,0,1,0]

theorem envBound18980 : H12AffineFastState.Bounded env18980 := by
  intro p hp
  have h : env18980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18979_18980 : H12AffineEnvironment.transform 4 0 env18979 = env18980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18979 == env18980) = true)

def leafEnv18980 : List Nat := [2,4,8,16,0,17,8,5,0,20,0,1,8,1,0,2,1,1,21,1,1,0,17,3,21,8,1,16,1,1,1,0,20,1,4,0,5,3,1,0,0,1,1]

def active18980 : List Nat := [0,1,2,3]

def tree18980 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18980 : H12WitnessSearch.Good tree18980 := H12GlobalWitnessIndex.good

theorem leafIdentity18980 : H12AffineFastState.composeSystem env18980 rootObs = leafEnv18980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18980 rootObs == leafEnv18980) = true)

theorem terminalChecked18980 : H12PackedTerminal.terminalCheckFast leafEnv18980 active18980 tree18980 = true := by decide +kernel

def env18981 : List Nat := [2,4,8,16,32,17,9,37,1,52,0,1,40,1,0,65536,1,1,53,1,1,32,17,65569,41,16,1,1,1,0,20,1,36,65571,1,1]

theorem envBound18981 : H12AffineFastState.Bounded env18981 := by
  intro p hp
  have h : env18981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18977_18981 : H12AffineEnvironment.transform 6 9 env18977 = env18981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18977 == env18981) = true)

theorem identity18981 : scanCanonicalize (H12AffineFastState.compose env18981 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18981 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18982 : List Nat := [2,4,8,16,1,17,9,4,1,21,0,1,9,1,0,65536,1,1,20,1,1,1,17,65536,8,16,1,1,1,0,20,1,5,65538,1,1]

theorem envBound18982 : H12AffineFastState.Bounded env18982 := by
  intro p hp
  have h : env18982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18981_18982 : H12AffineEnvironment.transform 4 1 env18981 = env18982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18981 == env18982) = true)

theorem identity18982 : scanCanonicalize (H12AffineFastState.compose env18982 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound18982 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18983 : List Nat := [2,4,8,16,1,17,9,4,1,21,0,1,9,1,0,2,1,1,20,1,1,1,17,2,8,16,1,1,1,0,20,1,5,0,1,1]

theorem envBound18983 : H12AffineFastState.Bounded env18983 := by
  intro p hp
  have h : env18983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18982_18983 : H12AffineEnvironment.transform 15 2 env18982 = env18983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env18982 == env18983) = true)

def leafEnv18983 : List Nat := [2,4,8,16,1,17,9,4,1,21,0,1,9,1,0,2,1,1,20,1,1,1,17,2,21,8,1,16,1,1,1,0,20,1,5,0,5,2,1,1,0,1,1]

def active18983 : List Nat := [0,1,2,3]

def tree18983 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18983 : H12WitnessSearch.Good tree18983 := H12GlobalWitnessIndex.good

theorem leafIdentity18983 : H12AffineFastState.composeSystem env18983 rootObs = leafEnv18983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18983 rootObs == leafEnv18983) = true)

theorem terminalChecked18983 : H12PackedTerminal.terminalCheckFast leafEnv18983 active18983 tree18983 = true := by decide +kernel

def env18984 : List Nat := [2,4,8,16,32,17,128,37,136,53,0,0,40,0,0,65536,0,1,52,1,0,32,17,65569,160,16,1,0,0,0,21,1,36,65706,0,136]

theorem envBound18984 : H12AffineFastState.Bounded env18984 := by
  intro p hp
  have h : env18984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18976_18984 : H12AffineEnvironment.transform 9 53 env18976 = env18984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env18976 == env18984) = true)

theorem identity18984 : scanCanonicalize (H12AffineFastState.compose env18984 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound18984 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18985 : List Nat := [2,4,8,16,32,17,128,37,136,53,0,0,40,0,0,170,0,1,52,1,0,32,17,139,160,16,1,0,0,0,21,1,36,0,0,136]

theorem envBound18985 : H12AffineFastState.Bounded env18985 := by
  intro p hp
  have h : env18985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18984_18985 : H12AffineEnvironment.transform 15 170 env18984 = env18985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env18984 == env18985) = true)

theorem identity18985 : scanCanonicalize (H12AffineFastState.compose env18985 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound18985 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18986 : List Nat := [2,4,8,16,32,17,40,37,32,53,0,0,40,0,0,2,0,1,52,1,0,32,17,35,8,16,1,0,0,0,21,1,36,0,0,32]

theorem envBound18986 : H12AffineFastState.Bounded env18986 := by
  intro p hp
  have h : env18986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18985_18986 : H12AffineEnvironment.transform 6 40 env18985 = env18986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env18985 == env18986) = true)

def leafEnv18986 : List Nat := [2,4,8,16,32,17,40,37,32,53,0,0,40,0,0,2,0,1,52,1,0,32,17,35,20,8,1,16,1,0,0,0,21,1,36,0,5,35,0,32,0,0,1]

def active18986 : List Nat := [0,1,2,3,4]

def tree18986 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18986 : H12WitnessSearch.Good tree18986 := H12GlobalWitnessIndex.good

theorem leafIdentity18986 : H12AffineFastState.composeSystem env18986 rootObs = leafEnv18986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18986 rootObs == leafEnv18986) = true)

theorem terminalChecked18986 : H12PackedTerminal.terminalCheckFast leafEnv18986 active18986 tree18986 = true := by decide +kernel

def env18987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,304169,32769,4096,8200,17665,98564,8328,320889,33061,16384,324969,25677,1285,4294967296,257,4295074214,1345,512]

theorem envBound18987 : H12AffineFastState.Bounded env18987 := by
  intro p hp
  have h : env18987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18934_18987 : H12AffineEnvironment.transform 18 304169 env18934 = env18987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304169 env18934 == env18987) = true)

theorem identity18987 : scanCanonicalize (H12AffineFastState.compose env18987 (packedSelected [4,9,18] rootPS)) = affineNative (2^(13+1) ^^^ 9293) := by decide +kernel

theorem selectedBound18987 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env18988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,9293,32768,65536,1345,262144,304169,32769,4096,8200,8524,98564,8328,295220,33061,9293,299300,0,1285,4294967296,257,4295074214,1345,512]

theorem envBound18988 : H12AffineFastState.Bounded env18988 := by
  intro p hp
  have h : env18988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18987_18988 : H12AffineEnvironment.transform 13 9293 env18987 = env18988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9293 env18987 == env18988) = true)

theorem identity18988 : scanCanonicalize (H12AffineFastState.compose env18988 (packedSelected [20,23] rootPS)) = affineNative (2^(17+1) ^^^ 0) := by decide +kernel

theorem selectedBound18988 : packedSelected [20,23] rootPS < 2^1333 := by decide +kernel

def env18989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,9293,32768,65536,1345,0,42025,32769,4096,8200,8524,98564,8328,33076,33061,9293,37156,0,1285,4294967296,257,4295074214,1345,512]

theorem envBound18989 : H12AffineFastState.Bounded env18989 := by
  intro p hp
  have h : env18989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18988_18989 : H12AffineEnvironment.transform 17 0 env18988 = env18989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env18988 == env18989) = true)

def env18990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,8201,147520,230469,8328,672785,925772,16384,676865,1073741824,131140,4294967296,257,4295206118,1345,512]

theorem envBound18990 : H12AffineFastState.Bounded env18990 := by
  intro p hp
  have h : env18990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18918_18990 : H12AffineEnvironment.transform 10 1 env18918 = env18990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env18918 == env18990) = true)

def env18991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,8201,17664,98565,8328,541009,795916,16384,545089,1073741824,1284,4294967296,257,4295074214,1345,512]

theorem envBound18991 : H12AffineFastState.Bounded env18991 := by
  intro p hp
  have h : env18991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18990_18991 : H12AffineEnvironment.transform 16 1344 env18990 = env18991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env18990 == env18991) = true)

theorem identity18991 : scanCanonicalize (H12AffineFastState.compose env18991 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 25629) := by decide +kernel

theorem selectedBound18991 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env18992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,8201,17664,98565,8328,541009,795916,16384,545089,25629,1284,4294967296,257,4295074214,1345,512]

theorem envBound18992 : H12AffineFastState.Bounded env18992 := by
  intro p hp
  have h : env18992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18991_18992 : H12AffineEnvironment.transform 29 25629 env18991 = env18992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 25629 env18991 == env18992) = true)

theorem identity18992 : scanCanonicalize (H12AffineFastState.compose env18992 (packedSelected [4,9,16] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound18992 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env18993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,1025,32769,4096,8201,17664,98565,8328,17744,270605,16384,21824,25629,1284,4294967296,257,4295074214,1345,512]

theorem envBound18993 : H12AffineFastState.Bounded env18993 := by
  intro p hp
  have h : env18993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18992_18993 : H12AffineEnvironment.transform 18 1025 env18992 = env18993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env18992 == env18993) = true)

theorem identity18993 : scanCanonicalize (H12AffineFastState.compose env18993 (packedSelected [1,5,8,15,17,21,24,38] rootPS)) = affineNative (2^(15+1) ^^^ 50335) := by decide +kernel

theorem selectedBound18993 : packedSelected [1,5,8,15,17,21,24,38] rootPS < 2^1333 := by decide +kernel

def env18994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,50335,1344,262144,1025,32769,4096,8201,17664,17818,8328,17744,270605,16384,21824,25629,1284,4294967296,257,4294993209,1345,512]

theorem envBound18994 : H12AffineFastState.Bounded env18994 := by
  intro p hp
  have h : env18994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18993_18994 : H12AffineEnvironment.transform 15 50335 env18993 = env18994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50335 env18993 == env18994) = true)

theorem identity18994 : scanCanonicalize (H12AffineFastState.compose env18994 (packedSelected [13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound18994 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env18995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,32768,38094,1344,262144,1025,32769,4096,8201,5457,5579,8328,5377,270605,4177,1297,13388,1284,4294967296,257,4294980968,1345,512]

theorem envBound18995 : H12AffineFastState.Bounded env18995 := by
  intro p hp
  have h : env18995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18994_18995 : H12AffineEnvironment.transform 13 4177 env18994 = env18995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env18994 == env18995) = true)

theorem identity18995 : scanCanonicalize (H12AffineFastState.compose env18995 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 8321) := by decide +kernel

theorem selectedBound18995 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,32768,38094,1344,262144,1025,32769,4096,8201,5457,5579,8328,5377,270605,4177,1297,13388,1284,8321,257,5609,1345,512]

theorem envBound18996 : H12AffineFastState.Bounded env18996 := by
  intro p hp
  have h : env18996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18995_18996 : H12AffineEnvironment.transform 31 8321 env18995 = env18996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8321 env18995 == env18996) = true)

theorem identity18996 : scanCanonicalize (H12AffineFastState.compose env18996 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 41001) := by decide +kernel

theorem selectedBound18996 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env18997 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,32768,38094,1344,41001,1025,32769,4096,8201,5457,5579,8328,5377,33060,4177,1297,13388,1284,8321,257,5609,1345,512]

theorem envBound18997 : H12AffineFastState.Bounded env18997 := by
  intro p hp
  have h : env18997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18996_18997 : H12AffineEnvironment.transform 17 41001 env18996 = env18997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41001 env18996 == env18997) = true)

theorem identity18997 : scanCanonicalize (H12AffineFastState.compose env18997 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound18997 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env18998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,469,4177,32768,38094,1344,33276,1025,32769,4096,476,5457,5579,349,5377,33060,4177,1297,5529,1284,340,257,5609,1345,512]

theorem envBound18998 : H12AffineFastState.Bounded env18998 := by
  intro p hp
  have h : env18998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18997_18998 : H12AffineEnvironment.transform 12 469 env18997 = env18998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env18997 == env18998) = true)

theorem identity18998 : scanCanonicalize (H12AffineFastState.compose env18998 (packedSelected [1,2,3,4,5,6,8,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 1020) := by decide +kernel

theorem selectedBound18998 : packedSelected [1,2,3,4,5,6,8,9,12] rootPS < 2^1333 := by decide +kernel

def env18999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1020,469,941,32768,34610,1344,33276,1025,32769,1020,476,1709,1591,349,1789,33060,941,1297,1637,1284,340,257,1557,1345,512]

theorem envBound18999 : H12AffineFastState.Bounded env18999 := by
  intro p hp
  have h : env18999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18998_18999 : H12AffineEnvironment.transform 11 1020 env18998 = env18999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1020 env18998 == env18999) = true)

theorem identity18999 : scanCanonicalize (H12AffineFastState.compose env18999 (packedSelected [1,2,4,5,6,9,17] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound18999 : packedSelected [1,2,4,5,6,9,17] rootPS < 2^1333 := by decide +kernel

def env19000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1020,469,941,137,1979,1344,373,1025,136,1020,476,1709,1591,349,1789,429,941,1297,1637,1284,340,257,1557,1345,512]

theorem envBound19000 : H12AffineFastState.Bounded env19000 := by
  intro p hp
  have h : env19000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18999_19000 : H12AffineEnvironment.transform 14 137 env18999 = env19000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env18999 == env19000) = true)

theorem identity19000 : scanCanonicalize (H12AffineFastState.compose env19000 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 581) := by decide +kernel

theorem selectedBound19000 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env19001 : List Nat := [2,4,8,16,32,64,128,256,512,581,1,1020,469,941,137,510,773,373,580,136,1020,476,232,114,349,184,429,941,852,32,833,340,257,80,772,512]

theorem envBound19001 : H12AffineFastState.Bounded env19001 := by
  intro p hp
  have h : env19001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19000_19001 : H12AffineEnvironment.transform 9 581 env19000 = env19001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 581 env19000 == env19001) = true)

def env19002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,8201,17665,98564,8328,541008,795917,16384,545088,1073741824,1285,4294967296,257,4295074215,1345,512]

theorem envBound19002 : H12AffineFastState.Bounded env19002 := by
  intro p hp
  have h : env19002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18990_19002 : H12AffineEnvironment.transform 16 1345 env18990 = env19002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env18990 == env19002) = true)

theorem identity19002 : scanCanonicalize (H12AffineFastState.compose env19002 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 25676) := by decide +kernel

theorem selectedBound19002 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env19003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,8201,17665,98564,8328,541008,795917,16384,545088,25676,1285,4294967296,257,4295074215,1345,512]

theorem envBound19003 : H12AffineFastState.Bounded env19003 := by
  intro p hp
  have h : env19003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19002_19003 : H12AffineEnvironment.transform 29 25676 env19002 = env19003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 25676 env19002 == env19003) = true)

def env19004 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,304168,32769,4096,8201,17665,98564,8328,320888,33061,16384,324968,25676,1285,4294967296,257,4295074215,1345,512]

theorem envBound19004 : H12AffineFastState.Bounded env19004 := by
  intro p hp
  have h : env19004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19003_19004 : H12AffineEnvironment.transform 18 304168 env19003 = env19004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304168 env19003 == env19004) = true)

theorem identity19004 : scanCanonicalize (H12AffineFastState.compose env19004 (packedSelected [4,9,18] rootPS)) = affineNative (2^(13+1) ^^^ 9293) := by decide +kernel

theorem selectedBound19004 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env19005 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,9293,32768,65536,1345,262144,304168,32769,4096,8201,8524,98564,8328,295221,33061,9293,299301,1,1285,4294967296,257,4295074215,1345,512]

theorem envBound19005 : H12AffineFastState.Bounded env19005 := by
  intro p hp
  have h : env19005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19004_19005 : H12AffineEnvironment.transform 13 9293 env19004 = env19005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9293 env19004 == env19005) = true)

theorem identity19005 : scanCanonicalize (H12AffineFastState.compose env19005 (packedSelected [20,23] rootPS)) = affineNative (2^(17+1) ^^^ 1) := by decide +kernel

theorem selectedBound19005 : packedSelected [20,23] rootPS < 2^1333 := by decide +kernel

def env19006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,9293,32768,65536,1345,1,42025,32769,4096,8201,8524,98564,8328,33076,33061,9293,37156,1,1285,4294967296,257,4295074215,1345,512]

theorem envBound19006 : H12AffineFastState.Bounded env19006 := by
  intro p hp
  have h : env19006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19005_19006 : H12AffineEnvironment.transform 17 1 env19005 = env19006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env19005 == env19006) = true)

def env19007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,304169,32769,4096,8201,17665,98564,8328,320889,33060,16384,324969,25676,1285,4294967296,257,4295074215,1345,512]

theorem envBound19007 : H12AffineFastState.Bounded env19007 := by
  intro p hp
  have h : env19007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19003_19007 : H12AffineEnvironment.transform 18 304169 env19003 = env19007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304169 env19003 == env19007) = true)

theorem identity19007 : scanCanonicalize (H12AffineFastState.compose env19007 (packedSelected [3,13,15,17,19,21,28] rootPS)) = affineNative (2^(17+1) ^^^ 58729) := by decide +kernel

theorem selectedBound19007 : packedSelected [3,13,15,17,19,21,28] rootPS < 2^1333 := by decide +kernel

def env19008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,58729,16704,32769,4096,8201,17665,98564,8328,16,33060,16384,4096,25676,1285,4294967296,257,4295074215,1345,512]

theorem envBound19008 : H12AffineFastState.Bounded env19008 := by
  intro p hp
  have h : env19008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19007_19008 : H12AffineEnvironment.transform 17 58729 env19007 = env19008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 58729 env19007 == env19008) = true)

def env19009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,25960,65536,1345,1,16704,25961,4096,8201,17665,91244,8328,16,25676,16384,4096,25676,1285,4294967296,257,4295050447,1345,512]

theorem envBound19009 : H12AffineFastState.Bounded env19009 := by
  intro p hp
  have h : env19009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19008_19009 : H12AffineEnvironment.transform 14 25960 env19008 = env19009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25960 env19008 == env19009) = true)

theorem identity19009 : scanCanonicalize (H12AffineFastState.compose env19009 (packedSelected [4,9] rootPS)) = affineNative (2^(13+1) ^^^ 1345) := by decide +kernel

theorem selectedBound19009 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env19010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1345,8233,65536,1345,1,1025,8232,4096,8201,64,74029,8328,16,8461,1345,4096,8461,1285,4294967296,257,4295033230,1345,512]

theorem envBound19010 : H12AffineFastState.Bounded env19010 := by
  intro p hp
  have h : env19010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19009_19010 : H12AffineEnvironment.transform 13 1345 env19009 = env19010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env19009 == env19010) = true)

theorem identity19010 : scanCanonicalize (H12AffineFastState.compose env19010 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound19010 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env19011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,269,1345,292,65536,1345,1,1025,293,4096,260,64,65568,389,16,0,1345,4096,0,1285,4294967296,257,4295033230,1345,512]

theorem envBound19011 : H12AffineFastState.Bounded env19011 := by
  intro p hp
  have h : env19011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19010_19011 : H12AffineEnvironment.transform 12 269 env19010 = env19011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env19010 == env19011) = true)

def env19012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1344,269,1345,292,65536,1345,1,1025,293,1344,260,64,65568,389,16,0,1345,1344,0,1285,4294967296,257,4295033230,1345,512]

theorem envBound19012 : H12AffineFastState.Bounded env19012 := by
  intro p hp
  have h : env19012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19011_19012 : H12AffineEnvironment.transform 11 1344 env19011 = env19012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env19011 == env19012) = true)

theorem identity19012 : scanCanonicalize (H12AffineFastState.compose env19012 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(15+1) ^^^ 251) := by decide +kernel

theorem selectedBound19012 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env19013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1344,269,1345,292,251,1345,1,1025,293,1344,260,64,219,389,16,0,1345,1344,0,1285,4294967296,257,4294967669,1345,512]

theorem envBound19013 : H12AffineFastState.Bounded env19013 := by
  intro p hp
  have h : env19013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19012_19013 : H12AffineEnvironment.transform 15 251 env19012 = env19013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 251 env19012 == env19013) = true)

theorem identity19013 : scanCanonicalize (H12AffineFastState.compose env19013 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19013 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19014 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,1296,269,1297,292,171,1297,1,1025,293,1296,260,16,139,389,16,0,1297,1296,0,1285,4294967296,257,4294967589,1297,512]

theorem envBound19014 : H12AffineFastState.Bounded env19014 := by
  intro p hp
  have h : env19014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19013_19014 : H12AffineEnvironment.transform 5 16 env19013 = env19014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19013 == env19014) = true)

theorem identity19014 : scanCanonicalize (H12AffineFastState.compose env19014 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19014 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19015 : List Nat := [2,4,8,16,32,16,128,36,512,1024,1,1076,41,1077,0,171,1077,1,1025,1,1076,32,16,139,161,16,0,1077,1076,0,1057,4294967296,37,4294967297,1077,512]

theorem envBound19015 : H12AffineFastState.Bounded env19015 := by
  intro p hp
  have h : env19015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19014_19015 : H12AffineEnvironment.transform 7 36 env19014 = env19015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19014 == env19015) = true)

theorem identity19015 : scanCanonicalize (H12AffineFastState.compose env19015 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound19015 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19016 : List Nat := [2,4,8,16,32,16,128,36,33,1024,1,1076,41,1077,0,171,1077,1,1025,1,1076,32,16,139,161,16,0,1077,1076,0,1057,4294967296,37,4294967297,1077,33]

theorem envBound19016 : H12AffineFastState.Bounded env19016 := by
  intro p hp
  have h : env19016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19015_19016 : H12AffineEnvironment.transform 8 33 env19015 = env19016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env19015 == env19016) = true)

theorem identity19016 : scanCanonicalize (H12AffineFastState.compose env19016 (packedSelected [0,4] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound19016 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19017 : List Nat := [2,4,8,16,32,16,128,36,33,1024,1,1076,41,1077,0,171,1077,1,1025,1,1076,32,16,139,161,16,0,1077,1076,0,1057,0,37,1,1077,33]

theorem envBound19017 : H12AffineFastState.Bounded env19017 := by
  intro p hp
  have h : env19017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19016_19017 : H12AffineEnvironment.transform 31 0 env19016 = env19017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env19016 == env19017) = true)

def env19018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1345,269,1345,292,65536,1345,1,1025,293,1345,260,64,65568,389,16,0,1345,1345,0,1285,4294967296,257,4295033230,1345,512]

theorem envBound19018 : H12AffineFastState.Bounded env19018 := by
  intro p hp
  have h : env19018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19011_19018 : H12AffineEnvironment.transform 11 1345 env19011 = env19018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env19011 == env19018) = true)

theorem identity19018 : scanCanonicalize (H12AffineFastState.compose env19018 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19018 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env19019 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1,1296,269,1296,292,65536,1296,1,1025,293,1296,260,17,65568,389,16,0,1296,1296,0,1285,4294967296,257,4295033230,1296,512]

theorem envBound19019 : H12AffineFastState.Bounded env19019 := by
  intro p hp
  have h : env19019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19018_19019 : H12AffineEnvironment.transform 5 17 env19018 = env19019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19018 == env19019) = true)

theorem identity19019 : scanCanonicalize (H12AffineFastState.compose env19019 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound19019 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19020 : List Nat := [2,4,8,16,32,17,128,256,137,1024,1,1296,269,1296,292,65536,1296,1,1025,293,1296,260,17,65568,389,16,0,1296,1296,0,1285,4294967296,257,4295033230,1296,137]

theorem envBound19020 : H12AffineFastState.Bounded env19020 := by
  intro p hp
  have h : env19020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19019_19020 : H12AffineEnvironment.transform 8 137 env19019 = env19020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env19019 == env19020) = true)

theorem identity19020 : scanCanonicalize (H12AffineFastState.compose env19020 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound19020 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env19021 : List Nat := [2,4,8,16,32,17,128,256,137,1024,1,1296,269,1296,292,171,1296,1,1025,293,1296,260,17,139,389,16,0,1296,1296,0,1285,4294967296,257,4294967589,1296,137]

theorem envBound19021 : H12AffineFastState.Bounded env19021 := by
  intro p hp
  have h : env19021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19020_19021 : H12AffineEnvironment.transform 15 171 env19020 = env19021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env19020 == env19021) = true)

theorem identity19021 : scanCanonicalize (H12AffineFastState.compose env19021 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19021 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env19022 : List Nat := [2,4,8,16,32,17,9,256,0,1024,1,1296,269,1296,292,34,1296,1,1025,293,1296,260,17,2,268,16,0,1296,1296,0,1285,4294967296,257,4294967589,1296,0]

theorem envBound19022 : H12AffineFastState.Bounded env19022 := by
  intro p hp
  have h : env19022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19021_19022 : H12AffineEnvironment.transform 6 9 env19021 = env19022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19021 == env19022) = true)

theorem identity19022 : scanCanonicalize (H12AffineFastState.compose env19022 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 293) := by decide +kernel

theorem selectedBound19022 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19023 : List Nat := [2,4,8,16,32,17,9,256,0,1024,1,1296,269,1296,292,34,1296,1,1025,293,1296,260,17,2,268,16,0,1296,1296,0,1285,293,257,0,1296,0]

theorem envBound19023 : H12AffineFastState.Bounded env19023 := by
  intro p hp
  have h : env19023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19022_19023 : H12AffineEnvironment.transform 31 293 env19022 = env19023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 293 env19022 == env19023) = true)

def env19024 : List Nat := [2,4,8,16,0,17,9,256,0,1024,1,1296,269,1296,260,2,1296,1,1025,261,1296,260,17,2,268,16,0,1296,1296,0,1285,261,257,0,1296,0]

theorem envBound19024 : H12AffineFastState.Bounded env19024 := by
  intro p hp
  have h : env19024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19023_19024 : H12AffineEnvironment.transform 4 0 env19023 = env19024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19023 == env19024) = true)

theorem identity19024 : scanCanonicalize (H12AffineFastState.compose env19024 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound19024 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19025 : List Nat := [2,4,8,16,0,17,9,4,0,1024,1,1044,9,1044,0,2,1044,1,1025,1,1044,0,17,2,8,16,0,1044,1044,0,1025,1,5,0,1044,0]

theorem envBound19025 : H12AffineFastState.Bounded env19025 := by
  intro p hp
  have h : env19025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19024_19025 : H12AffineEnvironment.transform 7 4 env19024 = env19025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env19024 == env19025) = true)

def leafEnv19025 : List Nat := [2,4,8,16,0,17,9,4,0,1024,1,1044,9,1044,0,2,1044,1,1025,1,1044,0,17,2,1024,8,1,16,0,1044,1044,0,1025,1,5,0,5,2,1044,0,0,1044,1]

def active19025 : List Nat := [0,1,2,3,9]

def tree19025 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19025 : H12WitnessSearch.Good tree19025 := H12GlobalWitnessIndex.good

theorem leafIdentity19025 : H12AffineFastState.composeSystem env19025 rootObs = leafEnv19025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19025 rootObs == leafEnv19025) = true)

theorem terminalChecked19025 : H12PackedTerminal.terminalCheckFast leafEnv19025 active19025 tree19025 = true := by decide +kernel

def env19026 : List Nat := [2,4,8,16,1,17,9,256,0,1024,1,1296,269,1296,261,3,1296,1,1025,260,1296,260,17,2,268,16,0,1296,1296,0,1285,260,257,0,1296,0]

theorem envBound19026 : H12AffineFastState.Bounded env19026 := by
  intro p hp
  have h : env19026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19023_19026 : H12AffineEnvironment.transform 4 1 env19023 = env19026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19023 == env19026) = true)

def env19027 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,25961,65536,1345,0,16704,25960,4096,8201,17665,91245,8328,16,25677,16384,4096,25676,1285,4294967296,257,4295050446,1345,512]

theorem envBound19027 : H12AffineFastState.Bounded env19027 := by
  intro p hp
  have h : env19027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19008_19027 : H12AffineEnvironment.transform 14 25961 env19008 = env19027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25961 env19008 == env19027) = true)

theorem identity19027 : scanCanonicalize (H12AffineFastState.compose env19027 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound19027 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env19028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,268,16384,17509,65536,1345,0,16704,17508,4096,261,17665,83297,388,16,17729,16384,4096,17728,1285,4294967296,257,4295050446,1345,512]

theorem envBound19028 : H12AffineFastState.Bounded env19028 := by
  intro p hp
  have h : env19028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19027_19028 : H12AffineEnvironment.transform 12 268 env19027 = env19028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env19027 == env19028) = true)

theorem identity19028 : scanCanonicalize (H12AffineFastState.compose env19028 (packedSelected [0,1,3,7,10,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 1345) := by decide +kernel

theorem selectedBound19028 : packedSelected [0,1,3,7,10,12,13] rootPS < 2^1333 := by decide +kernel

def env19029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,268,1345,292,65536,1345,0,1025,293,4096,261,64,65568,388,16,0,1345,4096,1,1285,4294967296,257,4295033231,1345,512]

theorem envBound19029 : H12AffineFastState.Bounded env19029 := by
  intro p hp
  have h : env19029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19028_19029 : H12AffineEnvironment.transform 13 1345 env19028 = env19029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env19028 == env19029) = true)

def env19030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1344,268,1345,292,65536,1345,0,1025,293,1344,261,64,65568,388,16,0,1345,1344,1,1285,4294967296,257,4295033231,1345,512]

theorem envBound19030 : H12AffineFastState.Bounded env19030 := by
  intro p hp
  have h : env19030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19029_19030 : H12AffineEnvironment.transform 11 1344 env19029 = env19030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env19029 == env19030) = true)

theorem identity19030 : scanCanonicalize (H12AffineFastState.compose env19030 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(15+1) ^^^ 251) := by decide +kernel

theorem selectedBound19030 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env19031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1344,268,1345,292,251,1345,0,1025,293,1344,261,64,219,388,16,0,1345,1344,1,1285,4294967296,257,4294967668,1345,512]

theorem envBound19031 : H12AffineFastState.Bounded env19031 := by
  intro p hp
  have h : env19031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19030_19031 : H12AffineEnvironment.transform 15 251 env19030 = env19031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 251 env19030 == env19031) = true)

theorem identity19031 : scanCanonicalize (H12AffineFastState.compose env19031 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19031 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19032 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,1296,268,1297,292,171,1297,0,1025,293,1296,261,16,139,388,16,0,1297,1296,1,1285,4294967296,257,4294967588,1297,512]

theorem envBound19032 : H12AffineFastState.Bounded env19032 := by
  intro p hp
  have h : env19032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19031_19032 : H12AffineEnvironment.transform 5 16 env19031 = env19032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19031 == env19032) = true)

theorem identity19032 : scanCanonicalize (H12AffineFastState.compose env19032 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19032 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19033 : List Nat := [2,4,8,16,32,16,128,36,512,1024,1,1076,40,1077,0,171,1077,0,1025,1,1076,33,16,139,160,16,0,1077,1076,1,1057,4294967296,37,4294967296,1077,512]

theorem envBound19033 : H12AffineFastState.Bounded env19033 := by
  intro p hp
  have h : env19033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19032_19033 : H12AffineEnvironment.transform 7 36 env19032 = env19033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19032 == env19033) = true)

theorem identity19033 : scanCanonicalize (H12AffineFastState.compose env19033 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 513) := by decide +kernel

theorem selectedBound19033 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19034 : List Nat := [2,4,8,16,32,16,128,36,512,1024,1,1076,40,1077,0,171,1077,0,1025,1,1076,33,16,139,160,16,0,1077,1076,1,1057,513,37,513,1077,512]

theorem envBound19034 : H12AffineFastState.Bounded env19034 := by
  intro p hp
  have h : env19034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19033_19034 : H12AffineEnvironment.transform 31 513 env19033 = env19034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 513 env19033 == env19034) = true)

theorem identity19034 : scanCanonicalize (H12AffineFastState.compose env19034 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound19034 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19035 : List Nat := [2,4,8,16,32,16,128,36,136,1024,1,1076,40,1077,0,171,1077,0,1025,1,1076,33,16,139,160,16,0,1077,1076,1,1057,137,37,137,1077,136]

theorem envBound19035 : H12AffineFastState.Bounded env19035 := by
  intro p hp
  have h : env19035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19034_19035 : H12AffineEnvironment.transform 8 136 env19034 = env19035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env19034 == env19035) = true)

def leafEnv19035 : List Nat := [2,4,8,16,32,16,128,36,136,1024,1,1076,40,1077,0,171,1077,0,1025,1,1076,33,16,139,1056,160,1,16,0,1077,1076,1,1057,137,37,137,5,34,1077,136,0,1076,1]

def active19035 : List Nat := [0,1,2,3,4,6,9]

def tree19035 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19035 : H12WitnessSearch.Good tree19035 := H12GlobalWitnessIndex.good

theorem leafIdentity19035 : H12AffineFastState.composeSystem env19035 rootObs = leafEnv19035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19035 rootObs == leafEnv19035) = true)

theorem terminalChecked19035 : H12PackedTerminal.terminalCheckFast leafEnv19035 active19035 tree19035 = true := by decide +kernel

def env19036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1345,268,1345,292,65536,1345,0,1025,293,1345,261,64,65568,388,16,0,1345,1345,1,1285,4294967296,257,4295033231,1345,512]

theorem envBound19036 : H12AffineFastState.Bounded env19036 := by
  intro p hp
  have h : env19036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19029_19036 : H12AffineEnvironment.transform 11 1345 env19029 = env19036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env19029 == env19036) = true)

theorem identity19036 : scanCanonicalize (H12AffineFastState.compose env19036 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19036 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env19037 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1,1296,268,1296,292,65536,1296,0,1025,293,1296,261,17,65568,388,16,0,1296,1296,1,1285,4294967296,257,4295033231,1296,512]

theorem envBound19037 : H12AffineFastState.Bounded env19037 := by
  intro p hp
  have h : env19037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19036_19037 : H12AffineEnvironment.transform 5 17 env19036 = env19037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19036 == env19037) = true)

theorem identity19037 : scanCanonicalize (H12AffineFastState.compose env19037 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound19037 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19038 : List Nat := [2,4,8,16,32,17,128,256,136,1024,1,1296,268,1296,292,65536,1296,0,1025,293,1296,261,17,65568,388,16,0,1296,1296,1,1285,4294967296,257,4295033231,1296,136]

theorem envBound19038 : H12AffineFastState.Bounded env19038 := by
  intro p hp
  have h : env19038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19037_19038 : H12AffineEnvironment.transform 8 136 env19037 = env19038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env19037 == env19038) = true)

def env19039 : List Nat := [2,4,8,16,32,17,128,36,136,1024,1,1076,40,1076,0,65536,1076,0,1025,1,1076,33,17,65568,160,16,0,1076,1076,1,1057,4294967296,37,4295033003,1076,136]

theorem envBound19039 : H12AffineFastState.Bounded env19039 := by
  intro p hp
  have h : env19039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19038_19039 : H12AffineEnvironment.transform 7 36 env19038 = env19039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19038 == env19039) = true)

theorem identity19039 : scanCanonicalize (H12AffineFastState.compose env19039 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 136) := by decide +kernel

theorem selectedBound19039 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19040 : List Nat := [2,4,8,16,32,17,128,36,136,1024,1,1076,40,1076,0,65536,1076,0,1025,1,1076,33,17,65568,160,16,0,1076,1076,1,1057,136,37,65571,1076,136]

theorem envBound19040 : H12AffineFastState.Bounded env19040 := by
  intro p hp
  have h : env19040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19039_19040 : H12AffineEnvironment.transform 31 136 env19039 = env19040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 136 env19039 == env19040) = true)

def env19041 : List Nat := [2,4,8,16,32,17,128,36,136,52,1,0,40,0,0,65536,0,0,53,1,0,33,17,65568,160,16,0,0,0,1,21,136,37,65571,0,136]

theorem envBound19041 : H12AffineFastState.Bounded env19041 := by
  intro p hp
  have h : env19041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19040_19041 : H12AffineEnvironment.transform 9 52 env19040 = env19041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env19040 == env19041) = true)

theorem identity19041 : scanCanonicalize (H12AffineFastState.compose env19041 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound19041 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19042 : List Nat := [2,4,8,16,32,17,128,36,136,52,1,0,40,0,0,171,0,0,53,1,0,33,17,139,160,16,0,0,0,1,21,136,37,136,0,136]

theorem envBound19042 : H12AffineFastState.Bounded env19042 := by
  intro p hp
  have h : env19042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19041_19042 : H12AffineEnvironment.transform 15 171 env19041 = env19042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env19041 == env19042) = true)

def leafEnv19042 : List Nat := [2,4,8,16,32,17,128,36,136,52,1,0,40,0,0,171,0,0,53,1,0,33,17,139,20,160,1,16,0,0,0,1,21,136,37,136,5,34,0,136,0,0,1]

def active19042 : List Nat := [0,1,2,3,4,6]

def tree19042 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19042 : H12WitnessSearch.Good tree19042 := H12GlobalWitnessIndex.good

theorem leafIdentity19042 : H12AffineFastState.composeSystem env19042 rootObs = leafEnv19042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19042 rootObs == leafEnv19042) = true)

theorem terminalChecked19042 : H12PackedTerminal.terminalCheckFast leafEnv19042 active19042 tree19042 = true := by decide +kernel

def env19043 : List Nat := [2,4,8,16,32,17,128,36,136,53,1,1,40,1,0,65536,1,0,52,1,1,33,17,65568,160,16,0,1,1,1,20,136,37,65571,1,136]

theorem envBound19043 : H12AffineFastState.Bounded env19043 := by
  intro p hp
  have h : env19043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19040_19043 : H12AffineEnvironment.transform 9 53 env19040 = env19043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env19040 == env19043) = true)

def env19044 : List Nat := [2,4,8,16,0,17,128,4,136,21,1,1,8,1,0,65536,1,0,20,1,1,1,17,65536,128,16,0,1,1,1,20,136,5,65539,1,136]

theorem envBound19044 : H12AffineFastState.Bounded env19044 := by
  intro p hp
  have h : env19044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19043_19044 : H12AffineEnvironment.transform 4 0 env19043 = env19044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19043 == env19044) = true)

theorem identity19044 : scanCanonicalize (H12AffineFastState.compose env19044 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound19044 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19045 : List Nat := [2,4,8,16,0,17,128,4,136,21,1,1,8,1,0,139,1,0,20,1,1,1,17,139,128,16,0,1,1,1,20,136,5,136,1,136]

theorem envBound19045 : H12AffineFastState.Bounded env19045 := by
  intro p hp
  have h : env19045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19044_19045 : H12AffineEnvironment.transform 15 139 env19044 = env19045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env19044 == env19045) = true)

def leafEnv19045 : List Nat := [2,4,8,16,0,17,128,4,136,21,1,1,8,1,0,139,1,0,20,1,1,1,17,139,21,128,1,16,0,1,1,1,20,136,5,136,5,2,1,136,0,1,1]

def active19045 : List Nat := [0,1,2,3,6]

def tree19045 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19045 : H12WitnessSearch.Good tree19045 := H12GlobalWitnessIndex.good

theorem leafIdentity19045 : H12AffineFastState.composeSystem env19045 rootObs = leafEnv19045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19045 rootObs == leafEnv19045) = true)

theorem terminalChecked19045 : H12PackedTerminal.terminalCheckFast leafEnv19045 active19045 tree19045 = true := by decide +kernel

def env19046 : List Nat := [2,4,8,16,1,17,128,5,136,20,1,1,9,1,0,65536,1,0,21,1,1,0,17,65537,129,16,0,1,1,1,20,136,4,65538,1,136]

theorem envBound19046 : H12AffineFastState.Bounded env19046 := by
  intro p hp
  have h : env19046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19043_19046 : H12AffineEnvironment.transform 4 1 env19043 = env19046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19043 == env19046) = true)

def leafEnv19046 : List Nat := [2,4,8,16,1,17,128,5,136,20,1,1,9,1,0,65536,1,0,21,1,1,0,17,65537,21,129,1,16,0,1,1,1,20,136,4,65538,5,3,1,136,0,1,1]

def active19046 : List Nat := [0,1,2,3,6,15]

def tree19046 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19046 : H12WitnessSearch.Good tree19046 := H12GlobalWitnessIndex.good

theorem leafIdentity19046 : H12AffineFastState.composeSystem env19046 rootObs = leafEnv19046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19046 rootObs == leafEnv19046) = true)

theorem terminalChecked19046 : H12PackedTerminal.terminalCheckFast leafEnv19046 active19046 tree19046 = true := by decide +kernel

def env19047 : List Nat := [2,4,8,16,32,17,128,37,136,1024,1,1077,41,1077,1,65536,1077,0,1025,0,1077,32,17,65568,161,16,0,1077,1077,1,1056,4294967296,36,4295033002,1077,136]

theorem envBound19047 : H12AffineFastState.Bounded env19047 := by
  intro p hp
  have h : env19047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19038_19047 : H12AffineEnvironment.transform 7 37 env19038 = env19047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19038 == env19047) = true)

theorem identity19047 : scanCanonicalize (H12AffineFastState.compose env19047 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65706) := by decide +kernel

theorem selectedBound19047 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19048 : List Nat := [2,4,8,16,32,17,128,37,136,1024,1,1077,41,1077,1,65536,1077,0,1025,0,1077,32,17,65568,161,16,0,1077,1077,1,1056,65706,36,0,1077,136]

theorem envBound19048 : H12AffineFastState.Bounded env19048 := by
  intro p hp
  have h : env19048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19047_19048 : H12AffineEnvironment.transform 31 65706 env19047 = env19048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65706 env19047 == env19048) = true)

def env19049 : List Nat := [2,4,8,16,32,17,128,37,136,52,1,1,41,1,1,65536,1,0,53,0,1,32,17,65568,161,16,0,1,1,1,20,65706,36,0,1,136]

theorem envBound19049 : H12AffineFastState.Bounded env19049 := by
  intro p hp
  have h : env19049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19048_19049 : H12AffineEnvironment.transform 9 52 env19048 = env19049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env19048 == env19049) = true)

def env19050 : List Nat := [2,4,8,16,32,17,8,37,0,52,1,1,41,1,1,65536,1,0,53,0,1,32,17,65568,41,16,0,1,1,1,20,65570,36,0,1,0]

theorem envBound19050 : H12AffineFastState.Bounded env19050 := by
  intro p hp
  have h : env19050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19049_19050 : H12AffineEnvironment.transform 6 8 env19049 = env19050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19049 == env19050) = true)

theorem identity19050 : scanCanonicalize (H12AffineFastState.compose env19050 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19050 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19051 : List Nat := [2,4,8,16,0,17,8,5,0,20,1,1,9,1,1,65536,1,0,21,0,1,0,17,65536,9,16,0,1,1,1,20,65538,4,0,1,0]

theorem envBound19051 : H12AffineFastState.Bounded env19051 := by
  intro p hp
  have h : env19051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19050_19051 : H12AffineEnvironment.transform 4 0 env19050 = env19051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19050 == env19051) = true)

def leafEnv19051 : List Nat := [2,4,8,16,0,17,8,5,0,20,1,1,9,1,1,65536,1,0,21,0,1,0,17,65536,21,9,1,16,0,1,1,1,20,65538,4,0,5,2,1,0,0,1,1]

def active19051 : List Nat := [0,1,2,3,15]

def tree19051 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19051 : H12WitnessSearch.Good tree19051 := H12GlobalWitnessIndex.good

theorem leafIdentity19051 : H12AffineFastState.composeSystem env19051 rootObs = leafEnv19051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19051 rootObs == leafEnv19051) = true)

theorem terminalChecked19051 : H12PackedTerminal.terminalCheckFast leafEnv19051 active19051 tree19051 = true := by decide +kernel

def env19052 : List Nat := [2,4,8,16,32,17,9,37,1,52,1,1,41,1,1,65536,1,0,53,0,1,32,17,65568,40,16,0,1,1,1,20,65571,36,0,1,1]

theorem envBound19052 : H12AffineFastState.Bounded env19052 := by
  intro p hp
  have h : env19052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19049_19052 : H12AffineEnvironment.transform 6 9 env19049 = env19052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19049 == env19052) = true)

theorem identity19052 : scanCanonicalize (H12AffineFastState.compose env19052 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound19052 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19053 : List Nat := [2,4,8,16,32,17,9,37,1,52,1,1,41,1,1,3,1,0,53,0,1,32,17,35,40,16,0,1,1,1,20,32,36,0,1,1]

theorem envBound19053 : H12AffineFastState.Bounded env19053 := by
  intro p hp
  have h : env19053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19052_19053 : H12AffineEnvironment.transform 15 3 env19052 = env19053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env19052 == env19053) = true)

def leafEnv19053 : List Nat := [2,4,8,16,32,17,9,37,1,52,1,1,41,1,1,3,1,0,53,0,1,32,17,35,21,40,1,16,0,1,1,1,20,32,36,0,5,34,1,1,0,1,1]

def active19053 : List Nat := [0,1,2,3,4]

def tree19053 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19053 : H12WitnessSearch.Good tree19053 := H12GlobalWitnessIndex.good

theorem leafIdentity19053 : H12AffineFastState.composeSystem env19053 rootObs = leafEnv19053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19053 rootObs == leafEnv19053) = true)

theorem terminalChecked19053 : H12PackedTerminal.terminalCheckFast leafEnv19053 active19053 tree19053 = true := by decide +kernel

def env19054 : List Nat := [2,4,8,16,32,17,128,37,136,53,1,0,41,0,1,65536,0,0,52,0,0,32,17,65568,161,16,0,0,0,1,21,65706,36,0,0,136]

theorem envBound19054 : H12AffineFastState.Bounded env19054 := by
  intro p hp
  have h : env19054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19048_19054 : H12AffineEnvironment.transform 9 53 env19048 = env19054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env19048 == env19054) = true)

theorem identity19054 : scanCanonicalize (H12AffineFastState.compose env19054 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound19054 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19055 : List Nat := [2,4,8,16,32,17,128,37,136,53,1,0,41,0,1,171,0,0,52,0,0,32,17,139,161,16,0,0,0,1,21,1,36,0,0,136]

theorem envBound19055 : H12AffineFastState.Bounded env19055 := by
  intro p hp
  have h : env19055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19054_19055 : H12AffineEnvironment.transform 15 171 env19054 = env19055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env19054 == env19055) = true)

theorem identity19055 : scanCanonicalize (H12AffineFastState.compose env19055 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound19055 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19056 : List Nat := [2,4,8,16,32,17,40,37,32,53,1,0,41,0,1,3,0,0,52,0,0,32,17,35,9,16,0,0,0,1,21,1,36,0,0,32]

theorem envBound19056 : H12AffineFastState.Bounded env19056 := by
  intro p hp
  have h : env19056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19055_19056 : H12AffineEnvironment.transform 6 40 env19055 = env19056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env19055 == env19056) = true)

def leafEnv19056 : List Nat := [2,4,8,16,32,17,40,37,32,53,1,0,41,0,1,3,0,0,52,0,0,32,17,35,20,9,1,16,0,0,0,1,21,1,36,0,5,34,0,32,0,0,1]

def active19056 : List Nat := [0,1,2,3,4]

def tree19056 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19056 : H12WitnessSearch.Good tree19056 := H12GlobalWitnessIndex.good

theorem leafIdentity19056 : H12AffineFastState.composeSystem env19056 rootObs = leafEnv19056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19056 rootObs == leafEnv19056) = true)

theorem terminalChecked19056 : H12PackedTerminal.terminalCheckFast leafEnv19056 active19056 tree19056 = true := by decide +kernel

def env19057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,10249,147520,230469,8328,672785,927820,16384,676865,1073741824,131140,4294967296,257,4295208166,1345,512]

theorem envBound19057 : H12AffineFastState.Bounded env19057 := by
  intro p hp
  have h : env19057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18917_19057 : H12AffineEnvironment.transform 21 10249 env18917 = env19057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env18917 == env19057) = true)

def env19058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,8201,147520,230469,8328,672785,925772,16384,676865,1073741824,131140,4294967296,257,4295206118,1345,512]

theorem envBound19058 : H12AffineFastState.Bounded env19058 := by
  intro p hp
  have h : env19058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19057_19058 : H12AffineEnvironment.transform 10 0 env19057 = env19058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env19057 == env19058) = true)

def env19059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,8201,17664,98565,8328,541009,795916,16384,545089,1073741824,1284,4294967296,257,4295074214,1345,512]

theorem envBound19059 : H12AffineFastState.Bounded env19059 := by
  intro p hp
  have h : env19059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19058_19059 : H12AffineEnvironment.transform 16 1344 env19058 = env19059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env19058 == env19059) = true)

theorem identity19059 : scanCanonicalize (H12AffineFastState.compose env19059 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 58681) := by decide +kernel

theorem selectedBound19059 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env19060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,8201,17664,98565,8328,541009,795916,16384,545089,58681,1284,4294967296,257,4295074214,1345,512]

theorem envBound19060 : H12AffineFastState.Bounded env19060 := by
  intro p hp
  have h : env19060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19059_19060 : H12AffineEnvironment.transform 29 58681 env19059 = env19060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 58681 env19059 == env19060) = true)

theorem identity19060 : scanCanonicalize (H12AffineFastState.compose env19060 (packedSelected [4,9,16] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound19060 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env19061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,1025,32769,4096,8201,17664,98565,8328,17744,270605,16384,21824,58681,1284,4294967296,257,4295074214,1345,512]

theorem envBound19061 : H12AffineFastState.Bounded env19061 := by
  intro p hp
  have h : env19061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19060_19061 : H12AffineEnvironment.transform 18 1025 env19060 = env19061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env19060 == env19061) = true)

theorem identity19061 : scanCanonicalize (H12AffineFastState.compose env19061 (packedSelected [1,5,8,15,17,21,24,38] rootPS)) = affineNative (2^(15+1) ^^^ 17850) := by decide +kernel

theorem selectedBound19061 : packedSelected [1,5,8,15,17,21,24,38] rootPS < 2^1333 := by decide +kernel

def env19062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,17850,1344,262144,1025,32769,4096,8201,17664,50367,8328,17744,270605,16384,21824,58681,1284,4294967296,257,4295025692,1345,512]

theorem envBound19062 : H12AffineFastState.Bounded env19062 := by
  intro p hp
  have h : env19062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19061_19062 : H12AffineEnvironment.transform 15 17850 env19061 = env19062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 17850 env19061 == env19062) = true)

theorem identity19062 : scanCanonicalize (H12AffineFastState.compose env19062 (packedSelected [13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound19062 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env19063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,32768,5611,1344,262144,1025,32769,4096,8201,5457,38126,8328,5377,270605,4177,1297,46440,1284,4294967296,257,4295013453,1345,512]

theorem envBound19063 : H12AffineFastState.Bounded env19063 := by
  intro p hp
  have h : env19063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19062_19063 : H12AffineEnvironment.transform 13 4177 env19062 = env19063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env19062 == env19063) = true)

theorem identity19063 : scanCanonicalize (H12AffineFastState.compose env19063 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 8321) := by decide +kernel

theorem selectedBound19063 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,32768,5611,1344,262144,1025,32769,4096,8201,5457,38126,8328,5377,270605,4177,1297,46440,1284,8321,257,38092,1345,512]

theorem envBound19064 : H12AffineFastState.Bounded env19064 := by
  intro p hp
  have h : env19064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19063_19064 : H12AffineEnvironment.transform 31 8321 env19063 = env19064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8321 env19063 == env19064) = true)

theorem identity19064 : scanCanonicalize (H12AffineFastState.compose env19064 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 41000) := by decide +kernel

theorem selectedBound19064 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env19065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,32768,5611,1344,41000,1025,32769,4096,8201,5457,38126,8328,5377,33061,4177,1297,46440,1284,8321,257,38092,1345,512]

theorem envBound19065 : H12AffineFastState.Bounded env19065 := by
  intro p hp
  have h : env19065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19064_19065 : H12AffineEnvironment.transform 17 41000 env19064 = env19065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41000 env19064 == env19065) = true)

theorem identity19065 : scanCanonicalize (H12AffineFastState.compose env19065 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(14+1) ^^^ 8432) := by decide +kernel

theorem selectedBound19065 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env19066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,8432,5611,1344,216,1025,8433,4096,8201,5457,13342,8328,5377,8661,4177,1297,5528,1284,8321,257,13372,1345,512]

theorem envBound19066 : H12AffineFastState.Bounded env19066 := by
  intro p hp
  have h : env19066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19065_19066 : H12AffineEnvironment.transform 14 8432 env19065 = env19066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8432 env19065 == env19066) = true)

theorem identity19066 : scanCanonicalize (H12AffineFastState.compose env19066 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(12+1) ^^^ 632) := by decide +kernel

theorem selectedBound19066 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env19067 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,632,4177,648,5611,1344,216,1025,649,4096,625,5457,5734,752,5377,941,4177,1297,5528,1284,761,257,5700,1345,512]

theorem envBound19067 : H12AffineFastState.Bounded env19067 := by
  intro p hp
  have h : env19067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19066_19067 : H12AffineEnvironment.transform 12 632 env19066 = env19067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 632 env19066 == env19067) = true)

theorem identity19067 : scanCanonicalize (H12AffineFastState.compose env19067 (packedSelected [2,3,4,6,7,12] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound19067 : packedSelected [2,3,4,6,7,12] rootPS < 2^1333 := by decide +kernel

def env19068 : List Nat := [2,4,8,16,32,64,128,4,512,1024,0,4096,632,4177,648,5359,1092,216,1025,649,4096,625,5205,5734,752,5125,681,4177,1045,5276,1024,761,5,5700,1093,512]

theorem envBound19068 : H12AffineFastState.Bounded env19068 := by
  intro p hp
  have h : env19068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19067_19068 : H12AffineEnvironment.transform 7 4 env19067 = env19068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env19067 == env19068) = true)

theorem identity19068 : scanCanonicalize (H12AffineFastState.compose env19068 (packedSelected [2,4,6,7,8,17] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound19068 : packedSelected [2,4,6,7,8,17] rootPS < 2^1333 := by decide +kernel

def env19069 : List Nat := [2,4,8,16,32,64,128,4,1,1024,0,4096,121,4177,137,5359,1092,216,1025,136,4096,112,5205,5223,241,5125,168,4177,1045,5276,1024,248,5,5189,1093,1]

theorem envBound19069 : H12AffineFastState.Bounded env19069 := by
  intro p hp
  have h : env19069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19068_19069 : H12AffineEnvironment.transform 8 1 env19068 = env19069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env19068 == env19069) = true)

theorem identity19069 : scanCanonicalize (H12AffineFastState.compose env19069 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound19069 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env19070 : List Nat := [2,4,8,16,32,64,128,4,1,1024,0,0,121,81,137,1263,1092,216,1025,136,0,112,1109,1127,241,1029,168,81,1045,1180,1024,248,5,1093,1093,1]

theorem envBound19070 : H12AffineFastState.Bounded env19070 := by
  intro p hp
  have h : env19070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19069_19070 : H12AffineEnvironment.transform 11 0 env19069 = env19070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env19069 == env19070) = true)

theorem identity19070 : scanCanonicalize (H12AffineFastState.compose env19070 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound19070 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env19071 : List Nat := [2,4,8,16,32,64,128,4,1,189,0,0,121,81,137,82,249,216,188,136,0,112,232,218,241,184,168,81,168,33,189,248,5,248,248,1]

theorem envBound19071 : H12AffineFastState.Bounded env19071 := by
  intro p hp
  have h : env19071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19070_19071 : H12AffineEnvironment.transform 9 189 env19070 = env19071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env19070 == env19071) = true)

theorem identity19071 : scanCanonicalize (H12AffineFastState.compose env19071 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound19071 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env19072 : List Nat := [2,4,8,16,16,64,128,4,1,141,0,0,73,81,137,82,201,216,140,136,0,64,216,218,193,136,152,81,152,17,141,200,5,200,200,1]

theorem envBound19072 : H12AffineFastState.Bounded env19072 := by
  intro p hp
  have h : env19072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19071_19072 : H12AffineEnvironment.transform 4 16 env19071 = env19072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env19071 == env19072) = true)

theorem identity19072 : scanCanonicalize (H12AffineFastState.compose env19072 (packedSelected [0,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19072 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env19073 : List Nat := [2,4,8,16,16,16,128,4,1,141,0,0,25,1,137,2,153,136,140,136,0,16,136,138,145,136,152,1,152,17,141,152,5,152,152,1]

theorem envBound19073 : H12AffineFastState.Bounded env19073 := by
  intro p hp
  have h : env19073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19072_19073 : H12AffineEnvironment.transform 5 16 env19072 = env19073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19072 == env19073) = true)

theorem identity19073 : scanCanonicalize (H12AffineFastState.compose env19073 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound19073 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env19074 : List Nat := [2,4,8,1,1,1,128,4,1,141,0,0,8,1,137,2,136,136,140,136,0,1,136,138,128,136,137,1,137,0,141,137,5,137,137,1]

theorem envBound19074 : H12AffineFastState.Bounded env19074 := by
  intro p hp
  have h : env19074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19073_19074 : H12AffineEnvironment.transform 3 1 env19073 = env19074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env19073 == env19074) = true)

theorem identity19074 : scanCanonicalize (H12AffineFastState.compose env19074 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19074 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19075 : List Nat := [2,4,8,1,1,1,9,4,1,4,0,0,8,1,0,2,1,1,5,1,0,1,1,3,9,1,0,1,0,0,4,0,5,0,0,1]

theorem envBound19075 : H12AffineFastState.Bounded env19075 := by
  intro p hp
  have h : env19075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19074_19075 : H12AffineEnvironment.transform 6 9 env19074 = env19075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19074 == env19075) = true)

def env19076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,8201,17665,98564,8328,541008,795917,16384,545088,1073741824,1285,4294967296,257,4295074215,1345,512]

theorem envBound19076 : H12AffineFastState.Bounded env19076 := by
  intro p hp
  have h : env19076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19058_19076 : H12AffineEnvironment.transform 16 1345 env19058 = env19076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env19058 == env19076) = true)

theorem identity19076 : scanCanonicalize (H12AffineFastState.compose env19076 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 58729) := by decide +kernel

theorem selectedBound19076 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env19077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,8201,17665,98564,8328,541008,795917,16384,545088,58729,1285,4294967296,257,4295074215,1345,512]

theorem envBound19077 : H12AffineFastState.Bounded env19077 := by
  intro p hp
  have h : env19077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19076_19077 : H12AffineEnvironment.transform 29 58729 env19076 = env19077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 58729 env19076 == env19077) = true)

def env19078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,304168,32769,4096,8201,17665,98564,8328,320888,33061,16384,324968,58729,1285,4294967296,257,4295074215,1345,512]

theorem envBound19078 : H12AffineFastState.Bounded env19078 := by
  intro p hp
  have h : env19078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19077_19078 : H12AffineEnvironment.transform 18 304168 env19077 = env19078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304168 env19077 == env19078) = true)

theorem identity19078 : scanCanonicalize (H12AffineFastState.compose env19078 (packedSelected [4,9,18] rootPS)) = affineNative (2^(17+1) ^^^ 25676) := by decide +kernel

theorem selectedBound19078 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env19079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,25676,49252,32769,4096,8201,17665,98564,8328,33076,33061,16384,37156,58729,1285,4294967296,257,4295074215,1345,512]

theorem envBound19079 : H12AffineFastState.Bounded env19079 := by
  intro p hp
  have h : env19079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19078_19079 : H12AffineEnvironment.transform 17 25676 env19078 = env19079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 25676 env19078 == env19079) = true)

def env19080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,28792,65536,1345,25676,12316,28793,4096,8201,17665,94588,8328,29004,29021,16384,24924,5393,1285,4294967296,257,4295053791,1345,512]

theorem envBound19080 : H12AffineFastState.Bounded env19080 := by
  intro p hp
  have h : env19080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19079_19080 : H12AffineEnvironment.transform 14 28792 env19079 = env19080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28792 env19079 == env19080) = true)

theorem identity19080 : scanCanonicalize (H12AffineFastState.compose env19080 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 5149) := by decide +kernel

theorem selectedBound19080 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env19081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5149,16384,17509,65536,1345,20561,1025,17508,4096,5140,17665,83297,5269,17745,17728,16384,21825,5393,1285,4294967296,257,4295053791,1345,512]

theorem envBound19081 : H12AffineFastState.Bounded env19081 := by
  intro p hp
  have h : env19081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19080_19081 : H12AffineEnvironment.transform 12 5149 env19080 = env19081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5149 env19080 == env19081) = true)

def env19082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1344,349,16384,17509,65536,1345,17681,1025,17508,1344,340,17665,83297,469,17745,17728,16384,16385,81,1285,4294967296,257,4295050399,1345,512]

theorem envBound19082 : H12AffineFastState.Bounded env19082 := by
  intro p hp
  have h : env19082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19081_19082 : H12AffineEnvironment.transform 11 1344 env19081 = env19082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env19081 == env19082) = true)

theorem identity19082 : scanCanonicalize (H12AffineFastState.compose env19082 (packedSelected [12] rootPS)) = affineNative (2^(15+1) ^^^ 251) := by decide +kernel

theorem selectedBound19082 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env19083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1344,349,16384,17509,251,1345,17681,1025,17508,1344,340,17665,17818,469,17745,17728,16384,16385,81,1285,4294967296,257,4294984804,1345,512]

theorem envBound19083 : H12AffineFastState.Bounded env19083 := by
  intro p hp
  have h : env19083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19082_19083 : H12AffineEnvironment.transform 15 251 env19082 = env19083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 251 env19082 == env19083) = true)

theorem identity19083 : scanCanonicalize (H12AffineFastState.compose env19083 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound19083 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env19084 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1344,349,1297,372,251,1345,0,1025,373,1344,340,16,139,469,64,81,1297,1296,81,1285,4294967296,257,4294967669,1345,512]

theorem envBound19084 : H12AffineFastState.Bounded env19084 := by
  intro p hp
  have h : env19084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19083_19084 : H12AffineEnvironment.transform 13 1297 env19083 = env19084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env19083 == env19084) = true)

theorem identity19084 : scanCanonicalize (H12AffineFastState.compose env19084 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19084 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19085 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1297,268,1297,293,170,1296,0,1025,292,1297,261,16,139,388,17,0,1297,1296,0,1285,4294967296,257,4294967588,1296,512]

theorem envBound19085 : H12AffineFastState.Bounded env19085 := by
  intro p hp
  have h : env19085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19084_19085 : H12AffineEnvironment.transform 5 17 env19084 = env19085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19084 == env19085) = true)

theorem identity19085 : scanCanonicalize (H12AffineFastState.compose env19085 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound19085 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19086 : List Nat := [2,4,8,16,32,17,128,172,512,1024,0,1213,160,1213,137,170,1212,0,1025,136,1213,169,16,139,40,17,0,1213,1212,0,1193,4294967296,173,4294967432,1212,512]

theorem envBound19086 : H12AffineFastState.Bounded env19086 := by
  intro p hp
  have h : env19086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19085_19086 : H12AffineEnvironment.transform 7 172 env19085 = env19086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env19085 == env19086) = true)

theorem identity19086 : scanCanonicalize (H12AffineFastState.compose env19086 (packedSelected [0,2,4] rootPS)) = affineNative (2^(31+1) ^^^ 1) := by decide +kernel

theorem selectedBound19086 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env19087 : List Nat := [2,4,8,16,32,17,128,172,512,1024,0,1213,160,1213,137,170,1212,0,1025,136,1213,169,16,139,40,17,0,1213,1212,0,1193,1,173,137,1212,512]

theorem envBound19087 : H12AffineFastState.Bounded env19087 := by
  intro p hp
  have h : env19087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19086_19087 : H12AffineEnvironment.transform 31 1 env19086 = env19087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1 env19086 == env19087) = true)

def env19088 : List Nat := [2,4,8,16,32,17,128,172,0,1024,0,1213,160,1213,137,170,1212,0,1025,136,1213,169,16,139,40,17,0,1213,1212,0,1193,1,173,137,1212,0]

theorem envBound19088 : H12AffineFastState.Bounded env19088 := by
  intro p hp
  have h : env19088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19087_19088 : H12AffineEnvironment.transform 8 0 env19087 = env19088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env19087 == env19088) = true)

theorem identity19088 : scanCanonicalize (H12AffineFastState.compose env19088 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound19088 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19089 : List Nat := [2,4,8,16,32,17,8,36,0,1024,0,1077,40,1077,1,34,1076,0,1025,0,1077,33,16,3,40,17,0,1077,1076,0,1057,1,37,1,1076,0]

theorem envBound19089 : H12AffineFastState.Bounded env19089 := by
  intro p hp
  have h : env19089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19088_19089 : H12AffineEnvironment.transform 6 8 env19088 = env19089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19088 == env19089) = true)

def leafEnv19089 : List Nat := [2,4,8,16,32,17,8,36,0,1024,0,1077,40,1077,1,34,1076,0,1025,0,1077,33,16,3,1056,40,1,17,0,1077,1076,0,1057,1,37,1,5,35,1076,0,0,1076,1]

def active19089 : List Nat := [0,1,2,3,4,9]

def tree19089 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19089 : H12WitnessSearch.Good tree19089 := H12GlobalWitnessIndex.good

theorem leafIdentity19089 : H12AffineFastState.composeSystem env19089 rootObs = leafEnv19089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19089 rootObs == leafEnv19089) = true)

theorem terminalChecked19089 : H12PackedTerminal.terminalCheckFast leafEnv19089 active19089 tree19089 = true := by decide +kernel

def env19090 : List Nat := [2,4,8,16,32,17,128,172,1,1024,0,1213,160,1213,137,170,1212,0,1025,136,1213,169,16,139,40,17,0,1213,1212,0,1193,1,173,137,1212,1]

theorem envBound19090 : H12AffineFastState.Bounded env19090 := by
  intro p hp
  have h : env19090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19087_19090 : H12AffineEnvironment.transform 8 1 env19087 = env19090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env19087 == env19090) = true)

def env19091 : List Nat := [2,4,8,16,0,17,128,140,1,1024,0,1181,128,1181,137,138,1180,0,1025,136,1181,137,16,139,8,17,0,1181,1180,0,1161,1,141,137,1180,1]

theorem envBound19091 : H12AffineFastState.Bounded env19091 := by
  intro p hp
  have h : env19091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19090_19091 : H12AffineEnvironment.transform 4 0 env19090 = env19091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19090 == env19091) = true)

theorem identity19091 : scanCanonicalize (H12AffineFastState.compose env19091 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19091 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19092 : List Nat := [2,4,8,16,0,17,9,5,1,1024,0,1044,9,1044,0,3,1045,0,1025,1,1044,0,16,2,8,17,0,1044,1045,0,1024,1,4,0,1045,1]

theorem envBound19092 : H12AffineFastState.Bounded env19092 := by
  intro p hp
  have h : env19092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19091_19092 : H12AffineEnvironment.transform 6 9 env19091 = env19092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19091 == env19092) = true)

def leafEnv19092 : List Nat := [2,4,8,16,0,17,9,5,1,1024,0,1044,9,1044,0,3,1045,0,1025,1,1044,0,16,2,1025,8,1,17,0,1044,1045,0,1024,1,4,0,5,3,1045,1,0,1045,1]

def active19092 : List Nat := [0,1,2,3,9]

def tree19092 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19092 : H12WitnessSearch.Good tree19092 := H12GlobalWitnessIndex.good

theorem leafIdentity19092 : H12AffineFastState.composeSystem env19092 rootObs = leafEnv19092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19092 rootObs == leafEnv19092) = true)

theorem terminalChecked19092 : H12PackedTerminal.terminalCheckFast leafEnv19092 active19092 tree19092 = true := by decide +kernel

def env19093 : List Nat := [2,4,8,16,1,17,128,141,1,1024,0,1180,129,1180,137,139,1181,0,1025,136,1180,136,16,139,9,17,0,1180,1181,0,1160,1,140,137,1181,1]

theorem envBound19093 : H12AffineFastState.Bounded env19093 := by
  intro p hp
  have h : env19093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19090_19093 : H12AffineEnvironment.transform 4 1 env19090 = env19093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19090 == env19093) = true)

def env19094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1345,348,16384,17509,65536,1345,17680,1025,17508,1345,341,17665,83297,468,17745,17728,16384,16384,80,1285,4294967296,257,4295050398,1345,512]

theorem envBound19094 : H12AffineFastState.Bounded env19094 := by
  intro p hp
  have h : env19094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19081_19094 : H12AffineEnvironment.transform 11 1345 env19081 = env19094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env19081 == env19094) = true)

theorem identity19094 : scanCanonicalize (H12AffineFastState.compose env19094 (packedSelected [12] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound19094 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env19095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1345,348,1296,373,65536,1345,0,1025,372,1345,341,17,65649,468,65,80,1296,1296,80,1285,4294967296,257,4295033230,1345,512]

theorem envBound19095 : H12AffineFastState.Bounded env19095 := by
  intro p hp
  have h : env19095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19094_19095 : H12AffineEnvironment.transform 13 1296 env19094 = env19095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env19094 == env19095) = true)

theorem identity19095 : scanCanonicalize (H12AffineFastState.compose env19095 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound19095 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19096 : List Nat := [2,4,8,16,32,64,128,256,216,1024,0,1345,348,1296,373,65536,1345,0,1025,372,1345,341,17,65649,468,65,80,1296,1296,80,1285,4294967296,257,4295033230,1345,216]

theorem envBound19096 : H12AffineFastState.Bounded env19096 := by
  intro p hp
  have h : env19096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19095_19096 : H12AffineEnvironment.transform 8 216 env19095 = env19096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env19095 == env19096) = true)

theorem identity19096 : scanCanonicalize (H12AffineFastState.compose env19096 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(15+1) ^^^ 250) := by decide +kernel

theorem selectedBound19096 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env19097 : List Nat := [2,4,8,16,32,64,128,256,216,1024,0,1345,348,1296,373,250,1345,0,1025,372,1345,341,17,139,468,65,80,1296,1296,80,1285,4294967296,257,4294967668,1345,216]

theorem envBound19097 : H12AffineFastState.Bounded env19097 := by
  intro p hp
  have h : env19097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19096_19097 : H12AffineEnvironment.transform 15 250 env19096 = env19097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 250 env19096 == env19097) = true)

theorem identity19097 : scanCanonicalize (H12AffineFastState.compose env19097 (packedSelected [1,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19097 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env19098 : List Nat := [2,4,8,16,32,64,9,256,81,1024,0,1345,348,1296,373,115,1345,0,1025,372,1345,341,17,2,349,65,80,1296,1296,80,1285,4294967296,257,4294967668,1345,81]

theorem envBound19098 : H12AffineFastState.Bounded env19098 := by
  intro p hp
  have h : env19098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19097_19098 : H12AffineEnvironment.transform 6 9 env19097 = env19098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19097 == env19098) = true)

def env19099 : List Nat := [2,4,8,16,32,16,9,256,1,1024,0,1297,268,1296,293,35,1297,0,1025,292,1297,261,17,2,269,17,0,1296,1296,0,1285,4294967296,257,4294967588,1297,1]

theorem envBound19099 : H12AffineFastState.Bounded env19099 := by
  intro p hp
  have h : env19099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19098_19099 : H12AffineEnvironment.transform 5 16 env19098 = env19099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19098 == env19099) = true)

theorem identity19099 : scanCanonicalize (H12AffineFastState.compose env19099 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound19099 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19100 : List Nat := [2,4,8,16,32,16,9,256,1,1024,0,1297,268,1296,293,35,1297,0,1025,292,1297,261,17,2,269,17,0,1296,1296,0,1285,0,257,292,1297,1]

theorem envBound19100 : H12AffineFastState.Bounded env19100 := by
  intro p hp
  have h : env19100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19099_19100 : H12AffineEnvironment.transform 31 0 env19099 = env19100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env19099 == env19100) = true)

def env19101 : List Nat := [2,4,8,16,0,16,9,256,1,1024,0,1297,268,1296,261,3,1297,0,1025,260,1297,261,17,2,269,17,0,1296,1296,0,1285,0,257,260,1297,1]

theorem envBound19101 : H12AffineFastState.Bounded env19101 := by
  intro p hp
  have h : env19101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19100_19101 : H12AffineEnvironment.transform 4 0 env19100 = env19101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19100 == env19101) = true)

def leafEnv19101 : List Nat := [2,4,8,16,0,16,9,256,1,1024,0,1297,268,1296,261,3,1297,0,1025,260,1297,261,17,2,1284,269,1,17,0,1296,1296,0,1285,0,257,260,5,3,1297,1,0,1296,1]

def active19101 : List Nat := [0,1,2,3,7,9]

def tree19101 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19101 : H12WitnessSearch.Good tree19101 := H12GlobalWitnessIndex.good

theorem leafIdentity19101 : H12AffineFastState.composeSystem env19101 rootObs = leafEnv19101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19101 rootObs == leafEnv19101) = true)

theorem terminalChecked19101 : H12PackedTerminal.terminalCheckFast leafEnv19101 active19101 tree19101 = true := by decide +kernel

def env19102 : List Nat := [2,4,8,16,1,16,9,256,1,1024,0,1297,268,1296,260,2,1297,0,1025,261,1297,261,17,2,269,17,0,1296,1296,0,1285,0,257,261,1297,1]

theorem envBound19102 : H12AffineFastState.Bounded env19102 := by
  intro p hp
  have h : env19102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19100_19102 : H12AffineEnvironment.transform 4 1 env19100 = env19102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19100 == env19102) = true)

theorem identity19102 : scanCanonicalize (H12AffineFastState.compose env19102 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound19102 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19103 : List Nat := [2,4,8,16,1,16,9,5,1,1024,0,1044,9,1045,1,2,1044,0,1025,0,1044,0,17,2,8,17,0,1045,1045,0,1024,0,4,0,1044,1]

theorem envBound19103 : H12AffineFastState.Bounded env19103 := by
  intro p hp
  have h : env19103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19102_19103 : H12AffineEnvironment.transform 7 5 env19102 = env19103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env19102 == env19103) = true)

def leafEnv19103 : List Nat := [2,4,8,16,1,16,9,5,1,1024,0,1044,9,1045,1,2,1044,0,1025,0,1044,0,17,2,1025,8,1,17,0,1045,1045,0,1024,0,4,0,5,2,1044,1,0,1045,1]

def active19103 : List Nat := [0,1,2,3,9]

def tree19103 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19103 : H12WitnessSearch.Good tree19103 := H12GlobalWitnessIndex.good

theorem leafIdentity19103 : H12AffineFastState.composeSystem env19103 rootObs = leafEnv19103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19103 rootObs == leafEnv19103) = true)

theorem terminalChecked19103 : H12PackedTerminal.terminalCheckFast leafEnv19103 active19103 tree19103 = true := by decide +kernel

def env19104 : List Nat := [2,4,8,16,32,17,9,256,0,1024,0,1296,269,1296,292,34,1296,0,1025,293,1296,260,17,2,268,16,1,1296,1296,1,1285,4294967296,257,4294967589,1296,0]

theorem envBound19104 : H12AffineFastState.Bounded env19104 := by
  intro p hp
  have h : env19104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19098_19104 : H12AffineEnvironment.transform 5 17 env19098 = env19104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19098 == env19104) = true)

theorem identity19104 : scanCanonicalize (H12AffineFastState.compose env19104 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 293) := by decide +kernel

theorem selectedBound19104 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19105 : List Nat := [2,4,8,16,32,17,9,256,0,1024,0,1296,269,1296,292,34,1296,0,1025,293,1296,260,17,2,268,16,1,1296,1296,1,1285,293,257,0,1296,0]

theorem envBound19105 : H12AffineFastState.Bounded env19105 := by
  intro p hp
  have h : env19105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19104_19105 : H12AffineEnvironment.transform 31 293 env19104 = env19105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 293 env19104 == env19105) = true)

def env19106 : List Nat := [2,4,8,16,0,17,9,256,0,1024,0,1296,269,1296,260,2,1296,0,1025,261,1296,260,17,2,268,16,1,1296,1296,1,1285,261,257,0,1296,0]

theorem envBound19106 : H12AffineFastState.Bounded env19106 := by
  intro p hp
  have h : env19106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19105_19106 : H12AffineEnvironment.transform 4 0 env19105 = env19106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19105 == env19106) = true)

theorem identity19106 : scanCanonicalize (H12AffineFastState.compose env19106 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound19106 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19107 : List Nat := [2,4,8,16,0,17,9,4,0,1024,0,1044,9,1044,0,2,1044,0,1025,1,1044,0,17,2,8,16,1,1044,1044,1,1025,1,5,0,1044,0]

theorem envBound19107 : H12AffineFastState.Bounded env19107 := by
  intro p hp
  have h : env19107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19106_19107 : H12AffineEnvironment.transform 7 4 env19106 = env19107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env19106 == env19107) = true)

def leafEnv19107 : List Nat := [2,4,8,16,0,17,9,4,0,1024,0,1044,9,1044,0,2,1044,0,1025,1,1044,0,17,2,1024,8,1,16,1,1044,1044,1,1025,1,5,0,5,2,1044,0,0,1044,1]

def active19107 : List Nat := [0,1,2,3,9]

def tree19107 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19107 : H12WitnessSearch.Good tree19107 := H12GlobalWitnessIndex.good

theorem leafIdentity19107 : H12AffineFastState.composeSystem env19107 rootObs = leafEnv19107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19107 rootObs == leafEnv19107) = true)

theorem terminalChecked19107 : H12PackedTerminal.terminalCheckFast leafEnv19107 active19107 tree19107 = true := by decide +kernel

def env19108 : List Nat := [2,4,8,16,1,17,9,256,0,1024,0,1296,269,1296,261,3,1296,0,1025,260,1296,260,17,2,268,16,1,1296,1296,1,1285,260,257,0,1296,0]

theorem envBound19108 : H12AffineFastState.Bounded env19108 := by
  intro p hp
  have h : env19108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19105_19108 : H12AffineEnvironment.transform 4 1 env19105 = env19108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19105 == env19108) = true)

def env19109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,28793,65536,1345,25676,12317,28792,4096,8201,17665,94589,8328,29005,29020,16384,24925,5392,1285,4294967296,257,4295053790,1345,512]

theorem envBound19109 : H12AffineFastState.Bounded env19109 := by
  intro p hp
  have h : env19109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19079_19109 : H12AffineEnvironment.transform 14 28793 env19079 = env19109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28793 env19079 == env19109) = true)

theorem identity19109 : scanCanonicalize (H12AffineFastState.compose env19109 (packedSelected [4,9] rootPS)) = affineNative (2^(13+1) ^^^ 1345) := by decide +kernel

theorem selectedBound19109 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env19110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1345,13624,65536,1345,8461,12317,13625,4096,8201,64,78908,8328,13324,13341,1345,9244,5392,1285,4294967296,257,4295038111,1345,512]

theorem envBound19110 : H12AffineFastState.Bounded env19110 := by
  intro p hp
  have h : env19110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19109_19110 : H12AffineEnvironment.transform 13 1345 env19109 = env19110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env19109 == env19110) = true)

theorem identity19110 : scanCanonicalize (H12AffineFastState.compose env19110 (packedSelected [3,8,12,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 5148) := by decide +kernel

theorem selectedBound19110 : packedSelected [3,8,12,15,17] rootPS < 2^1333 := by decide +kernel

def env19111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5148,1345,292,65536,1345,5393,1025,293,4096,5141,64,65568,5268,16,1,1345,4096,5392,1285,4294967296,257,4295038111,1345,512]

theorem envBound19111 : H12AffineFastState.Bounded env19111 := by
  intro p hp
  have h : env19111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19110_19111 : H12AffineEnvironment.transform 12 5148 env19110 = env19111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5148 env19110 == env19111) = true)

def env19112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1344,348,1345,292,65536,1345,81,1025,293,1344,341,64,65568,468,16,1,1345,1344,80,1285,4294967296,257,4295033311,1345,512]

theorem envBound19112 : H12AffineFastState.Bounded env19112 := by
  intro p hp
  have h : env19112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19111_19112 : H12AffineEnvironment.transform 11 1344 env19111 = env19112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env19111 == env19112) = true)

theorem identity19112 : scanCanonicalize (H12AffineFastState.compose env19112 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(15+1) ^^^ 251) := by decide +kernel

theorem selectedBound19112 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env19113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1344,348,1345,292,251,1345,81,1025,293,1344,341,64,219,468,16,1,1345,1344,80,1285,4294967296,257,4294967588,1345,512]

theorem envBound19113 : H12AffineFastState.Bounded env19113 := by
  intro p hp
  have h : env19113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19112_19113 : H12AffineEnvironment.transform 15 251 env19112 = env19113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 251 env19112 == env19113) = true)

theorem identity19113 : scanCanonicalize (H12AffineFastState.compose env19113 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19113 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19114 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,1296,268,1297,292,171,1297,1,1025,293,1296,261,16,139,388,16,1,1297,1296,0,1285,4294967296,257,4294967588,1297,512]

theorem envBound19114 : H12AffineFastState.Bounded env19114 := by
  intro p hp
  have h : env19114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19113_19114 : H12AffineEnvironment.transform 5 16 env19113 = env19114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19113 == env19114) = true)

theorem identity19114 : scanCanonicalize (H12AffineFastState.compose env19114 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19114 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19115 : List Nat := [2,4,8,16,32,16,128,36,512,1024,0,1076,40,1077,0,171,1077,1,1025,1,1076,33,16,139,160,16,1,1077,1076,0,1057,4294967296,37,4294967296,1077,512]

theorem envBound19115 : H12AffineFastState.Bounded env19115 := by
  intro p hp
  have h : env19115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19114_19115 : H12AffineEnvironment.transform 7 36 env19114 = env19115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19114 == env19115) = true)

theorem identity19115 : scanCanonicalize (H12AffineFastState.compose env19115 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 513) := by decide +kernel

theorem selectedBound19115 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19116 : List Nat := [2,4,8,16,32,16,128,36,512,1024,0,1076,40,1077,0,171,1077,1,1025,1,1076,33,16,139,160,16,1,1077,1076,0,1057,513,37,513,1077,512]

theorem envBound19116 : H12AffineFastState.Bounded env19116 := by
  intro p hp
  have h : env19116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19115_19116 : H12AffineEnvironment.transform 31 513 env19115 = env19116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 513 env19115 == env19116) = true)

theorem identity19116 : scanCanonicalize (H12AffineFastState.compose env19116 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound19116 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19117 : List Nat := [2,4,8,16,32,16,128,36,136,1024,0,1076,40,1077,0,171,1077,1,1025,1,1076,33,16,139,160,16,1,1077,1076,0,1057,137,37,137,1077,136]

theorem envBound19117 : H12AffineFastState.Bounded env19117 := by
  intro p hp
  have h : env19117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19116_19117 : H12AffineEnvironment.transform 8 136 env19116 = env19117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env19116 == env19117) = true)

def env19118 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1345,349,1345,292,65536,1345,80,1025,293,1345,340,64,65568,469,16,1,1345,1345,81,1285,4294967296,257,4295033310,1345,512]

theorem envBound19118 : H12AffineFastState.Bounded env19118 := by
  intro p hp
  have h : env19118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19111_19118 : H12AffineEnvironment.transform 11 1345 env19111 = env19118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env19111 == env19118) = true)

theorem identity19118 : scanCanonicalize (H12AffineFastState.compose env19118 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19118 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env19119 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1296,268,1296,292,65536,1296,1,1025,293,1296,261,17,65568,388,16,1,1296,1296,0,1285,4294967296,257,4295033231,1296,512]

theorem envBound19119 : H12AffineFastState.Bounded env19119 := by
  intro p hp
  have h : env19119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19118_19119 : H12AffineEnvironment.transform 5 17 env19118 = env19119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19118 == env19119) = true)

theorem identity19119 : scanCanonicalize (H12AffineFastState.compose env19119 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound19119 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19120 : List Nat := [2,4,8,16,32,17,128,256,136,1024,0,1296,268,1296,292,65536,1296,1,1025,293,1296,261,17,65568,388,16,1,1296,1296,0,1285,4294967296,257,4295033231,1296,136]

theorem envBound19120 : H12AffineFastState.Bounded env19120 := by
  intro p hp
  have h : env19120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19119_19120 : H12AffineEnvironment.transform 8 136 env19119 = env19120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env19119 == env19120) = true)

def env19121 : List Nat := [2,4,8,16,32,17,128,36,136,1024,0,1076,40,1076,0,65536,1076,1,1025,1,1076,33,17,65568,160,16,1,1076,1076,0,1057,4294967296,37,4295033003,1076,136]

theorem envBound19121 : H12AffineFastState.Bounded env19121 := by
  intro p hp
  have h : env19121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19120_19121 : H12AffineEnvironment.transform 7 36 env19120 = env19121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19120 == env19121) = true)

theorem identity19121 : scanCanonicalize (H12AffineFastState.compose env19121 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 137) := by decide +kernel

theorem selectedBound19121 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19122 : List Nat := [2,4,8,16,32,17,128,36,136,1024,0,1076,40,1076,0,65536,1076,1,1025,1,1076,33,17,65568,160,16,1,1076,1076,0,1057,137,37,65570,1076,136]

theorem envBound19122 : H12AffineFastState.Bounded env19122 := by
  intro p hp
  have h : env19122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19121_19122 : H12AffineEnvironment.transform 31 137 env19121 = env19122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env19121 == env19122) = true)

theorem identity19122 : scanCanonicalize (H12AffineFastState.compose env19122 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound19122 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19123 : List Nat := [2,4,8,16,32,17,128,36,136,1024,0,1076,40,1076,0,170,1076,1,1025,1,1076,33,17,138,160,16,1,1076,1076,0,1057,137,37,136,1076,136]

theorem envBound19123 : H12AffineFastState.Bounded env19123 := by
  intro p hp
  have h : env19123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19122_19123 : H12AffineEnvironment.transform 15 170 env19122 = env19123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env19122 == env19123) = true)

theorem identity19123 : scanCanonicalize (H12AffineFastState.compose env19123 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound19123 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2