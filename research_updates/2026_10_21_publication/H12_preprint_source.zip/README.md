# H(12,4) preprint source and audit material

The preprint is H12_quartic_preprint_v1.pdf. main.tex and H12_preprint.md are its editable sources. The result concerns the complete homogeneous quartic rotation symmetric space in twelve variables, not sixteen variables or all lower-degree functions.

The sole author approved the final preprint for publication. No funding and no competing interests were declared. AI-assisted tools are disclosed in the article. This is a preprint, not journal peer review.

Download H12_formal_sources.zip, H12_independent_verification.zip and H12_final_kernel_records.zip from the same item. Their mathematical contents retain the certified hashes. A compact independent replay is different from a full clean Lean rebuild of the exact Lake distribution; the latter has not been performed during preparation and remains an explicit limitation in AppendixC.3.

The manuscript was compiled with Tectonic0.17.0 (XeTeX); compile main.tex. audits/ contains finite representation/source audits and scripts. Earlier reports identify the manuscript hash used in their check; later changes were only explanatory witness statistics and author approval. The article transcription audit in this package was rerun on the final manuscript. No new Lean proof is claimed.

For audit scripts, place the separate formal-source and independent-checker ZIPs alongside H12_preprint.md after extracting this editorial ZIP. Use Python without -O. SOURCE_PACKAGE_SHA256.json covers this editorial source package; the mathematical archive has its own SOURCE_SHA256.json.

License: CC BY4.0. Author: Filipe Martins Vono. ORCID0009-0009-4994-8533. Correspondence: contatofilipevono@gmail.com.
