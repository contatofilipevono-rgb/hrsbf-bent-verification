from pathlib import Path
import zipfile,csv,io,re,json,hashlib,ast,collections
out=Path(__file__).resolve().parent.parent
if not (out/'H12_formal_sources.zip').exists():out=Path.cwd()/'outputs/H12_revisao3'
rows=[]
with zipfile.ZipFile(out/'H12_independent_verification.zip') as z:
 for n in z.namelist():
  if re.fullmatch(r'.*/full_thread\d+\.csv',n):rows.extend(csv.DictReader(io.StringIO(z.read(n).decode())))
with zipfile.ZipFile(out/'H12_formal_sources.zip') as z:
 raw=z.read('H12PeriodFour.lean');pins=json.loads(z.read('SOURCE_SHA256.json'));assert hashlib.sha256(raw).hexdigest()==pins['H12PeriodFour.lean']
 text=raw.decode().replace('\r','');orbits=ast.literal_eval(re.search(r'def quarticOrbits : List \(List Nat\) := (\[\[.*?\]\])\ndef',text,re.S)[1])
 s=z.read('H12Affine.lean').decode().replace('\r','');offsets=ast.literal_eval(re.search(r'def offsets : List Nat := (\[[^\n]*\])',s)[1]);basis=ast.literal_eval(re.search(r'def basis : List Nat := (\[[^\n]*\])',s)[1])
truth=[sum((sum((x&m)==m for m in orb)&1)<<x for x in range(4096)) for orb in orbits]
freq=collections.Counter(int(r['witness_frequency']) for r in rows);linear={b:sum(((x&b).bit_count()&1)<<x for x in range(4096)) for b in freq}
cs=[set() for _ in range(3)]
for row in rows:
 c=int(row['original_coefficient'],16);cs[int(row['chart'])].add(c);bits=c;f=0
 while bits:
  unit=bits&-bits;f^=truth[unit.bit_length()-1];bits^=unit
 b=int(row['witness_frequency']);w=4096-2*(f^linear[b]).bit_count()
 assert w==int(row['walsh_value']) and abs(w)!=64
assert set(freq)=={0,1,3,5,9} and freq[0]==160980 and len(rows)==164288
v=(1<<24)|(1<<36)|(1<<41);assert offsets[0]^offsets[1]==v
piv={}
for b in basis+[v]:
 while b:
  j=b.bit_length()-1
  if j not in piv:piv[j]=b;break
  b^=piv[j]
assert len(piv)==37
md=(out/'H12_preprint.md').read_text();seg=md.split('## Appendix B:')[1].split('\\begin{gathered}')[1].split('\\end{gathered}')[0];masks=list(map(int,re.findall(r'\d+',seg)))
def rot(m,r,n=12):return ((m<<r)|(m>>(n-r)))&((1<<n)-1)
sy=[]
for j,m in enumerate(masks):
 st=[r for r in range(1,12) if rot(m,r)==m]
 if st:sy.append({'filter':j,'nonidentity_stabilizer_shifts':st,'orbit_size':len({rot(m,r) for r in range(12)})})
o16={rot(15,r,16) for r in range(16)};wt=sum(sum((x&m)==m for m in o16)%2 for x in range(16));assert wt==1
report={'status':'PASS_DEADLINE_SCOPED_PATTERN_AUDIT','witness_frequencies':dict(sorted(freq.items())),'all_recorded_walsh_values_recomputed_from_495_original_monomials':True,'frequency_zero_count':160980,'total':164288,'frequency_zero_percent':100*160980/164288,'two_affine_covers_differ_by_claimed_translation':True,'union_affine_dimension':len(piv),'translation_overlap_of_surviving_zero_sets':len({c^v for c in cs[0]}&cs[1]),'chart_zero_counts':list(map(len,cs)),'symmetric_support_orbit_representatives':sy,'actual_symmetric_coordinate_sets':sum(x['orbit_size'] for x in sy),'n16_k4_counterexample_weight':wt,'P6_full_magnitude_elimination_replayed':False,'P7_proved':False,'lean_changed':False}
(out/'PATTERNS_DEADLINE_AUDIT.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps(report,indent=2))
